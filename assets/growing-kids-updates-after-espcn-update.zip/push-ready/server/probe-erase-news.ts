/**
 * 去手写 · 英语灰报 4 张样例验证 + 参数扫描
 *
 * ⚠️ 指标口径修正（上一版的教训）：
 *   "去红率"若把**印刷红页眉/红边框**算进分母，会得出"排除优化让效果变差"的荒谬结论——
 *   其实那部分是我们**故意不擦**的印刷内容。必须拆成两个互斥集合分别度量：
 *     · 教师红笔（red \ furniture）→ 去红率，越高越好
 *     · 印刷红家具（furniture）    → 保留率，越高越好（被擦=误删印刷）
 *     · 低彩度深色印刷像素        → 损伤率，越低越好（直接对应"误删印刷"事故）
 *
 * 扫描档位：
 *   base  chromaMin 22 + 印刷保护闸（= 当前线上行为）
 *   o1    base + 家具排除 + 闭运算补连
 *   o2    chromaMin 16 + 家具排除 + 闭运算
 *   o3    chromaMin 14 + 家具排除 + 闭运算
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { maskFromColorThreshold, inpaint, blendWithMask, protectPrintUnderColorHandwriting } from './src/image/handwriting-mask'
import { connectedComponents, estimateCharMetrics } from './src/image/image-layout'
import { closeInk3x3 } from './src/image/wrongq-layout'
import type { HandwritingMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'

async function rawPixels(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

/** 家具判定 + 从 mask 剔除 */
function excludeFurniture(data: Buffer, w: number, h: number, medH: number) {
  const ink = new Uint8Array(w * h)
  for (let i = 0; i < w * h; i++) ink[i] = data[i] ? 1 : 0
  const { comps } = connectedComponents(ink, w, h, false)
  const edgeTol = Math.max(4, Math.round(medH * 0.8))
  const furnitureMask = new Uint8Array(w * h)
  let furnPx = 0
  const out = Buffer.from(data)
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1
    const bh = c.y1 - c.y0 + 1
    const isF =
      c.x0 <= edgeTol || c.x1 >= w - 1 - edgeTol || c.y0 <= edgeTol || c.y1 >= h - 1 - edgeTol ||
      (bw > w * 0.8 && bh < medH * 3) ||
      (bh > h * 0.8 && bw < medH * 3)
    if (!isF) continue
    furnPx += c.n
    for (let y = c.y0; y <= c.y1; y++) {
      const b = y * w
      for (let x = c.x0; x <= c.x1; x++) if (ink[b + x]) { furnitureMask[b + x] = 1; out[b + x] = 0 }
    }
  }
  return { out, furnitureMask, furnPx }
}

interface Metrics { penRemoval: number; furnitureKeep: number; printDamage: number; penPx: number; furnPx: number }

async function measure(origBuf: Buffer, outBuf: Buffer, furnitureMask: Uint8Array, w: number, h: number): Promise<Metrics> {
  const redO = await maskFromColorThreshold(origBuf, { chromaMin: 14 })
  const redN = await maskFromColorThreshold(outBuf, { chromaMin: 14 })
  let penTotal = 0, penStill = 0, furnTotal = 0, furnStill = 0
  for (let i = 0; i < w * h; i++) {
    if (!redO.data[i]) continue
    if (furnitureMask[i]) { furnTotal++; if (redN.data[i]) furnStill++ }
    else { penTotal++; if (redN.data[i]) penStill++ }
  }

  const o = await rawPixels(origBuf)
  const n2 = await rawPixels(outBuf)
  const od = o.data, nd = n2.data, ch = o.info.channels
  const lumaOf = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
  const lumas: number[] = []
  for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(od, i * ch))
  lumas.sort((a, b) => a - b)
  const paperLuma = lumas[Math.floor(lumas.length * 0.9)] ?? 240
  const darkTh = paperLuma * 0.62
  let printTotal = 0, printChanged = 0
  for (let i = 0; i < w * h; i++) {
    const p = i * ch
    const chroma = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
    const lo = lumaOf(od, p)
    if (chroma >= 14 || lo >= darkTh) continue
    printTotal++
    if (Math.abs(lumaOf(nd, p) - lo) > 30) printChanged++
  }
  return {
    penRemoval: +(1 - penStill / Math.max(1, penTotal)).toFixed(4),
    furnitureKeep: +(furnStill / Math.max(1, furnTotal)).toFixed(4),
    printDamage: +(printChanged / Math.max(1, printTotal)).toFixed(5),
    penPx: penTotal,
    furnPx: furnTotal,
  }
}

async function runMode(file: string, mode: string) {
  const buf = fs.readFileSync(file)
  const { info } = await rawPixels(buf)
  const w = info.width, h = info.height
  const m = await estimateCharMetrics(buf, {})
  const prior = w / 70
  const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, m.medH > 0 ? m.medH : prior))

  const chromaMin = mode === 'base' ? 22 : mode === 'o2' ? 16 : mode === 'o3' ? 14 : 22
  let mask: HandwritingMask = await maskFromColorThreshold(buf, { chromaMin })
  // 与线上一致：先过印刷保护闸（保护彩色手写域内的印刷黑字）
  mask = await protectPrintUnderColorHandwriting(buf, mask)

  let furnitureMask = new Uint8Array(w * h)
  if (mode !== 'base') {
    // ⚠️ 顺序不可颠倒：先排除家具再闭运算。反过来的话 1px 膨胀会把页眉横幅与
    //    正文红笔连成整页巨型域，家具判定会把真笔迹一起误杀（v6 已实测该坑）。
    const r = excludeFurniture(mask.data, w, h, medH)
    furnitureMask = r.furnitureMask
    mask = { ...mask, data: r.out }
    const ink = new Uint8Array(w * h)
    for (let i = 0; i < w * h; i++) ink[i] = mask.data[i] ? 1 : 0
    const closed = closeInk3x3(ink, w, h)
    const nb = Buffer.alloc(w * h)
    for (let i = 0; i < w * h; i++) nb[i] = closed[i] ? 255 : 0
    mask = { ...mask, data: nb }
  } else {
    // base 也需家具集合用于指标统计
    const r = excludeFurniture(mask.data, w, h, medH)
    furnitureMask = r.furnitureMask
  }

  const repaired = await inpaint(buf, 'adaptive', mask)
  const out = await blendWithMask(buf, repaired, mask)
  const outPath = path.join(IN_DIR, `erase-${mode}-${path.basename(file)}`)
  fs.writeFileSync(outPath, out)
  const mt = await measure(buf, out, furnitureMask, w, h)
  return { cov: +mask.coverage.toFixed(4), ...mt }
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const f of files) {
    const row: Record<string, unknown> = { file: f }
    for (const mode of ['base', 'o1', 'o2', 'o3']) {
      try {
        row[mode] = await runMode(path.join(IN_DIR, f), mode)
      } catch (e) {
        row[mode] = { error: String((e as Error)?.message ?? e).slice(0, 120) }
      }
    }
    console.log('GUARD ' + JSON.stringify(row))
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
