/**
 * v20.2 · R 半径重扫描（修正红检测口径后）
 * 旧表（probe-red-prior，裸彩度判红）全部作废 —— 红集合本身是错的。
 * 本探针：redMask 注入 v19 色域精修链产物，菱形 R 扫描 + 域包含度过滤，
 * 指标：黑笔覆盖（对 penSet）/ 印刷覆盖（对 printSet）/ mask 总量。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask } from './src/image/handwriting-mask'
import { maskFromRedSpatialPrior } from './src/image/red-ink-prior'
import { normalizeIlluminationForDetection } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'
async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}
const L = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 1 === p ? p : p]
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]

async function main() {
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(path.join(IN_DIR, file))
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, ch = info.channels, n = w * h
    const lumas: number[] = []
    for (let i = 0; i < n; i += 37) lumas.push(luma(od, i * ch))
    lumas.sort((a, b) => a - b)
    const darkO = (lumas[Math.floor(lumas.length * 0.9)] || 240) * 0.62

    const pre = await normalizeIlluminationForDetection(buf)
    const chromaSensitive = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
    const redProtected = await protectPrintUnderColorHandwriting(buf, chromaSensitive)
    const rawD = await raw(pre.buffer)
    const redRefined = refineColorEraseMask(redProtected, 10, {
      grow: { rgb: rawD.data, channels: rawD.info.channels, radius: 2, chromaMin: 8 },
    })

    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const near = new Uint8Array(n)
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!redO.data[y * w + x]) continue
      for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
        for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near[yy * w + xx] = 1
    }
    const penSet = new Uint8Array(n); const printSet = new Uint8Array(n)
    for (let i = 0; i < n; i++) {
      const p = i * ch
      const c = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
      if (redO.data[i] || c >= 14 || luma(od, p) >= darkO) continue
      if (near[i]) penSet[i] = 1; else printSet[i] = 1
    }
    let nPen = 0, nPrint = 0
    for (let i = 0; i < n; i++) { if (penSet[i]) nPen++; if (printSet[i]) nPrint++ }

    const row: Record<string, unknown> = { file, nPen, nPrint }
    for (const R of [8, 12, 16, 20, 24, 28, 32]) {
      const b = await maskFromRedSpatialPrior(pre.buffer, { radius: R, redMask: redRefined.data })
      let pen = 0, pr = 0
      for (let i = 0; i < n; i++) {
        if (!b.data[i]) continue
        if (penSet[i]) pen++; else if (printSet[i]) pr++
      }
      row[`R${R}`] = { pen: +(pen / Math.max(1, nPen)).toFixed(3), print: +(pr / Math.max(1, nPrint)).toFixed(4), tot: b.penPx }
    }
    console.log('GUARD ' + JSON.stringify(row))
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
