/**
 * v20.6 · 段级（笔级）判定实现验证
 * ============================================================
 * 可行性已确认（probe-seg-feasible）：菱形内 1953 个墨迹域中，
 * 仅 26% 域内距红笔距离离散度 ≤4px（无法切分），**74% 有梯度**。
 *
 * 本探针实现段级判定并测两侧指标：
 *   域级（旧）：ratio = |bbox 内落菱形的像素| / |域像素数| ≥ minRatio → 整域擦
 *   段级（新）：同样先过域级闸，**但只擦域内"距红笔 ≤ 段阈值"的像素**
 *   段阈值 segR < R：对同域内远离红笔的部分手下留情
 *
 * 若段级能同时提高印刷保持率且不降黑笔去除，则它是**唯一不被
 * "缩小半径"同一根 trade-off 夹住**的路径——因为它改的是"域内哪些像素"，
 * 而半径改的是"域是否入选"。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { inpaint, blendWithMask, maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask } from './src/image/handwriting-mask'
import { connectedComponents } from './src/image/image-layout'
import { findThreeColumns, colRowsIn } from './src/image/wrongq-layout'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

function manhattanDist(red: Uint8Array, w: number, h: number): Int32Array {
  const INF = 1 << 20
  const dist = new Int32Array(w * h).fill(INF)
  for (let i = 0; i < w * h; i++) if (red[i]) dist[i] = 0
  for (let y = 0; y < h; y++) { const b = y * w; for (let x = 0; x < w; x++) { const i = b + x; if (red[i]) continue; const l = x > 0 ? dist[i - 1] : INF; const u = y > 0 ? dist[i - w] : INF; dist[i] = Math.min(dist[i], l + 1, u + 1) } }
  for (let y = h - 1; y >= 0; y--) { const b = y * w; for (let x = w - 1; x >= 0; x--) { const i = b + x; if (red[i]) continue; const r = x < w - 1 ? dist[i + 1] : INF; const d2 = y < h - 1 ? dist[i + w] : INF; dist[i] = Math.min(dist[i], r + 1, d2 + 1) } }
  return dist
}

async function main() {
  // segR = null 表示旧行为（整域擦）；否则只擦域内距红笔 ≤ segR 的像素
  const SEGS: Array<number | null> = [null, 20, 16, 12, 10, 8]
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, ch = info.channels, n = w * h
    const prior = w / 70
    const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, 11))
    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const darkTh = (ls[Math.floor(ls.length * 0.9)] || 240) * 0.62
    const ink = new Uint8Array(n)
    for (let i = 0; i < n; i++) { const p = i * ch; if (chrom(od, p) < 14 && luma(od, p) < darkTh) ink[i] = 1 }
    const cols = findThreeColumns(ink, w, h, medH).cols
    const { comps } = connectedComponents(ink, w, h, false)

    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const near = new Uint8Array(n)
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!redO.data[y * w + x]) continue
      for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
        for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near[yy * w + xx] = 1
    }
    const penSet = new Uint8Array(n)
    let nPen = 0
    for (let i = 0; i < n; i++) { const p = i * ch; if (chrom(od, p) >= 14 || luma(od, p) >= darkTh) continue; if (near[i]) { penSet[i] = 1; nPen++ } }

    const redMask = refineColorEraseMask(await protectPrintUnderColorHandwriting(buf, redO), medH, { growRadius: 2, growChroma: 8 })
    const red = new Uint8Array(n)
    for (let i = 0; i < n; i++) if (redMask.data[i] > 127) red[i] = 1
    const dist = manhattanDist(red, w, h)

    for (const segR of SEGS) {
      const merged = Buffer.alloc(n)
      let penPx = 0
      for (const c of comps) {
        let inR = 0
        for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (dist[b + x] <= 24) inR++ }
        if (inR / c.n < 0.6) continue
        for (let y = c.y0; y <= c.y1; y++) {
          const b = y * w
          for (let x = c.x0; x <= c.x1; x++) {
            const i = b + x
            if (!ink[i]) continue
            if (dist[i] > 24) continue
            if (segR !== null && dist[i] > segR) continue     // ★段级：域内远处手下留情
            merged[i] = 255; penPx++
          }
        }
      }
      for (let i = 0; i < n; i++) if (redMask.data[i]) merged[i] = 255
      const mm = { data: merged, width: w, height: h, coverage: 0 } as any
      const rep = await inpaint(buf, 'adaptive', mm)
      const img = await blendWithMask(buf, rep, mm)
      const { data: nd } = await raw(img)

      let aC = 0, kC = 0, dmgRows = 0
      cols.forEach(([cx0, cx1]) => {
        for (const r of colRowsIn(ink, w, h, cx0, cx1)) {
          let r2 = 0
          for (let y = r.y0; y <= r.y1; y++) { const b = y * w; for (let x = cx0; x <= cx1; x++) if (red[b + x]) r2++ }
          if (r2 > 0) continue
          let a = 0, keep = 0
          for (let y = r.y0; y <= r.y1; y++) { const b = y * w; for (let x = cx0; x <= cx1; x++) { const i = b + x; if (!ink[i]) continue; a++; const p = i * ch; if (luma(nd, p) < darkTh && chrom(nd, p) < 14) keep++ } }
          if (a < 25) continue
          aC += a; kC += keep
          if (keep / a < 0.8 && a - keep > 40) dmgRows++
        }
      })
      let penGone = 0
      for (let i = 0; i < n; i++) { if (!penSet[i]) continue; const p = i * ch; if (chrom(nd, p) >= 14 || luma(nd, p) >= darkTh) penGone++ }
      console.log('GUARD ' + JSON.stringify({
        file, segR: segR === null ? '域级(旧)' : segR, penPx,
        blackRemoval: +(penGone / Math.max(1, nPen)).toFixed(4),
        keepClean: +(kC / Math.max(1, aC)).toFixed(4), lostClean: aC - kC, dmgRows,
      }))
      process.stderr.write('.')
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
