/**
 * 图形区样本采集：全页网格目检
 * ============================================================
 * ⭐ 为什么需要这一步：probe-graphic-annot 的目检推翻了原标注 ——
 *   原"图形"样本 7 个里 5 个其实是印刷文字，原"文字"样本 4 个是纯白空白。
 *   → 基于错误标注标定出的"图形 4/4、文字 0/6 误判"是**无效结论**。
 *   实际行为是**反的**：把纯文字框拒了（挡了用户真正需要的补擦），
 *   把真照片放过了（涂白）。真图形样本只剩 1 个，样本量不足，必须补。
 *
 * 本脚本输出每页缩略图 + 坐标网格，供目检圈出所有图形区（照片/插图/图表）。
 */
import sharp from 'sharp'
import * as fs from 'fs'

const IN_DIR = '/workspace/wrongq-test'
const OUT = '/workspace/v20-框选E2E/zoom'

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  const all: any[] = []

  for (const file of files) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const meta = await sharp(buf).metadata()
    const w = meta.width!, h = meta.height!
    const SCALE = 1000 / w
    const dw = Math.round(w * SCALE), dh = Math.round(h * SCALE)

    // 每 100px（原图）画一条网格线，标原图坐标
    const lines: string[] = []
    for (let x = 100; x < w; x += 100) {
      const dx = Math.round(x * SCALE)
      lines.push(`<line x1="${dx}" y1="0" x2="${dx}" y2="${dh}" stroke="#ff0000" stroke-width="0.5" opacity="0.35"/>`)
      lines.push(`<text x="${dx + 2}" y="12" font-size="9" fill="#ff0000">${x}</text>`)
    }
    for (let y = 100; y < h; y += 100) {
      const dy = Math.round(y * SCALE)
      lines.push(`<line x1="0" y1="${dy}" x2="${dw}" y2="${dy}" stroke="#ff0000" stroke-width="0.5" opacity="0.35"/>`)
      lines.push(`<text x="2" y="${dy + 10}" font-size="9" fill="#ff0000">${y}</text>`)
    }
    const out = await sharp(buf)
      .resize({ width: dw })
      .composite([{ input: Buffer.from(`<svg width="${dw}" height="${dh}">${lines.join('')}</svg>`), left: 0, top: 0 }])
      .png().toBuffer()
    const p = `${OUT}/fullpage-${file}`
    fs.writeFileSync(p, out)
    all.push({ file, w, h, gridStep: 100, preview: p })
    console.error(`[${file}] ${w}x${h} → ${p} (${dw}x${dh}, 网格100px)`)
  }
  console.log('RESULT ' + JSON.stringify(all))
}

main().catch((e) => { console.error(e); process.exit(1) })