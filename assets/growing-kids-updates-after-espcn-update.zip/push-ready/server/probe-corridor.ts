/**
 * v20.6 · 各向异性走廊 vs 各向同性菱形（核心实验 · v2 修正版）
 * ============================================================
 * v1 三处口径错误（写下来防止重犯）：
 *   ① `rx=ry=24` 的矩形走廊 ≠ 曼哈顿菱形 |dx|+|dy|≤24。矩形**严格包含**菱形、
 *      面积约 2 倍，所以 v1 的 keepClean=0.5127 只是"圈了个更大的圈"，
 *      **不是改造后的收益**，却差点被当成"走廊无效"的证据。
 *      → v2 保留 shape='diamond' 作为与生产完全一致的基线。
 *   ② 水平膨胀判据写成 `hx[x-rx]`：只能按 rx 步长跳跃（r0, r0+rx, …），
 *      中间不填。正确写法是逐像素传播（`hx[x-1]` 正扫 + `hx[x+1]` 反扫）。
 *   ③ blackRemoval 的 24px 邻域用了精修后红笔，而生产口径
 *      （probe-hybrid-verify）用 `maskFromColorThreshold` 原始红笔。
 *      分母不同 → 0.9971 与 0.661 不可比。v2 统一为生产口径。
 *
 * 取证依据（probe-dmg-crop 三联图）：
 *   page28 `learn more about Beijing`（黑印刷）整行被擦空，而同句红印刷版保留
 *   page29 `We signed the contract` 整行被擦空，只剩行首 We / 行尾 nt
 *   几何：正文行高 6~7px、行距 ~1px，菱形垂直半径 24px ≈ 上下各 4 个整行
 * 假设：垂直半径收窄、水平保持，可在几乎不损黑笔召回的前提下大幅降损伤。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { inpaint, blendWithMask, maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask } from './src/image/handwriting-mask'
import { connectedComponents } from './src/image/image-layout'
import { findThreeColumns, colRowsIn } from './src/image/wrongq-layout'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])

/** 一维可分离膨胀：双向 max-filter 扫描，O(n) */
function dilateAxis(src: Uint8Array, w: number, h: number, radius: number, horizontal: boolean): Uint8Array {
  const out = new Uint8Array(w * h)
  if (radius <= 0) { out.set(src); return out }
  const outer = horizontal ? h : w
  const inner = horizontal ? w : h
  for (let a = 0; a < outer; a++) {
    const base = horizontal ? a * w : a
    let run = -1e9
    for (let b = 0; b < inner; b++) {
      const i = horizontal ? base + b : b * w + a
      if (src[i]) run = b
      if (b - run <= radius) out[i] = 1
    }
    run = 1e9
    for (let b = inner - 1; b >= 0; b--) {
      const i = horizontal ? base + b : b * w + a
      if (src[i]) run = b
      if (run - b <= radius) out[i] = 1
    }
  }
  return out
}

function regionOf(red: Uint8Array, w: number, h: number, shape: 'diamond' | 'box', rx: number, ry: number): Uint8Array {
  if (shape === 'diamond') {
    // 与 red-ink-prior 生产实现完全一致：两趟曼哈顿距离变换（rx=ry 时）
    const INF = rx + 1
    const dist = new Int32Array(w * h).fill(INF)
    for (let y = 0; y < h; y++) {
      const b = y * w
      for (let x = 0; x < w; x++) {
        if (red[b + x]) { dist[b + x] = 0; continue }
        const l = x > 0 ? dist[b + x - 1] : INF
        const u = y > 0 ? dist[(y - 1) * w + x] : INF
        dist[b + x] = Math.min(INF, l + 1, u + 1)
      }
    }
    for (let y = h - 1; y >= 0; y--) {
      const b = y * w
      for (let x = w - 1; x >= 0; x--) {
        if (red[b + x]) continue
        const r = x < w - 1 ? dist[b + x + 1] : INF
        const d = y < h - 1 ? dist[(y + 1) * w + x] : INF
        dist[b + x] = Math.min(dist[b + x], r + 1, d + 1)
      }
    }
    const out = new Uint8Array(w * h)
    for (let i = 0; i < w * h; i++) if (dist[i] <= rx) out[i] = 1
    return out
  }
  return dilateAxis(dilateAxis(red, w, h, rx, true), w, h, ry, false)
}

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  const COMBOS: Array<['diamond' | 'box', number, number]> = [
    ['diamond', 24, 24],   // ★生产基线，必须与 probe-hybrid-verify 对齐
    ['box', 24, 12], ['box', 24, 8], ['box', 24, 6],
    ['box', 32, 8], ['box', 40, 8], ['box', 40, 6], ['box', 56, 6],
  ]
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, ch = info.channels, n = w * h
    const prior = w / 70
    const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, 11))

    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const darkTh = (ls[Math.floor(ls.length * 0.9)] || 240) * 0.62
    const ink = new Uint8Array(n)
    for (let i = 0; i < n; i++) { const p = i * ch; if (chrom(od, p) < 14 && luma(od, p) < darkTh) ink[i] = 1 }
    const cols = findThreeColumns(ink, w, h, medH).cols
    const { comps } = connectedComponents(ink, w, h, false)

    // ★ GT：blackRemoval 的 24px 邻域必须用**原始**色域红笔（生产口径）
    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const near = new Uint8Array(n)
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!redO.data[y * w + x]) continue
      for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
        for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near[yy * w + xx] = 1
    }
    const penSet = new Uint8Array(n)
    let nPen = 0
    for (let i = 0; i < n; i++) {
      const p = i * ch
      if (chrom(od, p) >= 14 || luma(od, p) >= darkTh) continue
      if (near[i]) { penSet[i] = 1; nPen++ }
    }

    const redMask = refineColorEraseMask(await protectPrintUnderColorHandwriting(buf, redO), medH, { growRadius: 2, growChroma: 8 })
    const red = new Uint8Array(n)
    for (let i = 0; i < n; i++) if (redMask.data[i] > 127) red[i] = 1

    for (const [shape, rx, ry] of COMBOS) {
      const region = regionOf(red, w, h, shape, rx, ry)
      const merged = Buffer.alloc(n)
      let penPx = 0
      for (const c of comps) {
        let inR = 0
        for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (region[b + x]) inR++ }
        if (inR / c.n < 0.6) continue
        for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x] && region[b + x]) { merged[b + x] = 255; penPx++ } }
      }
      for (let i = 0; i < n; i++) if (redMask.data[i]) merged[i] = 255
      const mm = { data: merged, width: w, height: h, coverage: 0 } as any
      const rep = await inpaint(buf, 'adaptive', mm)
      const img = await blendWithMask(buf, rep, mm)
      const { data: nd } = await raw(img)

      let aC = 0, kC = 0, dmgRows = 0
      cols.forEach(([cx0, cx1]) => {
        for (const r of colRowsIn(ink, w, h, cx0, cx1)) {
          let r2 = 0
          for (let y = r.y0; y <= r.y1; y++) { const b = y * w; for (let x = cx0; x <= cx1; x++) if (red[b + x]) r2++ }
          if (r2 > 0) continue
          let a = 0, keep = 0
          for (let y = r.y0; y <= r.y1; y++) { const b = y * w; for (let x = cx0; x <= cx1; x++) { const i = b + x; if (!ink[i]) continue; a++; const p = i * ch; if (luma(nd, p) < darkTh && chrom(nd, p) < 14) keep++ } }
          if (a < 25) continue
          aC += a; kC += keep
          if (keep / a < 0.8 && a - keep > 40) dmgRows++
        }
      })
      let penGone = 0
      for (let i = 0; i < n; i++) {
        if (!penSet[i]) continue
        const p = i * ch
        if (chrom(nd, p) >= 14 || luma(nd, p) >= darkTh) penGone++
      }
      console.log('GUARD ' + JSON.stringify({
        file, shape, rx, ry, penPx,
        keepClean: +(kC / Math.max(1, aC)).toFixed(4), lostClean: aC - kC, dmgRows,
        blackRemoval: +(penGone / Math.max(1, nPen)).toFixed(4),
      }))
      process.stderr.write('.')
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
