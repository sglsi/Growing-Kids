/**
 * 「黑笔为什么擦不掉」诊断探针 · 第二轮（取完整 debug + 检验前提）
 * ============================================================
 * 第一轮探针的教训：empty() 路径不返回 rowsDetail，我误读成"行分割切出 0 行"。
 * 本轮直接打印 maskFromDarkInk / maskFromLayoutSlots 的 debug 全字段。
 *
 * 本轮要回答的三个问题：
 *   Q1 深色通道到底在报纸上切出多少行？glyphH / rowLimit / rowTall 是多少？
 *      拦截发生在哪一闸（short / baseline / density）？
 *   Q2 报纸真实行数是多少？（用三栏约束分割做参照 —— 错题提取侧已验证可用）
 *   Q3 ★ 关键前提检验：黑笔字高 vs 印刷字高。
 *      深色通道的核心判据 rowRatio=1.15 建立在「手写比印刷大」上。
 *      若黑笔候选连通域的 bbox 高度中位数 < 印刷，该前提在这批样本上直接反了。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import {
  maskFromColorThreshold,
  maskFromDarkInk,
  maskFromLayoutSlots,
  normalizeIlluminationForDetection,
} from './src/image/handwriting-mask'
import { buildLayoutContext } from './src/image/wrongq-layout'
import { connectedComponents } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

function lumaOf(d: Buffer, p: number) {
  return 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
}

function median(xs: number[]) {
  if (!xs.length) return -1
  const a = [...xs].sort((p, q) => p - q)
  return a[Math.floor(a.length / 2)]
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const file of files) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const meta = await sharp(buf).metadata()
      const w = meta.width ?? 0, h = meta.height ?? 0

      const pre = await normalizeIlluminationForDetection(buf)
      const detectBuf = pre.buffer
      const darkMask = await maskFromDarkInk(detectBuf)
      const layoutMask = await maskFromLayoutSlots(detectBuf)
      const dd = (darkMask.debug ?? {}) as Record<string, unknown>
      const ld = (layoutMask.debug ?? {}) as Record<string, unknown>

      // ── Q2 参照：三栏约束分割给出的真实行数（错题提取侧同源实现）──────
      let refRows = 0
      let refCols = 0
      try {
        const ctx = await buildLayoutContext(buf)
        refRows = ctx.colRows.reduce((s, r) => s + r.length, 0)
        refCols = ctx.cols.length
      } catch {
        /* 参照失败不影响主结论 */
      }

      // ── Q3 黑笔 vs 印刷 连通域尺度 ──────────────────────────────
      const o = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
      const od = o.data
      const ch = o.info.channels
      const redThin = await maskFromColorThreshold(detectBuf, { chromaMin: 14 })
      const near = new Uint8Array(w * h)
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          if (!redThin.data[y * w + x]) continue
          for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
            for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near[yy * w + xx] = 1
        }
      }
      const lumas: number[] = []
      for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(od, i * ch))
      lumas.sort((a, b) => a - b)
      const darkTh = (lumas[Math.floor(lumas.length * 0.9)] ?? 240) * 0.62

      const penInk = new Uint8Array(w * h)   // 黑笔候选（红笔邻域内的低彩度暗像素）
      const allInk = new Uint8Array(w * h)   // 全页低彩度暗像素（含印刷）
      for (let i = 0; i < w * h; i++) {
        const p = i * ch
        const c = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
        const lo = lumaOf(od, p)
        if (c >= 14 || lo >= darkTh) continue
        allInk[i] = 1
        if (near[i]) penInk[i] = 1
      }
      const stat = (ink: Uint8Array) => {
        const { comps } = connectedComponents(ink, w, h, false)
        const hs = comps.map((c) => c.y1 - c.y0 + 1).filter((v) => v >= 2)
        const ws = comps.map((c) => c.x1 - c.x0 + 1).filter((v) => v >= 2)
        let px = 0
        for (let i = 0; i < ink.length; i++) if (ink[i]) px++
        return { n: comps.length, medH: median(hs), medW: median(ws), px }
      }
      const penS = stat(penInk)
      const allS = stat(allInk)

      console.log('GUARD ' + JSON.stringify({
        file,
        size: `${w}x${h}`,
        darkDebug: dd,
        layoutDebug: ld,
        layoutCoverage: +layoutMask.coverage.toFixed(4),
        refThreeColRows: refRows,
        refColCount: refCols,
        penInkStats: penS,
        allInkStats: allS,
      }))
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 250))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
