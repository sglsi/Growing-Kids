/**
 * v20.5 · 墨迹暗阈值扫描：inkDarkRatio 0.62 / 0.66 / 0.70 / 0.74
 * 端到端指标（含 inpaint/blend），判断"放宽是否几乎免费"。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask, normalizeIlluminationForDetection, inpaint, blendWithMask } from './src/image/handwriting-mask'
import { maskFromRedSpatialPrior } from './src/image/red-ink-prior'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p+1], d[p+2]) - Math.min(d[p], d[p+1], d[p+2])

async function main() {
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height, ch = info.channels, n = w * h
    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const darkTh = (ls[Math.floor(ls.length * 0.9)] || 240) * 0.62

    const pre = await normalizeIlluminationForDetection(buf)
    const cs = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
    const rp = await protectPrintUnderColorHandwriting(buf, cs)
    const rw = await sharp(pre.buffer).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const red = refineColorEraseMask(rp, 10, { grow: { rgb: rw.data, channels: rw.info.channels, radius: 2, chromaMin: 8 } })

    // 真值集合：penSet（近红 24 方形）/ printSet（远离红）
    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const near = new Uint8Array(n)
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!redO.data[y*w+x]) continue
      for (let yy = Math.max(0,y-24); yy <= Math.min(h-1,y+24); yy++)
        for (let xx = Math.max(0,x-24); xx <= Math.min(w-1,x+24); xx++) near[yy*w+xx] = 1
    }
    const penSet = new Uint8Array(n), printSet = new Uint8Array(n)
    for (let i = 0; i < n; i++) {
      const p = i*ch
      if (redO.data[i] || chrom(od,p) >= 14 || luma(od,p) >= darkTh) continue
      if (near[i]) penSet[i]=1; else printSet[i]=1
    }
    let nPen=0, nPrint=0
    for (let i=0;i<n;i++){ if(penSet[i])nPen++; if(printSet[i])nPrint++ }

    const row: Record<string, unknown> = { file }
    for (const ratio of [0.62, 0.66, 0.70, 0.74]) {
      const black = await maskFromRedSpatialPrior(buf, { radius: 24, redMask: red.data, inkDarkRatio: ratio })
      const merged = Buffer.alloc(n)
      for (let i = 0; i < n; i++) if (red.data[i] || black.data[i]) merged[i] = 255
      const mask = { width: w, height: h, data: merged, coverage: 0, source: 'threshold' as const, seed: merged }
      const rep = await inpaint(buf, 'adaptive', mask)
      const img = await blendWithMask(buf, rep, mask)
      const nd = (await sharp(img).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })).data
      let penGone=0, printGone=0
      for (let i=0;i<n;i++){
        const p=i*ch
        const c0=chrom(od,p), l0=luma(od,p), c1=chrom(nd,p), l1=luma(nd,p)
        if (penSet[i] && c0<14 && l0<darkTh && (c1>=14||l1>=darkTh)) penGone++
        if (printSet[i] && c0<14 && l0<darkTh && (c1>=14||l1>=darkTh)) printGone++
      }
      row[`k${ratio}`] = [+(penGone/Math.max(1,nPen)).toFixed(3), +(printGone/Math.max(1,nPrint)).toFixed(5)]
    }
    console.log('GUARD ' + JSON.stringify(row))
  }
}
main().catch((e)=>{console.error('FAILED',e);process.exit(1)})
