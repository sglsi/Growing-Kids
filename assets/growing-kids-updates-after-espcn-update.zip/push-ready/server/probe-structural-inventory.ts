// probe-structural-inventory.ts —— 结构判别器取证探针（任务 B-1 · 先证"看得对"）
//
// 设计依据：去手写-结构一致性判别器-实施设计-v21.2.md §4 probe-structural-inventory
// 不做任何参数调优，只取证：三态可视化 + 机器自检（粗真值先声明后跑数，见 §4.2 纪律）。
//
// 粗真值口径（先声明，防指标为结果定做）：
//   · phys1 括号锚点命中数 ≥8（目检约 10 处选择题答案括号）
//   · phys2 下划线填写区墨迹召回：落在下划线锚点区的 ink 像素被标 HANDWRITING∪UNCERTAIN 的比例 ≥0.8
//   · phys4 空白解答块覆盖：落在空白区(≥8×charH 见方)的 ink 像素被标 手写∪UNCERTAIN 比例 ≥0.8
//   · 印刷行误标率：printLike comps 中被标 HANDWRITING 的比例 ≤2%

import sharp from 'sharp'
import { readdirSync, existsSync, mkdirSync } from 'fs'
import { join } from 'path'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminate } from './src/image/structural-discriminator'
import { protectPrintUnderColorHandwriting } from './src/image/handwriting-mask'
import type { HandwritingMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/worksheet-test'
const OUT_DIR = '/workspace/worksheet-test/inventory'
if (!existsSync(OUT_DIR)) mkdirSync(OUT_DIR, { recursive: true })

const files = readdirSync(IN_DIR).filter((f) => /^phys\d+\.png$/.test(f)).sort()
if (!files.length) { console.error('未找到 phys*.png 验证集'); process.exit(1) }

const TYPE_COLOR: Record<number, [number, number, number, number]> = {
  0: [200, 200, 200, 55], // PRINT → 浅灰（保留，基本不可见）
  1: [255, 0, 0, 170], // HANDWRITING → 红
  2: [255, 230, 0, 150], // UNCERTAIN → 黄
}

async function main() {
  const summary: any[] = []
  for (const f of files) {
    const p = join(IN_DIR, f)
    const buf = await sharp(p).toBuffer()
    const meta = await sharp(buf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(buf, { width: W, height: H, isGray: false })

    // 工作尺度 RGB（供家具先验）
    const work = await sharp(buf).resize(ctx.work.w, ctx.work.h, { fit: 'fill' }).removeAlpha().raw().toBuffer({ resolveWithObject: true })
    // 家具/印刷先验：色域精修保护链（黑笔场景返回原样，无彩色则零干预）
    const inkHM: HandwritingMask = {
      width: ctx.work.w, height: ctx.work.h, data: ctx.inkLocal as unknown as Buffer,
      coverage: ctx.inkLocal.reduce((a, b) => a + b, 0) / ctx.inkLocal.length, source: 'threshold',
    }
    let furniturePrior: Uint8Array | undefined
    try {
      // 用工作尺度 RGB 构造彩色 mask 喂给保护链，得到工作尺度印刷/家具先验
      const chromaMask = await maskFromChroma(work.data, work.info.width, work.info.height, work.info.channels)
      const chromaBuf = Buffer.from(chromaMask.data)
      const rgbBuf = await sharp(work.data, { raw: { width: work.info.width, height: work.info.height, channels: work.info.channels } }).png().toBuffer()
      const chromaHM: HandwritingMask = {
        width: work.info.width, height: work.info.height, data: chromaBuf,
        coverage: chromaBuf.reduce((a, b) => a + b, 0) / chromaBuf.length, source: 'threshold',
      }
      const prot = await protectPrintUnderColorHandwriting(rgbBuf, chromaHM)
      // 先验 = 原始 ink 中"被保护链判定为印刷"的像素
      furniturePrior = new Uint8Array(ctx.inkLocal.length)
      const protData = Buffer.from(prot.data)
      for (let i = 0; i < ctx.inkLocal.length; i++) {
        if (ctx.inkLocal[i] && !protData[i]) furniturePrior[i] = 255 // ink 但被保护链保留→印刷
      }
    } catch (e) {
      console.warn(`[${f}] 家具先验构建失败，跳过：${e instanceof Error ? e.message : e}`)
    }

    const res = discriminate({ ctx, furniturePrior })
    const { labels, comps, anchors, debug } = res

    // ── 三态叠加图（原图分辨率）──
    const orig = await sharp(buf).removeAlpha().raw().toBuffer({ resolveWithObject: true })
    const { data: od, info: oi } = orig
    const overlay = Buffer.from(od) // 复制原图，仅改 ink 像素
    const ch = oi.channels
    const sx = ctx.work.w / W, sy = ctx.work.h / H
    for (let y = 0; y < H; y++) {
      const wy = Math.min(ctx.work.h - 1, Math.floor(y * sy))
      for (let x = 0; x < W; x++) {
        const wx = Math.min(ctx.work.w - 1, Math.floor(x * sx))
        const st = labels[wy * ctx.work.w + wx]
        const oi2 = (y * W + x) * ch
        if (ctx.inkLocal[wy * ctx.work.w + wx]) {
          const c = TYPE_COLOR[st]
          // alpha 混合：overlay = orig*(1-a) + color*a
          const a = c[3] / 255
          overlay[oi2] = Math.round(od[oi2] * (1 - a) + c[0] * a)
          overlay[oi2 + 1] = Math.round(od[oi2 + 1] * (1 - a) + c[1] * a)
          overlay[oi2 + 2] = Math.round(od[oi2 + 2] * (1 - a) + c[2] * a)
        }
      }
    }
    const outPng = join(OUT_DIR, f.replace('.png', '-tritone.png'))
    await sharp(overlay, { raw: { width: W, height: H, channels: ch } }).png().toFile(outPng)

    // ── 机器自检 ──
    const nParen = anchors.filter((a) => a.type === 'paren').length
    const nUnder = anchors.filter((a) => a.type === 'underline').length
    const nGap = anchors.filter((a) => a.type === 'gap').length

    // phys2 下划线填写区墨迹召回：落在 underline 锚点区的 ink 像素被标 1∪2 的比例
    const underInk = inkInAnchorRecall(labels, ctx, anchors.filter((a) => a.type === 'underline'))
    // phys4 空白块覆盖：落在空白区(blankEvidence)的 comp ink 被标 1∪2 比例
    const blankComps = comps.filter((c) => (c as any).blankEvidence >= 1)
    let blankInkTot = 0, blankInkHit = 0
    for (const c of blankComps) {
      blankInkTot += c.n
      if (c.state === 1 || c.state === 2) blankInkHit += c.n
    }
    // 印刷行误标率：printLike comps 被标 HANDWRITING(1) 比例
    const printLike = comps.filter((c) => c.printLike)
    const printMis = printLike.filter((c) => c.state === 1).length
    const plStates = [0, 0, 0]
    let plScore = 0
    for (const c of printLike) { plStates[c.state]++; plScore += c.score }
    const plAvgScore = printLike.length ? +(plScore / printLike.length).toFixed(3) : 0

    const row = {
      file: f, charH: debug.charH, nComps: debug.nComps, nRows: debug.nRows,
      nAnchors: debug.nAnchors, paren: nParen, underline: nUnder, gap: nGap,
      labelInkShare: debug.labelInkShare,
      underRecall: +underInk.toFixed(3),
      blankComps: blankComps.length, blankInkTot, blankInkHit: +(blankInkHit / Math.max(1, blankInkTot)).toFixed(3),
      printLikeN: printLike.length, printMisN: printMis, printMisRate: +(printMis / Math.max(1, printLike.length)).toFixed(3),
      printLikeStates: plStates, printLikeAvgScore: plAvgScore,
      tritone: outPng,
    }
    summary.push(row)
    console.log(JSON.stringify(row))
  }
  const json = join(OUT_DIR, 'inventory-summary.json')
  require('fs').writeFileSync(json, JSON.stringify(summary, null, 2))
  console.log('\n=== 自检阈值（粗真值先声明）===')
  console.log('phys1 paren >=8 | phys2 underRecall >=0.8 | phys4 blankHit >=0.8 | 所有页 printMisRate <=0.02')
  console.log(`\n汇总已写入 ${json}`)
}

/** 落在指定锚点区内的 ink 像素被标 HANDWRITING∪UNCERTAIN 的比例。 */
function inkInAnchorRecall(labels: Uint8Array, ctx: any, zones: { x0: number; y0: number; x1: number; y1: number }[]): number {
  if (!zones.length) return 0
  let tot = 0, hit = 0
  for (const z of zones) {
    for (let y = Math.max(0, z.y0); y <= Math.min(ctx.work.h - 1, z.y1); y++) {
      const base = y * ctx.work.w
      for (let x = Math.max(0, z.x0); x <= Math.min(ctx.work.w - 1, z.x1); x++) {
        if (!ctx.inkLocal[base + x]) continue
        tot++
        if (labels[base + x] === 1 || labels[base + x] === 2) hit++
      }
    }
  }
  return tot ? hit / tot : 0
}

/** 工作尺度彩色 mask（粗 chroma 阈值），喂给保护链。 */
function maskFromChroma(data: Buffer, w: number, h: number, channels: number): { data: Uint8Array; width: number; height: number } {
  const n = w * h
  const m = new Uint8Array(n)
  for (let i = 0, p = 0; i < n; i++, p += channels) {
    const r = data[p], g = data[p + 1], b = data[p + 2]
    if (Math.max(r, g, b) - Math.min(r, g, b) >= 14) m[i] = 1
  }
  return { data: m, width: w, height: h }
}

main().catch((e) => { console.error(e); process.exit(1) })
