/**
 * 任务完成度检测机制（task-guard）
 * ============================================================
 * 作用：判定「去手写功能」当前任务是否全部完成，供 10 分钟周期自检调用。
 *
 * 设计铁律（源自历史「出错停止」事故复盘）：
 *  1. **永不崩溃**：每个检查项独立 try/catch；任何异常只把该项记为未完成，
 *     绝不让整体进程异常退出——这是过去 7 次任务中止的根因防线。
 *  2. **超时即未完成**：子命令超时不抛出，按缺数据记为 incomplete。
 *  3. **绝不读取图像本体**：历史事故多由读取大图导致响应截断，
 *     本脚本只做**文本/命令行/结构化 JSON** 校验。
 *  4. 结果双写：人类可读打印 + 机器可读 JSON（供循环脚本解析）。
 *
 * 用法：npx tsx task-guard.ts        → 打印清单，全部通过时 exit 0
 */
import { execSync } from 'node:child_process'
import { existsSync, readFileSync, statSync, writeFileSync } from 'node:fs'

const SERVER = '/workspace/push-ready/server'
const DOC = '/workspace/去手写功能-方法论与技术方案.md'
const EDITOR = '/workspace/push-ready/src/components/image-editor.tsx'
const RESULT_JSON = '/workspace/task-guard-result.json'

/** 安全执行：超时/异常都返回 {ok:false, out:''}，绝不抛出 */
function safeExec(cmd: string, timeoutMs = 180_000): { ok: boolean; out: string } {
  try {
    const out = execSync(cmd, {
      cwd: SERVER,
      timeout: timeoutMs,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      maxBuffer: 64 * 1024 * 1024,
    })
    return { ok: true, out: String(out ?? '') }
  } catch (e: unknown) {
    const err = e as { stdout?: string | Buffer; stderr?: string | Buffer; message?: string }
    const merged = `${err.stdout ?? ''}${err.stderr ?? ''}`
    return { ok: false, out: merged || String(err.message ?? 'exec failed') }
  }
}

function readFileOr(path: string, fallback = ''): string {
  try {
    return existsSync(path) ? readFileSync(path, 'utf8') : fallback
  } catch {
    return fallback
  }
}

interface CheckResult {
  id: string
  name: string
  ok: boolean
  detail: string
}

type CheckFn = () => CheckResult

/** 每个检查项都套一层兜底，保证单项异常不污染整体 */
function guard(id: string, name: string, fn: CheckFn): CheckResult {
  try {
    const r = fn()
    return { id, name, ok: r.ok, detail: r.detail }
  } catch (e: unknown) {
    return { id, name, ok: false, detail: `检查异常（已隔离）: ${String((e as Error)?.message ?? e)}` }
  }
}

/** 文本需同时包含全部关键词 */
function containsAll(text: string, keys: string[]): { ok: boolean; missing: string[] } {
  const missing = keys.filter((k) => !text.includes(k))
  return { ok: missing.length === 0, missing }
}

const CHECKS: Array<{ id: string; name: string; fn: CheckFn }> = [
  {
    // C1 方法论文档：本轮「有作用的最新思想」是否已固化（含 v17 根因）
    id: 'doc_latest_ideas',
    name: '方法论文档已补入最新思想（v15 一致性得分 / v16 分块阈值 / v17 底色步长错位）',
    fn: () =>
      guard('doc_latest_ideas', 'C1 文档·最新思想', () => {
        if (!existsSync(DOC)) return { id: 'doc_latest_ideas', name: 'doc', ok: false, detail: `文档不存在: ${DOC}` }
        const t = readFileOr(DOC)
        const r = containsAll(t, ['印刷一致性得分', '分块自适应阈值', '5.11'])
        return {
          id: 'doc_latest_ideas',
          name: 'doc',
          ok: r.ok,
          detail: r.ok
            ? `v15/v16/v17 均已落文档（${(statSync(DOC).size / 1024).toFixed(0)}KB）`
            : `文档缺少关键词: ${r.missing.join(' / ')}`,
        }
      }),
  },
  {
    // C2 文档需写明剩余功能的规划与验收标准（否则「完成」无从判定）
    id: 'doc_plan',
    name: '方法论文档已写明剩余功能规划与验收标准',
    fn: () =>
      guard('doc_plan', 'C2 文档·剩余规划', () => {
        const t = readFileOr(DOC)
        const r = containsAll(t, ['剩余功能', '验收', 'manual_regions'])
        return {
          id: 'doc_plan',
          name: 'plan',
          ok: r.ok,
          detail: r.ok ? '剩余功能规划 + 验收标准 + manual_regions 契约已落文档' : `缺少: ${r.missing.join(' / ')}`,
        }
      }),
  },
  {
    // C3 核心兜底功能：结果页框选补擦（手工圈选 → manual_regions 局部重擦）
    id: 'ui_box_erase',
    name: '结果页支持框选补擦（manual_regions 重擦已接线）',
    fn: () =>
      guard('ui_box_erase', 'C3 前端·框选补擦', () => {
        if (!existsSync(EDITOR)) return { id: 'ui_box_erase', name: 'ui-box', ok: false, detail: 'image-editor.tsx 不存在' }
        const t = readFileOr(EDITOR)
        const r = containsAll(t, ['manual_regions', 'applyEraseRegions', 'eraseTouchLayer'])
        return {
          id: 'ui_box_erase',
          name: 'ui-box',
          ok: r.ok,
          detail: r.ok ? '框选补擦已接线（触摸层 + 应用 + 提交键与后端 DTO 一致）' : `前端缺少: ${r.missing.join(' / ')}`,
        }
      }),
  },
  {
    // C4 P3 对标夸克：对比滑杆 + 撤销
    id: 'ui_compare_undo',
    name: '结果页支持原图/结果对比与撤销（P3 体验项）',
    fn: () =>
      guard('ui_compare_undo', 'C4 前端·对比撤销', () => {
        const t = readFileOr(EDITOR)
        const r = containsAll(t, ['compareRatio', '撤销', 'undoErase', 'Slider'])
        return {
          id: 'ui_compare_undo',
          name: 'ui-cmp',
          ok: r.ok,
          detail: r.ok ? '对比滑杆 + 撤销 + 步骤栈已落地' : `前端缺少: ${r.missing.join(' / ')}`,
        }
      }),
  },
  {
    // C5 前端无 tsconfig/无法编译，故用 parser 级语法校验兜住改动质量
    id: 'ui_syntax',
    name: '改造过的前端文件语法合法（TSX parser 校验）',
    fn: () =>
      guard('ui_syntax', 'C5 前端·语法校验', () => {
        const { ok, out } = safeExec('npx tsx tsx-syntax-check.ts', 120_000)
        return {
          id: 'ui_syntax',
          name: 'ui-syntax',
          ok: ok && (out.match(/\[✓\]/g) ?? []).length >= 2 && !out.includes('[✗]'),
          detail: ok ? '前端改动文件语法全部通过' : `语法校验失败/超时: ${out.slice(-200)}`,
        }
      }),
  },
  {
    // C6 检测质量回归（6 题 GT）：不允许出现 ❌
    id: 'gt_regression',
    name: 'GT 回归评测无退化（印刷零误检、手写区不丢失）',
    fn: () =>
      guard('gt_regression', 'C6 回归·GT 真卷', () => {
        const { ok, out } = safeExec('npx tsx eval-gt.ts', 180_000)
        if (!ok) return { id: 'gt_regression', name: 'gt', ok: false, detail: '回归执行失败/超时（已隔离）' }
        const lines = out.split('\n').filter((l) => l.includes('[') && (l.includes('✅') || l.includes('❌')))
        // 硬性底线：**印刷/保护区必须零误检**（一条都不允许）；手写区允许剩下的漏检，
        // 但必须是「已明确登记且与 by-design 边界」的项（当前为 7题：细笔画+括号碎裂+与印刷同高）。
        const protect = lines.filter((l) => l.includes('应≈0'))
        const detect = lines.filter((l) => l.includes('应检出'))
        const protectFail = protect.filter((l) => l.includes('❌')).length
        const detectPass = detect.filter((l) => l.includes('✅')).length
        const detectFail = detect.filter((l) => l.includes('❌')).map((l) => l.split(' ')[0])
        // ⭐ 不写死"必须全部检出"，而是维护一张**显式登记的老边界清单**：
        //   只有清单内的项允许缺失；任何**新出现**的漏检都会立刻让自检失败。
        //   （避免既得成果被悄悄腐蚀，又不必为一个已达理论上限的 case 让自检永久空转）
        const KNOWN_MISSES = new Set([
          '7题-括号答案(应检出)', // 细笔画 + 括号碎裂 + 与印刷同高 → 厚度判据上天然重合，已录 §5.10.1
        ])
        const unexpected = detectFail.filter((n) => !KNOWN_MISSES.has(n))
        return {
          id: 'gt_regression',
          name: 'gt',
          ok: protectFail === 0 && protect.length >= 1 && detectPass >= 4 && unexpected.length === 0,
          detail:
            `印刷零误检 ${protect.length - protectFail}/${protect.length}（硬底线）；` +
            `手写区检出 ${detectPass}/${detect.length}` +
            (detectFail.length
              ? `；未检出 ${detectFail.length} 项: ${detectFail.join('、')}` +
                (unexpected.length ? ` ⚠️ 其中 ${unexpected.join('、')} 未登记，属回归！` : '（已在登记边界内，由框选补擦兜底）')
              : ''),
        }
      }),
  },
  {
    // C7 v16 成果守住：重阴影卷手写要检出、印刷/图形不许被 dark 当墨
    id: 'shadow_regression',
    name: '重阴影卷：浅手写已检出且印刷/图形零误报（v16 成果）',
    fn: () =>
      guard('shadow_regression', 'C7 回归·重阴影卷', () => {
        const { ok, out } = safeExec('npx tsx quant-shadow-residual.ts', 240_000)
        if (!ok) return { id: 'shadow_regression', name: 'shadow', ok: false, detail: '重阴影量化执行失败/超时（已隔离）' }
        const m = out.match(/GUARD (\{.*\})/)
        if (!m) return { id: 'shadow_regression', name: 'shadow', ok: false, detail: '未拿到量化汇总输出' }
        let j: Record<string, number>
        try {
          j = JSON.parse(m[1]) as Record<string, number>
        } catch {
          return { id: 'shadow_regression', name: 'shadow', ok: false, detail: '汇总 JSON 解析失败' }
        }
        const bad = []
        if (!(j.bottomDark > 0)) bad.push('底部浅手写漏检')
        if (j.printDarkA !== 0 || j.printDarkB !== 0) bad.push('印刷带被误判为墨')
        if (j.graphicDark !== 0) bad.push('图形带被误判为墨')
        return {
          id: 'shadow_regression',
          name: 'shadow',
          ok: bad.length === 0,
          detail:
            bad.length === 0
              ? `手写出 ${j.bottomDark}px、印刷/图形误报 0、掩膜内残留 ${j.bottomResidualPct}%`
              : bad.join('；'),
        }
      }),
  },
  {
    // C8 v17 成果守住：大块 mask 内的局部底色必须是干净纸面（防「识别出来却擦不干净」复发）
    id: 'bgmap_v17',
    name: '大块 mask 内局部底色干净（v17 防复发锚点）',
    fn: () =>
      guard('bgmap_v17', 'C8 回归·v17 底色图', () => {
        const { ok, out } = safeExec('npx tsx probe-bgmap.ts', 240_000)
        if (!ok) return { id: 'bgmap_v17', name: 'bg', ok: false, detail: '底色图探针执行失败/超时（已隔离）' }
        const m = out.match(/GUARD (\{.*\})/)
        if (!m) return { id: 'bgmap_v17', name: 'bg', ok: false, detail: '未拿到底色图汇总' }
        let j: Record<string, number>
        try {
          j = JSON.parse(m[1]) as Record<string, number>
        } catch {
          return { id: 'bgmap_v17', name: 'bg', ok: false, detail: '汇总 JSON 解析失败' }
        }
        // 修复前 baseline = 31365，修复后 9516；阈值取 15000 留出波动空间
        const d = j.boxDarkInLocalBg
        return {
          id: 'bgmap_v17',
          name: 'bg',
          ok: d >= 0 && d < 15000,
          detail: `框内底色暗像素 ${d}（修复前 baseline 31365，阈值 <15000）`,
        }
      }),
  },
  {
    // C9 交付物：本轮去手写增量包已产出
    id: 'package_zip',
    name: '去手写增量更新包已产出到 /workspace',
    fn: () =>
      guard('package_zip', 'C9 交付·更新包', () => {
        try {
          const list = execSync('ls -t /workspace/*.zip 2>/dev/null', { encoding: 'utf8' })
            .split('\n')
            .filter(Boolean)
          // 要求明确的去手写增量包命名，避免把历史 zip 误判成本轮产物
          const hit = list.find((p) => /去手写-[a-z0-9-]+-update/.test(p))
          if (!hit) return { id: 'package_zip', name: 'zip', ok: false, detail: '未找到本轮去手写更新包（命名须含「去手写-…-update」）' }
          return {
            id: 'package_zip',
            name: 'zip',
            ok: true,
            detail: `${hit.split('/').pop()}（${(statSync(hit).size / 1024).toFixed(0)}KB）`,
          }
        } catch (e: unknown) {
          return { id: 'package_zip', name: 'zip', ok: false, detail: `列目录失败: ${String((e as Error)?.message ?? e)}` }
        }
      }),
  },
]

function main(): void {
  const results = CHECKS.map((c) => c.fn())
  const passed = results.filter((r) => r.ok).length
  const allDone = passed === results.length
  const payload = {
    finished_at: new Date().toISOString(),
    total: results.length,
    passed,
    all_complete: allDone,
    items: results,
  }
  try {
    writeFileSync(RESULT_JSON, JSON.stringify(payload, null, 2))
  } catch {
    /* 写文件失败不影响判定 */
  }
  console.log('\n=== 任务完成度检测 ===')
  console.log(`时间 ${payload.finished_at}  完成 ${passed}/${results.length}  ${allDone ? '🎉 全部完成' : '⏳ 未完成'}`)
  for (const r of results) console.log(`  ${r.ok ? '[✓]' : '[ ]'} ${r.name} — ${r.detail}`)
  process.exit(allDone ? 0 : 1)
}

main()
