/**
 * 探针完整性检查（v20.6 新增守卫）
 * ============================================================
 * 事故背景：v20.6 诊断过程中新建了 `probe-rscan-black.ts`，
 * 它 `import { evalGt } from './eval-gt'`，而 eval-gt.ts 是个**直接跑 main()
 * 的独立脚本、没有任何导出**。写完没跑，错误被推迟到下一次执行才爆，
 * 直接终止了任务。
 *
 * 为什么没被拦住：erase-guard 的 E4「TS 类型检查」**只筛核心三文件**
 * （red-ink-prior / handwriting-segmenter / image.service / handwriting-mask），
 * 探针脚本报错一律忽略（有意设计：探针坏不该阻塞守护）。
 * 结果就是「探针坏 = 静默」，等我真去跑它时才发现。
 *
 * 本检查补上这个盲区，且**零副作用**（只读源码 + 正则，不 import、不执行）：
 *   S1 语法可解析：TypeScript 解析器读每个 probe-*.ts，零 parse 诊断
 *   S2 导入存在性：`import { a, b } from './x'` 里的每个具名导入，
 *      必须在 x.ts 中确有对应 export（覆盖上面那类"引用不存在的导出"）
 *   S3 导入路径存在：相对路径必须能落到真实文件
 *
 * ⚠️ 覆盖边界（v20.6 二次事故后必须写清楚）：
 *   S1~S3 全是**静态**检查，抓不到"跑起来不报错但结果是错的"。
 *   真实案例：probe-redwidth.ts 测红笔笔画宽度，距离变换初版漏了
 *   `min(dist[i], l+1, u+1)` 中的 `dist[i]`，跑出来 p50/p90 全是 0——
 *   **语法完美、导入正确、exit code 0、输出还是合法 JSON**，
 *   但结论完全错误（若采信会得出"红笔笔画宽度=0"的荒谬结论）。
 *   E0 抓不到这类。抓它的是另一道机制：**每个新探针在写完后必须当场跑一次，
 *   并对输出做量级合理性校验**（行高 6~7px 的报纸算出 105px 行高就该停下）。
 *   所以本文件的定位是"挡住引用错/语法错"，**不是"保证结果对"**。
 *   探针结果对不对，只能靠人看一眼数值量级。
 */
import * as fs from 'fs'
import * as path from 'path'
import * as ts from 'typescript'

const ROOT = __dirname

/**
 * 收集某文件的所有具名导出名。
 * ⚠️ 必须同时识别 **re-export**（`export { a } from './x'` 与 `export { a }`）——
 *    漏掉会让 `wrongq-layout.ts` 里的 `export { closeInk3x3 } from './image-layout'`
 *    被误判为"未导出"，产生假警报。假警报比漏报更糟：
 *    一旦有假警报，人就会习惯性忽略这个检查，它就彻底失效了。
 */
function exportsOf(src: string, depth = 0): Set<string> {
  const out = new Set<string>()
  if (depth > 4) return out
  const sf = ts.createSourceFile('x.ts', src, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS)
  for (const st of sf.statements) {
    const mods = ts.canHaveModifiers(st) ? (ts.getModifiers(st) ?? []) : []
    const hasExportKw = mods.some((m) => m.kind === ts.SyntaxKind.ExportKeyword)
    // ⚠️ `export { a } from './x'`（re-export）在 TS AST 里**不带** ExportKeyword 修饰符
    //   （ExportDeclaration 本身就是导出声明），靠修饰符判断会把 re-export 全部漏掉。
    if (!hasExportKw && !ts.isExportDeclaration(st)) continue
    if (ts.isFunctionDeclaration(st) && st.name) out.add(st.name.text)
    else if (ts.isClassDeclaration(st) && st.name) out.add(st.name.text)
    else if (ts.isInterfaceDeclaration(st) && st.name) out.add(st.name.text)
    else if (ts.isTypeAliasDeclaration(st) && st.name) out.add(st.name.text)
    else if (ts.isEnumDeclaration(st) && st.name) out.add(st.name.text)
    else if (ts.isVariableStatement(st)) {
      for (const d of st.declarationList.declarations) if (ts.isIdentifier(d.name)) out.add(d.name.text)
    } else if (ts.isExportDeclaration(st)) {
      // re-export：export { a, b } from './x' / export { a } / export * from './x'
      if (st.exportClause && ts.isNamedExports(st.exportClause)) {
        for (const el of st.exportClause.elements) out.add(el.name.text)
      } else if (st.moduleSpecifier && ts.isStringLiteral(st.moduleSpecifier) && st.exportClause) {
        const spec = st.moduleSpecifier.text
        if (spec.startsWith('.')) {
          const p = path.resolve(ROOT, spec)
          const abs = fs.existsSync(p) ? p : `${p}.ts`
          if (fs.existsSync(abs)) for (const n of exportsOf(fs.readFileSync(abs, 'utf8'), depth + 1)) out.add(n)
        }
      }
    }
  }
  return out
}

function main() {
  const probes = fs
    .readdirSync(ROOT)
    .filter((f) => /^probe-.*\.ts$/.test(f) || /^verify-.*\.ts$/.test(f) || /^diag.*\.ts$/.test(f))
    .sort()

  const syntaxBad: string[] = []
  const importBad: string[] = []
  const pathBad: string[] = []
  const exportCache = new Map<string, Set<string>>()
  const getExports = (abs: string): Set<string> => {
    if (!exportCache.has(abs)) exportCache.set(abs, exportsOf(fs.readFileSync(abs, 'utf8')))
    return exportCache.get(abs)!
  }

  for (const f of probes) {
    const abs = path.join(ROOT, f)
    const src = fs.readFileSync(abs, 'utf8')
    // S1 语法
    const sf = ts.createSourceFile(f, src, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS)
    const diags = (sf as unknown as { parseDiagnostics: ts.Diagnostic[] }).parseDiagnostics ?? []
    if (diags.length) {
      const d = diags[0]
      const pos = sf.getLineAndCharacterOfPosition(d.start ?? 0)
      syntaxBad.push(`${f}:${pos.line + 1} TS${d.code} ${ts.flattenDiagnosticMessageText(d.messageText, ' ').slice(0, 90)}`)
      continue
    }
    // S2/S3 具名导入
    for (const st of sf.statements) {
      if (!ts.isImportDeclaration(st) || !ts.isStringLiteral(st.moduleSpecifier)) continue
      const spec = st.moduleSpecifier.text
      if (!spec.startsWith('.')) continue
      const clause = st.importClause
      if (!clause?.namedBindings || !ts.isNamedImports(clause.namedBindings)) continue
      const modAbs = path.resolve(path.dirname(abs), spec)
      const modPath = modAbs.endsWith('.ts') ? modAbs : `${modAbs}.ts`
      if (!fs.existsSync(modPath)) {
        pathBad.push(`${f}: 找不到模块 '${spec}'`)
        continue
      }
      const exp = getExports(modPath)
      for (const el of clause.namedBindings.elements) {
        const name = (el.propertyName ?? el.name).text
        if (!exp.has(name)) importBad.push(`${f}: '${spec}' 未导出 '${name}'`)
      }
    }
  }

  const all: string[] = [...syntaxBad, ...pathBad, ...importBad]
  console.log(
    'GUARD ' +
      JSON.stringify({
        pass: all.length === 0,
        scanned: probes.length,
        syntaxBad,
        pathBad,
        importBad,
        total: all.length,
      }),
  )
}
main()
