/**
 * 印刷体误删的**归属定位**：是自动检测的错，还是框选路径的错？
 * ============================================================
 * ⭐ 为什么要问这个：v20.9.1 加了「只补自动检测漏掉的像素」约束
 *   （strokeMask &= !base.mask），实测印刷体误删率**一格都没变**
 *   （中栏正文仍 100% 被擦成纸面）。
 *
 *   两种可能：
 *   (A) 自动检测 base.mask 本身就把这些印刷体判成手写 → 问题是**自动检测**的
 *       印刷误判（用户抱怨②的真正根源），框选只是放大它；
 *   (B) base.mask 不含它们，是框选路径加进去的 → 问题是**框选路径**的。
 *
 *   归属不同，修的地方完全不同（(A) 改检测链，(B) 改框选）。
 *   不分清就改，会修错地方 —— 这正是本项目反复踩的坑。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'

const IN = '/workspace/wrongq-test'

const CASES: Array<{ file: string; box: [number, number, number, number]; what: string }> = [
  { file: 'page31.png', box: [280, 250, 330, 300], what: '中栏正文(纯印刷体)' },
  { file: 'page30.png', box: [55, 1050, 105, 1100], what: '左栏正文(纯印刷体)' },
  { file: 'page29.png', box: [700, 620, 750, 670], what: '右栏红笔区' },
  { file: 'page29.png', box: [700, 200, 750, 250], what: '右栏正文段' },
]

async function main() {
  const rows: any[] = []
  for (const c of CASES) {
    const buf = fs.readFileSync(`${IN}/${c.file}`)
    const { data: g0 } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
    const meta = await sharp(buf).metadata()
    const w = meta.width, h = meta.height
    const ls: number[] = []
    for (let p = 0; p < g0.length; p += 7) ls.push(g0[p])
    ls.sort((a, b) => a - b)
    const paperL = ls[Math.floor(ls.length * 0.98)]

    const base = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })

    let dark = 0
    let darkInBase = 0
    for (let y = c.box[1]; y <= c.box[3]; y++) {
      for (let x = c.box[0]; x <= c.box[2]; x++) {
        const p = y * w + x
        if (g0[p] >= paperL - 42) continue
        dark++
        if (base.mask.data[p] > 127) darkInBase++
      }
    }
    const inBase = dark ? +(darkInBase / dark).toFixed(4) : 0
    rows.push({
      file: c.file, what: c.what,
      框内暗像素: dark,
      已在自动mask: darkInBase,
      自动检测占比: inBase,
      归属: inBase > 0.5 ? '(A) 自动检测已误判印刷体' : '(B) 框选路径引入',
    })
    void meta
    console.error(`[${c.file}/${c.what}] 暗像素=${dark} 其中已在自动mask=${darkInBase}(${(inBase * 100).toFixed(0)}%) → ${inBase > 0.5 ? '(A) 自动检测' : '(B) 框选'}`)
  }
  console.log('RESULT ' + JSON.stringify(rows, null, 1))
  console.log('\n| 样本 | 框内暗像素 | 已在自动mask | 自动检测占比 | 归属 |')
  console.log('|---|---|---|---|---|')
  for (const r of rows) {
    console.log(`| ${r.what} | ${r.框内暗像素} | ${r.已在自动mask} | ${(r.自动检测占比 * 100).toFixed(0)}% | ${r.归属} |`)
  }
}

main().catch((e) => { console.error(e); process.exit(1) })