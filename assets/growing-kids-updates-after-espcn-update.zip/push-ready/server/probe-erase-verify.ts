/**
 * 去手写优化 · 库路径验证（英语灰报 4 张）
 *
 * 与 probe-erase-news.ts 的参数扫描不同：这里走**真实线上路径**
 * buildHandwritingMask(eraseMode:'color') → inpaint → blend，
 * 验证 v19 优化（chromaMin 14 + 家具排除 + 闭运算）是否真的落到了库里并生效。
 *
 * 期望（对照扫描 o3 档）：
 *   教师红笔去红率 ≈ 0.57~0.82（基线 0.34~0.70）
 *   印刷红家具保留率 = 1.000（基线 0.000）
 *   低彩度深色印刷损伤率 ≈ 0
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, inpaint, blendWithMask } from './src/image/handwriting-mask'
import { connectedComponents, estimateCharMetrics } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

async function rawPixels(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

function furnitureSet(data: Buffer, w: number, h: number, medH: number) {
  const ink = new Uint8Array(w * h)
  for (let i = 0; i < w * h; i++) ink[i] = data[i] ? 1 : 0
  const { comps } = connectedComponents(ink, w, h, false)
  const edgeTol = Math.max(4, Math.round(medH * 0.8))
  const f = new Uint8Array(w * h)
  let px = 0
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1
    const bh = c.y1 - c.y0 + 1
    const isF =
      c.x0 <= edgeTol || c.x1 >= w - 1 - edgeTol || c.y0 <= edgeTol || c.y1 >= h - 1 - edgeTol ||
      (bw > w * 0.8 && bh < medH * 3) ||
      (bh > h * 0.8 && bw < medH * 3)
    if (!isF) continue
    px += c.n
    for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x]) f[b + x] = 1 }
  }
  return { f, px }
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const file of files) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const { info } = await rawPixels(buf)
      const w = info.width, h = info.height
      const m = await estimateCharMetrics(buf, {})
      const prior = w / 70
      const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, m.medH > 0 ? m.medH : prior))

      const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'color' })
      const repaired = await inpaint(buf, 'adaptive', seg.mask)
      const out = await blendWithMask(buf, repaired, seg.mask)
      fs.writeFileSync(path.join(IN_DIR, 'erase-final-' + file), out)

      const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
      const redN = await maskFromColorThreshold(out, { chromaMin: 14 })
      const { f: furn, px: furnPx } = furnitureSet(redO.data, w, h, medH)
      let penTotal = 0, penStill = 0, furnTotal = 0, furnStill = 0
      for (let i = 0; i < w * h; i++) {
        if (!redO.data[i]) continue
        if (furn[i]) { furnTotal++; if (redN.data[i]) furnStill++ }
        else { penTotal++; if (redN.data[i]) penStill++ }
      }
      const o = await rawPixels(buf)
      const n2 = await rawPixels(out)
      const od = o.data, nd = n2.data, ch = o.info.channels
      const lumaOf = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
      const lumas: number[] = []
      for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(od, i * ch))
      lumas.sort((a, b) => a - b)
      const darkTh = (lumas[Math.floor(lumas.length * 0.9)] ?? 240) * 0.62
      let printTotal = 0, printChanged = 0
      for (let i = 0; i < w * h; i++) {
        const p = i * ch
        const chroma = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
        const lo = lumaOf(od, p)
        if (chroma >= 14 || lo >= darkTh) continue
        printTotal++
        if (Math.abs(lumaOf(nd, p) - lo) > 30) printChanged++
      }
      console.log('GUARD ' + JSON.stringify({
        file,
        mode: 'lib-color-v19',
        coverage: +seg.mask.coverage.toFixed(4),
        penRemoval: +(1 - penStill / Math.max(1, penTotal)).toFixed(4),
        furnitureKeep: +(furnStill / Math.max(1, furnTotal)).toFixed(4),
        printDamage: +(printChanged / Math.max(1, printTotal)).toFixed(5),
        furnPx,
        growPx: (seg.mask.debug as Record<string, unknown> | undefined)?.growPx,
        debug: {
          furnitureDomains: (seg.mask.debug as Record<string, unknown> | undefined)?.furnitureDomains,
          refineApplied: (seg.mask.debug as Record<string, unknown> | undefined)?.refineApplied,
        },
      }))
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 200))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
