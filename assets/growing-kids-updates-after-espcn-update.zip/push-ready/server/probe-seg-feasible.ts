/**
 * v20.6 · 段级判定的可行性验证
 * ============================================================
 * 背景（方法论 §5.16.12）：域级判定已到尽头（缩小半径、各向异性走廊
 * 两条路都被否决，详见 red-ink-prior.ts 注释）。剩下唯一未违反上述否决的
 * 方向是**段级**：同一个墨迹连通域内，贴着红笔笔画的那几笔是黑笔（该擦），
 * 远离笔画的几笔是印刷（不该擦）。
 *
 * 但取证图显示受损印刷域 bh=6~11 极小（≈一个字），域内能否再切分存疑。
 * 本探针直接量这件事：
 *   对每个被擦掉的像素，统计它到最近红笔笔画的距离分布。
 *   若"黑笔像素"与"误擦印刷像素"的距离分布可分 → 段级可行
 *   若两者高度重叠 → 段级也不可行，必须承认"红笔旁印刷不可辨"
 *
 * ⚠️ GT 口径：黑笔 = 近红 24px 内低彩度暗像素（生产同口径）；
 *    误擦印刷 = 纯印刷行（行内无红笔）里被擦掉的印刷字域像素（E7 口径）。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask, maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask } from './src/image/handwriting-mask'
import { connectedComponents } from './src/image/image-layout'
import { findThreeColumns, colRowsIn } from './src/image/wrongq-layout'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  const out: any[] = []
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, ch = info.channels, n = w * h
    const prior = w / 70
    const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, 11))

    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const darkTh = (ls[Math.floor(ls.length * 0.9)] || 240) * 0.62
    const ink = new Uint8Array(n)
    for (let i = 0; i < n; i++) { const p = i * ch; if (chrom(od, p) < 14 && luma(od, p) < darkTh) ink[i] = 1 }
    const cols = findThreeColumns(ink, w, h, medH).cols

    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const redMask = refineColorEraseMask(await protectPrintUnderColorHandwriting(buf, redO), medH, { growRadius: 2, growChroma: 8 })
    const red = new Uint8Array(n)
    for (let i = 0; i < n; i++) if (redMask.data[i] > 127) red[i] = 1

    // 到最近红笔的曼哈顿距离。
    // ⚠️ 必须与 red-ink-prior.ts 的 `dilateDiamond` **逐字一致**（两趟 DT）。
    //    v1 初版写成 `dist[i] = min(l+1,u+1)`（漏了与 dist[i] 取 min），
    //    距离无法沿扫描方向累积 → 全部为 0 → 离散度恒 0 的假结论。
    const INF = 1 << 20
    const R = 24
    const dist = new Int32Array(n).fill(INF)
    for (let i = 0; i < n; i++) if (red[i]) dist[i] = 0
    // 正向：min(自身, 左+1, 上+1)
    for (let y = 0; y < h; y++) {
      const b = y * w
      for (let x = 0; x < w; x++) {
        const i = b + x
        if (red[i]) continue
        const l = x > 0 ? dist[i - 1] : INF
        const u = y > 0 ? dist[i - w] : INF
        dist[i] = Math.min(dist[i], l + 1, u + 1)
      }
    }
    // 反向：min(自身, 右+1, 下+1)
    for (let y = h - 1; y >= 0; y--) {
      const b = y * w
      for (let x = w - 1; x >= 0; x--) {
        const i = b + x
        if (red[i]) continue
        const r = x < w - 1 ? dist[i + 1] : INF
        const d2 = y < h - 1 ? dist[i + w] : INF
        dist[i] = Math.min(dist[i], r + 1, d2 + 1)
      }
    }
    let redCnt = 0
    for (let i = 0; i < n; i++) if (red[i]) redCnt++
    if (redCnt === 0) { console.log('GUARD ' + JSON.stringify({ file, error: 'no_red' })); continue }

    // 段级判定的关键：域内"到红笔距离"的离散度。
    // 若一个墨迹域内所有像素距红笔都差不多（离散度小）→ 域内无法再切分。
    const { comps } = connectedComponents(ink, w, h, false)
    let domsInRegion = 0, domsUniform = 0
    const spreadList: number[] = []
    for (const c of comps) {
      if (c.n < 4) continue
      const ds: number[] = []
      for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x] && dist[b + x] < INF) ds.push(dist[b + x]) }
      if (!ds.length) continue
      // 域是否"落在菱形内"（与生产 ratio 判定一致）
      let inR = 0
      for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (dist[b + x] <= 24) inR++ }
      if (inR / c.n < 0.6) continue
      domsInRegion++
      ds.sort((a, b) => a - b)
      const p10 = ds[Math.floor(ds.length * 0.1)], p90 = ds[Math.floor(ds.length * 0.9)]
      const spread = p90 - p10
      spreadList.push(spread)
      if (spread <= 4) domsUniform++
    }
    spreadList.sort((a, b) => a - b)
    out.push({
      file, domsInRegion, domsUniform,
      uniformPct: +(domsUniform / Math.max(1, domsInRegion)).toFixed(3),
      spreadMed: spreadList[Math.floor(spreadList.length / 2)] ?? -1,
      spreadP25: spreadList[Math.floor(spreadList.length * 0.25)] ?? -1,
      spreadP75: spreadList[Math.floor(spreadList.length * 0.75)] ?? -1,
    })
    process.stderr.write('.')
  }
  for (const o of out) console.log('GUARD ' + JSON.stringify(o))
  const totU = out.reduce((s, o) => s + o.domsUniform, 0)
  const totD = out.reduce((s, o) => s + o.domsInRegion, 0)
  console.log('GUARD ' + JSON.stringify({ summary: true, domsInRegion: totD, domsUniform: totU, uniformPct: +(totU / Math.max(1, totD)).toFixed(3) }))
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
