/**
 * 错题区域提取 · 前期测试探针 v5（根因修复轮）
 *
 * v4 复盘：binarizeBwPage 注释指出「全局 Otsu 的前提是管线①除法归一化把背景拉到 255」。
 * 探针此前只用了 Top-Hat 检测前置（normalizeIlluminationForDetection），没用
 * normalizeBackgroundLuma（除法归一化）——光照梯度未除掉，阴影纸面被判墨，投影焊死。
 *
 * v5：
 *  A. 墨占比体检：Otsu ink 在四角 vs 中心的分布（验证光照梯度假设）
 *  B. 除法归一化 → Otsu → 行投影（阈值扫描 0.04/0.08/0.12）
 *  C. 分栏 colTh 扫描 0.02/0.05（栏隙允许零星墨）
 *  D. 每栏行切分 + 悬挂缩进
 *  E. 诊断图 diag5-*.png
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { maskFromColorThreshold } from './src/image/handwriting-mask'
import { otsuThreshold, connectedComponents, quantileSorted, estimateCharMetrics } from './src/image/image-layout'
import { normalizeBackgroundLuma } from './src/image/image-doc-enhance'
import { straightenImage } from './src/image/image-dewarp'

const IN_DIR = '/workspace/wrongq-test'

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const f of files) {
    try {
      await probePage(path.join(IN_DIR, f))
    } catch (e) {
      console.log(`GUARD {"file":"${f}","error":${JSON.stringify(String((e as Error)?.message ?? e))}}`)
    }
  }
}

function lumaFrom(data: Buffer, w: number, h: number, ch: number) {
  const n = w * h
  const luma = new Float32Array(n)
  for (let i = 0, p = 0; i < n; i++, p += ch) {
    luma[i] = 0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2]
  }
  return luma
}

function inkStats(ink: Uint8Array, w: number, h: number, label: string) {
  const box = (xa: number, ya: number, xb: number, yb: number) => {
    let inkN = 0
    let tot = 0
    for (let y = Math.round(ya * h); y < Math.round(yb * h); y++) {
      const base = y * w
      for (let x = Math.round(xa * w); x < Math.round(xb * w); x++) {
        tot++
        if (ink[base + x]) inkN++
      }
    }
    return +(inkN / Math.max(1, tot)).toFixed(4)
  }
  return {
    label,
    total: box(0, 0, 1, 1),
    corners: {
      tl: box(0, 0, 0.15, 0.15),
      tr: box(0.85, 0, 1, 0.15),
      bl: box(0, 0.85, 0.15, 1),
      br: box(0.85, 0.85, 1, 1),
    },
    center: box(0.3, 0.3, 0.7, 0.7),
  }
}

function findCols(ink: Uint8Array, w: number, h: number, colThRatio: number, gapMin: number) {
  const colProfile = new Int32Array(w)
  for (let y = 0; y < h; y++) {
    const base = y * w
    for (let x = 0; x < w; x++) if (ink[base + x]) colProfile[x]++
  }
  const colMax = Math.max(...colProfile)
  const colTh = Math.max(1, Math.round(colMax * colThRatio))
  const gaps: Array<[number, number]> = []
  let x = 0
  while (x < w) {
    if (colProfile[x] > colTh) { x++; continue }
    const x0 = x
    while (x < w && colProfile[x] <= colTh) x++
    if (x - x0 >= gapMin) gaps.push([x0, x])
  }
  const cols: Array<[number, number]> = []
  let cur = 0
  for (const [g0, g1] of gaps) {
    if (g0 > cur) cols.push([cur, g0])
    cur = g1
  }
  if (cur < w) cols.push([cur, w])
  return { gaps, cols }
}

function colRows(ink: Uint8Array, w: number, h: number, x0: number, x1: number, rowThRatio: number) {
  const prof = new Int32Array(h)
  for (let y = 0; y < h; y++) {
    const base = y * w
    let c = 0
    for (let x = x0; x < x1; x++) if (ink[base + x]) c++
    prof[y] = c
  }
  const profMax = Math.max(...prof)
  const th = Math.max(1, Math.round(profMax * rowThRatio))
  const rows: Array<{ y0: number; y1: number; xLeft: number }> = []
  let y = 0
  while (y < h) {
    if (prof[y] < th) { y++; continue }
    const y0 = y
    while (y < h && prof[y] >= th) y++
    let xLeft = x1 - x0
    for (let yy = y0; yy < y && xLeft === x1 - x0; yy++) {
      const base = yy * w
      for (let x = x0; x < x1; x++) if (ink[base + x]) { xLeft = x - x0; break }
    }
    rows.push({ y0, y1: y, xLeft })
  }
  return rows
}

/** 剔除图形大连通域 */
function stripGraphics(ink: Uint8Array, w: number, h: number, medH: number) {
  const { comps } = connectedComponents(ink, w, h, false)
  const out = new Uint8Array(ink)
  let stripped = 0
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1
    const bh = c.y1 - c.y0 + 1
    const dense = c.n / (bw * bh)
    // 大且稀疏 = 框线/表格；大且致密 = 插图。都从"文字 ink"里剔除
    if ((bh > 4 * medH && bw > 2 * medH) || (bw > w * 0.85 && bh > 3 * medH)) {
      stripped++
      for (let y = c.y0; y <= c.y1; y++) {
        const base = y * w
        for (let x = c.x0; x <= c.x1; x++) out[base + x] = 0
      }
    }
    void dense
  }
  return { ink2: out, stripped }
}

async function probePage(file: string) {
  const buf = fs.readFileSync(file)
  const st = await straightenImage(buf, { auto: true, curved: false })
  const flatBuf = st.buffer ?? buf
  const { data, info } = await sharp(flatBuf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
  const w = info.width, h = info.height, ch = info.channels
  const n = w * h
  const luma = lumaFrom(data, w, h, ch)

  const flatMetrics = await estimateCharMetrics(flatBuf, {})
  const prior = w / 70
  const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, flatMetrics.medH > 0 ? flatMetrics.medH : prior))

  // ── A. 体检：除法归一化前 vs 后 ──
  const g0 = new Uint8Array(n)
  for (let i = 0; i < n; i++) g0[i] = Math.max(0, Math.min(255, Math.round(luma[i])))
  const t0 = otsuThreshold(g0, n)
  const ink0 = new Uint8Array(n)
  for (let i = 0; i < n; i++) ink0[i] = g0[i] < t0 ? 1 : 0
  const statsBefore = inkStats(ink0, w, h, 'raw-otsu')

  const lumaN = await normalizeBackgroundLuma(luma, w, h, { medH, flatten: 1, inkIsDark: true })
  const g1 = new Uint8Array(n)
  for (let i = 0; i < n; i++) g1[i] = Math.max(0, Math.min(255, Math.round(lumaN[i])))
  const t1 = otsuThreshold(g1, n)
  const ink1 = new Uint8Array(n)
  for (let i = 0; i < n; i++) ink1[i] = g1[i] < t1 ? 1 : 0
  const statsAfter = inkStats(ink1, w, h, 'normalized-otsu')

  // ── B. 归一化后行投影（全页，含图形剔除）──
  const { ink2, stripped } = stripGraphics(ink1, w, h, medH)
  const rowScan: Array<{ th: number; rows: number; p50: number; p90: number }> = []
  for (const rowThRatio of [0.04, 0.08, 0.12]) {
    const seg = rowScanRows(ink2, w, h, rowThRatio)
    const hs = seg.map((r) => r.y1 - r.y0).sort((a, b) => a - b)
    rowScan.push({
      th: rowThRatio,
      rows: seg.length,
      p50: quantileSorted(hs, 0.5),
      p90: quantileSorted(hs, 0.9),
    })
  }

  // ── C/D. 分栏（colTh 扫描）+ 最优栏内行切分 + 悬挂缩进 ──
  const colScan: Array<{ th: number; cols: number; ranges: Array<[number, number]> }> = []
  for (const colThRatio of [0.02, 0.05]) {
    const { cols } = findCols(ink2, w, h, colThRatio, Math.max(3, Math.round(medH * 0.3)))
    colScan.push({ th: colThRatio, cols: cols.filter(([a, b]) => b - a >= medH * 6).length, ranges: cols.filter(([a, b]) => b - a >= medH * 6) })
  }
  const bestTh = colScan.slice().sort((a, b) => b.cols - a.cols)[0]?.th ?? 0.02
  const { cols: bestCols } = findCols(ink2, w, h, bestTh, Math.max(3, Math.round(medH * 0.3)))
  const realCols = bestCols.filter(([a, b]) => b - a >= medH * 6)

  const colDetail = realCols.map(([a, b], i) => {
    const rows = colRows(ink2, w, h, a, b, 0.06)
    const merged: Array<{ y0: number; y1: number; xLeft: number }> = []
    for (const r of rows) {
      const last = merged[merged.length - 1]
      if (last && r.y0 - last.y1 <= medH * 0.4) {
        last.y1 = r.y1
        last.xLeft = Math.min(last.xLeft, r.xLeft)
      } else merged.push({ ...r })
    }
    const xs = merged.map((r) => r.xLeft).sort((p, q2) => p - q2)
    const clusters: Array<{ sum: number; count: number }> = []
    for (const x of xs) {
      const last = clusters[clusters.length - 1]
      if (last && x - last.sum / last.count <= medH * 0.6) { last.sum += x; last.count++ }
      else clusters.push({ sum: x, count: 1 })
    }
    const cl = clusters
      .map((c) => ({ center: Math.round(c.sum / c.count), count: c.count }))
      .sort((p, q2) => q2.count - p.count)
      .slice(0, 6)
    const hs = merged.map((r) => r.y1 - r.y0).sort((p, q2) => p - q2)
    return {
      col: i + 1,
      x: [a, b],
      rows: merged.length,
      rowH: { p25: quantileSorted(hs, 0.25), p50: quantileSorted(hs, 0.5), p75: quantileSorted(hs, 0.75) },
      xLeftClusters: cl,
      topFlushShare: cl.length ? +(cl[0].count / Math.max(1, merged.length)).toFixed(2) : 0,
    }
  })

  // ── 红笔统计 ──
  const cm = await maskFromColorThreshold(flatBuf, {})
  const mInk = new Uint8Array(n)
  for (let i = 0; i < n; i++) mInk[i] = cm.data[i] ? 1 : 0
  const { comps: mComps } = connectedComponents(mInk, w, h, false)
  const marks = mComps.filter((c) => c.n >= Math.max(8, Math.round(medH * 0.3)))
  const ars = marks.map((c) => (c.x1 - c.x0 + 1) / Math.max(1, c.y1 - c.y0 + 1)).sort((a, b) => a - b)
  const fills = marks.map((c) => c.n / Math.max(1, (c.x1 - c.x0 + 1) * (c.y1 - c.y0 + 1))).sort((a, b) => a - b)
  const areas = marks.map((c) => c.n).sort((a, b) => a - b)

  // ── 诊断图 ──
  const dw = 900
  const dh = Math.round((h / w) * dw)
  const baseRgb = await sharp(flatBuf).resize(dw, dh, { fit: 'fill' }).grayscale().removeAlpha().raw().toBuffer()
  const out = Buffer.alloc(dw * dh * 3)
  for (let i = 0, q3 = 0; i < dw * dh; i++, q3 += 3) {
    const g = baseRgb[i]
    out[q3] = g; out[q3 + 1] = g; out[q3 + 2] = g
  }
  const sx = dw / w, sy = dh / h
  const put = (x: number, y: number, r: number, g: number, b: number) => {
    if (x < 0 || y < 0 || x >= dw || y >= dh) return
    const q3 = (y * dw + x) * 3
    out[q3] = r; out[q3 + 1] = g; out[q3 + 2] = b
  }
  for (let y = 0; y < dh; y++) {
    const my = Math.min(h - 1, Math.round(y / sy))
    for (let x = 0; x < dw; x++) {
      const mx = Math.min(w - 1, Math.round(x / sx))
      if (mInk[my * w + mx]) put(x, y, 255, 30, 30)
    }
  }
  for (const [a, b] of realCols) {
    for (const gx of [a, b]) {
      const dx = Math.round(gx * sx)
      for (let y = 0; y < dh; y++) put(dx, y, 0, 200, 0)
    }
    const rows2 = colRows(ink2, w, h, a, b, 0.06)
    for (const r of rows2) {
      const dy = Math.round(r.y0 * sy)
      for (let x = Math.round(a * sx); x <= Math.round(b * sx); x += 2) put(x, dy, 40, 120, 255)
    }
  }
  const diagName = path.join(IN_DIR, 'diag5-' + path.basename(file))
  await sharp(out, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(diagName)

  const q = (a: number[], p: number) => (a.length ? +quantileSorted(a, p).toFixed(2) : 0)
  console.log(
    'GUARD ' +
      JSON.stringify({
        file: path.basename(file),
        size: `${w}x${h}`,
        medH: +medH.toFixed(1),
        A_inkCheck: { before: statsBefore, after: statsAfter, otsu: { raw: t0, norm: t1 } },
        B_rowScan: rowScan,
        C_colScan: colScan,
        colDetail,
        redMask: {
          coverage: +cm.coverage.toFixed(4),
          marks: marks.length,
          area: { p50: q(areas, 0.5), p90: q(areas, 0.9), max: areas[areas.length - 1] ?? 0 },
          aspect: { p10: q(ars, 0.1), p50: q(ars, 0.5), p90: q(ars, 0.9) },
          fill: { p10: q(fills, 0.1), p50: q(fills, 0.5), p90: q(fills, 0.9) },
        },
        gfxStripped: stripped,
        diag: path.basename(diagName),
      }),
  )
}

function rowScanRows(ink: Uint8Array, w: number, h: number, rowThRatio: number) {
  const prof = new Int32Array(h)
  for (let y = 0; y < h; y++) {
    const base = y * w
    let c = 0
    for (let x = 0; x < w; x++) if (ink[base + x]) c++
    prof[y] = c
  }
  const profMax = Math.max(...prof)
  const th = Math.max(1, Math.round(profMax * rowThRatio))
  const rows: Array<{ y0: number; y1: number }> = []
  let y = 0
  while (y < h) {
    if (prof[y] < th) { y++; continue }
    const y0 = y
    while (y < h && prof[y] >= th) y++
    rows.push({ y0, y1: y })
  }
  return rows
}

main().catch((e) => {
  console.error('PROBE FAILED:', e)
  process.exit(1)
})
