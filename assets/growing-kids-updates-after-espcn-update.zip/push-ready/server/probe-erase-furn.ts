/**
 * 去手写 v19.1 · 红色版面家具判据微调扫描（英语灰报 4 张）
 * ============================================================
 * 动机：v19 的「触边即家具」判据在 page29 上判出 26 个家具域，
 *       把靠页边的正文红笔批注一起剔了，导致去红率反比基线低 5pp（0.704 → 0.653）。
 *
 * 假设：版面家具（报头红横幅 / 页眉色条）是**成片实心块**，
 *       而红笔批注哪怕贴边也是**细碎镂空笔画**。
 *       给触边判据加「面积下限」+「填充率下限」即可把细碎笔迹放行。
 *
 * 扫描变体（medH≈30 → medH²≈900）：
 *   A  基线 v19          {}
 *   B  面积 ≥ 0.5medH²   { edgeMinArea: 0.5*medH² }
 *   C  面积 ≥ 0.8medH²   { edgeMinArea: 0.8*medH² }
 *   D  面积 ≥ 1.5medH²   { edgeMinArea: 1.5*medH² }
 *   E  C + 填充 ≥ 0.25   { edgeMinArea: 0.8*medH², edgeMinFill: 0.25 }
 *
 * 指标口径（与 probe-erase-verify 完全一致，三者互斥）：
 *   教师红笔擦除率（越高越好） / 印刷红家具保留率（越高越好） / 低色度印刷损伤率（越低越好）
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, inpaint, blendWithMask } from './src/image/handwriting-mask'
import { connectedComponents, estimateCharMetrics } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

async function rawPixels(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

function lumaOf(d: Buffer, p: number) {
  return 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
}

/** 家具真值集合：用 v19 无门槛判据在「原始红 mask」上确定，四张图固定，不随变体变化 */
function furnitureSet(data: Buffer, w: number, h: number, medH: number) {
  const ink = new Uint8Array(w * h)
  for (let i = 0; i < w * h; i++) ink[i] = data[i] ? 1 : 0
  const { comps } = connectedComponents(ink, w, h, false)
  const edgeTol = Math.max(4, Math.round(medH * 0.8))
  const f = new Uint8Array(w * h)
  let px = 0
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1
    const bh = c.y1 - c.y0 + 1
    const isF =
      c.x0 <= edgeTol || c.x1 >= w - 1 - edgeTol || c.y0 <= edgeTol || c.y1 >= h - 1 - edgeTol ||
      (bw > w * 0.8 && bh < medH * 3) ||
      (bh > h * 0.8 && bw < medH * 3)
    if (!isF) continue
    px += c.n
    for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x]) f[b + x] = 1 }
  }
  return { f, px }
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const file of files) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const { info } = await rawPixels(buf)
      const w = info.width
      const h = info.height
      const m = await estimateCharMetrics(buf, {})
      const prior = w / 70
      const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, m.medH > 0 ? m.medH : prior))
      const m2 = medH * medH

      // 家具真值 + 印刷（低色度暗色）真值，一次算好复用
      const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
      const { f: furn, px: furnPx } = furnitureSet(redO.data, w, h, medH)
      const o = await rawPixels(buf)
      const od = o.data
      const ch = o.info.channels
      const lumas: number[] = []
      for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(od, i * ch))
      lumas.sort((a, b) => a - b)
      const darkTh = (lumas[Math.floor(lumas.length * 0.9)] ?? 240) * 0.62

      const variants: Array<[string, Record<string, number>]> = [
        ['A-v19', {}],
        ['B-a0.5', { edgeMinArea: 0.5 * m2 }],
        ['C-a0.8', { edgeMinArea: 0.8 * m2 }],
        ['D-a1.5', { edgeMinArea: 1.5 * m2 }],
        ['E-a0.8f0.25', { edgeMinArea: 0.8 * m2, edgeMinFill: 0.25 }],
      ]

      for (const [tag, ref] of variants) {
        const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'color', colorRefine: ref })
        const repaired = await inpaint(buf, 'adaptive', seg.mask)
        const out = await blendWithMask(buf, repaired, seg.mask)

        const redN = await maskFromColorThreshold(out, { chromaMin: 14 })
        let penTotal = 0, penStill = 0, furnTotal = 0, furnStill = 0
        for (let i = 0; i < w * h; i++) {
          if (!redO.data[i]) continue
          if (furn[i]) { furnTotal++; if (redN.data[i]) furnStill++ }
          else { penTotal++; if (redN.data[i]) penStill++ }
        }
        const n2 = await rawPixels(out)
        const nd = n2.data
        let printTotal = 0, printChanged = 0
        for (let i = 0; i < w * h; i++) {
          const p = i * ch
          const chroma = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
          const lo = lumaOf(od, p)
          if (chroma >= 14 || lo >= darkTh) continue
          printTotal++
          if (Math.abs(lumaOf(nd, p) - lo) > 30) printChanged++
        }
        const dbg = (seg.mask.debug ?? {}) as Record<string, unknown>
        console.log('GUARD ' + JSON.stringify({
          file,
          variant: tag,
          medH: +medH.toFixed(1),
          coverage: +seg.mask.coverage.toFixed(4),
          penRemoval: +(1 - penStill / Math.max(1, penTotal)).toFixed(4),
          furnitureKeep: +(furnStill / Math.max(1, furnTotal)).toFixed(4),
          printDamage: +(printChanged / Math.max(1, printTotal)).toFixed(5),
          furnDomains: dbg.furnitureDomains,
          furnPxRef: dbg.furniturePx,
          furnPxGt: furnPx,
        }))
      }
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 200))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
