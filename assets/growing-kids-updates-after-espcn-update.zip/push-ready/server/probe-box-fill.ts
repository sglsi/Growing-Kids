/**
 * 探针：框选(solid rect mask) → inpaint('masked') → blend 后，框内到底有没有被换成纸面？
 * 逐项打印：尺寸、mask 值分布、inpaint 结果亮度、blend 结果亮度、暗像素数。
 */
import sharp from '/workspace/push-ready/server/node_modules/sharp'
import { buildHandwritingMask } from '/workspace/push-ready/server/src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from '/workspace/push-ready/server/src/image/handwriting-mask'

const PATH = '/root/uploads/1790697352956629135-1790697330026-hq5z96hx-9e12369282df0f327502a0364da8ea20.jpg'
const BOX = { name: '20题-手写', x: 30, y: 1225, w: 950, h: 480 }

async function stats(buf: Buffer, x: number, y: number, w: number, h: number) {
  const { data, info } = await sharp(buf).removeAlpha().raw().toBuffer({ resolveWithObject: true })
  const Wd = info.width, ch = info.channels
  let sum = 0, n = 0, dark = 0, min = 255, max = 0
  for (let yy = y; yy < Math.min(info.height, y + h); yy++)
    for (let xx = x; xx < Math.min(Wd, x + w); xx++) {
      const p = (yy * Wd + xx) * ch
      const l = 0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2]
      sum += l; n++; if (l < 140) dark++; if (l < min) min = l; if (l > max) max = l
    }
  return { mean: sum / n, dark, min, max, n, W: Wd, H: info.height, ch }
}

async function main() {
  const src = await sharp(PATH).rotate().png().toBuffer()
  const meta = await sharp(src).metadata()
  console.log(`src 尺寸 = ${meta.width}x${meta.height}（脚本假设 1279x1706）`)
  const W = meta.width!, H = meta.height!
  const manual = [{ x: BOX.x / W, y: BOX.y / H, w: BOX.w / W, h: BOX.h / H }]
  const seg = await buildHandwritingMask(src, '', {}, { allowVlm: false, manualRects: manual })
  const mask = seg.mask
  console.log(`mask 尺寸 = ${mask.width}x${mask.height} coverage=${(mask.coverage * 100).toFixed(2)}% source=${mask.source}`)

  // mask 在框内的值分布
  let mn = 255, mx = 0, sum = 0, cnt = 0, weak = 0
  for (let yy = BOX.y; yy < BOX.y + BOX.h; yy++)
    for (let xx = BOX.x; xx < BOX.x + BOX.w; xx++) {
      const v = mask.data[yy * mask.width + xx]
      if (v < mn) mn = v; if (v > mx) mx = v; sum += v; cnt++
      if (v < 128) weak++
    }
  console.log(`框内 mask: min=${mn} max=${mx} mean=${(sum / cnt).toFixed(1)} 弱值(<128)占比=${((weak / cnt) * 100).toFixed(2)}%`)

  const s0 = await stats(src, BOX.x, BOX.y, BOX.w, BOX.h)
  console.log(`\n原图  框内: 均值亮度=${s0.mean.toFixed(1)} 暗px=${s0.dark} min=${s0.min} max=${s0.max}`)

  const inp = await inpaint(src, 'masked', mask)
  const s1 = await stats(inp, BOX.x, BOX.y, BOX.w, BOX.h)
  console.log(`inpaint(masked) 输出框内: 均值亮度=${s1.mean.toFixed(1)} 暗px=${s1.dark} min=${s1.min} max=${s1.max}`)

  const merged = await blendWithMask(src, inp, mask)
  const s2 = await stats(merged, BOX.x, BOX.y, BOX.w, BOX.h)
  console.log(`blend 后box内: 均值亮度=${s2.mean.toFixed(1)} 暗px=${s2.dark} min=${s2.min} max=${s2.max}`)

  // 抽样几个具体像素对比
  const raw0 = await sharp(src).removeAlpha().raw().toBuffer()
  const raw2 = await sharp(merged).removeAlpha().raw().toBuffer()
  const ch2 = s2.ch
  console.log('\n抽样点 (x,y): 原图luma → blend后luma  [mask值]')
  for (const [xx, yy] of [[500, 1300], [600, 1350], [700, 1400], [300, 1500], [800, 1250]] as const) {
    const p = (yy * s0.W + xx) * ch2
    const l0 = 0.299 * raw0[p] + 0.587 * raw0[p + 1] + 0.114 * raw0[p + 2]
    const l2 = 0.299 * raw2[p] + 0.587 * raw2[p + 1] + 0.114 * raw2[p + 2]
    console.log(`  (${xx},${yy}): ${l0.toFixed(0)} → ${l2.toFixed(0)}  [mask=${mask.data[yy * mask.width + xx]}]`)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
