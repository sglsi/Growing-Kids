/**
 * v20.9 · 图形区判据 v2：灰阶复杂度（暗像素占比已实测否决）
 * ============================================================
 * v1 判据（暗像素占比 > 0.45 → 拒擦）**已被实测数据否决**：
 *   page30 两张实物照片 darkRatio = 0.496 / 0.176（同一张图，差 2.8 倍）
 *   page29 插图 darkRatio = 0.19 < page30 文字块中位数 0.24
 *   → 照片与文字的暗像素占比**完全重叠**，该判据无区分度。
 *   runRatio（最长连续暗游程）同样失败：照片 0.442~0.865，
 *   文字块 p50=0.82 —— 报纸的栏缝/表格线/下划线让文字块也有长游程。
 *
 * v2 判据假设：**照片 = 连续灰阶；文字 = 近二值笔画**
 *   度量：区域内灰阶的**唯一值数量**（distinct levels）与**中间调占比**。
 *   照片有上百级灰阶过渡；文字只有纸白 + 墨黑两级（抗锯齿带来少量中间调）。
 *
 * ⚠️ 这是假设，必须实测验证 —— 沿用 G1 精神。
 *   判据若不成立，直接否决，不硬凑。
 */
import sharp from 'sharp'
import * as fs from 'fs'

const IN_DIR = '/workspace/wrongq-test'

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()

  // 人工标注：图形区 vs 纯文字区（坐标为原图像素）
  const GRAPHICS: Array<{ file: string; box: [number, number, number, number]; what: string }> = [
    { file: 'page30.png', box: [530, 1193, 581, 1244], what: '实物照片A' },
    { file: 'page30.png', box: [60, 1200, 111, 1251], what: '实物照片B' },
    { file: 'page28.png', box: [430, 700, 481, 751], what: '插图' },
    { file: 'page29.png', box: [300, 600, 351, 651], what: '图片区' },
  ]
  // 纯文字区（从目检确认的正文段落选取，避开插图/表格/手写）
  const TEXT: Array<{ file: string; box: [number, number, number, number]; what: string }> = [
    { file: 'page30.png', box: [40, 60, 91, 111], what: '左栏正文段1' },
    { file: 'page30.png', box: [40, 170, 91, 221], what: '左栏正文段2' },
    { file: 'page30.png', box: [640, 60, 691, 111], what: '右栏正文段1' },
    { file: 'page30.png', box: [640, 170, 691, 221], what: '右栏正文段2' },
    { file: 'page28.png', box: [40, 60, 91, 111], what: '左栏正文段' },
    { file: 'page29.png', box: [40, 60, 91, 111], what: '左栏正文段' },
  ]

  const stat = (file: string, box: [number, number, number, number]) => {
    return (async () => {
      const buf = fs.readFileSync(`${IN_DIR}/${file}`)
      const { data: g } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
      const w = g.length / (buf.length / 1) // 占位，实际用 metadata
      void w
      return null
    })()
  }
  void stat

  for (const file of files) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: g, info } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height
    const ls: number[] = []
    for (let p = 0; p < g.length; p += 7) ls.push(g[p])
    ls.sort((a, b) => a - b)
    const paperL = ls[Math.floor(ls.length * 0.98)]
    const paperTh = paperL - 42
    void paperTh

    const measure = (box: [number, number, number, number]) => {
      const [x0, y0, x1, y1] = box
      const levels = new Set<number>()
      const hist = new Int32Array(256)
      let tot = 0
      for (let y = y0; y <= y1 && y < h; y++) {
        const b = y * w
        for (let x = x0; x <= x1 && x < w; x++) {
          const v = g[b + x]
          levels.add(v)
          hist[v]++
          tot++
        }
      }
      if (!tot) return null
      // 中间调占比：纸白与墨黑之间的灰阶
      let mid = 0
      for (let v = Math.max(0, paperL - 70); v <= paperL - 20; v++) mid += hist[v]
      // 唯一值按 4 级量化（抗锯齿/噪声不该让计数虚高）
      const q4 = new Set<number>()
      for (const v of levels) q4.add(Math.round(v / 4))
      return {
        px: tot,
        distinct: levels.size,
        distinctQ4: q4.size,
        midRatio: +(mid / tot).toFixed(4),
        mean: +(Array.from(levels).reduce((s, v) => s + v * hist[v], 0) / tot).toFixed(1),
        std: +(() => {
          const m = Array.from(levels).reduce((s, v) => s + v * hist[v], 0) / tot
          return Math.sqrt(Array.from(levels).reduce((s, v) => s + hist[v] * (v - m) ** 2, 0) / tot)
        })().toFixed(1),
      }
    }

    console.log(`\n=== ${file} (paperL=${paperL.toFixed(0)}) ===`)
    for (const m of GRAPHICS.filter((x) => x.file === file)) {
      const r = measure(m.box)
      if (r) console.log(`  ▓图形 ${m.what.padEnd(12)} distinct=${String(r.distinct).padStart(3)} dQ4=${String(r.distinctQ4).padStart(3)} mid=${(r.midRatio * 100).toFixed(1)}% std=${r.std}`)
    }
    for (const m of TEXT.filter((x) => x.file === file)) {
      const r = measure(m.box)
      if (r) console.log(`  ░文字 ${m.what.padEnd(12)} distinct=${String(r.distinct).padStart(3)} dQ4=${String(r.distinctQ4).padStart(3)} mid=${(r.midRatio * 100).toFixed(1)}% std=${r.std}`)
    }
  }
}

main().catch((e) => { console.error(e); process.exit(1) })
