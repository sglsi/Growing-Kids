/**
 * 去手写 v20 · 红笔空间先验（Red-Spatial Prior）
 * ============================================================
 * 【为什么换路线】probe-feature-auc.ts 实测结论：
 *   字号/粗细/间距/灰度方差/域形状 的 AUC 全部 ≈ 0.5（抛硬币）。
 *   原因：报纸输入仅 1024px 宽，正文字高 6~7px，手写与印刷在这个尺度上
 *   笔宽、字高、灰度、连通域形状**全部退化到同一量级**——信息本身不存在，
 *   任何"调阈值"都不可能凭空造出信息。
 *
 * 【唯一有判别力的信号】F9 域内平均 chroma 的 AUC：page29=0.830 / page31=0.705。
 *   但它的物理含义不是"手写字更红"，而是——**这个墨迹域被红笔接触过**
 *   （红笔抗锯齿边缘给邻域像素染色）。
 *   换句话说：唯一可靠的判据是**空间关系**，不是局部纹理。
 *
 * 【本方案】教师批改必然画在学生答案上（这是作业场景的物理约束）：
 *   mask = (红笔 mask 外扩 R) ∩ (低彩度暗像素)
 *   即"红笔够得着的地方，就是学生写过的地方"。
 *
 * 参数扫描 R，找黑笔覆盖率 vs 印刷误圈率的拐点。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { maskFromColorThreshold, normalizeIlluminationForDetection } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'

async function main() {
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const o = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
      const w = o.info.width, h = o.info.height, ch = o.info.channels
      const N = w * h
      const pre = await normalizeIlluminationForDetection(buf)
      const red = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })

      // 纸面亮度 / 暗阈值
      const ls: number[] = []
      for (let i = 0; i < N; i += 37) ls.push(0.299 * o.data[i * ch] + 0.587 * o.data[i * ch + 1] + 0.114 * o.data[i * ch + 2])
      ls.sort((a, b) => a - b)
      const paper = ls[Math.floor(ls.length * 0.9)] || 240
      const darkTh = paper * 0.62

      // 墨迹（低彩度暗像素 = 黑笔 + 印刷）
      const ink = new Uint8Array(N)
      for (let i = 0; i < N; i++) {
        const p = i * ch
        const c = Math.max(o.data[p], o.data[p + 1], o.data[p + 2]) - Math.min(o.data[p], o.data[p + 1], o.data[p + 2])
        if (c < 14 && 0.299 * o.data[p] + 0.587 * o.data[p + 1] + 0.114 * o.data[p + 2] < darkTh) ink[i] = 1
      }
      // 红笔区
      const redM = new Uint8Array(N)
      for (let i = 0; i < N; i++) if (red.data[i]) redM[i] = 1

      // 真值：黑笔候选 = 距红笔 24px 内的墨迹
      const near24 = new Uint8Array(N)
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          if (!redM[y * w + x]) continue
          for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
            for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near24[yy * w + xx] = 1
        }
      }
      let nPen = 0, nInk = 0
      for (let i = 0; i < N; i++) {
        if (ink[i]) nInk++
        if (ink[i] && near24[i]) nPen++
      }

      // 逐半径扫描
      const rows: Array<Record<string, number>> = []
      for (const R of [4, 6, 8, 10, 12, 16, 20, 24, 30, 40]) {
        // R 膨胀（用两遍横向 + 两遍纵向近似，R<=40 足够准）
        const d = new Uint8Array(redM)
        for (let k = 0; k < R; k++) {
          const prev = d.slice()
          for (let y = 0; y < h; y++) {
            for (let x = 1; x < w; x++) if (prev[y * w + x - 1]) d[y * w + x] = 1
            for (let x = w - 2; x >= 0; x--) if (prev[y * w + x + 1]) d[y * w + x] = 1
          }
          for (let x = 0; x < w; x++) {
            for (let y = 1; y < h; y++) if (prev[(y - 1) * w + x]) d[y * w + x] = 1
            for (let y = h - 2; y >= 0; y--) if (prev[(y + 1) * w + x]) d[y * w + x] = 1
          }
        }
        let hitPen = 0, hitInk = 0, cov = 0
        for (let i = 0; i < N; i++) {
          if (!(d[i] && ink[i])) continue
          cov++
          if (near24[i]) hitPen++
          hitInk++
        }
        rows.push({
          R,
          cov: +(cov / N).toFixed(4),
          penCover: +((hitPen / Math.max(1, nPen)) * 100).toFixed(1),
          inkInRegion: +((hitInk / Math.max(1, nInk)) * 100).toFixed(1),
        })
      }
      console.log('GUARD ' + JSON.stringify({ file, nPen, nInk, scan: rows }))
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 250))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
