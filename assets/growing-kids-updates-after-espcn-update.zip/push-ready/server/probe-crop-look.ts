/**
 * v20.2 · 目检取样：在红笔密集处裁 3 块 260×200 的对照图（原图 / hybrid 结果 / mask 叠加）
 * 目的：数字已经自相矛盾（真值定义把"近红=黑笔"当公理 → printDamage 恒 0 或恒爆），
 *       必须用眼睛确认：红笔周围 24px 内到底有没有印刷正文。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'
const OUT = '/workspace/wrongq-test/look'

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  for (const file of ['page28.png', 'page29.png', 'page30.png', 'page31.png']) {
    const buf = fs.readFileSync(path.join(IN_DIR, file))
    const { data, info } = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height, ch = info.channels
    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    // 找红笔最密的 3 个 80×80 格
    const cell = 80, gw = Math.floor(w / cell), gh = Math.floor(h / cell)
    const grid = new Array(gw * gh).fill(0)
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (redO.data[y * w + x]) grid[Math.floor(y / cell) * gw + Math.floor(x / cell)]++
    const order = grid.map((v, i) => ({ v, i })).sort((a, b) => b.v - a.v).slice(0, 3)

    const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
    const rep = await inpaint(buf, 'adaptive', seg.mask)
    const img = await blendWithMask(buf, rep, seg.mask)
    fs.writeFileSync(path.join(OUT, `full-${file}`), img)

    const CW = 300, CH = 220
    for (let k = 0; k < order.length; k++) {
      const gx = (order[k].i % gw) * cell, gy = Math.floor(order[k].i / gw) * cell
      const left = Math.max(0, Math.min(w - CW, gx + cell / 2 - CW / 2))
      const top = Math.max(0, Math.min(h - CH, gy + cell / 2 - CH / 2))
      await sharp(buf).extract({ left, top, width: CW, height: CH }).toFile(path.join(OUT, `${file.replace('.png', '')}-${k}-orig.png`))
      await sharp(img).extract({ left, top, width: CW, height: CH }).toFile(path.join(OUT, `${file.replace('.png', '')}-${k}-hybrid.png`))
      // mask 叠加：mask 区域染成品红
      const ov = Buffer.from(data)
      for (let y = top; y < top + CH; y++) {
        for (let x = left; x < left + CW; x++) {
          const i = y * w + x
          if (!seg.mask.data[i]) continue
          const p = i * ch
          ov[p] = 255; ov[p + 1] = 0; ov[p + 2] = 255
        }
      }
      await sharp(ov, { raw: { width: w, height: h, channels: ch } })
        .extract({ left, top, width: CW, height: CH })
        .toFile(path.join(OUT, `${file.replace('.png', '')}-${k}-mask.png`))
    }
    console.log(`GUARD ${JSON.stringify({ file, redPx: order.reduce((s, o) => s + o.v, 0), cov: +seg.mask.coverage.toFixed(4) })}`)
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
