/**
 * 探针：究竟是「局部底色图」还是「最终混合」没清干净？
 * 逐层打印 buildLocalBackgroundMap / estimateBackground / fillWithBackground 的统计。
 */
import sharp from '/workspace/push-ready/server/node_modules/sharp'
import { buildHandwritingMask } from '/workspace/push-ready/server/src/image/handwriting-segmenter'
import {
  buildLocalBackgroundMap, estimateBackground, inpaint,
} from '/workspace/push-ready/server/src/image/handwriting-mask'

const PATH = '/root/uploads/1790697352956629135-1790697330026-hq5z96hx-9e12369282df0f327502a0364da8ea20.jpg'
const BOX = { x: 30, y: 1225, w: 950, h: 480 }
/** 框外的纯纸面参照区（左下角空白处） */
const REF = { x: 40, y: 300, w: 200, h: 120 }

async function statRaw(data: Buffer, info: { width: number; height: number; channels: number }, b: typeof BOX) {
  let sum = 0, n = 0, dark = 0, min = 255, max = 0
  for (let y = b.y; y < Math.min(info.height, b.y + b.h); y++)
    for (let x = b.x; x < Math.min(info.width, b.x + b.w); x++) {
      const p = (y * info.width + x) * info.channels
      const l = 0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2]
      sum += l; n++; if (l < 140) dark++; if (l < min) min = l; if (l > max) max = l
    }
  return `均值=${(sum / n).toFixed(1)} 暗px=${dark} min=${min.toFixed(0)} max=${max.toFixed(0)}`
}

async function main() {
  const src = await sharp(PATH).rotate().png().toBuffer()
  const meta = await sharp(src).metadata()
  const W = meta.width!, H = meta.height!
  const manual = [{ x: BOX.x / W, y: BOX.y / H, w: BOX.w / W, h: BOX.h / H }]
  const seg = await buildHandwritingMask(src, '', {}, { allowVlm: false, manualRects: manual })
  const mask = seg.mask

  const srcMeta = { width: W, height: H, channels: 3 }
  const srcRaw = await sharp(src).removeAlpha().raw().toBuffer()
  console.log('=== 原图 ===')
  console.log(`  框内 : ${await statRaw(srcRaw, srcMeta, BOX)}`)
  console.log(`  框外参照: ${await statRaw(srcRaw, srcMeta, REF)}`)

  const g = await estimateBackground(src, mask)
  console.log(`\n=== 全局底色 estimateBackground ===\n  rgb=(${g.r},${g.g},${g.b}) luma=${(0.299 * g.r + 0.587 * g.g + 0.114 * g.b).toFixed(1)} noise=${g.noise?.toFixed?.(2)}`)

  const localBuf = await buildLocalBackgroundMap(src, mask)
  if (!localBuf) {
    console.log('\n=== 局部底色图 === 返回 null（应回退全局单色）')
  } else {
    console.log(`\n=== 局部底色图 (len=${localBuf.length}, 期望=${W * H * 3}) ===`)
    console.log(`  框内 : ${await statRaw(localBuf, srcMeta, BOX)}`)
    console.log(`  框外参照: ${await statRaw(localBuf, srcMeta, REF)}`)
  }

  const inp = await inpaint(src, 'masked', mask)
  const inpRaw = await sharp(inp).removeAlpha().raw().toBuffer()
  console.log('\n=== inpaint(masked) 结果 ===')
  console.log(`  框内 : ${await statRaw(inpRaw, srcMeta, BOX)}`)
  console.log(`  框外参照: ${await statRaw(inpRaw, srcMeta, REF)}`)

  // 机器可读汇总（供 task-guard 断言 v17 防退化：大块 mask 内底色必须干净）
  const countDark = (buf: Buffer) => {
    let n = 0
    for (let i = 0; i < buf.length; i += 3) {
      const l = 0.299 * buf[i] + 0.587 * buf[i + 1] + 0.114 * buf[i + 2]
      if (l < 140) n++
    }
    return n
  }
  const localDarkInBox = localBuf
    ? await (async () => {
        let n = 0
        for (let y = BOX.y; y < Math.min(H, BOX.y + BOX.h); y++)
          for (let x = BOX.x; x < Math.min(W, BOX.x + BOX.w); x++) {
            const p = (y * W + x) * 3
            const l = 0.299 * localBuf[p] + 0.587 * localBuf[p + 1] + 0.114 * localBuf[p + 2]
            if (l < 140) n++
          }
        return n
      })()
    : -1
  void countDark
  console.log(`GUARD ${JSON.stringify({ boxDarkInLocalBg: localDarkInBox })}`)
}
main().catch((e) => { console.error(e); process.exit(1) })
