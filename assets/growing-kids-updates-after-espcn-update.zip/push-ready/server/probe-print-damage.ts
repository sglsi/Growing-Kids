/**
 * v20.9 · 框内印刷体误删的定量测量
 * ============================================================
 * ⭐ 本探针的存在理由：G3 目检否定了我的结论。
 *   三联图显示：mask 只选笔画状像素（笔迹占比 60%）、红笔被擦掉了，
 *   **但印刷字 "company" 和 "(59)" 一起被擦掉了** —— 它们也是暗像素。
 *   而我先前拿"信息保留提升 1.3~4.5×"当证据，那个指标是**有偏的**：
 *   印刷体被删掉 → 擦后更像纸面 → "信息保留"上升。
 *   **第四次在验收指标上骗自己。**
 *
 * 正确问题不是"擦后像不像纸面"，而是：
 *   **框内的印刷体有多少被误删了？**
 *
 * 难点：印刷体与手写同色同深，无自动判据。但**可以人工标定**：
 *   在框内标出"属于印刷体的笔画区域"，测量其存活率。
 *   这正是 G2 门禁（黄金样例）要干的事，本探针先做可行性验证。
 *
 * 做法：用**对齐差分**造出"如果印刷体没被误删应该是什么样"的参照 ——
 *   实际上做不到（无法凭空还原被擦掉的字）。
 *   ⇒ 改为直接目视判定：把 after 与 orig 并排放大，人工数"还剩几个字"。
 *
 * 输出：每例的（a）框内暗像素（笔迹候选）数（b）其中印刷体占比估计
 *   （c）after 中这些位置是否已变纸面，供目检逐个确认。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN = '/workspace/wrongq-test'
const OUT = '/workspace/v20-框选E2E/v209/print'

const CASES: Array<{ file: string; box: [number, number, number, number]; what: string }> = [
  { file: 'page29.png', box: [700, 620, 750, 670], what: '红笔区含印刷字' },
  { file: 'page31.png', box: [280, 250, 330, 300], what: '中栏正文' },
  { file: 'page30.png', box: [55, 1050, 105, 1100], what: '左栏正文' },
  { file: 'page29.png', box: [700, 200, 750, 250], what: '右栏正文段' },
]

const Z = 10

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  const rows: any[] = []

  for (const c of CASES) {
    const buf = fs.readFileSync(`${IN}/${c.file}`)
    const { data: od, info } = await raw(buf)
    const { data: g0 } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height
    const ls: number[] = []
    for (let p = 0; p < g0.length; p += 7) ls.push(g0[p])
    ls.sort((a, b) => a - b)
    const paperL = ls[Math.floor(ls.length * 0.98)]

    const man = await buildHandwritingMask(buf, '', {}, {
      allowVlm: false, eraseMode: 'hybrid',
      manualRects: [{
        x: +(c.box[0] / w).toFixed(4), y: +(c.box[1] / h).toFixed(4),
        w: +((c.box[2] - c.box[0] + 1) / w).toFixed(4),
        h: +((c.box[3] - c.box[1] + 1) / h).toFixed(4),
      }],
    })
    const img = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)
    const { data: gA } = await sharp(img).grayscale().raw().toBuffer({ resolveWithObject: true })

    // 框内暗像素（= 笔迹候选 = 印刷体 + 手写，全都被并入 mask）
    let darkBefore = 0
    for (let y = c.box[1]; y <= c.box[3]; y++) {
      for (let x = c.box[0]; x <= c.box[2]; x++) if (g0[y * w + x] < paperL - 42) darkBefore++
    }
    // 这些暗像素中，擦后已变成纸面（≈ 灰度 > paperL-20）的比例 → 越高说明印刷体被误删越多
    let nowPaper = 0
    for (let y = c.box[1]; y <= c.box[3]; y++) {
      for (let x = c.box[0]; x <= c.box[2]; x++) {
        if (g0[y * w + x] >= paperL - 42) continue
        if (gA[y * w + x] > paperL - 20) nowPaper++
      }
    }
    // 仍在的暗像素数（可能含残留手写）
    let stillDark = 0
    for (let y = c.box[1]; y <= c.box[3]; y++) {
      for (let x = c.box[0]; x <= c.box[2]; x++) if (gA[y * w + x] < paperL - 42) stillDark++
    }

    const dbg = (man.mask.debug ?? {}) as Record<string, unknown>
    rows.push({
      file: c.file, what: c.what,
      strokeRatio: dbg.manualStrokeRatio,
      框内暗像素: darkBefore,
      擦后变纸面: nowPaper,
      误删率: darkBefore ? +(nowPaper / darkBefore).toFixed(4) : 0,
      残留暗像素: stillDark,
      残留率: darkBefore ? +(stillDark / darkBefore).toFixed(4) : 0,
    })

    // 目检图：orig / after，印刷体与手写并排
    const cw = c.box[2] - c.box[0] + 1, ch = c.box[3] - c.box[1] + 1
    const p1 = await sharp(buf).extract({ left: c.box[0], top: c.box[1], width: cw, height: ch })
      .resize({ width: cw * Z, kernel: 'nearest' }).png().toBuffer()
    const p2 = await sharp(img).extract({ left: c.box[0], top: c.box[1], width: cw, height: ch })
      .resize({ width: cw * Z, kernel: 'nearest' }).png().toBuffer()
    const W = cw * Z, H = ch * Z
    const sheet = await sharp({
      create: { width: W + 4, height: (H + 4) * 2, channels: 3, background: { r: 255, g: 0, b: 255 } },
    }).composite([
      { input: p1, left: 0, top: 0 }, { input: p2, left: 0, top: H + 4 },
      { input: Buffer.from(`<svg width="${W}" height="${H}"><rect width="${W}" height="${H}" fill="none" stroke="#0a0"/><text x="4" y="16" font-size="13" fill="#0a0">orig</text></svg>`), left: 0, top: 0 },
      { input: Buffer.from(`<svg width="${W}" height="${H}"><rect width="${W}" height="${H}" fill="none" stroke="#0a0"/><text x="4" y="16" font-size="13" fill="#0a0">after</text></svg>`), left: 0, top: H + 4 },
    ]).png().toBuffer()
    const f = `${OUT}/${c.file.replace('.png', '')}-${c.what}.png`
    fs.writeFileSync(f, sheet)
    rows[rows.length - 1].sheet = f
    void od
    console.error(`[${c.file}/${c.what}] 暗像素=${darkBefore} 擦后变纸面=${nowPaper}(${(nowPaper / Math.max(1, darkBefore) * 100).toFixed(0)}%) → ${f}`)
  }

  console.log('RESULT ' + JSON.stringify(rows, null, 1))
  console.log('\n| 样本 | 笔迹占比 | 框内暗像素 | 擦后变纸面 | 误删率 | 残留率 |')
  console.log('|---|---|---|---|---|---|')
  for (const r of rows) {
    console.log(`| ${r.what} | ${r.strokeRatio} | ${r.框内暗像素} | ${r.擦后变纸面} | ${(r.误删率 * 100).toFixed(0)}% | ${(r.残留率 * 100).toFixed(0)}% |`)
  }
  console.log('\n⚠️ "误删率"里含真正的红笔（该删），无法自动拆分 —— 必须目检区分。')
  console.log('   但若"残留率"也很高，说明连该删的都没删干净。')
}

main().catch((e) => { console.error(e); process.exit(1) })