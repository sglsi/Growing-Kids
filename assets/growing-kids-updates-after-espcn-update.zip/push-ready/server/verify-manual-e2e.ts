/**
 * v20.9 · 框选补擦端到端验证（E2E）
 * ============================================================
 * 目的：前端框选 UI 与后端 mergeManualRects 此前各自验证过，但**从未串起来跑过**。
 *   前端 `image-editor.tsx` 有触摸层、`manual_regions` 透传链路完整；
 *   后端 `mergeManualRects` 被 probe-manual-merge.ts 验证 4/4 通过。
 *   两个都"对"，不代表**接起来**对。
 *
 * 本探针模拟前端的真实调用：取一张真实图 → 选"自动漏擦区"
 *   → 按前端口径（归一化 0~1）构造 manual_regions
 *   → 调 buildHandwritingMask → 检验最终图像像素。
 *
 * ⚠️ 严禁用「mask 覆盖率上升」当验收 —— v20.6 的 printDamage 教训：
 *   覆盖率上升也可能来自把印刷体一起擦了。**必须验像素**。
 *
 * ⭐ v20.9 验收标准二次修正（本文件自身被推翻过两次，都记在这里）：
 *
 * 事故① 盲区（漏了"不该擦的"）：v1 只验"框选区变干净了"（A = 新增擦除>0），
 *   于是在框选区恰好是**实物照片**时也判通过 —— 而那时整块照片被涂成纯白、
 *   图片内容不可逆摧毁。**验收只验了该验的一半。**
 *   修正：区分「框被接受」/「框被拒擦」两条互斥路径，拒擦是正确行为。
 *
 * 事故② 盲区（漏了"该验的"）：修正后 4/4 全绿，但选框分布是
 *   page28=接受 / page29,30,31=拒擦 —— **主路径（框住漏擦的黑笔文字）
 *   只被测了 1 次**。原因是选框策略"暗像素最多 + 基线未改变"**系统性
 *   偏向照片**：照片暗像素多，且永远不会被自动擦除 → 必然满足"基线未改变"。
 *   **验收全绿，但覆盖的是错的那条路径。**
 *   修正：每页测两个框 —— ① 自动挑的（可能落图形区，验拒擦保护）
 *        ② midRatio 最低的纯文字块（验补擦主路径）。与①同位时不重复测。
 *
 * 与 printDamage（v20.6）、照片被涂白（v20.9）是同一类病：
 *   **验收标准/覆盖有盲区**。已复发三次，故把"验收要问'漏了什么'"写进本注释。
 *
 * 验收标准（三条全过）：
 *   A. 框被接受 → 框内**新增**被擦像素 > 0（补擦生效）
 *      框被拒擦 → 框内**零**新增擦除（保护生效）
 *      附加 A_honestField：debug 声称并入 N 框，就必须真有 N 框进 mask
 *   B. 框选区外，基线已擦的像素**没有**回到原样（检测链效果未被撤销）
 *   C. 掩外损伤 = 0（修复层无越界）
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'
const OUT_DIR = '/workspace/v20-框选E2E'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

type CaseResult = Record<string, unknown>

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  const out: CaseResult[] = []

  for (const file of files) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, n = w * h

    const base = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
    const baseImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', base.mask), base.mask)
    const { data: baseNd } = await raw(baseImg)
    await sharp(baseImg).png().toFile(`${OUT_DIR}/${file.replace('.png', '')}-base.png`)

    // 变化阈值（自适应，避免硬编码亮度）
    const diffs: number[] = []
    for (let k = 0; k < 1500; k++) {
      const p = Math.floor((k / 1500) * n)
      diffs.push(Math.max(
        Math.abs(od[p * 3] - baseNd[p * 3]),
        Math.abs(od[p * 3 + 1] - baseNd[p * 3 + 1]),
        Math.abs(od[p * 3 + 2] - baseNd[p * 3 + 2]),
      ))
    }
    diffs.sort((a, b) => a - b)
    const TH = Math.max(12, Math.min(40, diffs[Math.floor(diffs.length * 0.99)]))
    const changed = (d: Buffer, p: number) => {
      const i = p * 3
      return Math.abs(od[i] - d[i]) > TH || Math.abs(od[i + 1] - d[i + 1]) > TH || Math.abs(od[i + 2] - d[i + 2]) > TH
    }

    // 找"漏擦区"：有暗像素、但基线没改变 —— 这正是用户会去框的地方
    const BS = Math.max(24, Math.round(Math.min(w, h) * 0.05))
    const luma = (p: number) => 0.299 * od[p * 3] + 0.587 * od[p * 3 + 1] + 0.114 * od[p * 3 + 2]
    const ls: number[] = []
    for (let p = 0; p < n; p += 13) ls.push(luma(p))
    ls.sort((a, b) => a - b)
    const inkTh = ls[Math.floor(ls.length * 0.98)] - 45
    const paperL = ls[Math.floor(ls.length * 0.98)]

    // 中间调占比 —— 用于挑"纯文字块"作为第二个测试框（照片/插图 ≫ 文字，
    // 见 probe-graphic-guard2.ts 实测：照片 47~51% vs 文字 0~10.7%）
    const midRatioOf = (bx: number, by: number) => {
      let mid = 0, tot = 0
      for (let y = by; y < by + BS; y++) {
        const b = y * w
        for (let x = bx; x < bx + BS; x++) {
          const v = Math.round(luma(b + x))
          if (v >= paperL - 70 && v <= paperL - 20) mid++
          tot++
        }
      }
      return tot ? mid / tot : 1
    }

    let best: { x: number; y: number; ink: number } | null = null
    let bestText: { x: number; y: number; ink: number; mid: number } | null = null
    for (let by = 0; by + BS <= h; by += BS) {
      for (let bx = 0; bx + BS <= w; bx += BS) {
        let ink = 0, chg = 0
        for (let y = by; y < by + BS; y++) {
          const b = y * w
          for (let x = bx; x < bx + BS; x++) {
            const p = b + x
            if (luma(p) < inkTh) ink++
            if (changed(baseNd, p)) chg++
          }
        }
        if (ink > BS * BS * 0.02 && chg === 0) {
          if (!best || ink > best.ink) best = { x: bx, y: by, ink }
          const mid = midRatioOf(bx, by)
          if (!bestText || mid < bestText.mid) bestText = { x: bx, y: by, ink, mid }
        }
      }
    }
    if (!best) { out.push({ file, skip: '未找到漏擦区' }); continue }

    // ⭐ 每页测两个框（见文件头"事故②"）
    const cases: { tag: string; bx: number; by: number; mid: number }[] = [
      { tag: 'auto', bx: best.x, by: best.y, mid: +midRatioOf(best.x, best.y).toFixed(3) },
    ]
    if (bestText && (bestText.x !== best.x || bestText.y !== best.y)) {
      cases.push({ tag: 'text', bx: bestText.x, by: bestText.y, mid: +bestText.mid.toFixed(3) })
    }

    for (const cs of cases) {
      out.push(await runCase({
        file, buf, od, baseNd, n, w, h, changed, TH, BS,
        bx: cs.bx, by: cs.by, caseTag: cs.tag, boxMid: cs.mid, darkPx: cs.tag === 'auto' ? best.ink : bestText!.ink,
      }))
    }
  }

  console.log('RESULT ' + JSON.stringify(out, null, 1))
  const bad = out.filter((r) => r.skip || !r.A_pass || !r.B_pass || !r.C_pass || !r.D_pass)
  if (bad.length) {
    console.error('FAIL: ' + bad.map((b) => `${b.file}/${(b.case as string) ?? '?'}`).join(','))
    process.exitCode = 1
  } else {
    console.error('E2E PASS: 框选补擦全绿（拒擦保护路径 + 补擦主路径均有覆盖）')
  }
}

interface RunCaseArg {
  file: string; buf: Buffer; od: Buffer; baseNd: Buffer
  n: number; w: number; h: number
  changed: (d: Buffer, p: number) => boolean
  TH: number; BS: number
  bx: number; by: number; caseTag: string; boxMid: number; darkPx: number
}

async function runCase(a: RunCaseArg): Promise<CaseResult> {
  const { file, buf, od, baseNd, n, w, h, changed, TH, BS, bx, by, caseTag, boxMid, darkPx } = a

  // ★ 前端口径：归一化 0~1 的矩形，直接透传
  const regions = [{
    x: +(bx / w).toFixed(4),
    y: +(by / h).toFixed(4),
    w: +(BS / w).toFixed(4),
    h: +(BS / h).toFixed(4),
  }]

  const man = await buildHandwritingMask(buf, '', {}, {
    allowVlm: false, eraseMode: 'hybrid', manualRects: regions,
  })
  const manImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)
  const { data: manNd } = await raw(manImg)
  await sharp(manImg).png().toFile(`${OUT_DIR}/${file.replace('.png', '')}-${caseTag}-after.png`)

  // A. 框选区新增被擦
  const rx0 = bx, ry0 = by, rx1 = bx + BS, ry1 = by + BS
  let inRectBefore = 0, inRectAfter = 0
  for (let y = ry0; y < ry1; y++) {
    const b = y * w
    for (let x = rx0; x < rx1; x++) {
      if (changed(baseNd, b + x)) inRectBefore++
      if (changed(manNd, b + x)) inRectAfter++
    }
  }
  // B. 区外回归
  let regressed = 0
  for (let p = 0; p < n; p++) {
    const y = (p / w) | 0, x = p - y * w
    if (x >= rx0 && x < rx1 && y >= ry0 && y < ry1) continue
    if (changed(baseNd, p) && !changed(manNd, p)) regressed++
  }
  // C. 掩外损伤
  let outsideMask = 0
  for (let p = 0; p < n; p++) {
    if (man.mask.data[p] > 127) continue
    if (changed(baseNd, p) !== changed(manNd, p)) outsideMask++
  }

  // ⭐ v20.9 验收口径第三次修正：机制从「整框并入」改成「框内笔迹像素」。
  //   读取路径：`manualRejected` 已随拒擦机制一起删除（判据实测不成立）。
  //   现在看 `manualStrokeRatio`（框内被判为笔迹的像素占比）——
  //   它**不是**拒擦依据，只用于交叉验证"擦除范围没有超出框"。
  const dbg = (man.mask.debug ?? {}) as Record<string, unknown>
  const topDbg = (man.debug ?? {}) as Record<string, unknown>
  const mergedCount = Number(dbg.manualRects ?? topDbg.manualRects ?? 0)
  const addedPx = Number(dbg.manualAddedPx ?? 0)
  const strokeRatio = Number(dbg.manualStrokeRatio ?? 0)

  const eraseInRect = inRectAfter - inRectBefore
  // A. 框选补擦必须生效（不再有"拒擦"这条路径）
  const A_pass = eraseInRect > 0
  // D. ⭐ 新增硬校验：**擦除范围不得超出框**。
  //   整框并入时框内像素 100% 被重绘（照片涂白）；
  //   笔迹像素机制下该比例应显著 < 1（框内亮部留作参考）。
  //   实测文字区笔迹占比约 20~60%；照片区才接近 1。
  //   这里只断言「确实不是全框」（>0.99 即视为异常），具体水位交给目检。
  const D_notWholeBox = strokeRatio < 0.99

  let cov = 0
  for (let p = 0; p < n; p++) if (man.mask.data[p] > 127) cov++

  const tag = mergedCount > 0 ? '并入' : '未并入'
  console.error(
    `[${file}/${caseTag}] ${tag}=${mergedCount} 笔迹占比=${(strokeRatio * 100).toFixed(0)}% ` +
    `框内擦除=${eraseInRect} 区外回归=${regressed} 掩外变化=${outsideMask}` +
    (addedPx ? ` 新增mask=${addedPx}px` : ''),
  )

  return {
    file, case: caseTag, changeTH: TH,
    rect: `${bx},${by} ${BS}x${BS}`,
    rectMidRatio: boxMid, rectDarkPx: darkPx,
    regionsSent: regions,
    path: '笔迹像素机制（矩形仅为搜索范围）',
    manualMerged: mergedCount,
    manualAddedPx: addedPx,
    manualStrokeRatio: strokeRatio,
    A_eraseInRect: eraseInRect,
    A_expectation: '>0（框选补擦生效）',
    A_pass,
    B_regressedOutside: regressed,
    B_pass: regressed === 0,
    C_outsideMaskChanged: outsideMask,
    C_pass: outsideMask === 0,
    D_strokeRatio: strokeRatio,
    D_notWholeBox,
    D_pass: D_notWholeBox,
    coverageAfter: +(cov / n).toFixed(5),
  }
}

main().catch((e) => { console.error(e); process.exit(1) })