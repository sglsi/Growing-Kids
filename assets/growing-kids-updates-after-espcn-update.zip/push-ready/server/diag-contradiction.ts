/**
 * 矛盾定位：两个探针对同一区域给出相反结论
 * ============================================================
 * probe-attribution.ts : 纯印刷体区（中栏正文）框内暗像素在 base.mask 里占 **0%**
 * probe-print-damage.ts: 同一区域框选后暗像素 **100% 变纸面**
 *
 * 两个结论不可能同时成立。逐一验证：
 *   假设 1：inpaint 把 mask 外的像素也改了（→ 问题在inpaint/混合层，不在 mask）
 *   假设 2：mergeManualRects 的笔画条件没生效（→ 代码没走到）
 *   假设 3：两个探针算的 "暗像素" 定义不同（paperL-42 vs 别的东西）
 *   假设 4：base.mask 在两次调用里不同（有随机性/状态污染）
 *
 * 直接把 mask 落盘 + 逐像素计数，一次分辨全部。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN = '/workspace/wrongq-test'
const OUT = '/workspace/v20-框选E2E/v209/diag'
const BOX: [number, number, number, number] = [280, 250, 330, 300]  // page31 中栏正文
const FILE = 'page31.png'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  const buf = fs.readFileSync(`${IN}/${FILE}`)
  const { data: od, info } = await raw(buf)
  const { data: g0 } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
  const w = info.width, h = info.height

  const ls: number[] = []
  for (let p = 0; p < g0.length; p += 7) ls.push(g0[p])
  ls.sort((a, b) => a - b)
  const paperL = ls[Math.floor(ls.length * 0.98)]

  const base = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
  const regions = [{
    x: +(BOX[0] / w).toFixed(4), y: +(BOX[1] / h).toFixed(4),
    w: +((BOX[2] - BOX[0] + 1) / w).toFixed(4),
    h: +((BOX[3] - BOX[1] + 1) / h).toFixed(4),
  }]
  const man = await buildHandwritingMask(buf, '', {}, {
    allowVlm: false, eraseMode: 'hybrid', manualRects: regions,
  })

  let dark = 0, inBase = 0, inMan = 0, addedByManual = 0
  for (let y = BOX[1]; y <= BOX[3]; y++) {
    for (let x = BOX[0]; x <= BOX[2]; x++) {
      const p = y * w + x
      const b = base.mask.data[p] > 127
      const m = man.mask.data[p] > 127
      if (m && !b) addedByManual++
      if (g0[p] >= paperL - 42) continue
      dark++
      if (b) inBase++
      if (m) inMan++
    }
  }
  const area = (BOX[2] - BOX[0] + 1) * (BOX[3] - BOX[1] + 1)
  console.log(JSON.stringify({
    paperL: Math.round(paperL), 框面积: area,
    框内暗像素: dark,
    暗像素在base: inBase,
    暗像素在man: inMan,
    框选新增mask: addedByManual,
    全图base覆盖: +(base.mask.coverage).toFixed(5),
    全图man覆盖: +(man.mask.coverage).toFixed(5),
    框内man覆盖: +(inMan / area).toFixed(4),
  }, null, 1))

  // 落盘 mask 供目检
  const cw = BOX[2] - BOX[0] + 1, ch = BOX[3] - BOX[1] + 1
  await sharp(Buffer.from(man.mask.data), { raw: { width: w, height: h, channels: 1 } })
    .extract({ left: BOX[0], top: BOX[1], width: cw, height: ch })
    .resize({ width: cw * 10, kernel: 'nearest' }).png().toFile(`${OUT}/man-mask.png`)
  await sharp(Buffer.from(base.mask.data), { raw: { width: w, height: h, channels: 1 } })
    .extract({ left: BOX[0], top: BOX[1], width: cw, height: ch })
    .resize({ width: cw * 10, kernel: 'nearest' }).png().toFile(`${OUT}/base-mask.png`)

  // 假设 1：inpaint 是否改了 mask 外像素？
  const baseImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', base.mask), base.mask)
  const manImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)
  const { data: gB } = await sharp(baseImg).grayscale().raw().toBuffer({ resolveWithObject: true })
  const { data: gM } = await sharp(manImg).grayscale().raw().toBuffer({ resolveWithObject: true })
  let outsideChanged = 0
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const p = y * w + x
      if (man.mask.data[p] > 127) continue
      if (Math.abs(gB[p] - gM[p]) > 24) outsideChanged++
    }
  }
  console.log(JSON.stringify({ 掩外像素变化数: outsideChanged }))
  void od
}

main().catch((e) => { console.error(e); process.exit(1) })