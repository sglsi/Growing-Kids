/**
 * 错题区域提取（Path B）+ 去手写 v19 完成度检测机制（wrongq-guard）
 * ============================================================
 * 作用：判定本轮三项任务是否全部完成，供 10 分钟周期自检调用。
 *
 *   任务1：路径 B 推进（三栏版面 → 红笔证据 → 题目块 → 语义判定）
 *   任务2：优化去手写（v19：chromaMin 14 + 印刷红家具排除 + 闭运算细化）
 *         并在英语灰报 4 张图上验证
 *   任务3：本检测机制自身（每 10 分钟一次，完成后自终止）
 *
 * 设计铁律（沿用 task-guard / p1-guard，源自历史「出错停止」事故复盘）：
 *  1. **永不崩溃**：每个检查项独立 try/catch；异常只把该项记为未完成，绝不整体退出。
 *  2. **超时即未完成**：子命令超时不抛出，按缺数据记为 incomplete。
 *  3. **绝不读取图像本体**：只做文本/命令行/结构化 JSON 校验（历史事故多由读大图截断引起）。
 *     图像相关的判据一律由探针子进程输出 GUARD JSON 行，本脚本只解析文本。
 *  4. 结果双写：人类可读打印 + 机器可读 JSON（供循环脚本解析）。
 *
 * 用法：npx tsx wrongq-guard.ts   → 全部通过时 exit 0
 */
import { execSync } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'

const SERVER = '/workspace/push-ready/server'
const DOC_DESIGN = '/workspace/错题区域提取-程序设计.md'
const DOC_ERASE = '/workspace/去手写功能-方法论与技术方案.md'
const RESULT_JSON = '/workspace/wrongq-guard-result.json'

/** 安全执行：超时/异常都返回 {ok:false}，绝不抛出 */
function safeExec(cmd: string, timeoutMs = 240_000): { ok: boolean; out: string } {
  try {
    const out = execSync(cmd, {
      cwd: SERVER,
      timeout: timeoutMs,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      maxBuffer: 64 * 1024 * 1024,
    })
    return { ok: true, out: String(out ?? '') }
  } catch (e: unknown) {
    const err = e as { stdout?: string | Buffer; stderr?: string | Buffer; message?: string }
    return { ok: false, out: `${err.stdout ?? ''}${err.stderr ?? ''}` || String(err.message ?? 'exec failed') }
  }
}

function readFileOr(path: string, fallback = ''): string {
  try {
    return existsSync(path) ? readFileSync(path, 'utf8') : fallback
  } catch {
    return fallback
  }
}

/** 文件是否包含全部给定片段 */
function hasAll(file: string, needles: string[]): { ok: boolean; missing: string[] } {
  const src = readFileOr(file)
  const missing = needles.filter((n) => !src.includes(n))
  return { ok: src.length > 0 && missing.length === 0, missing }
}

/** 从探针 stdout 中抽取全部 GUARD JSON 行 */
function guardLines(out: string): Array<Record<string, unknown>> {
  const rows: Array<Record<string, unknown>> = []
  for (const line of out.split('\n')) {
    const i = line.indexOf('GUARD ')
    if (i < 0) continue
    try {
      rows.push(JSON.parse(line.slice(i + 6).trim()))
    } catch {
      /* 忽略非 JSON 行 */
    }
  }
  return rows
}

interface CheckResult {
  id: string
  name: string
  ok: boolean
  detail: string
}

function guard(id: string, name: string, fn: () => CheckResult): CheckResult {
  try {
    return fn()
  } catch (e: unknown) {
    return { id, name, ok: false, detail: `检查异常：${String((e as Error)?.message ?? e)}` }
  }
}

const checks: CheckResult[] = []

/**
 * 探针结果缓存：同一探针在本次 guard 内只真跑一次（4 个检查项复用同一份输出）。
 * 缓存 {ok:false} 也照样缓存——避免失败时反复重试拖垮 10 分钟节拍。
 */
const probeCache = new Map<string, { ok: boolean; out: string }>()
function probeOnce(cmd: string, timeoutMs: number): { ok: boolean; out: string } {
  const hit = probeCache.get(cmd)
  if (hit) return hit
  const r = safeExec(cmd, timeoutMs)
  probeCache.set(cmd, r)
  return r
}

// ══════════ 任务1：路径 B ══════════

// ── C1 Path B 模块齐全 ────────────────────────────────────
checks.push(
  guard('C1', 'Path B 模块齐全（8 文件 + 关键导出）', () => {
    const files = [
      'src/image/wrongq.types.ts',
      'src/image/wrongq-layout.ts',
      'src/image/wrongq-mark.ts',
      'src/image/wrongq-block.ts',
      'src/image/wrongq-decide.ts',
      'src/image/wrongq-vlm.ts',
      'src/image/wrongq-render.ts',
      'src/image/wrongq.ts',
    ]
    const missing = files.filter((f) => !existsSync(`${SERVER}/${f}`))
    if (missing.length) return { id: 'C1', name: 'Path B 模块', ok: false, detail: `缺失文件：${missing.join(', ')}` }
    // 用正则匹配，容忍 sync / async 声明差异（硬编码 "export function X" 会因 async 误判）
    const exp = [
      ['src/image/wrongq-layout.ts', 'buildLayoutContext'],
      ['src/image/wrongq-mark.ts', 'detectRedMarks'],
      ['src/image/wrongq-block.ts', 'buildBlocks'],
      ['src/image/wrongq-decide.ts', 'decideLocal'],
      ['src/image/wrongq-vlm.ts', 'parseVlmItems'],
      ['src/image/wrongq.ts', 'extractWrongQuestions'],
    ] as const
    const missExp = exp
      .filter(([f, name]) => !new RegExp(`export\\s+(async\\s+)?function\\s+${name}\\b`).test(readFileOr(`${SERVER}/${f}`)))
      .map(([, name]) => name)
    return {
      id: 'C1',
      name: 'Path B 模块',
      ok: missExp.length === 0,
      detail: missExp.length ? `缺失导出：${missExp.join(', ')}` : '8 个模块齐备，关键导出完整',
    }
  }),
)

// ── C2 service + controller 接线 ─────────────────────────
checks.push(
  guard('C2', 'service/controller 已接线（POST image/wrongq）', () => {
    const s = hasAll(`${SERVER}/src/image/image.service.ts`, ['extractWrongQuestions', 'buildLayoutContext', 'async wrongq('])
    if (!s.ok) return { id: 'C2', name: 'service 接线', ok: false, detail: `service 缺失：${s.missing.join(', ')}` }
    const c = hasAll(`${SERVER}/src/image/image.controller.ts`, ["@Post('wrongq')", 'imageService.wrongq'])
    return {
      id: 'C2',
      name: 'service/controller 接线',
      ok: c.ok,
      detail: c.ok ? 'service.wrongq + @Post(wrongq) 已接线' : `controller 缺失：${c.missing.join(', ')}`,
    }
  }),
)

// ── C3 DTO 参数 ──────────────────────────────────────────
checks.push(
  guard('C3', 'DTO 支持 wrongq_chroma_min / allow_vlm / assets', () => {
    const r = hasAll(`${SERVER}/src/image/image.types.ts`, ['wrongq_chroma_min', 'wrongq_allow_vlm', 'wrongq_assets'])
    return { id: 'C3', name: 'DTO 参数', ok: r.ok, detail: r.ok ? '三参数齐备' : `缺失：${r.missing.join(', ')}` }
  }),
)

// ── C4 三栏分割实测（4 页全为 3 栏且各栏都能切出行）────────
checks.push(
  guard('C4', '三栏分割实测：4 页均 3 栏、每栏均有行', () => {
    const r = probeOnce('npx tsx probe-wrongq-b.ts', 900_000)
    if (!r.ok) return { id: 'C4', name: '三栏分割实测', ok: false, detail: `探针未跑通：${String(r.out).slice(0, 200)}` }
    const rows = guardLines(r.out).filter((x) => typeof x.file === 'string' && Array.isArray(x.cols))
    if (rows.length < 4) {
      const errs = guardLines(r.out).filter((x) => x.error)
      return { id: 'C4', name: '三栏分割实测', ok: false, detail: `仅 ${rows.length} 页有效${errs.length ? '；错误：' + JSON.stringify(errs[0]) : ''}` }
    }
    const bad = rows.filter((x) => {
      const cols = x.cols as number[]
      const rowCounts = (x.colRowCounts as number[]) ?? []
      return cols.length !== 3 || rowCounts.length !== 3 || rowCounts.some((n) => n <= 0)
    })
    const desc = rows.map((x) => `${x.file}:栏宽[${(x.cols as number[]).join('/')}]行[${(x.colRowCounts as number[]).join('/')}]`).join('  ')
    return {
      id: 'C4',
      name: '三栏分割实测',
      ok: bad.length === 0,
      detail: bad.length ? `异常页 ${bad.length} 个 → ${desc}` : desc,
    }
  }),
)

// ── C5 题目块产出实测（每页 ≥10 块，合计 ≥60）──────────────
checks.push(
  guard('C5', '题目块产出实测：每页 ≥10 块、合计 ≥60', () => {
    const r = probeOnce('npx tsx probe-wrongq-b.ts', 900_000)
    if (!r.ok) return { id: 'C5', name: '题目块实测', ok: false, detail: `探针未跑通：${String(r.out).slice(0, 200)}` }
    const rows = guardLines(r.out).filter((x) => typeof x.file === 'string' && x.blocks && typeof x.blocks === 'object')
    if (rows.length < 4) return { id: 'C5', name: '题目块实测', ok: false, detail: `仅 ${rows.length} 页有效` }
    const per = rows.map((x) => ({ f: String(x.file), n: Number((x.blocks as Record<string, unknown>).count ?? 0) }))
    const total = per.reduce((s, p) => s + p.n, 0)
    const min = Math.min(...per.map((p) => p.n))
    return {
      id: 'C5',
      name: '题目块实测',
      ok: total >= 60 && min >= 10,
      detail: `合计 ${total} 块（${per.map((p) => `${p.f}:${p.n}`).join(' ')}）；最小页 ${min}`,
    }
  }),
)

// ── C6 红笔 mask 家具排除生效（每页都剔除了家具且仍有足够批注）──
checks.push(
  guard('C6', '红笔 mask 家具排除生效（每页家具 ≥1、批注 ≥20）', () => {
    const r = probeOnce('npx tsx probe-wrongq-b.ts', 900_000)
    if (!r.ok) return { id: 'C6', name: '红笔家具排除', ok: false, detail: `探针未跑通：${String(r.out).slice(0, 200)}` }
    const rows = guardLines(r.out).filter((x) => typeof x.file === 'string' && x.red && typeof x.red === 'object')
    if (rows.length < 4) return { id: 'C6', name: '红笔家具排除', ok: false, detail: `仅 ${rows.length} 页有效` }
    const bad = rows.filter((x) => {
      const red = x.red as Record<string, unknown>
      return Number(red.furniture ?? 0) < 1 || Number(red.marks ?? 0) < 20
    })
    const desc = rows.map((x) => {
      const red = x.red as Record<string, unknown>
      return `${x.file}:批注${red.marks}/家具${red.furniture}`
    }).join('  ')
    return {
      id: 'C6',
      name: '红笔家具排除',
      ok: bad.length === 0,
      detail: bad.length ? `异常页 ${bad.length} 个 → ${desc}` : desc,
    }
  }),
)

// ── C7 VLM 适配器：契约测试通过 + 真实调用 fail-open ────────
checks.push(
  guard('C7', 'VLM 适配器：契约通过且真实调用 fail-open（不伪造）', () => {
    const r = probeOnce('npx tsx probe-wrongq-b.ts', 900_000)
    if (!r.ok) return { id: 'C7', name: 'VLM 适配器', ok: false, detail: `探针未跑通：${String(r.out).slice(0, 200)}` }
    const rows = guardLines(r.out)
    const ct = rows.find((x) => x.contract === 'parseVlmItems')
    const vp = rows.find((x) => x.vlmProbe && typeof x.vlmProbe === 'object')
    const ctOk = ct?.ok === true && Number(ct.items ?? 0) === 2
    const vpObj = (vp?.vlmProbe ?? {}) as Record<string, unknown>
    // 本环境无 COZE_API_TOKEN：期望 used=false 且给出 error（即 fail-open 而非伪造结果）
    const vpOk = vpObj.used === false && typeof vpObj.error === 'string' && String(vpObj.error).length > 0
    return {
      id: 'C7',
      name: 'VLM 适配器',
      ok: ctOk && vpOk,
      detail: `契约 ok=${ct?.ok}/items=${ct?.items}；真实调用 used=${vpObj.used} error=${String(vpObj.error ?? '—').slice(0, 80)}`,
    }
  }),
)

// ══════════ 任务2：去手写 v19 ══════════

// ── C8 v19 代码落地（refineColorEraseMask + chromaMin 14 + 导出 closeInk3x3）──
checks.push(
  guard('C8', 'v19 代码落地（家具排除 + chromaMin14 + 导出 closeInk3x3）', () => {
    const m = hasAll(`${SERVER}/src/image/handwriting-mask.ts`, [
      'export function refineColorEraseMask',
      'furnitureDomains',
      'closeInk3x3',
      'growPx',
    ])
    if (!m.ok) return { id: 'C8', name: 'v19 代码落地', ok: false, detail: `handwriting-mask 缺失：${m.missing.join(', ')}` }
    const s = hasAll(`${SERVER}/src/image/handwriting-segmenter.ts`, [
      'refineColorEraseMask',
      'chromaMin: 14',
      'growRadius',
      'growRadius: 2',
    ])
    if (!s.ok) return { id: 'C8', name: 'v19 代码落地', ok: false, detail: `segmenter 缺失：${s.missing.join(', ')}` }
    const l = hasAll(`${SERVER}/src/image/image-layout.ts`, ['export function closeInk3x3'])
    return {
      id: 'C8',
      name: 'v19/v19.2 代码落地',
      ok: l.ok,
      detail: l.ok
        ? 'refineColorEraseMask 已接入 color 分支（chromaMin 14 → 印刷保护 → 家具排除+闭合 → 种子生长 r2/c8 默认开），closeInk3x3 已导出复用'
        : 'image-layout 未导出 closeInk3x3',
    }
  }),
)

// ── C9 v19 四页验证指标（去红率 / 家具保留 / 印刷损伤）───────
checks.push(
  guard('C9', 'v19.2 四页验证：家具保留=1.0、去红率均值≥0.80、损伤≤0.003', () => {
    const r = probeOnce('npx tsx probe-erase-verify.ts', 900_000)
    if (!r.ok) return { id: 'C9', name: 'v19 四页验证', ok: false, detail: `探针未跑通：${String(r.out).slice(0, 200)}` }
    const rows = guardLines(r.out).filter((x) => typeof x.file === 'string' && typeof x.penRemoval === 'number')
    if (rows.length < 4) {
      const errs = guardLines(r.out).filter((x) => x.error)
      return { id: 'C9', name: 'v19 四页验证', ok: false, detail: `仅 ${rows.length} 页有效${errs.length ? '；错误：' + JSON.stringify(errs[0]).slice(0, 160) : ''}` }
    }
    const avgPen = rows.reduce((s, x) => s + Number(x.penRemoval), 0) / rows.length
    const minKeep = Math.min(...rows.map((x) => Number(x.furnitureKeep)))
    const maxDmg = Math.max(...rows.map((x) => Number(x.printDamage)))
    const growAll = rows.every((x) => Number(x.growPx ?? 0) > 0)
    const ok = minKeep >= 0.999 && avgPen >= 0.8 && maxDmg <= 0.003 && growAll
    const desc = rows.map((x) => `${x.file}:去红${x.penRemoval}/家具${x.furnitureKeep}/损伤${x.printDamage}/生长${x.growPx}`).join('  ')
    return {
      id: 'C9',
      name: 'v19.2 四页验证',
      ok,
      detail: `均值去红 ${avgPen.toFixed(3)}（门槛 0.800）、家具保留最低 ${minKeep.toFixed(3)}、印刷损伤最高 ${maxDmg.toFixed(5)}、生长生效=${growAll} → ${desc}`,
    }
  }),
)

// ══════════ 工程质量 & 文档 ══════════

// ── C10 TS 类型检查：本轮改动文件 0 错误 ───────────────────
checks.push(
  guard('C10', 'TS 类型检查：本轮改动文件 0 错误', () => {
    const r = safeExec('npx tsc --noEmit', 600_000)
    const out = String(r.out ?? '')
    const touched = [
      'src/image/wrongq',
      'src/image/handwriting-mask.ts',
      'src/image/handwriting-segmenter.ts',
      'src/image/image-layout.ts',
      'src/image/image.service.ts',
      'src/image/image.controller.ts',
      'src/image/image.types.ts',
    ]
    const errs = out.split('\n').filter((l) => /error TS\d+/.test(l) && touched.some((t) => l.includes(t)))
    return {
      id: 'C10',
      name: 'TS 类型检查',
      ok: errs.length === 0,
      detail: errs.length ? `${errs.length} 处：${errs[0].slice(0, 160)}` : '本轮改动文件无类型错误（项目内既有无关错误不计入）',
    }
  }),
)

// ── C11 文档写回 ─────────────────────────────────────────
checks.push(
  guard('C11', '两份文档均已写回本轮结论', () => {
    const d = readFileOr(DOC_DESIGN)
    const dOk = d.includes('6.3') && d.includes('chromaMin') && d.includes('14')
    const e = readFileOr(DOC_ERASE)
    const eOk =
      e.includes('5.13') && e.includes('5.14') &&
      e.includes('refineColorEraseMask') && e.includes('印刷红家具保留率') &&
      e.includes('种子生长')
    return {
      id: 'C11',
      name: '文档写回',
      ok: dOk && eOk,
      detail: `程序设计.md(v6/chromaMin14)=${dOk}；去手写方法论.md(§5.13 v19 + §5.14 v19.1反证/v19.2 生长)=${eOk}`,
    }
  }),
)

const passed = checks.filter((c) => c.ok).length
const failed = checks.filter((c) => !c.ok)

console.log('\n════ 错题 Path B + 去手写 v19 完成度检测 ════')
for (const c of checks) console.log(`${c.ok ? '✅' : '⬜'} ${c.id} ${c.name} — ${c.detail}`)
console.log(`\n通过 ${passed}/${checks.length}`)

writeFileSync(
  RESULT_JSON,
  JSON.stringify(
    { ts: new Date().toISOString(), passed, total: checks.length, done: failed.length === 0, checks },
    null,
    2,
  ),
)
console.log(`结果写入 ${RESULT_JSON}`)

if (failed.length === 0) {
  console.log('\n🎉 本轮三项任务全部完成，检测机制终止。')
  process.exit(0)
}
process.exit(1)
