/**
 * v20.9 · 版面度量校准（真实字高/字宽/行距）
 * ============================================================
 * 背景：槽位探针 v1（`probe-slot-feasible.ts`）检出率几乎为零，根因是**度量失真**：
 *   · 用 `estimateCharMetrics` 的 medH，原始值高达 105，经 buildLayoutContext
 *     同口径双源钳位（prior=w/70=14.6，区间 [11.7, 29.3]）后仍被钳到 **29.3**
 *   · 而报纸正文字高**实测仅 6~7px** —— 筛选条件 `bh >= medH*1.6 = 47px`
 *     完全对不上实际括号（约 7~10px 高），槽位自然检不出。
 *   · 另：`CharMetrics` **没有 medW 字段**（只有 medH/strokeWidth/rowPitch），
 *     v1 直接引用 `fm.medW` → undefined → `medW` 变 NaN → 所有宽度条件恒 false。
 *
 * 教训（与行墨量守恒探针的 medH 翻车同源）：
 *   **钳位只能压制离谱值，不能凭空产生正确值。**
 *   当一个"权威度量"与目检矛盾时，正确做法是**回到像素重新量**，
 *   而不是给它加更宽的钳位区间。
 *
 * 本探针：不依赖任何既有度量函数，直接从**原图连通域**统计字形分布。
 *   ① 连通域按面积过滤：排除图形/照片区（面积大）、排除噪点（面积过小）
 *   ② 高度取众数区间（字符高度集中，行距/栏宽不集中）
 *   ③ 行距由行投影的峰间距得出（与字符高度独立，可交叉验证）
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { connectedComponents, closeInk3x3 } from './src/image/image-layout'
import { estimateCharMetrics } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

function otsu(g: Buffer): number {
  const hist = new Int32Array(256)
  for (let i = 0; i < g.length; i++) hist[g[i]]++
  const total = g.length
  let sum = 0
  for (let i = 0; i < 256; i++) sum += i * hist[i]
  let sumB = 0, wB = 0, best = 0, bt = 128
  for (let t = 0; t < 256; t++) {
    wB += hist[t]
    if (!wB) continue
    const wF = total - wB
    if (!wF) break
    sumB += t * hist[t]
    const mB = sumB / wB, mF = (sum - sumB) / wF
    const v = wB * wF * (mB - mF) * (mB - mF)
    if (v > best) { best = v; bt = t }
  }
  return bt
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  const out: any[] = []

  for (const file of files) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: g, info } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height, n = w * h
    const thr = otsu(g)
    const ink = new Uint8Array(n)
    for (let i = 0; i < n; i++) ink[i] = g[i] < thr ? 1 : 0
    const inkC = closeInk3x3(ink, w, h)
    const { comps } = connectedComponents(inkC, w, h, false)

    // ① 过滤：面积 ≥3（去噪点）、≤ 400px（去图形/照片）、宽高都 ≤ 60px（去长横线/竖线）
    const glyphs: Array<{ bw: number; bh: number; n: number }> = []
    for (const c of comps) {
      const bw = c.x1 - c.x0 + 1, bh = c.y1 - c.y0 + 1
      if (c.n < 3) continue
      if (c.n > 400) continue
      if (bw > 60 || bh > 60) continue
      // 排除长横线（宽高比极端）：字符宽高比通常在 [0.2, 5]
      if (bw / bh > 5 || bh / bw > 5) continue
      glyphs.push({ bw, bh, n: c.n })
    }

    const med = (a: number[]) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[s.length >> 1] : 0 }
    const pct = (a: number[], p: number) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor(s.length * p)] : 0 }

    const bhs = glyphs.map((c) => c.bh)
    const bws = glyphs.map((c) => c.bw)
    const medH = med(bhs)
    const medW = med(bws)
    // 众数（按 1px 桶）比中位数更能代表"正文字高"（中位数会被少量大字符拉偏）
    const histH = new Int32Array(80)
    for (const b of bhs) if (b < 80) histH[b]++
    let modeH = 0, modeCnt = 0
    for (let i = 0; i < 80; i++) if (histH[i] > modeCnt) { modeCnt = histH[i]; modeH = i }
    const histW = new Int32Array(80)
    for (const b of bws) if (b < 80) histW[b]++
    let modeW = 0, modeCntW = 0
    for (let i = 0; i < 80; i++) if (histW[i] > modeCntW) { modeCntW = histW[i]; modeW = i }

    // ② 行距：行投影找峰，峰间距的中位数
    const rowInk = new Int32Array(h)
    for (let y = 0; y < h; y++) {
      const b = y * w
      for (let x = 0; x < w; x++) if (inkC[b + x]) rowInk[y]++
    }
    const rowMax = Math.max(...rowInk)
    const th = rowMax * 0.25
    const spans: Array<{ y0: number; y1: number }> = []
    let s = -1
    for (let y = 0; y < h; y++) {
      if (rowInk[y] > th && s < 0) s = y
      else if (rowInk[y] <= th && s >= 0) { if (y - s >= 2) spans.push({ y0: s, y1: y - 1 }); s = -1 }
    }
    const pitches: number[] = []
    for (let i = 1; i < spans.length; i++) pitches.push(spans[i].y0 - spans[i - 1].y0)
    const medPitch = med(pitches)

    // ③ 对照：权威函数的返回值（证明它失真）
    const fm = await estimateCharMetrics(buf)
    const prior = w / 70
    const clampH = Math.max(prior * 0.8, Math.min(prior * 2.0, fm.medH))

    const r = {
      file, size: `${w}x${h}`, thr,
      glyphComps: glyphs.length,
      // ★ 实测（本探针的核心产出）
      modeH, modeW, medH, medW,
      bh_p10: pct(bhs, 0.1), bh_p50: pct(bhs, 0.5), bh_p90: pct(bhs, 0.9),
      bw_p10: pct(bws, 0.1), bw_p50: pct(bws, 0.5), bw_p90: pct(bws, 0.9),
      medRowPitch: medPitch,
      spanCount: spans.length,
      // 对照：权威函数（失真证据）
      estimateCharMetrics_medH: fm.medH,
      estimateCharMetrics_strokeWidth: fm.strokeWidth,
      estimateCharMetrics_rowPitch: fm.rowPitch,
      clampedMedH: +clampH.toFixed(1),
      // 失真倍数：钳位值 / 实测众数
      distortion: modeH ? +(clampH / modeH).toFixed(2) : null,
    }
    out.push(r)
    console.error(`[${file}] 实测 modeH=${modeH} modeW=${modeW} 行距=${medPitch} | 权威 medH=${fm.medH}→钳位${clampH.toFixed(1)} (失真 ${r.distortion}x)`)
  }

  console.log('RESULT ' + JSON.stringify(out, null, 1))
  // ── G1 量级门禁：关键量的合理区间（治"数字合法但结论荒谬"）──
  // 区间来自 probe-metrics-calib 自身的实测（报纸版面 1024x1365）
  // 失真警示：estimateCharMetrics.medH 实测 48~105，若用它的值做筛选条件会失真 2.7~2.9x
  console.error('GUARD_RANGE ' + JSON.stringify({
    modeH: [5, 20],      // 报纸正文字高（实测 10~11）
    modeW: [4, 30],      // 字宽（实测 6~14）
    medRowPitch: [8, 40], // 行距（实测 17~19）
  }))
}

main().catch((e) => { console.error(e); process.exit(1) })
