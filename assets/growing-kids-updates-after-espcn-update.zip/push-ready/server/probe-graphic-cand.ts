/**
 * 图形区判据标定 · 第 0 步 b：候选框目视确认
 * ============================================================
 * 背景：probe-graphic-annot 已证明"靠坐标猜标注"必然错（7 个图形标注里 5 个是文字）。
 *   本脚本从整页缩略图目测出候选坐标，裁出放大 6 倍拼网格，
 *   由我目视逐格确认"图形/文字/空白" —— **确认结果落盘为标注文件**，
 *   之后所有判据标定都读该文件，消除标注漂移。
 *
 * ⚠️ 本脚本只负责"让我看清每个候选框到底是什么"，不做任何判据计算。
 */
import sharp from 'sharp'
import * as fs from 'fs'

const IN_DIR = '/workspace/wrongq-test'
const OUT = '/workspace/v20-框选E2E/zoom'

interface Cand { file: string; box: [number, number, number, number]; guess: string }

const CAND: Cand[] = [
  // ── 从整页缩略图目测的"疑似图形" ──
  { file: 'page28.png', box: [690, 60, 740, 110], guess: '页眉插画' },
  { file: 'page28.png', box: [300, 250, 350, 300], guess: 'Reading小照片' },
  { file: 'page28.png', box: [255, 255, 306, 306], guess: '已知照片' },
  { file: 'page28.png', box: [430, 300, 480, 350], guess: '面具照?' },
  { file: 'page29.png', box: [360, 150, 410, 200], guess: '表格区' },
  { file: 'page29.png', box: [440, 150, 490, 200], guess: '表格区2' },
  { file: 'page30.png', box: [680, 90, 730, 140], guess: '页眉插画' },
  { file: 'page30.png', box: [310, 570, 360, 620], guess: '线描图A' },
  { file: 'page30.png', box: [400, 570, 450, 620], guess: '线描图C' },
  { file: 'page30.png', box: [390, 1270, 440, 1320], guess: '选项图片' },
  { file: 'page30.png', box: [390, 1310, 440, 1360], guess: '选项图片2' },
  { file: 'page31.png', box: [60, 60, 110, 110], guess: '页眉文字?' },
  // ── 疑似纯文字 ──
  { file: 'page28.png', box: [60, 330, 110, 380], guess: '左栏英文段落' },
  { file: 'page29.png', box: [55, 100, 105, 150], guess: '左栏正文' },
  { file: 'page30.png', box: [55, 1050, 105, 1100], guess: '左栏正文' },
  { file: 'page31.png', box: [280, 250, 330, 300], guess: '中栏正文' },
  { file: 'page31.png', box: [700, 300, 750, 350], guess: '右栏手写区' },
  { file: 'page29.png', box: [700, 620, 750, 670], guess: '右栏红笔区' },
  { file: 'page29.png', box: [660, 1220, 710, 1270], guess: '底部署名区' },
]

const ZOOM = 6, COLS = 5

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  const tiles: Buffer[] = []

  for (let i = 0; i < CAND.length; i++) {
    const c = CAND[i]
    const src = fs.readFileSync(`${IN_DIR}/${c.file}`)
    const cw = c.box[2] - c.box[0] + 1, ch = c.box[3] - c.box[1] + 1
    const cut = await sharp(src).extract({ left: c.box[0], top: c.box[1], width: cw, height: ch })
      .resize({ width: cw * ZOOM, kernel: 'nearest' }).png().toBuffer()
    const W = cw * ZOOM, H = ch * ZOOM
    const framed = await sharp({
      create: { width: W + 4, height: H + 4 + 24, channels: 3, background: { r: 255, g: 255, b: 255 } },
    }).composite([
      { input: cut, left: 2, top: 2 },
      {
        input: Buffer.from(
          `<svg width="${W + 4}" height="${H + 28}">` +
          `<rect width="${W + 4}" height="${H + 28}" fill="none" stroke="#888"/>` +
          `<text x="3" y="${H + 20}" font-size="16" font-weight="bold" fill="#c00">#${i}</text>` +
          `<text x="34" y="${H + 20}" font-size="14" fill="#036">${c.file} ${c.guess}</text>` +
          `</svg>`,
        ), left: 0, top: 0,
      },
    ]).png().toBuffer()
    tiles.push(framed)
  }

  const metas = await Promise.all(tiles.map((t) => sharp(t).metadata()))
  const cellW = Math.max(...metas.map((m) => m.width!)) + 6
  const cellH = Math.max(...metas.map((m) => m.height!)) + 6
  const rows = Math.ceil(tiles.length / COLS)
  const out = await sharp({
    create: { width: cellW * COLS, height: cellH * rows, channels: 3, background: { r: 245, g: 245, b: 245 } },
  }).composite(tiles.map((t, i) => ({
    input: t, left: (i % COLS) * cellW + 3, top: Math.floor(i / COLS) * cellH + 3,
  }))).png().toBuffer()

  const outFile = `${OUT}/cand-grid.png`
  fs.writeFileSync(outFile, out)
  fs.writeFileSync(`${OUT}/cand-list.json`, JSON.stringify(CAND.map((c, i) => ({ no: i, ...c })), null, 1))
  console.log('RESULT ' + JSON.stringify({ out: outFile, n: CAND.length, cell: `${cellW}x${cellH}` }))
  console.error(`候选框对照图: ${outFile} (${COLS}列, 放大${ZOOM}倍)`)
}

main().catch((e) => { console.error(e); process.exit(1) })