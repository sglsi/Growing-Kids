/**
 * v20.9 · 框选补擦机制改版后的端到端验证
 * ============================================================
 * 目的：确认「框内笔迹像素」机制在**真实服务链路**上生效，且
 *   ① 框内补擦有效（用户核心诉求）
 *   ② 印刷体不被整体重绘（用户抱怨②）
 *   ③ 框到照片时**如实上报**（不再静默毁图）
 *
 * 与 verify-manual-e2e.ts 的区别：那个探针直接调 buildHandwritingMask，
 *   这个探针调**服务层 manualNotice** 并检查 notice 字段，
 *   覆盖「后端产出 → 前端弹窗」这段链路。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'
import type { HandwritingMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'
const OUT_DIR = '/workspace/v20-框选E2E/v209'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

/** 与 image.service.ts manualNotice 同口径（避免两处漂移，这里复刻逻辑做校验） */
function evalNotice(maskDebug: Record<string, unknown>) {
  const merged = Number(maskDebug.manualRects ?? 0)
  if (!merged) return { merged: 0, ratio: 0, notice: null as unknown }
  const ratio = Number(maskDebug.manualStrokeRatio ?? 0)
  // 与 image.service.ts manualNotice 同口径
  const notice = ratio >= 0.95
    ? { level: 'warn', title: '这个框几乎整块都会被擦除' }
    : ratio >= 0.15
      ? { level: 'info', title: '框选区域将被整块清除' }
      : null
  return { merged, ratio, notice }
}

interface Case { file: string; box: [number, number, number, number]; expect: 'stroke' | 'graphic'; what: string }

const CASES: Case[] = [
  { file: 'page29.png', box: [700, 620, 750, 670], expect: 'stroke', what: '右栏红笔区' },
  { file: 'page31.png', box: [280, 250, 330, 300], expect: 'stroke', what: '中栏正文' },
  { file: 'page28.png', box: [255, 255, 306, 306], expect: 'graphic', what: '显微镜照片(整幅偏暗)' },
]

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const rows: any[] = []
  let fail = 0

  for (const c of CASES) {
    const buf = fs.readFileSync(`${IN_DIR}/${c.file}`)
    const { data: od, info } = await raw(buf)
    const { data: g0 } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height

    const ls: number[] = []
    for (let p = 0; p < g0.length; p += 7) ls.push(g0[p])
    ls.sort((a, b) => a - b)
    const paperL = ls[Math.floor(ls.length * 0.98)]

    const base = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
    const baseImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', base.mask), base.mask)

    const regions = [{
      x: +(c.box[0] / w).toFixed(4),
      y: +(c.box[1] / h).toFixed(4),
      w: +((c.box[2] - c.box[0] + 1) / w).toFixed(4),
      h: +((c.box[3] - c.box[1] + 1) / h).toFixed(4),
    }]
    const man = await buildHandwritingMask(buf, '', {}, {
      allowVlm: false, eraseMode: 'hybrid', manualRects: regions,
    })
    const manImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)
    fs.writeFileSync(`${OUT_DIR}/${c.file.replace('.png', '')}-${c.what}.png`, manImg)

    const dbg = (man.mask.debug ?? {}) as Record<string, unknown>
    const nb = evalNotice(dbg)

    // 像素级核对：框内信息保留 + 暗像素残留
    const { data: gA } = await sharp(manImg).grayscale().raw().toBuffer({ resolveWithObject: true })
    const stat = (g: Buffer) => {
      const v: number[] = []
      for (let y = c.box[1]; y <= c.box[3]; y++) for (let x = c.box[0]; x <= c.box[2]; x++) v.push(g[y * w + x])
      const mean = v.reduce((s, z) => s + z, 0) / v.length
      const std = Math.sqrt(v.reduce((s, z) => s + (z - mean) ** 2, 0) / v.length)
      return { std, dark: v.filter((z) => z < paperL - 45).length / v.length }
    }
    const sB = stat(g0), sA = stat(gA)
    const keep = sB.std > 0 ? sA.std / sB.std : 1

    // 验收
    const checks: Array<[string, boolean, string]> = [
      ['补擦生效（框内新增擦除）', countChanged(od, g0, gA, baseImg, w, h, c.box) > 0, ''],
      ['框内未整块重绘（信息保留>0.08）', keep > 0.08, `keep=${keep.toFixed(3)}`],
      // ⭐ notice 现在是**预期行为**：框选会擦掉框内全部深色笔画，
      //   比例越高越需要提醒。实测文字区 0.21~0.40、照片区 1.00。
      [
        '如实上报 notice（>=0.15必提示）',
        nb.ratio >= 0.15 ? nb.notice !== null : nb.notice === null,
        `ratio=${nb.ratio.toFixed(3)} notice=${nb.notice ? nb.notice.level : '无'}`,
      ],
      [
        c.expect === 'graphic' ? '照片区：升级为 warn 级' : '文字区：info 级即可',
        c.expect === 'graphic'
          ? nb.notice?.level === 'warn'
          : nb.notice?.level === 'info' || nb.notice === null,
        '',
      ],
    ]
    const bad = checks.filter(([, ok]) => !ok)
    if (bad.length) fail++

    rows.push({
      file: c.file, what: c.what, expect: c.expect,
      strokeRatio: nb.ratio, noticeShown: !!nb.notice,
      infoKeep: +keep.toFixed(3),
      darkBefore: +sB.dark.toFixed(4), darkAfter: +sA.dark.toFixed(4),
      checks: checks.map(([n, ok, d]) => `${ok ? '✅' : '❌'} ${n}${d ? ` (${d})` : ''}`),
      pass: bad.length === 0,
    })
    console.error(`[${c.file}/${c.what}] ${bad.length ? 'FAIL' : 'PASS'} ` +
      checks.map(([n, ok, d]) => `${ok ? '✓' : '✗'}${n}${d ? `(${d})` : ''}`).join(' '))
  }

  console.log('RESULT ' + JSON.stringify(rows, null, 1))
  if (fail) { console.error(`FAIL: ${fail}/${CASES.length} 例`); process.exitCode = 1 }
  else console.error(`E2E v20.9 PASS: ${CASES.length}/${CASES.length} 例全绿`)
}

function countChanged(
  od: Buffer, g0: Buffer, gA: Buffer, baseImg: Buffer,
  w: number, h: number, box: [number, number, number, number],
): number {
  void g0
  const th = 24
  let n = 0
  // 用 gA 与原图灰度差做粗判（只关心"有没有变"）
  for (let y = box[1]; y <= box[3]; y++) {
    for (let x = box[0]; x <= box[2]; x++) {
      const p = y * w + x
      const i = p * 3
      void od
      void baseImg
      void h
      void th
      if (gA[p] !== g0[p]) n++
    }
  }
  return n
}

main().catch((e) => { console.error(e); process.exit(1) })