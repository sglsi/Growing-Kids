/**
 * 错题区域提取 · 前期测试探针 v4（成败关键轮）
 *
 * v3 剩余问题与修正：
 *  R1 字高被插图污染（page28/30 medH 62~66 虚大）→ 双源交叉：
 *     medH_prior = w/70（报纸正文经验值，待标定），medH = clamp(连通域估计, 0.8×prior, 2.0×prior)
 *  R2 行投影被插图/表格大连通域焊死 → 先剔除"图形域"（高>4×medH 或 宽>0.85×w 且高>3×medH）再投影
 *  R3 分栏 gapMin 过大（0.5×medH≈13px > 实际栏隙 8~10px）→ 扫描 0.2/0.3/0.5×medH
 *  产物：GUARD JSON + diag4-*.png（红mask + 栏绿线 + 行蓝线）
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { normalizeIlluminationForDetection, maskFromColorThreshold, segmentTextRows } from './src/image/handwriting-mask'
import { otsuThreshold, connectedComponents, quantileSorted, estimateCharMetrics } from './src/image/image-layout'
import { straightenImage } from './src/image/image-dewarp'

const IN_DIR = '/workspace/wrongq-test'

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const f of files) {
    try {
      await probePage(path.join(IN_DIR, f))
    } catch (e) {
      console.log(`GUARD {"file":"${f}","error":${JSON.stringify(String((e as Error)?.message ?? e))}}`)
    }
  }
}

function buildGray(data: Buffer, w: number, h: number, ch: number) {
  const n = w * h
  const gray = new Uint8Array(n)
  for (let i = 0, p = 0; i < n; i++, p += ch) {
    gray[i] = Math.max(0, Math.min(255, Math.round(0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2])))
  }
  return gray
}

function buildInk(gray: Uint8Array, data: Buffer, ch: number, thr: number, excludeRedChroma = 0) {
  const n = gray.length
  const ink = new Uint8Array(n)
  let redExcluded = 0
  for (let i = 0, p = 0; i < n; i++, p += ch) {
    if (gray[i] >= thr) continue
    if (excludeRedChroma > 0) {
      const r = data[p], g = data[p + 1], b = data[p + 2]
      if (Math.max(r, g, b) - Math.min(r, g, b) >= excludeRedChroma) { redExcluded++; continue }
    }
    ink[i] = 1
  }
  return { ink, redExcluded }
}

/** 剔除图形域：返回剔除后的 ink 与被剔除块列表 */
function stripGraphicDomains(ink: Uint8Array, w: number, h: number, medH: number) {
  const { comps } = connectedComponents(ink, w, h, false)
  const gfx: Array<{ x0: number; x1: number; y0: number; y1: number; n: number; why: string }> = []
  const out = new Uint8Array(ink)
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1
    const bh = c.y1 - c.y0 + 1
    if (bh > 4 * medH && bw > 2 * medH) {
      gfx.push({ x0: c.x0, x1: c.x1, y0: c.y0, y1: c.y1, n: c.n, why: `h=${bh}>4medH` })
    } else if (bw > w * 0.85 && bh > 3 * medH) {
      gfx.push({ x0: c.x0, x1: c.x1, y0: c.y0, y1: c.y1, n: c.n, why: `fullwidth&h=${bh}` })
    } else continue
    for (let y = c.y0; y <= c.y1; y++) {
      const base = y * w
      for (let x = c.x0; x <= c.x1; x++) out[base + x] = 0
    }
  }
  return { ink2: out, gfx }
}

function findCols(ink: Uint8Array, w: number, h: number, colThRatio: number, gapMin: number) {
  const colProfile = new Int32Array(w)
  for (let y = 0; y < h; y++) {
    const base = y * w
    for (let x = 0; x < w; x++) if (ink[base + x]) colProfile[x]++
  }
  const colMax = Math.max(...colProfile)
  const colTh = Math.max(1, Math.round(colMax * colThRatio))
  const gaps: Array<[number, number]> = []
  let x = 0
  while (x < w) {
    if (colProfile[x] > colTh) { x++; continue }
    const x0 = x
    while (x < w && colProfile[x] <= colTh) x++
    if (x - x0 >= gapMin) gaps.push([x0, x])
  }
  const cols: Array<[number, number]> = []
  let cur = 0
  for (const [g0, g1] of gaps) {
    if (g0 > cur) cols.push([cur, g0])
    cur = g1
  }
  if (cur < w) cols.push([cur, w])
  return { gaps, cols }
}

function colRows(ink: Uint8Array, w: number, h: number, x0: number, x1: number, rowThRatio = 0.04) {
  const prof = new Int32Array(h)
  for (let y = 0; y < h; y++) {
    const base = y * w
    let c = 0
    for (let x = x0; x < x1; x++) if (ink[base + x]) c++
    prof[y] = c
  }
  const profMax = Math.max(...prof)
  const th = Math.max(1, Math.round(profMax * rowThRatio))
  const rows: Array<{ y0: number; y1: number; xLeft: number }> = []
  let y = 0
  while (y < h) {
    if (prof[y] < th) { y++; continue }
    const y0 = y
    while (y < h && prof[y] >= th) y++
    let xLeft = x1 - x0
    for (let yy = y0; yy < y && xLeft === x1 - x0; yy++) {
      const base = yy * w
      for (let x = x0; x < x1; x++) if (ink[base + x]) { xLeft = x - x0; break }
    }
    rows.push({ y0, y1: y, xLeft })
  }
  return rows
}

async function probePage(file: string) {
  const buf = fs.readFileSync(file)
  const st = await straightenImage(buf, { auto: true, curved: false })
  const flatBuf = st.buffer ?? buf

  const flatMetrics = await estimateCharMetrics(flatBuf, {})
  const { data, info } = await sharp(flatBuf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
  const w = info.width, h = info.height, ch = info.channels
  const gray = buildGray(data, w, h, ch)
  const thr = otsuThreshold(gray, w * h)

  // ── R1 双源字高 ──
  const prior = w / 70
  const est = flatMetrics.medH > 0 ? flatMetrics.medH : prior
  const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, est))

  // ── R2 剔除图形域后再行投影 ──
  const { ink } = buildInk(gray, data, ch, thr, 22)
  const { ink2, gfx } = stripGraphicDomains(ink, w, h, medH)
  const seg = segmentTextRows(ink2, w, h, { rowProfileRatio: 0.05 })
  const rowHeights = seg.rows.map((r) => r.y1 - r.y0).sort((a, b) => a - b)

  // ── R3 分栏扫描 ──
  const scan: Array<{ gapF: number; gapMin: number; cols: Array<[number, number]> }> = []
  for (const gapF of [0.2, 0.3, 0.5]) {
    const gapMin = Math.max(3, Math.round(medH * gapF))
    const { cols } = findCols(ink2, w, h, 0.01, gapMin)
    scan.push({ gapF, gapMin, cols: cols.filter(([a, b]) => b - a >= medH * 6) })
  }
  const best = scan.slice().sort((a, b) => b.cols.length - a.cols.length)[0]

  // ── 每栏行切分 + 悬挂缩进 ──
  const colDetail = best.cols.map(([a, b], i) => {
    const rows = colRows(ink2, w, h, a, b)
    const merged: Array<{ y0: number; y1: number; xLeft: number }> = []
    for (const r of rows) {
      const last = merged[merged.length - 1]
      if (last && r.y0 - last.y1 <= medH * 0.4) {
        last.y1 = r.y1
        last.xLeft = Math.min(last.xLeft, r.xLeft)
      } else merged.push({ ...r })
    }
    const xs = merged.map((r) => r.xLeft).sort((p, q2) => p - q2)
    const clusters: Array<{ sum: number; count: number }> = []
    for (const x of xs) {
      const last = clusters[clusters.length - 1]
      if (last && x - last.sum / last.count <= medH * 0.6) { last.sum += x; last.count++ }
      else clusters.push({ sum: x, count: 1 })
    }
    const cl = clusters
      .map((c) => ({ center: Math.round(c.sum / c.count), count: c.count }))
      .sort((p, q2) => q2.count - p.count)
      .slice(0, 6)
    const hs = merged.map((r) => r.y1 - r.y0).sort((p, q2) => p - q2)
    return {
      col: i + 1,
      x: [a, b],
      rows: merged.length,
      rowH: { p25: quantileSorted(hs, 0.25), p50: quantileSorted(hs, 0.5), p75: quantileSorted(hs, 0.75) },
      xLeftClusters: cl,
      topFlushShare: cl.length ? +(cl[0].count / Math.max(1, merged.length)).toFixed(2) : 0,
    }
  })

  // ── 红笔统计 ──
  const cm = await maskFromColorThreshold(flatBuf, {})
  const n = w * h
  const mInk = new Uint8Array(n)
  for (let i = 0; i < n; i++) mInk[i] = cm.data[i] ? 1 : 0
  const { comps: mComps } = connectedComponents(mInk, w, h, false)
  const marks = mComps.filter((c) => c.n >= Math.max(8, Math.round(medH * 0.3)))
  const ars = marks.map((c) => (c.x1 - c.x0 + 1) / Math.max(1, c.y1 - c.y0 + 1)).sort((a, b) => a - b)
  const fills = marks.map((c) => c.n / Math.max(1, (c.x1 - c.x0 + 1) * (c.y1 - c.y0 + 1))).sort((a, b) => a - b)
  const areas = marks.map((c) => c.n).sort((a, b) => a - b)

  // ── 诊断图 ──
  const dw = 900
  const dh = Math.round((h / w) * dw)
  const baseRgb = await sharp(flatBuf).resize(dw, dh, { fit: 'fill' }).grayscale().removeAlpha().raw().toBuffer()
  const out = Buffer.alloc(dw * dh * 3)
  for (let i = 0, q3 = 0; i < dw * dh; i++, q3 += 3) {
    const g = baseRgb[i]
    out[q3] = g; out[q3 + 1] = g; out[q3 + 2] = g
  }
  const sx = dw / w, sy = dh / h
  const put = (x: number, y: number, r: number, g: number, b: number) => {
    if (x < 0 || y < 0 || x >= dw || y >= dh) return
    const q3 = (y * dw + x) * 3
    out[q3] = r; out[q3 + 1] = g; out[q3 + 2] = b
  }
  for (let y = 0; y < dh; y++) {
    const my = Math.min(h - 1, Math.round(y / sy))
    for (let x = 0; x < dw; x++) {
      const mx = Math.min(w - 1, Math.round(x / sx))
      if (mInk[my * w + mx]) put(x, y, 255, 30, 30)
    }
  }
  for (const [a, b] of best.cols) {
    for (const gx of [a, b]) {
      const dx = Math.round(gx * sx)
      for (let y = 0; y < dh; y++) put(dx, y, 0, 200, 0)
    }
    const rows2 = colRows(ink2, w, h, a, b)
    for (const r of rows2) {
      const dy = Math.round(r.y0 * sy)
      for (let x = Math.round(a * sx); x <= Math.round(b * sx); x += 2) put(x, dy, 40, 120, 255)
    }
  }
  const diagName = path.join(IN_DIR, 'diag4-' + path.basename(file))
  await sharp(out, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(diagName)

  const q = (a: number[], p: number) => (a.length ? +quantileSorted(a, p).toFixed(2) : 0)
  console.log(
    'GUARD ' +
      JSON.stringify({
        file: path.basename(file),
        size: `${w}x${h}`,
        medH: { prior: +prior.toFixed(1), est: +est.toFixed(1), final: +medH.toFixed(1) },
        gfxStripped: { count: gfx.length, list: gfx.slice(0, 8) },
        rows: {
          count: seg.rows.length,
          rowH: { p25: q(rowHeights, 0.25), p50: q(rowHeights, 0.5), p90: q(rowHeights, 0.9) },
        },
        colScan: scan.map((s) => ({ gapF: s.gapF, cols: s.cols.length, ranges: s.cols })),
        colDetail,
        redMask: {
          coverage: +cm.coverage.toFixed(4),
          marks: marks.length,
          area: { p50: q(areas, 0.5), p90: q(areas, 0.9), max: areas[areas.length - 1] ?? 0 },
          aspect: { p10: q(ars, 0.1), p50: q(ars, 0.5), p90: q(ars, 0.9) },
          fill: { p10: q(fills, 0.1), p50: q(fills, 0.5), p90: q(fills, 0.9) },
        },
        diag: path.basename(diagName),
      }),
  )
}

main().catch((e) => {
  console.error('PROBE FAILED:', e)
  process.exit(1)
})
