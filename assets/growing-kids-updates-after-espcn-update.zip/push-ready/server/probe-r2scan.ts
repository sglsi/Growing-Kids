/**
 * v20.4 · R × minDomainRatio 二维扫描
 * 目标：在「印刷覆盖 ≤0.001」硬约束下，找黑笔覆盖最大的参数组合。
 * 动机：R=28 覆盖 0.73 但印刷 0.4~1%；若同时收紧域包含度（只留完全落在菱形内的域），
 *       能否把 R 提上去而把印刷压回 0？一次扫描同时标定两个参数。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask, normalizeIlluminationForDetection } from './src/image/handwriting-mask'
import { maskFromRedSpatialPrior } from './src/image/red-ink-prior'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])

async function main() {
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height, ch = info.channels, n = w * h
    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const darkTh = (ls[Math.floor(ls.length * 0.9)] || 240) * 0.62

    const pre = await normalizeIlluminationForDetection(buf)
    const cs = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
    const rp = await protectPrintUnderColorHandwriting(buf, cs)
    const rw = await sharp(pre.buffer).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const redRefined = refineColorEraseMask(rp, 10, { grow: { rgb: rw.data, channels: rw.info.channels, radius: 2, chromaMin: 8 } })

    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const near = new Uint8Array(n)
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!redO.data[y * w + x]) continue
      for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
        for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near[yy * w + xx] = 1
    }
    const penSet = new Uint8Array(n), printSet = new Uint8Array(n)
    for (let i = 0; i < n; i++) {
      const p = i * ch
      if (redO.data[i] || chrom(od, p) >= 14 || luma(od, p) >= darkTh) continue
      if (near[i]) penSet[i] = 1; else printSet[i] = 1
    }
    let nPen = 0, nPrint = 0
    for (let i = 0; i < n; i++) { if (penSet[i]) nPen++; if (printSet[i]) nPrint++ }

    const row: Record<string, unknown> = { file }
    for (const R of [24, 28, 32, 36]) {
      const cells: Record<string, unknown> = {}
      for (const ratio of [0.6, 0.8, 1.0]) {
        const b = await maskFromRedSpatialPrior(pre.buffer, { radius: R, redMask: redRefined.data, minDomainRatio: ratio })
        let pen = 0, pr = 0
        for (let i = 0; i < n; i++) {
          if (!b.data[i]) continue
          if (penSet[i]) pen++; else if (printSet[i]) pr++
        }
        cells[`r${ratio}`] = [+(pen / Math.max(1, nPen)).toFixed(3), +(pr / Math.max(1, nPrint)).toFixed(4)]
      }
      row[`R${R}`] = cells
    }
    console.log('GUARD ' + JSON.stringify(row))
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
