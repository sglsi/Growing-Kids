/**
 * v20.2 · mask 归因诊断：hybrid 的 mask 到底圈住了什么？
 * ============================================================
 * 背景：hybrid 把黑笔去除从 0.012 拉到 0.73~0.86，但印刷误删 4~79%，
 *       而 probe-red-prior 单独测菱形 R=24 时报"印刷误删 0"。两者矛盾，
 *       必须定位真实差异来源 —— 不再猜。
 *
 * 本探针直接做**像素归因**，把 mask 的每一个像素分到互斥集合里：
 *   mask ∩ 红笔真值 / mask ∩ 黑笔真值 / mask ∩ 印刷真值 / mask ∩ 纸底
 * 并对以下可疑来源逐项开列：
 *   S1 菱形半径在**光照归一化图**上与**原图**上的差异
 *   S2 红笔 mask 在归一化图上的膨胀（归一化放大彩度 → redPx 暴涨）
 *   S3 墨迹阈值在归一化图上的 basin 变化（darkTh = p90×0.62）
 *   S4 mask ∩ print 到底是"圈内本就有印刷"还是"阈值把印刷也判成墨迹"
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, normalizeIlluminationForDetection } from './src/image/handwriting-mask'
import { maskFromRedSpatialPrior } from './src/image/red-ink-prior'

const IN_DIR = '/workspace/wrongq-test'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}
const L = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const C = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])

function p90(d: Buffer, ch: number, n: number) {
  const a: number[] = []
  for (let i = 0; i < n; i += 37) a.push(L(d, i * ch))
  a.sort((x, y) => x - y)
  return a[Math.floor(a.length * 0.9)] || 240
}

/** 在给定图上建「红笔邻域」(方形 ±R，与 probe 真值口径一致) */
function nearRed(red: Buffer, w: number, h: number, r: number) {
  const near = new Uint8Array(w * h)
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (!red[y * w + x]) continue
      for (let yy = Math.max(0, y - r); yy <= Math.min(h - 1, y + r); yy++)
        for (let xx = Math.max(0, x - r); xx <= Math.min(w - 1, x + r); xx++) near[yy * w + xx] = 1
    }
  }
  return near
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const file of files) {
    const buf = fs.readFileSync(path.join(IN_DIR, file))
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, ch = info.channels, n = w * h
    const paperO = p90(od, ch, n)
    const darkO = paperO * 0.62

    // ── 真值集合（全部基于原图）──────────────────────────
    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const near = nearRed(redO.data, w, h, 24)
    const penSet = new Uint8Array(n)
    const printSet = new Uint8Array(n)
    const paperSet = new Uint8Array(n)
    for (let i = 0; i < n; i++) {
      const p = i * ch
      const c = C(od, p), l = L(od, p)
      if (redO.data[i]) continue
      if (c < 14 && l < darkO) { if (near[i]) penSet[i] = 1; else printSet[i] = 1 }
      else if (l >= darkO) paperSet[i] = 1
    }
    const cnt = (a: Uint8Array) => { let k = 0; for (let i = 0; i < n; i++) if (a[i]) k++; return k }
    const nPen = cnt(penSet), nPrint = cnt(printSet)

    // ── 归一化图（检测用）──────────────────────────────
    const pre = await normalizeIlluminationForDetection(buf)
    const { data: dd } = await raw(pre.buffer)
    const paperD = p90(dd, ch, n)
    const darkD = paperD * 0.62
    const redD = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
    let redDpx = 0, redOpx = 0
    for (let i = 0; i < n; i++) { if (redD.data[i]) redDpx++; if (redO.data[i]) redOpx++ }

    // 归一化图上的墨迹像素数 vs 原图
    let inkD = 0, inkO = 0
    for (let i = 0; i < n; i++) {
      const p = i * ch
      if (C(dd, p) < 14 && L(dd, p) < darkD) inkD++
      if (C(od, p) < 14 && L(od, p) < darkO) inkO++
    }

    // ── 单独跑红笔空间先验（detectBuf / 原图 两种输入）──
    const bD = await maskFromRedSpatialPrior(pre.buffer, { radius: 24 })
    const bO = await maskFromRedSpatialPrior(buf, { radius: 24 })

    // ── hybrid 整体 mask ──────────────────────────────
    const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
    const mk = seg.mask.data

    const attr = (m: Buffer | Uint8Array, name: string) => {
      let pen = 0, pr = 0, rd = 0, pap = 0, tot = 0
      for (let i = 0; i < n; i++) {
        if (!m[i]) continue
        tot++
        if (redO.data[i]) rd++
        else if (penSet[i]) pen++
        else if (printSet[i]) pr++
        else pap++
      }
      return {
        name,
        tot,
        cov: +(tot / n).toFixed(4),
        red: +(rd / Math.max(1, tot)).toFixed(3),
        pen: +(pen / Math.max(1, tot)).toFixed(3),
        print: +(pr / Math.max(1, tot)).toFixed(3),
        paper: +(pap / Math.max(1, tot)).toFixed(3),
        penCovered: +(pen / Math.max(1, nPen)).toFixed(3),
        printCovered: +(pr / Math.max(1, nPrint)).toFixed(3),
      }
    }

    console.log('GUARD ' + JSON.stringify({
      file,
      size: `${w}x${h}`,
      truth: { nPen, nPrint, nPenPct: +(nPen / n * 100).toFixed(2), nPrintPct: +(nPrint / n * 100).toFixed(2) },
      norm: {
        applied: pre.applied,
        paperOrig: +paperO.toFixed(1), paperNorm: +paperD.toFixed(1),
        redPxOrig: redOpx, redPxNorm: redDpx, redRatio: +(redDpx / Math.max(1, redOpx)).toFixed(2),
        inkOrig: inkO, inkNorm: inkD, inkRatio: +(inkD / Math.max(1, inkO)).toFixed(2),
      },
      masks: [
        attr(bD.data, 'prior@norm'),
        attr(bO.data, 'prior@orig'),
        attr(mk, 'hybrid'),
      ],
    }))
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
