/**
 * v20.6 · 受损域特征诊断（回答"凭什么区分黑笔与红笔旁的印刷"）
 * ============================================================
 * 事实前提（probe-line-integrity v4 实测，100% 可信）：
 *   · 纯印刷行保持率 0.953~0.979，损失 3149~6258px，但**掩外为 0**
 *     → 损伤全部由 mask（检测层）越界造成，inpaint 无责。
 *   · 损失高度集中：page28 有一整行 776px 墨被擦 64% → 用户看到的是"成片消失"。
 *   · 菱形 R=24 无差别圈定：红笔**压过**的印刷该擦，红笔**路过**的印刷不该擦，
 *     两者在菱形内无法区分——这才是问题②的真正根因。
 *
 * 本探针目的：验证是否存在可分特征。对每个"受损的印刷域"提取一组特征：
 *   ratioInRegion  域落在菱形内的比例（当前唯一判据）
 *   mixRatio       域内**带彩度**像素比例（红黑混合 → 红笔压过此域）
 *   redInDomRatio  域内红笔像素比例（红笔穿过此域）
 *   distToRed      域内像素到最近红笔的距离中位数
 *   domW/H/N       域形状
 * 若 mixRatio / distToRed 能把"受损印刷域"和"被正确擦除的黑笔域"分开，
 * 就有可用的新判据；分不开，就说明必须换思路（而不是继续调阈值）。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])

async function main() {
  const file = process.argv[2] || 'page28.png'
  const buf = fs.readFileSync(`${IN_DIR}/${file}`)
  const { data: od, info } = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
  const w = info.width, h = info.height, ch = info.channels, n = w * h

  const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
  const m = seg.mask.data

  // 纸面 + 墨迹
  const ls: number[] = []
  for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
  ls.sort((a, b) => a - b)
  const paper = ls[Math.floor(ls.length * 0.9)] || 240
  const darkTh = paper * 0.62
  const ink = new Uint8Array(n)
  for (let i = 0; i < n; i++) { const p = i * ch; if (chrom(od, p) < 14 && luma(od, p) < darkTh) ink[i] = 1 }

  // 红笔（v19 色域精修链，与生产 hybrid 分支完全同口径）
  const chromaSensitive = await maskFromColorThreshold(buf, { chromaMin: 14 })
  const redProtected = await protectPrintUnderColorHandwriting(buf, chromaSensitive)
  const prior = w / 70
  const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, 11))
  const redRef = refineColorEraseMask(redProtected, medH, { growRadius: 2, growChroma: 8 })

  // 距离变换（曼哈顿），用于 distToRed
  let redPx = 0
  const red = new Uint8Array(n)
  for (let i = 0; i < n; i++) if (redRef.data[i] > 127) { red[i] = 1; redPx++ }
  const INF = 1 << 20
  const dist = new Int32Array(n).fill(redPx ? 0 : INF)
  for (let i = 0; i < n; i++) if (red[i]) dist[i] = 0
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = y * w + x; if (red[i]) continue; const l = x > 0 ? dist[i - 1] : INF; const u = y > 0 ? dist[i - w] : INF; const v = l + 1 < u + 1 ? l : u; dist[i] = Math.min(v, INF) }
  for (let y = h - 1; y >= 0; y--) for (let x = w - 1; x >= 0; x--) { const i = y * w + x; if (red[i]) continue; const r = x < w - 1 ? dist[i + 1] : INF; const d = y < h - 1 ? dist[i + w] : INF; const v = r + 1 < d + 1 ? r : d; if (v < dist[i]) dist[i] = v }
  const R = 24
  const region = new Uint8Array(n)
  for (let i = 0; i < n; i++) if (dist[i] <= R) region[i] = 1

  // 连通域
  const { comps } = connectedComponentsLocal(ink, w, h)

  type Row = { n: number; bw: number; bh: number; ratio: number; mix: number; redIn: number; d: number; lost: number; kept: number }
  const rows: Row[] = []
  for (const c of comps) {
    if (c.n < 6) continue
    let inR = 0, mix = 0, redIn = 0, lost = 0, kept = 0, dsum = 0, dcnt = 0
    const dlist: number[] = []
    for (let y = c.y0; y <= c.y1; y++) {
      const b = y * w
      for (let x = c.x0; x <= c.x1; x++) {
        if (region[b + x]) inR++
        const p = (b + x) * ch
        // 混合像素：低彩度但在 6px 内存在显著彩度 → 红黑混合
        if (ink[b + x]) {
          const c0 = chrom(od, p)
          if (c0 >= 6) mix++
          if (red[b + x]) redIn++
          if (m[b + x] > 127) lost++; else kept++
          dlist.push(dist[b + x])
        }
      }
    }
    dlist.sort((a, b2) => a - b2)
    for (const d of dlist) { dsum += d; dcnt++ }
    rows.push({
      n: c.n, bw: c.x1 - c.x0 + 1, bh: c.y1 - c.y0 + 1,
      ratio: inR / c.n, mix: mix / c.n, redIn: redIn / c.n,
      d: dcnt ? dlist[Math.floor(dcnt / 2)] : 999,
      lost, kept,
    })
  }

  // 分类：受损印刷域 = 被擦掉的（lost>kept）且规模像印刷（n 大、域高接近行高）
  const dmg = rows.filter((r) => r.lost > r.kept * 2 && r.lost > 20).sort((a, b) => b.lost - a.lost)
  const good = rows.filter((r) => r.kept >= r.lost && r.lost > 20).sort((a, b) => b.lost - a.lost)

  const stat = (arr: Row[], k: 'ratio' | 'mix' | 'redIn' | 'd') => {
    const v = arr.map((r) => r[k]).sort((a, b) => a - b)
    if (!v.length) return null
    return { p25: +v[Math.floor(v.length * 0.25)].toFixed(2), med: +v[Math.floor(v.length * 0.5)].toFixed(2), p75: +v[Math.floor(v.length * 0.75)].toFixed(2) }
  }

  console.log('GUARD ' + JSON.stringify({
    file, redPx, doms: rows.length, dmg: dmg.length, good: good.length,
    dmgFeat: { ratio: stat(dmg, 'ratio'), mix: stat(dmg, 'mix'), redIn: stat(dmg, 'redIn'), d: stat(dmg, 'd') },
    goodFeat: { ratio: stat(good, 'ratio'), mix: stat(good, 'mix'), redIn: stat(good, 'redIn'), d: stat(good, 'd') },
    dmgTop: dmg.slice(0, 8),
    goodTop: good.slice(0, 5),
  }))
}

function connectedComponentsLocal(ink: Uint8Array, w: number, h: number) {
  const label = new Int32Array(w * h).fill(-1)
  const comps: Array<{ x0: number; y0: number; x1: number; y1: number; n: number }> = []
  const st: number[] = []
  let cur = 0
  for (let i = 0; i < w * h; i++) {
    if (!ink[i] || label[i] >= 0) continue
    const y0 = Math.floor(i / w), x0 = i - y0 * w
    let x1 = x0, y1 = y0, n = 0
    st.length = 0; st.push(i); label[i] = cur
    while (st.length) {
      const p = st.pop()!; n++
      const py = Math.floor(p / w), px = p - py * w
      if (px < x1) x1 = px; if (px > x1) x1 = px
      if (py < y0) y0 = py; if (py > y1) y1 = py
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const qx = px + dx, qy = py + dy
        if (qx < 0 || qy < 0 || qx >= w || qy >= h) continue
        const q = qy * w + qx
        if (ink[q] && label[q] < 0) { label[q] = cur; st.push(q) }
      }
    }
    comps.push({ x0, y0, x1, y1, n })
    cur++
  }
  return { comps }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
