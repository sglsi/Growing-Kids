import sharp from 'sharp'
import * as fs from 'fs'
const D = '/workspace/wrongq-test'
async function main() {
  fs.mkdirSync(`${D}/look21`, { recursive: true })
  // page30 左栏选项区（大量红笔括号答案），page28 中栏选择题区
  const jobs: Array<[string, number, number, number, number, string]> = [
    ['page30.png', 40, 700, 260, 400, 'p30-左栏选项'],
    ['page30.png', 620, 640, 300, 420, 'p30-右栏选项'],
    ['page28.png', 40, 1000, 260, 350, 'p28-左栏选项'],
    ['page28.png', 350, 620, 330, 300, 'p28-中栏选择'],
  ]
  for (const [f, l, t, ww, hh, name] of jobs) {
    const img = sharp(`${D}/${f}`).extract({ left: l, top: t, width: ww, height: hh })
    await img.resize({ width: ww * 3, kernel: 'nearest' }).png().toFile(`${D}/look21/${name}.png`)
    console.log(name, 'ok')
  }
}
main()
