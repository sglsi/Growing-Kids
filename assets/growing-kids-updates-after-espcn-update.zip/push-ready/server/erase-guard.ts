/**
 * 去手写 v20 守护探针（10 分钟周期检测用）
 * ============================================================
 * 检查项（全部机器可判，输出 GUARD JSON）：
 *   E1  red-ink-prior 模块存在且导出 maskFromRedSpatialPrior（regex 容错）
 *   E2  segmenter hybrid 分支：redMask 注入 + 连通域包含度 + union 回退
 *   E3  service 默认 eraseMode = hybrid
 *   E4  TS 类型检查（仅核心三文件）
 *   E5  端到端 4 页指标：黑笔去除 ≥0.55、印刷误删 ≤0.01、
 *       红笔去除 ≥ color-0.02、家具误删 ≤0.02（probe-hybrid-verify.ts）
 *   E6  归因一致性：hybrid mask 对 printSet 覆盖 ≤0.01（probe-mask-attrib.ts）
 *   E0  探针完整性（probe-integrity.ts）——v20.6 事故补漏
 *   E7  ⭐ 红笔周边印刷损伤（probe-line-integrity.ts）——v20.6 新增硬指标
 *
 * ⚠️ v20.6 事故记录（务必读）：
 *   新建 probe-rscan-black.ts 时 import 了 './eval-gt' 里不存在的 evalGt，
 *   写完没跑就去做别的，错误被推迟到下次执行才爆 → 任务终止。
 *   之所以没被 E4 拦住：E4 只筛核心四文件，**探针脚本报错一律忽略**
 *   （本意是"探针坏不该阻塞守护"，实际造成了"探针坏 = 静默"）。
 *   E0 就是补这个洞：静态扫描每个探针的语法、导入路径、具名导出是否真实存在。
 *   已用注入错误法验证 E0 确实能抓到（见方法论 §5.16）。
 *
 * 用法：npx tsx erase-guard.ts；全过输出 GUARD {"pass":true,...}
 * 设计约束：不读图片文件本体（探针自己读）、fail-open 探针失败记 FAIL 不抛异常。
 */
import * as fs from 'fs'
import * as path from 'path'
import { execSync } from 'child_process'

const ROOT = __dirname
const results: { id: string; name: string; pass: boolean; detail: string }[] = []
const add = (id: string, name: string, pass: boolean, detail: unknown = '') =>
  results.push({ id, name, pass, detail: String(detail).slice(0, 300) })

/** E1/E2/E3/E8 静态检查 */
function staticChecks() {
  const segP = path.join(ROOT, 'src/image/handwriting-segmenter.ts')
  const priorP = path.join(ROOT, 'src/image/red-ink-prior.ts')
  const svcP = path.join(ROOT, 'src/image/image.service.ts')

  const priorSrc = fs.readFileSync(priorP, 'utf8')
  add('E1', '先验模块导出', /export\s+async\s+function\s+maskFromRedSpatialPrior\b/.test(priorSrc), priorP)

  const segSrc = fs.readFileSync(segP, 'utf8')
  add('E2a', 'hybrid 分支存在', /eraseMode\s*===\s*'hybrid'/.test(segSrc))
  add('E2b', '红笔 mask 注入（口径统一）', /redMask:\s*redMask\.data/.test(segSrc), 'v20.2 教训一：禁止内部裸彩度判红')
  add('E2c', '先验不可用回退 union', /unionFallbackFromHybrid/.test(segSrc), '无红笔卷必须落回三通道并集')
  add('E2d', '槽位通道未并入 hybrid（v20.3 否决项）',
    !/layout\.data\[i\]\s*\|\|/.test(segSrc) || !/redMask\.data\[i\]\s*\|\|\s*black\.data\[i\]\s*\|\|\s*layout/.test(segSrc),
    '密排报纸上槽位通道印刷误删 6~22%，实测否决')
  add('E2e', '黑笔先验喂原图（非归一化图）',
    /maskFromRedSpatialPrior\s*\(\s*imageBuffer/.test(segSrc),
    'v20.5：归一化图抬高纸面基准，墨迹少 15%，黑笔去除 +2.6~11.5pp')
  add('E2f', '域包含度沿用 bbox 口径（勿改成严格口径）',
    /if\s*\(\s*region\[b \+ x\]\s*\)\s*inR\+\+/.test(priorSrc) && /不要"修正" inR/.test(priorSrc),
    'v20.5：改严格口径黑笔去除掉到 0.52~0.58，见 red-ink-prior.ts 注释')

  const svcSrc = fs.readFileSync(svcP, 'utf8')
  add('E3', 'service 默认 hybrid',
    /eraseMode:\s*dto\.erase_mode\s*===\s*'color'\s*\?\s*'color'\s*:\s*dto\.erase_mode\s*===\s*'union'\s*\?\s*'union'\s*:\s*'hybrid'/.test(svcSrc))
}

/** E4 类型检查（只看核心文件是否报错） */
function tscCheck() {
  try {
    const out = execSync('npx tsc --noEmit', { cwd: ROOT, encoding: 'utf8', timeout: 120000 })
    add('E4', 'TS 类型检查', true, 'clean')
  } catch (e: unknown) {
    const out = String((e as { stdout?: string; message?: string })?.stdout ?? (e as Error)?.message ?? e)
    const core = out.split('\n').filter((l) => /red-ink-prior|handwriting-segmenter|image\.service|handwriting-mask/.test(l))
    add('E4', 'TS 类型检查', core.length === 0, core.slice(0, 3).join(' | ') || '(仅探针脚本报错)')
  }
}

/** 跑一个探针并抽取 GUARD 行 */
function runProbe(script: string, timeoutMs = 300000): string[] {
  try {
    const out = execSync(`npx tsx ${script}`, { cwd: ROOT, encoding: 'utf8', timeout: timeoutMs })
    return out.split('\n').filter((l) => l.startsWith('GUARD '))
  } catch (e: unknown) {
    const out = String((e as { stdout?: string })?.stdout ?? '')
    const lines = out.split('\n').filter((l) => l.startsWith('GUARD '))
    if (lines.length) return lines
    throw e
  }
}

/** E5 端到端指标 */
function e2eCheck() {
  const lines = runProbe('probe-hybrid-verify.ts')
  let checked = 0
  const fails: string[] = []
  const warns: string[] = []
  for (const l of lines) {
    const d = JSON.parse(l.slice(6))
    if (d.error || !d.hybrid || !d.color) { fails.push(`${d.file}: ${d.error ?? 'missing'}`); continue }
    const h = d.hybrid, c = d.color
    checked++
    // ⚠️ v21.1 · P2 修正：原 blackRemoval(近红暗像素去除率) 把印刷计入黑笔真值，在红笔旁
    //    印刷密集页必然与 E7 冲突（G5 类口径问题）。现改用 blackRemovalPen（剔除印刷域后的
    //    真实黑笔去除率）作为**软告警**：其 0.55 阈值原为旧(含印刷)口径标定，修正后真值集
    //    大幅缩小（近红暗像素 90%+ 是印刷），故仅告警不卡构建；硬闸保留 printDamage(E7 掩码级)。
    if (h.blackRemovalPen < 0.55) warns.push(`${d.file} 黑笔去除(净) ${h.blackRemovalPen} < 0.55 (粗${h.blackRemoval} 真值${h.penTruthGen}/${h.penTruthTotal})`)
    if (h.printDamage > 0.01) fails.push(`${d.file} 印刷误删 ${h.printDamage} > 0.01`)
    if (h.redRemoval < c.redRemoval - 0.02) fails.push(`${d.file} 红笔回退 ${c.redRemoval}→${h.redRemoval}`)
    if (h.furnKeep > 0.02) fails.push(`${d.file} 家具误删 ${h.furnKeep} > 0.02`)
  }
  add('E5', `端到端 4 页指标（${checked} 页）`, checked === 4 && fails.length === 0,
    (fails.length ? fails.join('; ') : '硬指标全部达标') + (warns.length ? ' | ⚠️' + warns.join('; ') : ''))
}

/** E6 mask 归因（印刷覆盖硬闸） */
function attribCheck() {
  const lines = runProbe('probe-mask-attrib.ts')
  const fails: string[] = []
  let checked = 0
  for (const l of lines) {
    const d = JSON.parse(l.slice(6))
    const hybrid = (d.masks ?? []).find((m: { name: string }) => m.name === 'hybrid')
    if (!hybrid) { fails.push(`${d.file}: no hybrid mask`); continue }
    checked++
    if (hybrid.printCovered > 0.01) fails.push(`${d.file} mask印刷覆盖 ${hybrid.printCovered}`)
  }
  add('E6', `mask 归因印刷覆盖（${checked} 页）`, checked === 4 && fails.length === 0, fails.join('; ') || '≤0.01')
}

/** E0 探针完整性：堵住"探针坏了却静默"的盲区（v20.6 事故的直接教训） */
function probeIntegrityCheck() {
  try {
    const lines = runProbe('probe-integrity.ts', 120000)
    const d = JSON.parse(lines[0].slice(6))
    add('E0', `探针完整性（${d.scanned} 个）`, d.pass === true,
      d.pass ? '语法/导入路径/具名导出全部有效' : `syntax:${d.syntaxBad.length} path:${d.pathBad.length} import:${d.importBad.length}`)
  } catch (e) {
    add('E0', '探针完整性', false, String(e).slice(0, 200))
  }
}

/**
 * E7 ⭐ v20.6：**红笔周边印刷损伤**（用户反馈②的硬指标）
 * ------------------------------------------------------------------
 * ⚠️ 为什么必须新增，不能靠 E5 的 printDamage：
 *   printDamage 的 printSet 定义为"**离红笔 24px 之外**的低彩度暗像素"，
 *   红笔周边（24px 内）的印刷损伤**从未进入任何指标**——
 *   于是出现"指标全绿、用户肉眼看到红笔周边成片印刷消失"的典型假达标。
 *   probe-line-integrity v4 实测：损伤 100% 落在 mask 内（掩外为 0），
 *   纯印刷行保持率仅 0.953~0.979，且损失高度集中（单行可损 776px = 64%）。
 *
 * 口径：行墨量守恒（不依赖任何"什么是印刷体"的假设）——
 *   A = 原图行内暗像素数，B = 结果图行内**仍是**暗像素的个数；
 *   纯印刷行（行内无任何红笔像素）的损失在物理上只能是误擦。
 * 阈值：keepClean ≥ 0.985（实测 0.951~0.999，低于 0.985 视为红笔周边有可感损伤）
 */
function printIntegrityCheck() {
  const lines = runProbe('probe-line-integrity.ts', 600000)
  const fails: string[] = []
  let checked = 0
  for (const l of lines) {
    const d = JSON.parse(l.slice(6))
    if (d.error) { fails.push(`${d.file}: ${d.error}`); continue }
    checked++
    if (d.keepNoRed < 0.985) fails.push(`${d.file} 纯印刷行保持 ${d.keepNoRed} < 0.985（损 ${d.lostNoRedPx}px/受损行 ${d.dmgRows}）`)
    // 掩外损伤必须为 0：>0 说明 inpaint/blend 有副作用，属于另一类 bug
    if (d.lostNoRedOutsideMask > 0) fails.push(`${d.file} 掩外损伤 ${d.lostNoRedOutsideMask}px（应为 0，inpaint 越界）`)
  }
  add('E7', `红笔周边印刷损伤（${checked} 页）`, checked === 4 && fails.length === 0, fails.join('; ') || '纯印刷行保持 ≥0.985 且掩外损伤=0')
}

/**
 * E8 ⭐ v20.9：**探针量级门禁**（G1）——治"数字合法但结论荒谬"
 * ------------------------------------------------------------------
 * ⚠️ 为什么 E0 抓不到这一类（务必读，这是三次反复失效的根因）：
 *   E0 是**静态**检查（语法/导入路径/具名导出）。它能抓住"引用不存在的导出"，
 *   但抓不住**语义错误**——距离变换漏与自身取 min（跑出 p50=0）、
 *   连通域几何内缩不足（pad=1 时"槽内"仍含括号自身）、
 *   使用失真度量（estimateCharMetrics 的 medH 在报纸版面实测失真 2.66~2.93x）。
 *   这类错误的共同特征：**exit 0、JSON 合法、量级荒谬**。
 *
 *   实证：v20.9 槽位探针连续三轮"跑通"，每轮数字都合法，
 *   但三轮结论全错。真正的暴露点是最后一次**逐目标放大目检**。
 *
 * 机制：探针可声明 `GUARD_RANGE` 行声明关键量的合理区间，越界即 exit≠0。
 *   本检查扫描全部探针的区间声明，并对**已声明**的探针强制执行。
 *   未声明的探针会被列出为"未受量级保护"（提醒，不判失败）。
 */
function rangeGuardCheck() {
  const fs = require('fs') as typeof import('fs')
  const path = require('path') as typeof import('path')
  const dir = __dirname
  const probes = fs.readdirSync(dir).filter((f) => /^(probe|verify|diag).*\.(ts|js)$/.test(f))

  // 收集已声明区间：GUARD_RANGE { key: [lo, hi], ... }
  const declared = new Map<string, Record<string, [number, number]>>()
  for (const f of probes) {
    let txt = ''
    try { txt = fs.readFileSync(path.join(dir, f), 'utf8') } catch { continue }
    const m = txt.match(/GUARD_RANGE\s*(\{[\s\S]*?\n\})/)
    if (!m) continue
    try {
      // 用 Function 构造字面量对象（避免 JSON5 注释问题）
      const obj = new Function(`return ${m[1]}`)() as Record<string, [number, number]>
      declared.set(f, obj)
    } catch { /* 声明本身写错 → 下面 E0 会报语法错 */ }
  }

  // 强制执行：只跑「耗时短 + 有声明 + 会被反复跑」的探针
  // （重量级探针由 E5/E7 负责，重复跑无收益）
  const ENFORCE = new Set(['probe-metrics-calib.ts', 'probe-slot-feasible.ts', 'probe-slot-zoom.ts', 'probe-redwidth.ts'])
  const fails: string[] = []
  let enforced = 0
  for (const f of probes) {
    const ranges = declared.get(f)
    if (!ranges) continue
    if (!ENFORCE.has(f)) continue
    enforced++
    let lines: string[]
    try {
      lines = runProbe(f, 300000)
    } catch (e) {
      fails.push(`${f} 运行失败: ${String(e).slice(0, 120)}`)
      continue
    }
    // 探针自身应在越界时 exit≠0；这里做二次兜底（万一探针没实现）
    for (const l of lines) {
      if (!l.startsWith('GUARD ')) continue
      let d: any
      try { d = JSON.parse(l.slice(6)) } catch { continue }
      for (const [k, rng] of Object.entries(ranges)) {
        const arr = Array.isArray(d[k]) ? d[k] : [d[k]]
        for (const v of arr) {
          if (typeof v !== 'number') continue
          if (v < rng[0] || v > rng[1]) {
            fails.push(`${f} ${k}=${v} 越界 [${rng[0]},${rng[1]}]`)
          }
        }
      }
    }
  }

  const unprotected = probes.length - declared.size
  add('E8', `探针量级门禁（${enforced} 个强制 / ${probes.length} 个探针）`,
    fails.length === 0,
    fails.length ? fails.join('; ') : `已声明区间探针 ${declared.size} 个，全部在量级内；未声明 ${unprotected} 个（新增探针应加 GUARD_RANGE）`)
}

/**
 * G6 补丁计数器：同一函数在同一抽象层级上被反复修改 → 说明层级错了
 * ============================================================
 * ⭐ 目的（见 反补丁机制-四层穷举与拦截器.md §4 拦截器 1）：
 *   拦下"模式 A/B 补丁"——在同一函数里反复换阈值/换统计量/换实现，
 *   却从不质疑"这个函数所在的抽象层级是否错了"。
 *
 * 判定：扫 git log，按"函数级改动"聚合。
 *   若某函数在最近 N 次提交里被改 ≥PATCH_LIMIT 次，
 *   且每次改动 diff 只涉及 L1/L2 层特征（改数字、改判断条件、换函数调用），
 *   则判定为补丁堆叠，强制失败。
 *
 * 降级：不在 git 仓库 / log 不可用时，退化为"注释代理指标"（见 G7）。
 */
function patchStackingCheck() {
  const LIMIT = 3
  let usedGit = false
  const suspects: string[] = []

  try {
    // 按函数名聚合改动次数（近似：从 diff 的 hunk header 提取所在函数）
    const log = execSync(
      'git log -n 40 --pretty=format:"%H" -- src/image/handwriting-segmenter.ts src/image/handwriting-mask.ts',
      { cwd: ROOT, encoding: 'utf8' },
    ).trim().split('\n').filter(Boolean)

    const fnHits = new Map<string, number>()
    for (const h of log) {
      const diff = execSync(
        `git show ${h} --format="" --unified=0 -- src/image/handwriting-segmenter.ts src/image/handwriting-mask.ts`,
        { cwd: ROOT, encoding: 'utf8' },
      )
      // hunk header: @@ -a,b +c,d @@ functionName
      const fnRe = /@@\s+[-\d,+\s]+@@\s*(?:.*?\b)?([A-Za-z_$][\w$]*)\s*\(/g
      const seen = new Set<string>()
      let m: RegExpExecArray | null
      while ((m = fnRe.exec(diff)) !== null) {
        const fn = m[1]
        if (!fn || fn.length < 3) continue
        if (seen.has(fn)) continue
        seen.add(fn)
        fnHits.set(fn, (fnHits.get(fn) ?? 0) + 1)
      }
    }
    usedGit = true
    for (const [fn, cnt] of fnHits) {
      if (cnt >= LIMIT) suspects.push(`${fn}×${cnt}`)
    }
  } catch {
    usedGit = false
  }

  if (usedGit) {
    add('G6', `补丁计数器（函数级改动 ≥${LIMIT} 次）`,
      suspects.length === 0,
      suspects.length ? suspects.join('; ') : '无函数级高频改动')
    return
  }

  // G7 降级：注释代理指标
  //   "已否决 / 改用 / 改成 / 换成" 在注释里的出现频率，
  //   是补丁堆叠的可靠代理（每次打补丁我都会留一句这类话）。
  const files = ['src/image/handwriting-segmenter.ts', 'src/image/handwriting-mask.ts']
  const flags: string[] = []
  for (const f of files) {
    const src = fs.readFileSync(path.join(ROOT, f), 'utf8')
    const patchWords = (src.match(/已否决|改用|改成|换成/g) ?? []).length
    const fnCount = (src.match(/^(?:export\s+)?(?:async\s+)?function\s/gm) ?? []).length
    if (fnCount > 0 && patchWords / fnCount > 0.5) {
      flags.push(`${f.split('/').pop()}: 补丁词${patchWords} / 函数${fnCount}`)
    }
  }
  add('G6', '补丁计数器（git不可用，降级为注释代理）',
    flags.length === 0,
    flags.length ? flags.join('; ') : '注释代理指标正常')
}

/**
 * G8 探针只增不减门禁：试错式开发的物证
 * ============================================================
 * probe-*.ts 只增不减 = 每个被否决的思路都留下一个探针继续混淆视听。
 * 规则：被否决的探针应归档到 probe-archive/ 并在文件头注明否决原因。
 */
function probeHoardingCheck() {
  const files = fs.readdirSync(ROOT).filter((f) => /^probe-.*\.ts$/.test(f))
  const archived = fs.existsSync(path.join(ROOT, 'probe-archive'))
    ? fs.readdirSync(path.join(ROOT, 'probe-archive')).filter((f) => f.endsWith('.ts')).length
    : 0
  // 检查主目录探针里有多少自己声明了"已否决"
  let declaredDead = 0
  for (const f of files) {
    const src = fs.readFileSync(path.join(ROOT, f), 'utf8')
    if (/已否决|已废弃|本探针已停止|do not use/i.test(src.slice(0, 1500))) declaredDead++
  }
  const active = files.length - declaredDead
  // 主目录活跃探针 >40 且归档数 < 被否决数 → 在堆积
  const hoarding = active > 40 && archived < declaredDead
  add('G8', `探针只增不减门禁（活跃${active} / 已否决${declaredDead} / 归档${archived}）`,
    !hoarding,
    hoarding
      ? `${active} 个活跃探针在主目录，${declaredDead} 个自报已否决却未归档——试错堆叠`
      : '探针规模受控')
}

/**
 * G9 同一句话出现两次：模式 A/B 补丁的最直接信号
 * ============================================================
 * 若我在注释里第二次写下"这次用 XX 判据/机制/阈值"，
 * 却答不出"上一次 XX 为什么失败、这次的本质区别是什么"，
 * 就是典型的换判据不换思路。
 *
 * 实现：扫描注释中"改用/换成/改为/这次用/现用 + 名词"的重复模式，
 *   同一对象（判据名/机制名）被"改"过 ≥2 次 → 强制失败。
 */
function repeatedRethinkCheck() {
  const files = ['src/image/handwriting-segmenter.ts']
  // ⭐ 实测：初版正则只覆盖"改用/换成"，漏掉了"改为/替代/而非/不再"——
  //   而这些才是补丁的真实措辞（本文件就有 8 处）。门禁用词必须
  //   覆盖**我自己实际会写的话**，不能只覆盖我想象中我会写的话。
  const rethinkRe = /(改用|换成|改为|这次用|现用|新机制|新判据|替代|而非|不再|弃用)[：: ]*([A-Za-z一-龥「」]{2,14})/g
  const seen = new Map<string, number>()
  for (const f of files) {
    const src = fs.readFileSync(path.join(ROOT, f), 'utf8')
    let m: RegExpExecArray | null
    while ((m = rethinkRe.exec(src)) !== null) {
      const key = m[2].replace(/[「」]/g, '')
      // 跳过"而非 X"这种纯对比（不是在说"我改了"）
      if (m[1] === '而非') continue
      seen.set(key, (seen.get(key) ?? 0) + 1)
    }
  }
  const repeats = [...seen.entries()].filter(([, c]) => c >= 2).map(([k, c]) => `${k}×${c}`)
  add('G9', '同一句话出现两次门禁', repeats.length === 0,
    repeats.length
      ? `这些对象被"改"过 ≥2 次：${repeats.join('; ')}——换判据不换思路`
      : '无重复"改用"模式')
}

/**
 * G10 参数来源门禁（固定参数拦截器，v21 新增）
 * 依据：去手写-自适应方法论-v21.md §1「说不出估计来源的参数 = 非法参数」
 *
 * 棘轮机制（无 git 环境替代 diff 的方案）：
 *   guard/param-baseline.json 登记全部存量固定参数 + 每个参数规划中的自适应来源。
 *   · 检出项不在基线里           → FAIL（新增固定参数）
 *   · 检出值与基线登记值不一致     → FAIL（静默调参——打补丁的典型动作）
 *   · 例外：常量上方 2 行内有来源标注注释（L0~L3/众数/分位/估计/标定/文献…）→ 合法新增
 *   G10_LEARN=1 时反向输出当前全量清单（用于建立/更新基线——更新基线是有意识的决策，
 *   必须在 JSON 里为每个参数写明规划来源，这本身就是方法论的替换路线图）。
 */
function paramSourceCheck() {
  const FILES = ['src/image/handwriting-mask.ts', 'src/image/red-ink-prior.ts', 'src/image/handwriting-segmenter.ts', 'src/image/adaptive-stats.ts', 'src/image/structural-discriminator.ts']
  // 可调阈值的两类写法：opts.xxx ?? <num> 、裸常量 const XXX = <num>（仅全大写/阈值命名）
  const optsRe = /opts\.(\w+) \?\? (-?[\d.]+)/g
  const constRe = /const ([A-Z][A-Z_]{2,}|thr) = (-?[\d.]+)\s*$/gm
  const sourceKw = /L[0-3]|物理|常数|众数|分位|估计|MAD|标定|文献|相对|上限|预算|禁用|占位|开关/

  type Found = { file: string; name: string; value: string; annotated: boolean }
  const found: Found[] = []
  for (const f of FILES) {
    const src = fs.readFileSync(path.join(ROOT, f), 'utf8')
    const lines = src.split('\n')
    const short = f.split('/').pop()!
    const scan = (re: RegExp) => {
      let m: RegExpExecArray | null
      re.lastIndex = 0
      while ((m = re.exec(src)) !== null) {
        const lineNo = src.slice(0, m.index).split('\n').length
        const ctx = lines.slice(Math.max(0, lineNo - 3), lineNo).join(' ')
        found.push({ file: short, name: m[1], value: m[2], annotated: sourceKw.test(ctx) })
      }
    }
    scan(optsRe); scan(constRe)
  }

  const basePath = path.join(ROOT, 'guard', 'param-baseline.json')
  if (process.env.G10_LEARN === '1') {
    const inv = found.map(x => ({ file: x.file, name: x.name, value: Number(x.value), source: x.annotated ? '已标注' : 'TODO·待标注' }))
    fs.mkdirSync(path.dirname(basePath), { recursive: true })
    fs.writeFileSync(basePath, JSON.stringify({ note: 'G10 存量基线。新增/改值必须更新本文件并在 source 写明自适应来源（见方法论 §1）', params: inv }, null, 2))
    add('G10', '参数来源门禁（LEARN 模式）', true, `已写入基线 ${inv.length} 项 → guard/param-baseline.json`)
    return
  }

  if (!fs.existsSync(basePath)) {
    add('G10', '参数来源门禁', false, '基线缺失：先 G10_LEARN=1 生成 guard/param-baseline.json')
    return
  }
  const baseline = JSON.parse(fs.readFileSync(basePath, 'utf8')) as { params: { file: string; name: string; value: number }[] }
  const bKey = new Map(baseline.params.map(p => [`${p.file}:${p.name}`, p.value]))
  const violations: string[] = []
  for (const x of found) {
    const k = `${x.file}:${x.name}`
    if (!bKey.has(k)) {
      if (!x.annotated) violations.push(`新增未标注 ${k}=${x.value}`)
      continue
    }
    if (Number(x.value) !== bKey.get(k)) violations.push(`静默调参 ${k}: ${bKey.get(k)}→${x.value}`)
  }
  add('G10', '参数来源门禁（固定参数棘轮）', violations.length === 0,
    violations.length ? violations.slice(0, 8).join('; ') : `存量 ${bKey.size} 项全部一致，无新增无标注参数`)
}

/**
 * E9 结构判别器门禁（任务 B-2 新增，与 probe-structural-ab 的 S2/S3/S4 互为表里）
 * 设计：去手写-结构一致性判别器-实施设计-v21.2.md §8
 *   · E9a（硬）STRUCT_ADAPTIVE 禁止置 'on'（检查点 S2/S3/S4 全过前不得切换主路径）
 *   · E9b（硬）segmenter 已接入影子调用点（引用 discriminate + STRUCT_ADAPTIVE）
 *   · E9c（硬）判别器含像素级 E7 保护闸（furniturePrior 印刷像素不被结构通道擦除）
 * 注：S2/S3/S4 的运行时数值由 probe-structural-ab.ts 给出；E9 是门禁层的"接线 + 纪律"断言。
 */
function e9Check() {
  // E9a：禁止 on（fail-open：未设或 off/shadow 均放行）
  const mode = process.env.STRUCT_ADAPTIVE
  add('E9a', 'STRUCT_ADAPTIVE 未置 on（检查点前禁止切换主路径）',
    mode !== 'on',
    mode === 'on' ? '检查点(S2/S3/S4)未通过即禁止 on：见设计 §8 S5' : `当前=${mode || '未设'}（off/shadow 放行）`)

  const segSrc = fs.readFileSync(path.join(ROOT, 'src/image/handwriting-segmenter.ts'), 'utf8')
  const discSrc = fs.readFileSync(path.join(ROOT, 'src/image/structural-discriminator.ts'), 'utf8')
  // E9b：影子调用点已接线
  add('E9b', 'segmenter 接入结构判别器影子调用点',
    /STRUCT_ADAPTIVE/.test(segSrc) && /discriminate\(\{/.test(segSrc),
    'hybrid 路径合并前应存在 STRUCT_ADAPTIVE 门控的 discriminate 调用')
  // E9c：像素级 E7 保护闸存在
  add('E9c', '判别器含像素级印刷保护闸（E7-safe）',
    /furniturePrior\[\s*base \+ x\s*\]/.test(discSrc),
    '印刷像素绝不被结构通道擦除：labels[base+x]=0 且 continue')
}

function main() {
  staticChecks()
  tscCheck()
  probeIntegrityCheck()
  try { e2eCheck() } catch (e) { add('E5', '端到端指标', false, String(e).slice(0, 200)) }
  try { attribCheck() } catch (e) { add('E6', 'mask 归因', false, String(e).slice(0, 200)) }
  try { printIntegrityCheck() } catch (e) { add('E7', '红笔周边印刷损伤', false, String(e).slice(0, 200)) }
  try { rangeGuardCheck() } catch (e) { add('E8', '探针量级门禁', false, String(e).slice(0, 200)) }
  // ── 反补丁拦截器（v20.9.1 新增，见 反补丁机制-四层穷举与拦截器.md）──
  try { patchStackingCheck() } catch (e) { add('G6', '补丁计数器', false, String(e).slice(0, 200)) }
  try { probeHoardingCheck() } catch (e) { add('G8', '探针只增不减', false, String(e).slice(0, 200)) }
  try { repeatedRethinkCheck() } catch (e) { add('G9', '同一句话出现两次', false, String(e).slice(0, 200)) }
  try { paramSourceCheck() } catch (e) { add('G10', '参数来源门禁', false, String(e).slice(0, 200)) }
  // ── E9 结构判别器门禁（任务 B-2）──
  try { e9Check() } catch (e) { add('E9', '结构判别器门禁', false, String(e).slice(0, 200)) }

  const pass = results.every((r) => r.pass)
  console.log('GUARD ' + JSON.stringify({ pass, checks: results }))
  process.exit(pass ? 0 : 1)
}
main()
