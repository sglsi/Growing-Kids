/**
 * 从人工标注截图中提取真值框（红框=手写，蓝框=插图）。
 * 方法论纪律：标注仅用于【验证基准】，不参与任何设计/调参（v21.3 §6）。
 *
 * 产出：
 *   worksheet-test/annotated/gt.json            —— 每页真值框列表
 *   worksheet-test/annotated/annotN-clean.png   —— 抹除标注笔画后的干净图（评估输入）
 *   worksheet-test/annotated/annotN-gtvis.png   —— 真值框可视化（供人工核对）
 */
import sharp from 'sharp'
import { connectedComponents } from './src/image/image-layout'
import * as fs from 'fs'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']

interface Box { x0: number; y0: number; x1: number; y1: number; cls: 'handwriting' | 'illustration' | 'ambiguous'; n: number }

function mergeBoxes(raw: { x0: number; y0: number; x1: number; y1: number }[], gap: number): { x0: number; y0: number; x1: number; y1: number }[] {
  // 框笔画是闭合矩形轮廓，连通域已是一条完整框线；但断角会产生碎片，做矩形合并
  const boxes = raw.slice()
  let changed = true
  while (changed) {
    changed = false
    outer: for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        const a = boxes[i], b = boxes[j]
        // 相交或间距 < gap 视为同一框碎片
        if (a.x0 <= b.x1 + gap && b.x0 <= a.x1 + gap && a.y0 <= b.y1 + gap && b.y0 <= a.y1 + gap) {
          boxes[i] = { x0: Math.min(a.x0, b.x0), y0: Math.min(a.y0, b.y0), x1: Math.max(a.x1, b.x1), y1: Math.max(a.y1, b.y1) }
          boxes.splice(j, 1)
          changed = true
          break outer
        }
      }
    }
  }
  return boxes
}

async function main() {
  const gt: Record<string, Box[]> = {}
  for (const f of PAGES) {
    const { data, info } = await sharp(`${DIR}/${f}`).raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height, ch = info.channels
    const redMask = new Uint8Array(w * h)
    const blueMask = new Uint8Array(w * h)
    for (let i = 0; i < w * h; i++) {
      const r = data[i * ch], g = data[i * ch + 1], b = data[i * ch + 2]
      // 纯红标注：R 高、G/B 低（红笔迹通常更暗或偏橙，先严后宽）
      if (r >= 180 && g <= 90 && b <= 90) redMask[i] = 1
      // 纯蓝标注：B 高、R 低、G 中（区别于黑色墨迹与灰纸）
      if (b >= 150 && r <= 110 && g >= 60 && g <= 190 && b - r >= 80) blueMask[i] = 1
    }
    const nRed = redMask.reduce((a, b) => a + b, 0)
    const nBlue = blueMask.reduce((a, b) => a + b, 0)
    console.log(`${f}: redPx=${nRed} bluePx=${nBlue}`)
    const extract = (mask: Uint8Array, cls: Box['cls']): Box[] => {
      const { comps } = connectedComponents(mask, w, h, true)
      const raw = comps.filter((c) => c.n >= 30).map((c) => ({ x0: c.x0, y0: c.y0, x1: c.x1, y1: c.y1 }))
      return mergeBoxes(raw, 12).map((b) => ({ ...b, cls, n: 0 }))
    }
    const boxes = [...extract(redMask, 'handwriting'), ...extract(blueMask, 'illustration')]
    // 冲突标记：手写尺度的蓝框（长边<64px；本集所有真实插图长边>=77px）
    // 颜色与语义矛盾（蓝框圈着手写答案），交人工复核，不参与打分
    for (const b of boxes) {
      if (b.cls === 'illustration' && Math.max(b.x1 - b.x0, b.y1 - b.y0) < 64) {
        b.cls = 'ambiguous'
        console.log(`  [冲突标记] 蓝框但手写尺度 (${b.x0},${b.y0}) ${b.x1 - b.x0}x${b.y1 - b.y0} —— 请人工复核`)
      }
    }
    // 过滤过小的碎片框
    gt[f] = boxes.filter((b) => b.x1 - b.x0 >= 16 && b.y1 - b.y0 >= 12)
    console.log(`  -> handwriting=${gt[f].filter((b) => b.cls === 'handwriting').length} illustration=${gt[f].filter((b) => b.cls === 'illustration').length}`)

    // 干净图：把标注像素替换为周边灰纸估计（3x3 邻域非标注均值，退化取 245）
    const out = Buffer.from(data)
    const ann = new Uint8Array(w * h)
    for (let i = 0; i < w * h; i++) ann[i] = redMask[i] | blueMask[i]
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!ann[y * w + x]) continue
        let sum = 0, cnt = 0
        for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
          const ny = y + dy, nx = x + dx
          if (ny < 0 || nx < 0 || ny >= h || nx >= w || ann[ny * w + nx]) continue
          const p = (ny * w + nx) * ch
          sum += (data[p] + data[p + 1] + data[p + 2]) / 3; cnt++
        }
        const v = cnt ? Math.round(sum / cnt) : 245
        const p = (y * w + x) * ch
        out[p] = v; out[p + 1] = v; out[p + 2] = v; if (ch === 4) out[p + 3] = 255
      }
    }
    await sharp(out, { raw: { width: w, height: h, channels: ch } }).png().toFile(`${DIR}/${f.replace('.png', '-clean.png')}`)

    // 真值可视化
    const vis = Buffer.from(data)
    for (const b of gt[f]) {
      const col = b.cls === 'handwriting' ? [255, 0, 255] : [0, 200, 0]
      for (let x = b.x0; x <= b.x1; x++) for (const y of [b.y0, b.y1]) {
        const p = (y * w + x) * ch; vis[p] = col[0]; vis[p + 1] = col[1]; vis[p + 2] = col[2]
      }
      for (let y = b.y0; y <= b.y1; y++) for (const x of [b.x0, b.x1]) {
        const p = (y * w + x) * ch; vis[p] = col[0]; vis[p + 1] = col[1]; vis[p + 2] = col[2]
      }
    }
    await sharp(vis, { raw: { width: w, height: h, channels: ch } }).png().toFile(`${DIR}/${f.replace('.png', '-gtvis.png')}`)
  }
  fs.writeFileSync(`${DIR}/gt.json`, JSON.stringify(gt, null, 2))
  console.log('gt.json written')
}
main().catch((e) => { console.error(e); process.exit(1) })
