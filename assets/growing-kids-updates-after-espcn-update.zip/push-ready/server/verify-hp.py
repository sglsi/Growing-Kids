import json

def load(f):
    out = {}
    for line in open(f):
        line = line.strip()
        if line.startswith('GUARD'):
            d = json.loads(line[6:])
            out[d['file']] = d
    return out

a = load('verify-out/e7-hp-off.jsonl')
b = load('verify-out/e7-hp-on.jsonl')
print(f"{'file':12} {'keepNoRed':>9} {'lostNR':>7} {'inMask':>7} {'outMask':>8} {'lostNearRed':>11} {'lostFarRed':>10} {'dmgRows':>8}")
for f in sorted(set(a) & set(b)):
    o, n = a[f], b[f]
    print(f"{f:12} {n['keepNoRed']:9.4f} {n['lostNoRedPx']:7} {n['lostNoRedInMask']:7} "
          f"{n['lostNoRedOutsideMask']:8} {n['lostNearRed']:11} {n['lostFarRed']:10} {n['dmgRows']:8}")
print('\n=== 关键判读 ===')
for f in sorted(set(a) & set(b)):
    n = b[f]
    tot = n['lostNoRedPx']
    inm = n['lostNoRedInMask']
    outm = n['lostNoRedOutsideMask']
    pct_in = (inm/max(1,tot))*100
    print(f"{f}: 纯印刷损失 {tot}px → mask内 {inm}({pct_in:.0f}%) / mask外 {outm}({100-pct_in:.0f}%)；"
          f"近红笔损失 {n['lostNearRed']} / 远离红笔 {n['lostFarRed']}")
print('\nmask内占比高 → 检测越界（P2-2b 保护应已改善）；mask外占比高 → inpaint/修复副作用（保护治不了，是另一类病）')
