/**
 * P1 后续端到端探针：验证 ① 单色源检测判定 ② 五模式并列渲染可用（含 brighten/gray）
 * 输出机器可读行：GUARD {"modes":5,"bwBytes":...,"grayBytes":...,"brightenBytes":...}
 */
import fs from 'fs'
import sharp from 'sharp'
import { detectMonoSource } from './src/image/image-doc-enhance'
import { enhanceImageModes } from './src/image/image-superres'

const SRC = process.env.P1_SRC || '/workspace/erase-work/page-1.png'

async function main() {
  const buf = fs.readFileSync(SRC)
  const gray = await sharp(buf).toColourspace('b-w').png().toBuffer()
  const g = await detectMonoSource(gray)
  const c = await detectMonoSource(buf)
  console.log(`[mono] 灰度样本 isMono=${g.isMono} p95=${g.inkChromaP95} | 彩色样本 isMono=${c.isMono} p95=${c.inkChromaP95}`)
  console.log(`[mono] 智能默认档建议：灰度样本→${g.isMono ? 'bw' : 'enhance'}；彩色样本→${c.isMono ? 'bw' : 'enhance'}`)

  const t0 = Date.now()
  const r = await enhanceImageModes(buf, { scale: 1 })
  const ms = Date.now() - t0
  const sizes: Record<string, number> = {}
  for (const [k, v] of Object.entries(r.modes)) {
    sizes[k] = v.length
    const meta = await sharp(v).metadata()
    console.log(`[mode] ${k.padEnd(9)} ${meta.width}x${meta.height} ${(v.length / 1024).toFixed(0)}KB`)
  }
  console.log(`[perf] 五模式并列耗时 ${ms}ms（scale=1 预览档）`)
  console.log(
    'GUARD ' +
      JSON.stringify({
        modes: Object.keys(r.modes).length,
        grayIsMono: g.isMono,
        colorIsMono: c.isMono,
        bwBytes: sizes.bw,
        grayBytes: sizes.gray,
        brightenBytes: sizes.brighten,
        ms,
      }),
  )
}
main().catch((e) => {
  console.error(e)
  process.exit(1)
})
