/**
 * 去手写 v20 · hybrid 模式库路径验证（英语灰报 4 张）
 * ============================================================
 * 目标：证明「红笔空间先验」能在**不误删任何印刷**的前提下把黑笔覆盖从 0% 拉到 60%+，
 *       且红笔去率相对 v19.2 不回退。
 *
 * 指标（三者互斥，口径与 probe-erase-verify.ts 完全一致）：
 *   教师红笔擦除率     ↑（越高越好）
 *   印刷红家具保留率   ↑（越高越好）
 *   黑笔擦除率         ↑（v20 新增，核心指标）
 *   印刷暗像素误删率   ↓（**新增最关键指标**：v20 必须为 0）
 *   印刷正文损伤率     ↓
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, inpaint, blendWithMask } from './src/image/handwriting-mask'
import { connectedComponents, estimateCharMetrics } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

async function rawPixels(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}
function lumaOf(d: Buffer, p: number) {
  return 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
}
/** 印刷红家具真值：v19 无门槛判据 */
function furnitureSet(data: Buffer, w: number, h: number, medH: number) {
  const ink = new Uint8Array(w * h)
  for (let i = 0; i < w * h; i++) ink[i] = data[i] ? 1 : 0
  const { comps } = connectedComponents(ink, w, h, false)
  const edgeTol = Math.max(4, Math.round(medH * 0.8))
  const f = new Uint8Array(w * h)
  let px = 0
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1, bh = c.y1 - c.y0 + 1
    const isF =
      c.x0 <= edgeTol || c.x1 >= w - 1 - edgeTol || c.y0 <= edgeTol || c.y1 >= h - 1 - edgeTol ||
      (bw > w * 0.8 && bh < medH * 3) || (bh > h * 0.8 && bw < medH * 3)
    if (!isF) continue
    px += c.n
    for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x]) f[b + x] = 1 }
  }
  return { f, px }
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const file of files) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const { info } = await rawPixels(buf)
      const w = info.width, h = info.height
      const m = await estimateCharMetrics(buf, {})
      const prior = w / 70
      const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, m.medH > 0 ? m.medH : prior))

      // ── 真值集合（全部基于原图，互斥）──────────────────────
      const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
      const { f: furn } = furnitureSet(redO.data, w, h, medH)
      const o = await rawPixels(buf)
      const od = o.data, ch = o.info.channels
      const lumas: number[] = []
      for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(od, i * ch))
      lumas.sort((a, b) => a - b)
      const paper = lumas[Math.floor(lumas.length * 0.9)] || 240
      const darkTh = paper * 0.62
      // 红笔邻域 24px（黑笔真值代理，与 probe-red-prior 一致）
      const near = new Uint8Array(w * h)
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          if (!redO.data[y * w + x]) continue
          for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
            for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near[yy * w + xx] = 1
        }
      }
      // 三类像素集合
      const penSet = new Uint8Array(w * h)   // 黑笔候选
      const printSet = new Uint8Array(w * h) // 印刷正文（低彩度暗像素，且不在红笔邻域内 → 纯印刷）
      for (let i = 0; i < w * h; i++) {
        const p = i * ch
        const c = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
        if (c >= 14 || lumaOf(od, p) >= darkTh) continue
        if (near[i]) penSet[i] = 1
        else printSet[i] = 1
      }
      const cnt = (a: Uint8Array) => { let n = 0; for (let i = 0; i < a.length; i++) if (a[i]) n++; return n }
      const inter = (a: Uint8Array, b: Uint8Array) => { let n = 0; for (let i = 0; i < a.length; i++) if (a[i] && b[i]) n++; return n }
      const nPen = cnt(penSet), nPrint = cnt(printSet)

      // ⚠️ E5 真值修正（v21.1 · P2 验收发现）：原 blackRemoval 的"黑笔真值"= 红笔 24px
      //    邻域内**所有暗像素**，把印刷也计入。在红笔旁印刷密集的页，近红暗像素本就以
      //    印刷为主，导致该指标要求"擦掉 ≥55% 近红暗像素"= 要求擦印刷，与 E7(印刷保留)
      //    结构性冲突（G5 类口径问题）。修正：用连通域高度把印刷域从黑笔真值中剔除，
      //    使 blackRemovalPen 只统计**真实黑笔**的去除率（与 probe-line-integrity 同源分类器）。
      const inkAll = new Uint8Array(w * h)
      for (let i = 0; i < w * h; i++) {
        const p = i * ch
        const c = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
        if (c < 14 && lumaOf(od, p) < darkTh) inkAll[i] = 1
      }
      // 行高基准（首栏水平投影，与 probe-line-integrity 同源）
      const prof = new Int32Array(h)
      for (let y = 0; y < h; y++) { const b = y * w; let c = 0; for (let x = 0; x < w; x++) if (inkAll[b + x]) c++; prof[y] = c }
      const pmax = Math.max(...Array.from(prof))
      const th = Math.max(1, Math.round(pmax * 0.06))
      const hs: number[] = []
      { let y = 0; while (y < h) { if (prof[y] < th) { y++; continue } const y0 = y; while (y < h && prof[y] >= th) y++; if (y - y0 >= 3) hs.push(y - y0) } }
      hs.sort((a, b) => a - b)
      const medRowH = hs.length ? hs[Math.floor(hs.length / 2)] : 10
      const { comps } = connectedComponents(inkAll, w, h, false)
      const printComp = new Uint8Array(w * h)
      for (const c of comps) {
        const bh = c.y1 - c.y0 + 1, bw = c.x1 - c.x0 + 1
        if (c.n < 4) continue
        if (bh > medRowH * 1.6) continue
        if (bw > medRowH * 6) continue
        for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (inkAll[b + x]) printComp[b + x] = 1 }
      }
      // 近红暗像素中的印刷部分（应从黑笔真值剔除）
      let nPenPrint = 0
      for (let i = 0; i < w * h; i++) if (penSet[i] && printComp[i]) nPenPrint++
      const nPenGen = Math.max(1, nPen - nPenPrint)   // 真实黑笔真值
      let nFurnTotal = 0, nPenTotal = 0
      for (let i = 0; i < w * h; i++) {
        if (!redO.data[i]) continue
        if (furn[i]) nFurnTotal++
        else nPenTotal++
      }

      // ── 两模式对比 ─────────────────────────────────────────
      const out: Record<string, unknown> = { file, truth: { pen: nPen, print: nPrint, redTotal: nFurnTotal + nPenTotal } }
      for (const mode of ['color', 'hybrid'] as const) {
        const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: mode })
        const rep = await inpaint(buf, 'adaptive', seg.mask)
        const img = await blendWithMask(buf, rep, seg.mask)
        if (mode === 'hybrid') fs.writeFileSync(path.join(IN_DIR, `erase-hybrid-${file}`), img)

        const redN = await maskFromColorThreshold(img, { chromaMin: 14 })
        // 红笔：分家具/教师
        let furnStill = 0, penRedStill = 0
        for (let i = 0; i < w * h; i++) {
          if (!redO.data[i]) continue
          if (furn[i]) { if (redN.data[i]) furnStill++ }
          else if (redN.data[i]) penRedStill++
        }
        // 黑笔：擦除率 = 该像素在结果图中已不再是低彩度暗像素
        const n2 = await rawPixels(img)
        const nd = n2.data
        let penGone = 0, printGone = 0, penGonePrint = 0
        for (let i = 0; i < w * h; i++) {
          const p = i * ch
          const c0 = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
          const l0 = lumaOf(od, p)
          const c1 = Math.max(nd[p], nd[p + 1], nd[p + 2]) - Math.min(nd[p], nd[p + 1], nd[p + 2])
          const l1 = lumaOf(nd, p)
          if (penSet[i] && c0 < 14 && l0 < darkTh && (c1 >= 14 || l1 >= darkTh)) {
            penGone++
            if (printComp[i]) penGonePrint++
          }
          if (printSet[i] && c0 < 14 && l0 < darkTh && (c1 >= 14 || l1 >= darkTh)) printGone++
        }
        out[mode] = {
          cov: +seg.mask.coverage.toFixed(4),
          redRemoval: +(1 - penRedStill / Math.max(1, nPenTotal)).toFixed(4),
          furnKeep: +(1 - furnStill / Math.max(1, nFurnTotal)).toFixed(4),
          blackRemoval: +(penGone / Math.max(1, nPen)).toFixed(4),
          blackRemovalPen: +((penGone - penGonePrint) / nPenGen).toFixed(4),
          penTruthTotal: nPen, penTruthGen: nPenGen, penTruthPrint: nPenPrint,
          printDamage: +(printGone / Math.max(1, nPrint)).toFixed(5),
        }
      }
      console.log('GUARD ' + JSON.stringify(out))
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 250))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
