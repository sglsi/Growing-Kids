/**
 * P1-3 · 探针 probe-inklocal-ab.ts
 * ============================================================
 * 验证 maskFromDarkInk 的 Niblack(旧) → Sauvola(新) 切换在真实图上的分域表现。
 *
 * 方法论纪律（§4 影子模式规范 / §1 禁止猜标注）：
 *   · 不看总体覆盖率，分域看：照片块误吞 / 全局墨迹保持 / 新旧 diff 剧烈度
 *   · 照片块坐标先目检核验（verify-photo-region.png 已确认 page28 照片区
 *     x432-578 y297-373 为纯照片、无文字混入）
 *   · E7 纯印刷行保持率由 probe-line-integrity.ts（走完整管线）在 off/on
 *     两种 env 下分别测出——本探针不重复实现该口径，避免两套行分割漂移。
 *
 * 判据（P1-3，逐项全过才允许 P1-4 切参数）：
 *   J1 照片块误吞 <30%（on 模式 dark mask 在照片区覆盖率）
 *   J2 全局 dark coverage 绝对漂移 ≤2pp（相对漂移在 off≈0 时无意义，弃用）
 *   J3 shadow diffShare ≤ 20% 图幅（超过必须先目检 probe-graphic-cand 网格图）
 *   J4 E7 纯印刷行保持率 ≥ 0.985（probe-line-integrity off/on 对比，主目标）
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { maskFromDarkInk, normalizeIlluminationForDetection } from './src/image/handwriting-mask'

const CASES = [
  { tag: 'page28', file: '/workspace/wrongq-test/page28.png' },
  { tag: 'page29', file: '/workspace/wrongq-test/page29.png' },
  { tag: 'page30', file: '/workspace/wrongq-test/page30.png' },
  { tag: 'page31', file: '/workspace/wrongq-test/page31.png' },
  { tag: 'mix-1', file: '/workspace/pdf-demo/mix-1.png' },
  { tag: 'poc-orig', file: '/workspace/poc-phase0/orig.png' },
  { tag: 'case3', file: '/workspace/主流方案对比/case-case3.png' },
]

// 目检核验过的照片块区域（原图坐标）。⚠️ 新增区域必须先裁图目检（方法论 §1）
const PHOTO_REGIONS: Record<string, { x0: number; y0: number; x1: number; y1: number }> = {
  page28: { x0: 432, y0: 297, x1: 578, y1: 373 }, // 北京脸谱照片（verify-photo-region.png 已核验）
}

async function darkCoverage(buf: Buffer, mode: string, region?: { x0: number; y0: number; x1: number; y1: number }) {
  process.env.INK_ADAPTIVE = mode
  // ⚠️ 与生产一致：检测输入是光照归一化后的 buffer，不是原图
  //   （handwriting-segmenter.ts:475 detectBuf = pre.buffer）
  const pre = await normalizeIlluminationForDetection(buf)
  const m = await maskFromDarkInk(pre.buffer)
  const n = m.width * m.height
  let covered = 0
  for (let i = 0; i < n; i++) if (m.data[i] > 127) covered++
  let regionCov: number | null = null
  if (region) {
    let inR = 0, covR = 0
    for (let y = region.y0; y < region.y1; y++) {
      for (let x = region.x0; x < region.x1; x++) {
        inR++
        if (m.data[y * m.width + x] > 127) covR++
      }
    }
    regionCov = inR ? +(covR / inR).toFixed(4) : null
  }
  const dbg = (m.debug ?? {}) as Record<string, unknown>
  return {
    coverage: +(covered / n).toFixed(4),
    regionCov,
    inkTotal: dbg.inkTotal,
    reason: dbg.reason ?? null,
    shadow: dbg.shadow ?? null,
  }
}

async function main() {
  const rows: Array<Record<string, unknown>> = []
  for (const c of CASES) {
    try {
      const buf = fs.readFileSync(c.file)
      const region = PHOTO_REGIONS[c.tag]
      const off = await darkCoverage(buf, 'off', region)
      const on = await darkCoverage(buf, 'on', region)
      const sh = await darkCoverage(buf, 'shadow')
      const diffShare = (sh.shadow as { diffShare?: number } | undefined)?.diffShare ?? null
      const winR = (sh.shadow as { winR?: number } | undefined)?.winR ?? null
      const charH = (sh.shadow as { charH?: number } | undefined)?.charH ?? null
      const row = {
        tag: c.tag,
        coverageOff: off.coverage, coverageOn: on.coverage,
        absDiff: +Math.abs(on.coverage - off.coverage).toFixed(4),
        reasonOff: off.reason, reasonOn: on.reason,
        photoSwallowOff: off.regionCov, photoSwallowOn: on.regionCov,
        diffShare, winR, charH,
      }
      rows.push(row)
      console.log(
        `${c.tag.padEnd(9)}\toff=${off.coverage}${off.reason ? `(${off.reason})` : ''}\ton=${on.coverage}${on.reason ? `(${on.reason})` : ''}`
        + `\tabsDiff=${row.absDiff}`
        + `\tphoto(off→on)=${off.regionCov ?? '-'}→${on.regionCov ?? '-'}`
        + `\tdiffShare=${diffShare ?? '-'}\twinR=${winR ?? '-'}\tcharH=${charH ?? '-'}`,
      )
    } catch (e) {
      console.log(`✗ ${c.tag}: ${(e as Error).message}`)
      rows.push({ tag: c.tag, error: (e as Error).message })
    }
  }

  // ── 判据 ──
  console.log('\n══ P1-3 判据 ══')
  const photoRows = rows.filter((r) => r.photoSwallowOn != null) as Array<{ tag: string; photoSwallowOn: number }>
  const j1 = photoRows.every((r) => r.photoSwallowOn < 0.3)
  console.log(`J1 照片块误吞 <30%: ${j1 ? 'PASS' : 'FAIL'}${photoRows.map((r) => `  ${r.tag}=${r.photoSwallowOn}`).join('')}`)

  const driftRows = rows.filter((r) => r.absDiff != null) as Array<{ tag: string; absDiff: number }>
  // 绝对 2pp 口径（与计划判据"覆盖率 ≥ 现状 − 2pp"一致）；
  // 相对漂移在 off≈0 时无意义（page29 0.0005→0.0164 会报 3180%），弃用。
  const j2 = driftRows.every((r) => r.absDiff <= 0.02)
  console.log(`J2 全局 coverage 绝对漂移 ≤2pp: ${j2 ? 'PASS' : 'FAIL'}${driftRows.filter((r) => r.absDiff > 0.02).map((r) => `  ✗${r.tag}=${(r.absDiff * 100).toFixed(1)}pp`).join('')}`)

  const diffRows = rows.filter((r) => r.diffShare != null) as Array<{ tag: string; diffShare: number }>
  const j3 = diffRows.every((r) => r.diffShare <= 0.2)
  console.log(`J3 shadow diffShare ≤20%: ${j3 ? 'PASS' : 'FAIL'}${diffRows.filter((r) => r.diffShare > 0.2).map((r) => `  ✗${r.tag}=${(r.diffShare * 100).toFixed(1)}%`).join('')}`)

  console.log('J4 E7 纯印刷行保持率 ≥0.985：由 probe-line-integrity.ts off/on 两轮分别输出（见 verify-out/）')

  fs.writeFileSync('/workspace/push-ready/server/verify-out/inklocal-ab.json',
    JSON.stringify({ rows, j1, j2, j3 }, null, 2))
  console.log('明细 → verify-out/inklocal-ab.json')
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
