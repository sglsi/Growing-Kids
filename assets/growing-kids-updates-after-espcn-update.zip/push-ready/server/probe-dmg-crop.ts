/**
 * v20.6 · 受损行目检取证
 * ============================================================
 * 目的：把"纯印刷行损失"最严重的几行**放大导出来看**，用眼睛判断红笔周边
 * 到底长什么样——是"红笔压住的印刷"（该擦）还是"红笔路过的印刷"（误擦）。
 * 理论推演到头了：R 扫描已证明调半径只是 trade-off 两端转移，
 * 新判据必须来自对实际像素结构的观察，而不是继续猜。
 *
 * 每行输出一张三联图（原图 / mask 品红叠加 / 结果图），3x 放大。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask, maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask } from './src/image/handwriting-mask'
import { findThreeColumns, colRowsIn } from './src/image/wrongq-layout'

const IN_DIR = '/workspace/wrongq-test'
const OUT = '/workspace/v20-损伤取证'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, ch = info.channels, n = w * h

    const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
    const rep = await inpaint(buf, 'adaptive', seg.mask)
    const img = await blendWithMask(buf, rep, seg.mask)
    const { data: nd } = await raw(img)

    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const darkTh = (ls[Math.floor(ls.length * 0.9)] || 240) * 0.62
    const ink = new Uint8Array(n)
    for (let i = 0; i < n; i++) { const p = i * ch; if (chrom(od, p) < 14 && luma(od, p) < darkTh) ink[i] = 1 }
    const prior = w / 70
    const cols = findThreeColumns(ink, w, h, Math.max(prior * 0.8, Math.min(prior * 2.0, 11))).cols

    const chromaSensitive = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const redRef = refineColorEraseMask(await protectPrintUnderColorHandwriting(buf, chromaSensitive), Math.max(prior * 0.8, Math.min(prior * 2.0, 11)), { growRadius: 2, growChroma: 8 })

    // 找损失最重的 3 个纯印刷行
    const worst: Array<{ lost: number; cx0: number; cx1: number; y0: number; y1: number }> = []
    cols.forEach(([cx0, cx1]) => {
      for (const r of colRowsIn(ink, w, h, cx0, cx1)) {
        let red = 0
        for (let y = r.y0; y <= r.y1; y++) { const b = y * w; for (let x = cx0; x <= cx1; x++) if (redRef.data[b + x] > 127) red++ }
        if (red > 0) continue                                   // 只看纯印刷行
        let a = 0, keep = 0
        for (let y = r.y0; y <= r.y1; y++) {
          const b = y * w
          for (let x = cx0; x <= cx1; x++) {
            const i = b + x
            if (!ink[i]) continue
            a++
            const p = i * ch
            if (luma(nd, p) < darkTh && chrom(nd, p) < 14) keep++
          }
        }
        if (a >= 25 && a - keep > 40) worst.push({ lost: a - keep, cx0, cx1, y0: r.y0, y1: r.y1 })
      }
    })
    worst.sort((x, y) => y.lost - x.lost)

    // 每行导一张三联图
    for (let k = 0; k < Math.min(3, worst.length); k++) {
      const t = worst[k]
      const padY = 26, padX = 10
      const y0 = Math.max(0, t.y0 - padY), y1 = Math.min(h - 1, t.y1 + padY)
      const x0 = Math.max(0, t.cx0 - padX), x1 = Math.min(w - 1, t.cx1 + padX)
      const cw = x1 - x0 + 1, chh = y1 - y0 + 1

      // 中间图：原图 + mask 品红
      const ov = Buffer.from(od)
      for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) {
          if (seg.mask.data[y * w + x] > 127) { const p = (y * w + x) * ch; ov[p] = 255; ov[p + 1] = 0; ov[p + 2] = 255 }
        }
      }
      const panels = [ov, od, Buffer.from(nd)]
      const metas = await Promise.all(panels.map((b) => sharp(b, { raw: { width: w, height: h, channels: ch } }).png().toBuffer()))
      const strips = await Promise.all(metas.map((b) => sharp(b).extract({ left: x0, top: y0, width: cw, height: chh }).resize({ width: cw * 2, kernel: 'nearest' }).png().toBuffer()))
      const H = strips[0] ? (await sharp(strips[0]).metadata()).height! : 0
      await sharp({ create: { width: cw * 2, height: H * 3, channels: 3, background: { r: 255, g: 255, b: 255 } } })
        .composite(strips.map((b, i) => ({ input: b, top: i * H, left: 0 })))
        .png().toFile(`${OUT}/${file.replace('.png', '')}-worst${k + 1}.png`)
      console.log('GUARD ' + JSON.stringify({ file, k: k + 1, lost: t.lost, y0: t.y0, y1: t.y1, x0: t.cx0, x1: t.cx1, rowH: t.y1 - t.y0 + 1 }))
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
