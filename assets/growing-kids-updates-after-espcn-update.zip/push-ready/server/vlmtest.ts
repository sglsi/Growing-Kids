import { LLMClient } from 'coze-coding-dev-sdk'
async function main(){
  const c = new LLMClient()
  const r = await c.invoke([{role:'user',content:[{type:'text',text:'只回复两个字：可用'}]}], { model:'doubao-seed-2-0-pro-260215', temperature:0.1 })
  console.log('VLM_OK', JSON.stringify(String(r.content).slice(0,200)))
}
main().catch(e=>{ console.log('VLM_FAIL', String((e as Error)?.message ?? e).slice(0,400)) })
