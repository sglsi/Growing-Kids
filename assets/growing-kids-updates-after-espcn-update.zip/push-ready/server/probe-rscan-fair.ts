/**
 * v20.6 · R 重扫（新口径）
 * ============================================================
 * R=24 当初是在**有漏洞的 printDamage**（离红笔 24px 外的暗像素）下选出的，
 * 该口径对"红笔周边印刷损伤"完全盲区。本探针用两个可信口径重扫：
 *   ① 纯印刷行保持率（行墨量守恒，probe-line-integrity v4 修正后）
 *   ② 黑笔去除率（漏擦，用户问题①）
 * 期望：R 变小 → 印刷损伤下降、黑笔覆盖下降。找 Pareto 前沿。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask, maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask } from './src/image/handwriting-mask'
import { maskFromRedSpatialPrior } from './src/image/red-ink-prior'
import { findThreeColumns, colRowsIn } from './src/image/wrongq-layout'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])
const RS = [8, 12, 16, 20, 22, 24, 26, 28]

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  const out: any[] = []
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, ch = info.channels, n = w * h

    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const paper = ls[Math.floor(ls.length * 0.9)] || 240
    const darkTh = paper * 0.62
    const ink = new Uint8Array(n)
    for (let i = 0; i < n; i++) { const p = i * ch; if (chrom(od, p) < 14 && luma(od, p) < darkTh) ink[i] = 1 }
    const prior = w / 70
    const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, 11))
    const cols = findThreeColumns(ink, w, h, medH).cols

    // 红笔（v19 链，与生产同口径）
    const chromaSensitive = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const redProtected = await protectPrintUnderColorHandwriting(buf, chromaSensitive)
    const redMask = refineColorEraseMask(redProtected, medH, { growRadius: 2, growChroma: 8 })

    for (const R of RS) {
      const black = await maskFromRedSpatialPrior(buf, { radius: R, redMask: redMask.data })
      const merged = Buffer.alloc(n)
      for (let i = 0; i < n; i++) if (redMask.data[i] || black.data[i]) merged[i] = 255
      const mm = { data: merged, width: w, height: h, coverage: 0 } as any
      const rep = await inpaint(buf, 'adaptive', mm)
      const img = await blendWithMask(buf, rep, mm)
      const { data: nd } = await raw(img)

      // 纯印刷行 = 行内无红笔像素
      let aAll = 0, kAll = 0, aClean = 0, kClean = 0, dmgRows = 0
      cols.forEach(([cx0, cx1]) => {
        for (const r of colRowsIn(ink, w, h, cx0, cx1)) {
          let a = 0, keep = 0, red = 0
          for (let y = r.y0; y <= r.y1; y++) {
            const b = y * w
            for (let x = cx0; x <= cx1; x++) if (redMask.data[b + x] > 127) red++
          }
          for (let y = r.y0; y <= r.y1; y++) {
            const b = y * w
            for (let x = cx0; x <= cx1; x++) {
              const i = b + x
              if (!ink[i]) continue
              a++
              const p = i * ch
              if (luma(nd, p) < darkTh && chrom(nd, p) < 14) keep++
            }
          }
          if (a < 25) continue
          aAll += a; kAll += keep
          if (red === 0) {
            aClean += a; kClean += keep
            if (keep / a < 0.8 && a - keep > 40) dmgRows++
          }
        }
      })
      out.push({
        file, R, keepClean: +(kClean / Math.max(1, aClean)).toFixed(4),
        lostClean: aClean - kClean, dmgRows, keepAll: +(kAll / Math.max(1, aAll)).toFixed(4),
        blackReason: black.reason,
      })
      process.stderr.write('.')
    }
  }
  for (const o of out) console.log('GUARD ' + JSON.stringify(o))
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
