/**
 * 错题区域提取 · 前期测试探针（设计文档 §11 标定用）
 *
 * 输入：/workspace/wrongq-test/page*.png（4 张《学英语》报纸版试卷）
 * 输出：
 *   ① 每张图的 GUARD JSON 行（度量 / 分栏 / 红笔统计 / 悬挂缩进）
 *   ② 诊断图 diag-<page>.png：灰度底图 + 红笔mask涂红 + 栏边界绿线 + 行边界蓝线
 *
 * 复用资产（零改动）：normalizeIlluminationForDetection / estimateCharMetrics /
 *   otsuThreshold / connectedComponents / segmentTextRows / maskFromColorThreshold / detectMonoSource
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import {
  normalizeIlluminationForDetection,
  maskFromColorThreshold,
  segmentTextRows,
} from './src/image/handwriting-mask'
import {
  estimateCharMetrics,
  otsuThreshold,
  connectedComponents,
  quantileSorted,
  median,
} from './src/image/image-layout'
import { detectMonoSource } from './src/image/image-doc-enhance'

const IN_DIR = '/workspace/wrongq-test'
const DIAG_W = 900 // 诊断图宽（控制产物大小）

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  if (!files.length) throw new Error('no page*.png in ' + IN_DIR)

  for (const f of files) {
    try {
      await probePage(path.join(IN_DIR, f))
    } catch (e) {
      console.log(`GUARD {"file":"${f}","error":${JSON.stringify(String((e as Error)?.message ?? e))}}`)
    }
  }
}

async function probePage(file: string) {
  const buf = fs.readFileSync(file)
  const meta = await sharp(buf).metadata()
  const W0 = meta.width || 0
  const H0 = meta.height || 0

  // ── ① 预处理 + 度量（全部复用）──
  const pre = await normalizeIlluminationForDetection(buf, {})
  const metrics = await estimateCharMetrics(pre.buffer, {})
  const mono = await detectMonoSource(buf, {})

  // ── ② 工作图（1:1，图本身 1024×1365 不大）──
  const { data, info } = await sharp(pre.buffer)
    .removeAlpha()
    .toColourspace('srgb')
    .raw()
    .toBuffer({ resolveWithObject: true })
  const w = info.width
  const h = info.height
  const ch = info.channels
  const n = w * h
  const gray = new Uint8Array(n)
  const luma = new Float32Array(n)
  for (let i = 0, p = 0; i < n; i++, p += ch) {
    const l = 0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2]
    luma[i] = l
    gray[i] = l < 0 ? 0 : l > 255 ? 255 : l
  }
  const medH = metrics.medH || Math.round(h * 0.012)

  // ── ③ Otsu → ink → 行切分 ──
  const thr = otsuThreshold(gray, n)
  const ink = new Uint8Array(n)
  for (let i = 0; i < n; i++) ink[i] = gray[i] < thr ? 1 : 0
  const segAll = segmentTextRows(ink, w, h, { rowProfileRatio: 0.05 })

  // ── ④ 分栏探针：列投影 → 垂直"近空白"带 → 栏边界 ──
  const colProfile = new Int32Array(w)
  for (let y = 0; y < h; y++) {
    const base = y * w
    for (let x = 0; x < w; x++) if (ink[base + x]) colProfile[x]++
  }
  const colMax = Math.max(...colProfile)
  const colTh = Math.max(2, Math.round(colMax * 0.015))
  const gapMin = Math.max(3, Math.round(medH * 0.8)) // 空白带宽度下限（栏间距）
  const gaps: Array<{ x0: number; x1: number }> = []
  {
    let x = 0
    while (x < w) {
      if (colProfile[x] > colTh) { x++; continue }
      const x0 = x
      while (x < w && colProfile[x] <= colTh) x++
      if (x - x0 >= gapMin) gaps.push({ x0, x1: x })
    }
  }
  // 由空白带推出栏区间
  const cols: Array<{ x0: number; x1: number }> = []
  {
    let cur = 0
    for (const g of gaps) {
      if (g.x0 > cur) cols.push({ x0: cur, x1: g.x0 })
      cur = g.x1
    }
    if (cur < w) cols.push({ x0: cur, x1: w })
  }
  // 过滤过窄的"栏"（< 8×medH 宽的不是栏，是花边空隙）
  const realCols = cols.filter((c) => c.x1 - c.x0 >= medH * 8)

  // ── ⑤ 红笔 mask + 连通域统计 ──
  const cm = await maskFromColorThreshold(pre.buffer, {})
  const maskInk = new Uint8Array(n)
  for (let i = 0; i < n; i++) maskInk[i] = cm.data[i] ? 1 : 0
  const { comps: markComps } = connectedComponents(maskInk, w, h, false)
  const marks = markComps.filter((c) => c.n >= Math.max(6, Math.round(medH * 0.4)))
  const areas = marks.map((c) => c.n).sort((a, b) => a - b)
  const ars = marks
    .map((c) => {
      const bw = c.x1 - c.x0 + 1
      const bh = c.y1 - c.y0 + 1
      return bw / Math.max(1, bh)
    })
    .sort((a, b) => a - b)
  const fills = marks
    .map((c) => c.n / Math.max(1, (c.x1 - c.x0 + 1) * (c.y1 - c.y0 + 1)))
    .sort((a, b) => a - b)
  const bigTh = (4 * medH) * (4 * medH)
  const bigCount = marks.filter((c) => c.n > bigTh).length
  // 顶部 12% 的红色像素占比（报头红字/红底页码）
  let topRed = 0
  const topY = Math.round(h * 0.12)
  for (let y = 0; y < topY; y++) {
    const base = y * w
    for (let x = 0; x < w; x++) if (maskInk[base + x]) topRed++
  }
  const topRedRatio = topRed / Math.max(1, topY * w)

  // ── ⑥ 每栏：行切分 + 悬挂缩进聚类 ──
  const colInfos = realCols.map((c, ci) => {
    const cw = c.x1 - c.x0
    // 栏内行切分（复用 segmentTextRows，切列子图语义 → 用行投影局部化）
    const subProf = new Int32Array(h)
    for (let y = 0; y < h; y++) {
      const base = y * w
      let cnt = 0
      for (let x = c.x0; x < c.x1; x++) if (ink[base + x]) cnt++
      subProf[y] = cnt
    }
    const subMax = Math.max(...subProf)
    const subTh = Math.max(1, Math.round(subMax * 0.05))
    const rows: Array<{ y0: number; y1: number; xLeft: number }> = []
    {
      let y = 0
      while (y < h) {
        if (subProf[y] < subTh) { y++; continue }
        const y0 = y
        while (y < h && subProf[y] >= subTh) y++
        // 行首 x：该行最小有墨列
        let xLeft = cw
        for (let yy = y0; yy < y && xLeft === cw; yy++) {
          const base = yy * w
          for (let x = c.x0; x < c.x1; x++) {
            if (ink[base + x]) { xLeft = x - c.x0; break }
          }
        }
        rows.push({ y0, y1: y, xLeft })
      }
    }
    // 合并小间隙行（< 0.5×medH）
    const merged: typeof rows = []
    for (const r of rows) {
      const last = merged[merged.length - 1]
      if (last && r.y0 - last.y1 <= medH * 0.5) {
        last.y1 = r.y1
        last.xLeft = Math.min(last.xLeft, r.xLeft)
      } else merged.push({ ...r })
    }
    // 悬挂缩进聚类：行首 x 聚类（阈值 0.6×medH）
    const xs = merged.map((r) => r.xLeft).sort((a, b) => a - b)
    const clusters: Array<{ center: number; count: number }> = []
    for (const x of xs) {
      const last = clusters[clusters.length - 1]
      if (last && x - last.center / last.count <= medH * 0.6) {
        last.center += x
        last.count++
      } else clusters.push({ center: x, count: 1 })
    }
    const clustersFixed = clusters.map((c) => ({ center: Math.round(c.center / c.count), count: c.count }))
    const topCluster = clustersFixed.slice().sort((a, b) => b.count - a.count)[0]
    return {
      idx: ci + 1,
      x0: c.x0,
      x1: c.x1,
      rows: merged.length,
      clusters: clustersFixed.slice(0, 6),
      topFlushRows: topCluster?.count ?? 0,
    }
  })

  // ── ⑦ 诊断图：灰度底 + 红mask + 栏线（绿） + 行线（蓝） ──
  const dw = Math.min(DIAG_W, w)
  const dh = Math.round((h / w) * dw)
  const baseRgb = await sharp(buf).resize(dw, dh, { fit: 'fill' }).grayscale().removeAlpha().raw().toBuffer()
  const out = Buffer.alloc(dw * dh * 3)
  for (let i = 0, q = 0; i < dw * dh; i++, q += 3) {
    const g = baseRgb[i]
    out[q] = g; out[q + 1] = g; out[q + 2] = g
  }
  const sx = dw / w
  const sy = dh / h
  const put = (x: number, y: number, r: number, g: number, b: number) => {
    if (x < 0 || y < 0 || x >= dw || y >= dh) return
    const q = (y * dw + x) * 3
    out[q] = r; out[q + 1] = g; out[q + 2] = b
  }
  // 红笔 mask 涂红（最近邻）
  for (let y = 0; y < dh; y++) {
    const my = Math.min(h - 1, Math.round(y / sy))
    for (let x = 0; x < dw; x++) {
      const mx = Math.min(w - 1, Math.round(x / sx))
      if (maskInk[my * w + mx]) put(x, y, 255, 30, 30)
    }
  }
  // 栏边界绿线
  for (const g of gaps) {
    for (const gx of [g.x0, g.x1]) {
      const dx = Math.round(gx * sx)
      for (let y = 0; y < dh; y++) put(dx, y, 0, 200, 0)
    }
  }
  // 每栏行边界蓝线
  for (const ci of colInfos) {
    // 重算该栏行边界太贵，直接用全页行做参考 + 栏边界已经能看
  }
  for (const r of segAll.rows) {
    for (const yy of [r.y0, r.y1]) {
      const dy = Math.round(yy * sy)
      for (let x = 0; x < dw; x++) if (x % 2 === 0) put(x, dy, 40, 120, 255)
    }
  }
  const diagName = path.join(IN_DIR, 'diag-' + path.basename(file))
  await sharp(out, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(diagName)

  // ── ⑧ GUARD JSON ──
  const q = (a: number[], p: number) => (a.length ? +quantileSorted(a, p).toFixed(2) : 0)
  const guard = {
    file: path.basename(file),
    size: `${w}x${h}`,
    preprocess: { applied: pre.applied, deltaMean: +pre.deltaMean.toFixed(1) },
    metrics: {
      medH: +metrics.medH.toFixed(1),
      rowPitch: +metrics.rowPitch.toFixed(1),
      strokeWidth: +metrics.strokeWidth.toFixed(1),
      inkIsDark: metrics.inkIsDark,
      confidence: +metrics.confidence.toFixed(2),
      rows: segAll.rows.length,
      glyphH: segAll.glyphH,
      otsu: thr,
    },
    mono: { isMono: mono.isMono, inkChromaP95: mono.inkChromaP95, otsuSeparation: +mono.otsuSeparation.toFixed(1) },
    columns: { gaps: gaps.length, realCols: realCols.length, ranges: realCols.map((c) => [c.x0, c.x1]) },
    redMask: {
      coverage: +cm.coverage.toFixed(4),
      source: cm.source,
      debug: cm.debug ?? {},
      comps: markComps.length,
      marks: marks.length,
      area: { p50: q(areas, 0.5), p90: q(areas, 0.9), p99: q(areas, 0.99), max: areas[areas.length - 1] ?? 0 },
      aspect: { p10: q(ars, 0.1), p50: q(ars, 0.5), p90: q(ars, 0.9) },
      fill: { p10: q(fills, 0.1), p50: q(fills, 0.5), p90: q(fills, 0.9) },
      bigDomains: bigCount,
      topRedRatio: +topRedRatio.toFixed(4),
    },
    colDetail: colInfos,
    diag: path.basename(diagName),
  }
  console.log('GUARD ' + JSON.stringify(guard))
}

// 避免 TS 对未使用变量报错（诊断图行线使用全页行）
void median
main().catch((e) => {
  console.error('PROBE FAILED:', e)
  process.exit(1)
})
