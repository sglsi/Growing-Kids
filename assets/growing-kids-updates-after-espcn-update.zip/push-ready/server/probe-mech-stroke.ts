/**
 * 框选补擦机制对比：整框 vs 框内笔迹像素
 * ============================================================
 * ⭐ 背景：基于可信标注的判据标定（probe-graphic-guard4）证明——
 *   midRatio / flatRatio / edgeDensity / lumaStd / spread **全部否决**
 *   （最好 AUC 0.896 但无法零误伤，最优折中误伤 33% 文字）。
 *   ⇒ "事前判断这是图形还是文字"这条路在统计上走不通。
 *
 *   但根子不在判据，在**机制**：矩形被整块当成 mask → inpaint 拿不到
 *   任何框内参考像素 → 只能填白 → 照片被涂成纯白方块（已目检证实）。
 *
 * 本探针验证另一个机制：
 *   策略 A（旧）：整个矩形并入 mask        → 框内全部重绘
 *   策略 B（新）：只有框内的"笔迹像素"并入 → 框内亮部/纹理作参考保留
 *
 *   矩形语义从"要擦的区域"改为"**要擦的像素的搜索范围**"。
 *   这与用户意图一致（框的是"这一块有手写"），且不需要判断图形/文字。
 *
 * 评价指标（不是覆盖率！覆盖率上升可能来自把印刷体擦了）：
 *   ①信息保留率：框内灰阶标准差 after/before，越高越好
 *   ②暗像素残留：框内仍暗于纸面的像素数（越低说明手写擦得越干净）
 *   ③对印刷体的损伤：用**基线框外的印刷体**作对照，量化误伤
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'
import type { HandwritingMask } from './src/image/handwriting-mask'

/** 裸 Buffer → HandwritingMask（inpaint/alignMask 需要完整结构） */
function mkMask(data: Buffer, w: number, h: number): HandwritingMask {
  let cov = 0
  for (let i = 0; i < data.length; i++) if (data[i] > 127) cov++
  return { data, width: w, height: h, coverage: cov / (w * h), source: 'manual' } as HandwritingMask
}

const IN_DIR = '/workspace/wrongq-test'
const OUT_DIR = '/workspace/v20-框选E2E/mech'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

/** 从原图取 ROI 的掩膜（用于合成局部图） */
async function roi(src: Buffer, box: [number, number, number, number], scale = 1) {
  const cw = box[2] - box[0] + 1, ch = box[3] - box[1] + 1
  const out = await sharp(src).extract({ left: box[0], top: box[1], width: cw, height: ch })
    .resize({ width: Math.round(cw * scale), kernel: 'nearest' }).png().toBuffer()
  return out
}

/** 统计 ROI 内的灰度信息 */
function roiStats(g: Buffer, w: number, box: [number, number, number, number], paperL: number) {
  const [x0, y0, x1, y1] = box
  const vals: number[] = []
  for (let y = y0; y <= y1 && y < w; y++) for (let x = x0; x <= x1 && x < w; x++) vals.push(g[y * w + x])
  if (vals.length < 10) return null
  const mean = vals.reduce((s, v) => s + v, 0) / vals.length
  const std = Math.sqrt(vals.reduce((s, v) => s + (v - mean) ** 2, 0) / vals.length)
  const dark = vals.filter((v) => v < paperL - 45).length
  return { mean, std, dark, tot: vals.length, darkRatio: dark / vals.length }
}

/** 策略 B：框内"笔迹像素"掩膜 —— 暗于纸面 或 高彩度 */
function strokeMask(od: Buffer, w: number, h: number, box: [number, number, number, number], paperL: number) {
  const data = Buffer.alloc(w * h)
  const [x0, y0, x1, y1] = box
  for (let y = y0; y <= y1 && y < h; y++) {
    for (let x = x0; x <= x1 && x < w; x++) {
      const p = y * w + x
      const i = p * 3
      const r = od[i], g = od[i + 1], b = od[i + 2]
      const l = 0.299 * r + 0.587 * g + 0.114 * b
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b)
      const chrom = mx === 0 ? 0 : (mx - mn) / mx
      // 手写笔迹：明显暗于纸面，或明显有彩度（红/蓝笔）
      if (l < paperL - 42 || chrom > 0.28) data[p] = 255
    }
  }
  return data
}

function rectMask(w: number, h: number, box: [number, number, number, number], dilate: number) {
  const data = Buffer.alloc(w * h)
  const [x0, y0, x1, y1] = box
  const marks: boolean[] = []
  for (let y = y0 - dilate; y <= y1 + dilate; y++) {
    for (let x = x0 - dilate; x <= x1 + dilate; x++) {
      if (x < 0 || y < 0 || x >= w || y >= h) continue
      const inX = x >= x0 - dilate && x <= x1 + dilate
      const inY = y >= y0 - dilate && y <= y1 + dilate
      const onX = x >= x0 && x <= x1
      const onY = y >= y0 && y <= y1
      if ((inX && inY) || (onX && onY)) marks.push(true)
    }
  }
  for (let y = Math.max(0, y0 - dilate); y <= Math.min(h - 1, y1 + dilate); y++) {
    for (let x = Math.max(0, x0 - dilate); x <= Math.min(w - 1, x1 + dilate); x++) {
      if ((x >= x0 && x <= x1 && y >= y0 && y <= y1) ||
        (x >= x0 - dilate && x <= x1 + dilate && y >= y0 - dilate && y <= y1 + dilate)) {
        data[y * w + x] = 255
      }
    }
  }
  void marks
  return data
}

type Box = { file: string; box: [number, number, number, number]; kind: 'G' | 'T'; what: string }

// ⭐ 框全部来自 probe-graphic-cand 的目视确认标注
const CASES: Box[] = [
  { file: 'page28.png', box: [255, 255, 306, 306], kind: 'G', what: '照片·物体' },
  { file: 'page28.png', box: [430, 300, 480, 350], kind: 'G', what: '照片·物体2' },
  { file: 'page30.png', box: [390, 1270, 440, 1320], kind: 'G', what: '选项图片' },
  { file: 'page29.png', box: [55, 100, 105, 150], kind: 'T', what: '左栏正文' },
  { file: 'page30.png', box: [55, 1050, 105, 1100], kind: 'T', what: '左栏正文' },
  { file: 'page31.png', box: [280, 250, 330, 300], kind: 'T', what: '中栏正文' },
  { file: 'page29.png', box: [700, 620, 750, 670], kind: 'T', what: '右栏红笔区' },
]

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const out: any[] = []

  for (const c of CASES) {
    const buf = fs.readFileSync(`${IN_DIR}/${c.file}`)
    const { data: od, info } = await raw(buf)
    const { data: g0 } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height

    const ls: number[] = []
    for (let p = 0; p < g0.length; p += 7) ls.push(g0[p])
    ls.sort((a, b) => a - b)
    const paperL = ls[Math.floor(ls.length * 0.98)]

    const before = roiStats(g0, w, c.box, paperL)!
    const dilate = Math.round(Math.min(w, h) * 0.008)

    // 策略 A：整框
    const mA = rectMask(w, h, c.box, dilate)
    const maskA = mkMask(mA, w, h)
    const imgA = await blendWithMask(buf, await inpaint(buf, 'adaptive', maskA), maskA)
    // 策略 B：框内笔迹像素
    const mB = strokeMask(od, w, h, c.box, paperL)
    const maskB = mkMask(mB, w, h)
    const imgB = await blendWithMask(buf, await inpaint(buf, 'adaptive', maskB), maskB)

    const { data: gA } = await sharp(imgA).grayscale().raw().toBuffer({ resolveWithObject: true })
    const { data: gB } = await sharp(imgB).grayscale().raw().toBuffer({ resolveWithObject: true })
    const stA = roiStats(gA, w, c.box, paperL)
    const stB = roiStats(gB, w, c.box, paperL)
    if (!stA || !stB) {
      console.error(`[${c.file}/${c.what}] roiStats 空：gA=${gA.length} gB=${gB.length} w=${w} h=${h} box=${c.box}`)
      continue
    }

    const mk = (n: number) => +(n / Math.max(1, before.tot)).toFixed(4)
    const row = {
      file: c.file, kind: c.kind === 'G' ? '图形' : '文字', what: c.what,
      paperL: Math.round(paperL),
      before: { std: +before.std.toFixed(1), darkRatio: +before.darkRatio.toFixed(4) },
      A_整框: {
        maskPx: mA.reduce((s, v) => s + (v > 127 ? 1 : 0), 0),
        std保留: +(stA.std / before.std).toFixed(3),
        暗残留: +stA.darkRatio.toFixed(4),暗残留变化: +(stA.darkRatio - before.darkRatio).toFixed(4),
      },
      B_笔迹: {
        maskPx: mB.reduce((s, v) => s + (v > 127 ? 1 : 0), 0),
        std保留: +(stB.std / before.std).toFixed(3),
        暗残留: +stB.darkRatio.toFixed(4),暗残留变化: +(stB.darkRatio - before.darkRatio).toFixed(4),
      },
    }
    out.push(row)
    void mk

    // 取证图：orig | A整框后 | B笔迹后，3 倍放大
    const Z = 3
    const cw = c.box[2] - c.box[0] + 1, ch = c.box[3] - c.box[1] + 1
    const panels = await Promise.all([buf, imgA, imgB].map((s) =>
      sharp(s).extract({ left: c.box[0], top: c.box[1], width: cw, height: ch })
        .resize({ width: cw * Z, kernel: 'nearest' }).png().toBuffer()))
    // ⚠️ mask 是单通道裸 Buffer，必须走 raw 输入（直接 sharp(mA) 会被当图片格式解析而报错）
    const roiRaw = (m: Buffer) => sharp(Buffer.from(m), { raw: { width: w, height: h, channels: 1 } })
      .extract({ left: c.box[0], top: c.box[1], width: cw, height: ch })
      .resize({ width: cw * Z, kernel: 'nearest' }).png().toBuffer()
    const mA2 = await roiRaw(mA)
    const mB2 = await roiRaw(mB)
    const W = cw * Z, H = ch * Z
    const comp = [
      ...panels.map((p, i) => ({ input: p, left: 0, top: i * (H + 4) })),
      { input: mA2, left: W + 4, top: 0 },
      { input: mB2, left: W + 4, top: H + 4 },
      { input: mA2, left: W + 4, top: (H + 4) * 2 },
      { input: mB2, left: W + 4, top: (H + 4) * 3 },
    ]
    const sheet = await sharp({
      create: { width: W * 2 + 8, height: (H + 4) * 4, channels: 3, background: { r: 255, g: 0, b: 255 } },
    }).composite(comp).png().toBuffer()
    const f = `${OUT_DIR}/${c.file.replace('.png', '')}-${c.what}.png`
    fs.writeFileSync(f, sheet)
    row.sheet = f
  }

  console.log('RESULT ' + JSON.stringify(out, null, 1))

  console.log('\n| 类型 | 样本 | A整框·信息保留 | B笔迹·信息保留 | A暗残留变化 | B暗残留变化 |')
  console.log('|---|---|---|---|---|---|')
  for (const r of out) {
    console.log(`| ${r.kind} | ${r.what} | ${r.A_整框.std保留} | ${r.B_笔迹.std保留} | ${r.A_整框.暗残留变化} | ${r.B_笔迹.暗残留变化} |`)
  }
  const gA = out.filter((r) => r.kind === '图形').map((r) => r.A_整框.std保留)
  const gB = out.filter((r) => r.kind === '图形').map((r) => r.B_笔迹.std保留)
  console.log(`\n图形区信息保留：A=${Math.min(...gA).toFixed(3)}~${Math.max(...gA).toFixed(3)}  B=${Math.min(...gB).toFixed(3)}~${Math.max(...gB).toFixed(3)}`)
  console.log('（信息保留 = 灰度标准差 after/before。接近 1 = 图像信息基本没丢；接近 0 = 被涂成一片）')
}

main().catch((e) => { console.error(e); process.exit(1) })