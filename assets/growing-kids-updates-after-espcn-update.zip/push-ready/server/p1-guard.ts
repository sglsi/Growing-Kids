/**
 * P1 后续任务完成度检测机制（p1-guard）
 * ============================================================
 * 作用：判定「智能高清增强 · P1 后续内容（五模式并列 + 智能默认档 + 预览自选）」
 *      是否全部完成，供 10 分钟周期自检调用。
 *
 * 设计铁律（沿用 task-guard，源自历史「出错停止」事故复盘）：
 *  1. **永不崩溃**：每个检查项独立 try/catch；异常只把该项记为未完成，绝不整体退出。
 *  2. **超时即未完成**：子命令超时不抛出，按缺数据记为 incomplete。
 *  3. **绝不读取图像本体**：只做文本/命令行/结构化 JSON 校验（历史事故多由读大图截断引起）。
 *  4. 结果双写：人类可读打印 + 机器可读 JSON（供循环脚本解析）。
 *
 * 用法：npx tsx p1-guard.ts   → 全部通过时 exit 0
 */
import { execSync } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'

const SERVER = '/workspace/push-ready/server'
const CLIENT = '/workspace/push-ready/src'
const DOC = '/workspace/智能高清增强-方法论与技术方案.md'
const RESULT_JSON = '/workspace/p1-guard-result.json'

/** 安全执行：超时/异常都返回 {ok:false}，绝不抛出 */
function safeExec(cmd: string, timeoutMs = 240_000): { ok: boolean; out: string } {
  try {
    const out = execSync(cmd, {
      cwd: SERVER,
      timeout: timeoutMs,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      maxBuffer: 64 * 1024 * 1024,
    })
    return { ok: true, out: String(out ?? '') }
  } catch (e: unknown) {
    const err = e as { stdout?: string | Buffer; stderr?: string | Buffer; message?: string }
    return { ok: false, out: `${err.stdout ?? ''}${err.stderr ?? ''}` || String(err.message ?? 'exec failed') }
  }
}

function readFileOr(path: string, fallback = ''): string {
  try {
    return existsSync(path) ? readFileSync(path, 'utf8') : fallback
  } catch {
    return fallback
  }
}

interface CheckResult {
  id: string
  name: string
  ok: boolean
  detail: string
}

function guard(id: string, name: string, fn: () => CheckResult): CheckResult {
  try {
    return fn()
  } catch (e: unknown) {
    return { id, name, ok: false, detail: `检查异常：${String((e as Error)?.message ?? e)}` }
  }
}

/** 文件是否包含全部给定片段 */
function hasAll(file: string, needles: string[]): { ok: boolean; missing: string[] } {
  const src = readFileOr(file)
  const missing = needles.filter((n) => !src.includes(n))
  return { ok: src.length > 0 && missing.length === 0, missing }
}

const checks: CheckResult[] = []

// ── C1 单色源检测函数已落地 ───────────────────────────────
checks.push(
  guard('C1', 'detectMonoSource 单色源检测已实现', () => {
    const r = safeExec('grep -rn "export async function detectMonoSource" src/image/*.ts | head -3', 60_000)
    if (!r.ok || !r.out.trim()) return { id: 'C1', name: '单色源检测', ok: false, detail: '未找到 detectMonoSource 导出' }
    return { id: 'C1', name: '单色源检测', ok: true, detail: r.out.trim().split('\n')[0] }
  }),
)

// ── C2 单色检测实测：灰度样本判单色、彩色样本判非单色 ──────
checks.push(
  guard('C2', '单色检测实测判定正确（灰度=单色 / 彩色=非单色）', () => {
    const r = safeExec('npx tsx probe-mono.ts', 240_000)
    if (!r.ok) return { id: 'C2', name: '单色检测实测', ok: false, detail: `探针未跑通：${String(r.out).slice(0, 160)}` }
    const line = r.out.split('\n').find((l) => l.includes('GUARD')) ?? ''
    let data: Record<string, unknown> = {}
    try {
      data = JSON.parse(line.replace(/^.*GUARD\s*/, ''))
    } catch {
      return { id: 'C2', name: '单色检测实测', ok: false, detail: '未解析到 GUARD JSON 行' }
    }
    const grayOk = data.grayIsMono === true
    const colorOk = data.colorIsMono === false
    return {
      id: 'C2',
      name: '单色检测实测',
      ok: grayOk && colorOk,
      detail: `灰度样本 isMono=${data.grayIsMono}（应 true）；彩色样本 isMono=${data.colorIsMono}（应 false）；` +
        `chromaP95 灰=${data.grayChromaP95} 彩=${data.colorChromaP95}`,
    }
  }),
)

// ── C3 智能默认档（autoPreset）接入 service ────────────────
checks.push(
  guard('C3', 'service 智能默认档（单色源→黑白 / 否则增强）', () => {
    const r = hasAll(`${SERVER}/src/image/image.service.ts`, ['detectMonoSource', 'autoPreset'])
    return {
      id: 'C3',
      name: '智能默认档',
      ok: r.ok,
      detail: r.ok ? 'service 已接入 detectMonoSource 并透出 autoPreset' : `缺失：${r.missing.join(', ')}`,
    }
  }),
)

// ── C4 多模式并列输出（enhanceImageModes + modes 存储）──────
checks.push(
  guard('C4', '多模式并列输出（五模式 ingest + modes 返回）', () => {
    const r = hasAll(`${SERVER}/src/image/image.service.ts`, ['enhanceImageModes', 'modes'])
    if (!r.ok) return { id: 'C4', name: '多模式并列输出', ok: false, detail: `缺失：${r.missing.join(', ')}` }
    const t = hasAll(`${SERVER}/src/image/image.types.ts`, ['modes'])
    return {
      id: 'C4',
      name: '多模式并列输出',
      ok: t.ok,
      detail: t.ok ? 'service 调 enhanceImageModes 且 ImageProcessResult 含 modes' : 'types 未声明 modes',
    }
  }),
)

// ── C5 后端 DTO 参数（multi_modes / enhance_preset / strength）──
checks.push(
  guard('C5', '后端 DTO 支持 multi_modes / preset / strength', () => {
    const r = hasAll(`${SERVER}/src/image/image.types.ts`, ['multi_modes', 'enhance_preset', 'enhance_strength'])
    return {
      id: 'C5',
      name: '后端 DTO 参数',
      ok: r.ok,
      detail: r.ok ? 'DTO 三参数齐备' : `缺失：${r.missing.join(', ')}`,
    }
  }),
)

// ── C6 前端 api.ts 透传与类型 ─────────────────────────────
checks.push(
  guard('C6', '前端 api.ts 透传参数 + modes 结果类型', () => {
    const r = hasAll(`${CLIENT}/services/api.ts`, ['enhance_preset', 'enhance_strength', 'multi_modes', 'modes'])
    return {
      id: 'C6',
      name: '前端 api 透传',
      ok: r.ok,
      detail: r.ok ? 'api.ts 参数与结果类型齐备' : `缺失：${r.missing.join(', ')}`,
    }
  }),
)

// ── C7 前端多模式预览自选 UI ──────────────────────────────
checks.push(
  guard('C7', '前端多模式预览自选 UI（缩略图 + 强度档位）', () => {
    const r = hasAll(`${CLIENT}/components/image-editor.tsx`, ['ENHANCE_PRESETS', 'ENHANCE_STRENGTHS'])
    if (!r.ok) return { id: 'C7', name: '前端预览 UI', ok: false, detail: `缺失常量：${r.missing.join(', ')}` }
    const u = hasAll(`${CLIENT}/components/image-editor.tsx`, ['modeThumbs', 'setActivePreset'])
    return {
      id: 'C7',
      name: '前端预览 UI',
      ok: u.ok,
      detail: u.ok ? '模式缩略图条与档位切换已实现' : `缺失交互状态：${u.missing.join(', ')}`,
    }
  }),
)

// ── C8 前端语法校验（可用的唯一前端质量门）──────────────────
checks.push(
  guard('C8', 'TSX 语法校验通过', () => {
    const r = safeExec('npx tsx tsx-syntax-check.ts', 180_000)
    const ok = r.ok && r.out.includes('全部语法校验通过')
    return { id: 'C8', name: 'TSX 语法', ok, detail: ok ? 'image-editor.tsx / api.ts 语法通过' : String(r.out).slice(0, 200) }
  }),
)

// ── C9 既有单模式增强未回归 ───────────────────────────────
checks.push(
  guard('C9', '既有单模式 enhance 路径未破坏', () => {
    const r = hasAll(`${SERVER}/src/image/image.service.ts`, ['enhanceImage(srcBuffer', 'normalizeEnhancePreset'])
    return {
      id: 'C9',
      name: '单模式回归',
      ok: r.ok,
      detail: r.ok ? 'enhanceImage 单模式入口与 preset 归一化仍在' : `缺失：${r.missing.join(', ')}`,
    }
  }),
)

// ── C10 文档记录 P1 后续实施结果 ──────────────────────────
checks.push(
  guard('C10', '方案文档已记录 P1 后续实施结果', () => {
    const src = readFileOr(DOC)
    const ok = src.includes('10.11')
    return { id: 'C10', name: '文档记录', ok, detail: ok ? '§10.11 已写入' : '文档缺少 §10.11' }
  }),
)

const passed = checks.filter((c) => c.ok).length
const failed = checks.filter((c) => !c.ok)

console.log('\n════ P1 后续任务完成度检测 ════')
for (const c of checks) console.log(`${c.ok ? '✅' : '⬜'} ${c.id} ${c.name} — ${c.detail}`)
console.log(`\n通过 ${passed}/${checks.length}`)

writeFileSync(
  RESULT_JSON,
  JSON.stringify(
    { ts: new Date().toISOString(), passed, total: checks.length, done: failed.length === 0, checks },
    null,
    2,
  ),
)
console.log(`结果写入 ${RESULT_JSON}`)

if (failed.length === 0) {
  console.log('\n🎉 P1 后续内容全部完成，检测机制终止。')
  process.exit(0)
}
process.exit(1)
