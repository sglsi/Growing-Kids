/**
 * v20.9 · 图形区判据 v4：局部梯度平坦度（v3 已被实测否决）
 * ============================================================
 * ⭐ v3（中间调占比 midRatio）**被实测推翻**，推翻它的是一个真实产品事故：
 *   probe-manual-zoom 抓到的 page28 实物照片（显微镜视野）：
 *     · 整幅偏暗 → 全部像素落在 [paperL-70, paperL-20] 带**之下** → midRatio = 0%
 *     · 被判为"纯文字区" → 框选后**整块涂成纯白**（目检确认）
 *     · 而 verify-manual-e2e 当时报 A_pass = true（框内擦除 2601 > 0）
 *   根因：v3 判据用**绝对灰阶带**，只对"纸白底"成立。
 *     照片偏暗 → 绝对带失效 → 保护形同虚设。
 *   ⇒ 新判据必须**与绝对亮度无关**（尺度/照度不变）。
 *
 * v4 候选：局部梯度平坦度 flatRatio
 *   原理：文字区 = 大面积**纯白纸面 + 纯黑笔画内部**，梯度**恰好为 0**；
 *         只有笔画边缘一圈有高梯度 → 绝大多数像素"完全平坦"。
 *         照片 = **处处有纹理**，即使整体偏暗也到处有非零梯度。
 *   ⇒ flatRatio（梯度 < ε 的像素占比）与绝对亮度无关，
 *     期望：照片低、文字高。这是本判据**必须实测验证**的假设（沿用 G1 精神）。
 *
 * 同时测多个候选，避免再猜阈值：
 *   midRatio / flatRatio / edgeDensity / spread(p95-p5) / lumaStd
 */
import sharp from 'sharp'
import * as fs from 'fs'

const IN_DIR = '/workspace/wrongq-test'

interface Sample { file: string; box: [number, number, number, number]; what: string; label: 'G' | 'T' }

const GRAPHICS: Sample[] = [
  // ⭐ v3 失效案例：整体偏暗的实物照片（显微镜视野）
  { file: 'page28.png', box: [255, 255, 306, 306], what: '★显微镜照片(v3失效案例)', label: 'G' },
  { file: 'page30.png', box: [530, 1193, 581, 1244], what: '实物照片A', label: 'G' },
  { file: 'page30.png', box: [60, 1200, 111, 1251], what: '实物照片B', label: 'G' },
  { file: 'page28.png', box: [430, 700, 481, 751], what: '插图', label: 'G' },
  { file: 'page29.png', box: [300, 600, 351, 651], what: '图片区', label: 'G' },
  // E2E 自动选框命中的图形（verify-manual-e2e 实测：这三个都被拒擦）
  { file: 'page29.png', box: [459, 450, 510, 501], what: 'E2E-auto命中图形', label: 'G' },
  { file: 'page31.png', box: [102, 566, 153, 617], what: 'E2E-auto命中图形', label: 'G' },
]
const TEXT: Sample[] = [
  { file: 'page30.png', box: [40, 60, 91, 111], what: '左栏正文段1', label: 'T' },
  { file: 'page30.png', box: [40, 170, 91, 221], what: '左栏正文段2', label: 'T' },
  { file: 'page30.png', box: [640, 60, 691, 111], what: '右栏正文段1', label: 'T' },
  { file: 'page30.png', box: [640, 170, 691, 221], what: '右栏正文段2', label: 'T' },
  { file: 'page28.png', box: [40, 60, 91, 111], what: '左栏正文段', label: 'T' },
  { file: 'page29.png', box: [40, 60, 91, 111], what: '左栏正文段', label: 'T' },
  { file: 'page31.png', box: [40, 60, 91, 111], what: '左栏正文段', label: 'T' },
  // E2E text 用例框（实为纯文字区，被接受并补擦成功）
  { file: 'page29.png', box: [459, 654, 510, 705], what: 'E2E-text命中文字', label: 'T' },
  { file: 'page30.png', box: [663, 1254, 714, 1305], what: 'E2E-text命中文字', label: 'T' },
]

async function loadGray(file: string) {
  const buf = fs.readFileSync(`${IN_DIR}/${file}`)
  const { data: g, info } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
  return { g, w: info.width, h: info.height }
}

function measure(
  g: Buffer, w: number, h: number,
  box: [number, number, number, number],
  paperL: number,
) {
  const [x0, y0, x1, y1] = box
  const hist = new Int32Array(256)
  const vals: number[] = []
  let tot = 0
  for (let y = Math.max(1, y0); y <= Math.min(h - 2, y1); y++) {
    for (let x = Math.max(1, x0); x <= Math.min(w - 2, x1); x++) {
      const v = g[y * w + x]
      hist[v]++; vals.push(v); tot++
    }
  }
  if (!tot) return null

  // ① midRatio（v3，绝对带）—— 预期在偏暗照片上失效
  let mid = 0
  for (let v = Math.max(0, paperL - 70); v <= Math.round(paperL - 20); v++) mid += hist[v]
  const midRatio = mid / tot

  // ② 局部梯度平坦度（v4 候选）：Sobel 幅度 < ε 的像素占比
  const EPS = 10
  let flat = 0, gradSum = 0
  for (let y = Math.max(1, y0); y <= Math.min(h - 2, y1); y++) {
    for (let x = Math.max(1, x0); x <= Math.min(w - 2, x1); x++) {
      const p = y * w + x
      const gx = -g[p - w - 1] - 2 * g[p - 1] - g[p + w - 1] + g[p - w + 1] + 2 * g[p + 1] + g[p + w + 1]
      const gy = -g[p - w - 1] - 2 * g[p - w] - g[p - w + 1] + g[p + w - 1] + 2 * g[p + w] + g[p + w + 1]
      const mag = Math.sqrt(gx * gx + gy * gy)
      gradSum += mag
      if (mag < EPS) flat++
    }
  }
  const flatRatio = flat / tot
  const meanGrad = gradSum / tot

  // ③ edgeDensity：梯度 ≥ 40 的像素占比（笔画边缘密度）
  let strongEdge = 0
  for (let y = Math.max(1, y0); y <= Math.min(h - 2, y1); y++) {
    for (let x = Math.max(1, x0); x <= Math.min(w - 2, x1); x++) {
      const p = y * w + x
      const gx = -g[p - w - 1] - 2 * g[p - 1] - g[p + w - 1] + g[p - w + 1] + 2 * g[p + 1] + g[p + w + 1]
      const gy = -g[p - w - 1] - 2 * g[p - w] - g[p - w + 1] + g[p + w - 1] + 2 * g[p + w] + g[p + w + 1]
      if (Math.sqrt(gx * gx + gy * gy) >= 40) strongEdge++
    }
  }
  const edgeDensity = strongEdge / tot

  // ④ 动态范围与标准差
  vals.sort((a, b) => a - b)
  const p05 = vals[Math.floor(vals.length * 0.05)]
  const p95 = vals[Math.floor(vals.length * 0.95)]
  const spread = p95 - p05
  const mean = vals.reduce((s, v) => s + v, 0) / vals.length
  const lumaStd = Math.sqrt(vals.reduce((s, v) => s + (v - mean) ** 2, 0) / vals.length)

  return { midRatio, flatRatio, meanGrad, edgeDensity, spread, lumaStd, mean, paperL }
}

async function main() {
  const papers: Record<string, number> = {}
  const files = [...new Set([...GRAPHICS, ...TEXT].map((s) => s.file))].sort()
  for (const f of files) {
    const { g, w, h } = await loadGray(f)
    const ls: number[] = []
    for (let p = 0; p < g.length; p += 7) ls.push(g[p])
    ls.sort((a, b) => a - b)
    papers[f] = ls[Math.floor(ls.length * 0.98)]
  }

  const rows: any[] = []
  for (const s of [...GRAPHICS, ...TEXT]) {
    const { g, w, h } = await loadGray(s.file)
    const m = measure(g, w, h, s.box, papers[s.file])
    if (!m) { console.error(`skip ${s.file} ${s.what}`); continue }
    rows.push({ label: s.label, what: s.what, file: s.file, mean: +m.mean.toFixed(0), ...Object.fromEntries(Object.entries(m).filter(([k]) => k !== 'mean' && k !== 'paperL').map(([k, v]) => [k, +(v as number).toFixed(4)])) })
  }

  const cols = ['midRatio', 'flatRatio', 'meanGrad', 'edgeDensity', 'spread', 'lumaStd'] as const
  console.log('\n| 类型 | 样本 | midRatio | flatRatio | meanGrad | edgeDensity | spread | lumaStd | 均值 |')
  console.log('|---|---|---|---|---|---|---|---|---|')
  for (const r of rows) {
    console.log(`| ${r.label === 'G' ? '**图形**' : '文字'} | ${r.what} | ${r.midRatio} | ${r.flatRatio} | ${r.meanGrad} | ${r.edgeDensity} | ${r.spread} | ${r.lumaStd} | ${r.mean} |`)
  }

  // 分离度：AUC（G 全部应低于文字，或高于——给方向）
  const auc = (get: (r: any) => number) => {
    const G = rows.filter((r) => r.label === 'G').map(get)
    const T = rows.filter((r) => r.label === 'T').map(get)
    let s = 0
    for (const g of G) for (const t of T) s += g > t ? 1 : g === t ? 0.5 : 0
    return +(s / (G.length * T.length)).toFixed(3)
  }
  console.log('\n| 判据 | AUC(G< T) | AUC(G>T) | G范围 | T范围 |')
  console.log('|---|---|---|---|---|')
  for (const c of cols) {
    const G = rows.filter((r) => r.label === 'G').map((r) => r[c])
    const T = rows.filter((r) => r.label === 'T').map((r) => r[c])
    const a1 = auc((r) => r[c])
    const a2 = 1 - a1
    const fmt = (a: number[]) => `${Math.min(...a).toFixed(3)}~${Math.max(...a).toFixed(3)}`
    console.log(`| ${c} | ${a1} | ${a2} | ${fmt(G)} | ${fmt(T)} |`)
  }
  console.log(`\nGUARD_RANGE ${JSON.stringify({ AUC_best: [0.85, 1.0] })}`)
}

main().catch((e) => { console.error(e); process.exit(1) })