/**
 * v20.9 · 图形区保护阈值标定（G1 前提：阈值必须实测，不得凭推理）
 * ============================================================
 * 背景：v20.9 发现严重缺陷 —— 用户框到**实物照片**（报纸插图）时，
 *   整块照片被涂成纯白，图片内容不可逆摧毁。
 *   修复手段是"框内暗像素占比 > 阈值 → 判为图形区 → 整框拒绝"。
 *   **但那个阈值 0.45 是我猜的**。猜阈值 = 重犯 v20.6「参数靠调出来的」老毛病。
 *
 * 本探针从真实样本标定两个分布：
 *   · 文字区（纯文字 + 手写）：暗像素占比
 *   · 图形区（照片/插图/表格底纹）：暗像素占比
 * 给出分离度与建议阈值。
 *
 * ⭐ 同时纠正一个更根本的问题：**用"暗像素占比"判图形本身就不对**。
 *   报纸上的**深色插图**也可能很亮（白底线描图），而**文字区**遇到
 *   反白/加粗也可能很暗。占比只是代理指标，真实判据应是
 *   「该区域是否存在**大片连续**的非白内容」—— 即连通性/密度。
 *   本探针同时测 `darkRunRatio`（最长连续暗游程占比）作为更准的候选判据。
 */
import sharp from 'sharp'
import * as fs from 'fs'

const IN_DIR = '/workspace/wrongq-test'

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()

  // 人工标注的图形区（报纸插图/照片位置，取自 page30 第 22-23 题的实物图、
  // page28 的地图/图表、page29 的图片区）。坐标为原图像素 (x0,y0,x1,y1)。
  const GRAPHICS: Array<{ file: string; box: [number, number, number, number]; what: string }> = [
    { file: 'page30.png', box: [530, 1193, 581, 1244], what: '实物照片（玻璃杯/订书机）' },
    { file: 'page30.png', box: [60, 1200, 111, 1251], what: '实物照片（第二张）' },
    { file: 'page28.png', box: [430, 700, 481, 751], what: '插图区域' },
    { file: 'page28.png', box: [700, 1000, 751, 1051], what: '插图/表格' },
    { file: 'page29.png', box: [300, 600, 351, 651], what: '图片区域' },
  ]

  for (const file of files) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: g, info } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height
    const ls: number[] = []
    for (let p = 0; p < g.length; p += 7) ls.push(g[p])
    ls.sort((a, b) => a - b)
    const paperL = ls[Math.floor(ls.length * 0.98)]
    const paperTh = paperL - 42

    // ① 整页分块统计：哪些块是"图形区"（靠人工标注验证）
    const BS = 51
    const blocks: Array<{ x: number; y: number; dark: number; run: number }> = []
    for (let by = 0; by + BS <= h; by += BS) {
      for (let bx = 0; bx + BS <= w; bx += BS) {
        let dark = 0, maxRun = 0
        for (let y = by; y < by + BS; y++) {
          const b = y * w
          let run = 0
          for (let x = bx; x < bx + BS; x++) {
            if (g[b + x] < paperTh) { dark++; run++; if (run > maxRun) maxRun = run }
          }
        }
        blocks.push({ x: bx, y: by, dark: dark / (BS * BS), run: maxRun / BS })
      }
    }
    const darks = blocks.map((b) => b.dark).sort((a, b) => a - b)
    const runs = blocks.map((b) => b.run).sort((a, b) => a - b)
    const q = (a: number[], p: number) => a[Math.floor(a.length * p)]

    // ② 人工标注区的实测值
    const marked = GRAPHICS.filter((m) => m.file === file).map((m) => {
      const [x0, y0, x1, y1] = m.box
      let dark = 0, tot = 0, maxRun = 0
      for (let y = y0; y <= y1; y++) {
        const b = y * w
        let run = 0
        for (let x = x0; x <= x1; x++) {
          tot++
          if (g[b + x] < paperTh) { dark++; run++; if (run > maxRun) maxRun = run }
        }
      }
      return { ...m, darkRatio: +(dark / tot).toFixed(3), runRatio: +(maxRun / (x1 - x0 + 1)).toFixed(3) }
    })

    console.log(`\n=== ${file} (paperL=${paperL.toFixed(0)} paperTh=${paperTh.toFixed(0)}) ===`)
    console.log(`  全页 ${blocks.length} 块 darkRatio: p10=${q(darks, 0.1).toFixed(2)} p50=${q(darks, 0.5).toFixed(2)} p90=${q(darks, 0.9).toFixed(2)} p99=${q(darks, 0.99).toFixed(2)}`)
    console.log(`              runRatio:  p10=${q(runs, 0.1).toFixed(2)} p50=${q(runs, 0.5).toFixed(2)} p90=${q(runs, 0.9).toFixed(2)} p99=${q(runs, 0.99).toFixed(2)}`)
    for (const m of marked) {
      console.log(`  ★图形区 [${m.box.join(',')}] ${m.what}: darkRatio=${m.darkRatio} runRatio=${m.runRatio}`)
    }
    // 最高 darkRatio 的 5 块（候选图形区）
    const top = [...blocks].sort((a, b) => b.dark - a.dark).slice(0, 5)
    console.log(`  最暗 5 块: ${top.map((b) => `(${b.x},${b.y})dark=${b.dark.toFixed(2)} run=${b.run.toFixed(2)}`).join(' ')}`)
  }
}

main().catch((e) => { console.error(e); process.exit(1) })
