/**
 * G3 目检取证：框内「笔迹像素」机制的 before/after/mask 三联（放大 8 倍）
 *
 * 用途：验收数字全绿 ≠ 图对了。本探针把每个目标裁出放大，
 *   供逐项目检"印刷体是否真的保住了"。
 *
 * ⚠️ 本文件必须放在**工作区内**：/tmp 在本沙箱会被隔离清空
 *   （已踩两次：/tmp/gk-probe 克隆消失、/tmp/g3.ts 消失）。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN = '/workspace/wrongq-test'
const OUT = '/workspace/v20-框选E2E/v209'

const CASES: Array<{ file: string; box: [number, number, number, number]; what: string }> = [
  { file: 'page29.png', box: [700, 620, 750, 670], what: '右栏红笔区' },
  { file: 'page28.png', box: [255, 255, 306, 306], what: '显微镜照片' },
  { file: 'page31.png', box: [280, 250, 330, 300], what: '中栏正文' },
]

const Z = 8

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  for (const c of CASES) {
    const buf = fs.readFileSync(`${IN}/${c.file}`)
    const meta = await sharp(buf).metadata()
    const regions = [{
      x: +(c.box[0] / meta.width!).toFixed(4),
      y: +(c.box[1] / meta.height!).toFixed(4),
      w: +((c.box[2] - c.box[0] + 1) / meta.width!).toFixed(4),
      h: +((c.box[3] - c.box[1] + 1) / meta.height!).toFixed(4),
    }]
    const man = await buildHandwritingMask(buf, '', {}, {
      allowVlm: false, eraseMode: 'hybrid', manualRects: regions,
    })
    const img = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)

    const cw = c.box[2] - c.box[0] + 1, ch = c.box[3] - c.box[1] + 1
    const mk = (src: Buffer, raw1ch = false) => sharp(
      raw1ch ? Buffer.from(src) : src,
      raw1ch ? { raw: { width: man.mask.width, height: man.mask.height, channels: 1 } } : {},
    ).extract({ left: c.box[0], top: c.box[1], width: cw, height: ch })
      .resize({ width: cw * Z, kernel: 'nearest' }).png().toBuffer()

    const orig = await mk(buf)
    const after = await mk(img)
    const maskImg = await mk(man.mask.data, true)

    const W = cw * Z, H = ch * Z
    const label = (t: string) => Buffer.from(
      `<svg width="${W}" height="${H}"><rect width="${W}" height="${H}" fill="none" stroke="#0a0" stroke-width="2"/>` +
      `<text x="4" y="16" font-size="13" fill="#0a0">${t}</text></svg>`,
    )
    const sheet = await sharp({
      create: { width: W + 4, height: (H + 4) * 3, channels: 3, background: { r: 255, g: 0, b: 255 } },
    }).composite([
      { input: orig, left: 0, top: 0 },
      { input: after, left: 0, top: H + 4 },
      { input: maskImg, left: 0, top: (H + 4) * 2 },
      { input: label('1.orig'), left: 0, top: 0 },
      { input: label('2.after'), left: 0, top: H + 4 },
      { input: label('3.mask'), left: 0, top: (H + 4) * 2 },
    ]).png().toBuffer()

    const f = `${OUT}/g3-${c.file.replace('.png', '')}-${c.what}.png`
    fs.writeFileSync(f, sheet)
    const dbg = (man.mask.debug ?? {}) as Record<string, unknown>
    console.error(`[${c.file}/${c.what}] ${f} 笔迹占比=${dbg.manualStrokeRatio} 新增mask=${dbg.manualAddedPx}px 放大${Z}倍`)
  }
}

main().catch((e) => { console.error(e); process.exit(1) })