/**
 * 框选补擦：残留来源归因
 * 假设：buildHandwritingMask(manualRects) 产出的是整块实心 mask，
 *       残留不是 mask 没盖住，而是 inpaint('adaptive') 判定区域内有印刷体/横线时
 *       **有意做结构延拓、保留线条**（区别于 the wrong conclusion "框选没擦干净"）。
 * 对照：同一批 manual 框，分别用 adaptive / median / masked 三种策略修复，
 *       若 median/masked 残留趋近 0 → mask 覆盖没问题，adaptive 的残留是**刻意保留的印刷线条**。
 */
import sharp from '/workspace/push-ready/server/node_modules/sharp'
import { buildHandwritingMask } from '/workspace/push-ready/server/src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from '/workspace/push-ready/server/src/image/handwriting-mask'

const PATH = '/root/uploads/1790697352956629135-1790697330026-hq5z96hx-9e12369282df0f327502a0364da8ea20.jpg'
const W = 1279, H = 1706
// 只取 3 个大框（残留最明显的区域）做归因，避免跑太慢
const BOXES: Array<[string, number, number, number, number]> = [
  ['13题-取值范围', 880, 440, 400, 90],
  ['16题-填空线序号', 820, 985, 460, 70],
  ['20题-手写', 30, 1225, 950, 480],
]

async function inkAt(src: Buffer, x: number, y: number, w: number, h: number) {
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true })
  const Wd = info.width
  let n = 0
  for (let yy = y; yy < Math.min(info.height, y + h); yy++)
    for (let xx = x; xx < Math.min(Wd, x + w); xx++) {
      const p = (yy * Wd + xx) * info.channels
      if (0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2] < 140) n++
    }
  return n
}

async function main() {
  const src = await sharp(PATH).rotate().png().toBuffer()
  const manual = BOXES.map(([, x, y, w, h]) => ({ x: x / W, y: y / H, w: w / W, h: h / H }))
  const seg = await buildHandwritingMask(src, '', {}, { allowVlm: false, manualRects: manual })
  const mask = seg.mask

  // ★ 先确认 mask 是否真的盖满整个框（取样框中心一个 3x3 区域）
  let fullInBox = 0, totalInBox = 0
  for (const [, x, y, w, h] of BOXES) {
    for (let yy = y; yy < y + h; yy++)
      for (let xx = x; xx < x + w; xx++) { totalInBox++; if (mask.data[yy * mask.width + xx] > 200) fullInBox++ }
  }
  console.log(`框内 mask 覆盖率 = ${((fullInBox / totalInBox) * 100).toFixed(2)}%（接近 100% 才说明框被完整盖住）\n`)

  console.log('区域              | 原图墨px | adaptive | median  | masked')
  console.log('---|---|---|---|---')
  for (const [name, x, y, w, h] of BOXES) {
    const before = await inkAt(src, x, y, w, h)
    const row: string[] = []
    for (const st of ['adaptive', 'median', 'masked'] as const) {
      const inp = await inpaint(src, st, mask)
      const merged = await blendWithMask(src, inp, mask)
      const after = await inkAt(merged, x, y, w, h)
      row.push(`${String(after).padStart(6)}(${String(Math.round(((before - after) / before) * 100)).padStart(3)}%)`)
    }
    console.log(`${name.padEnd(16)} | ${String(before).padStart(8)} | ${row.join(' | ')}`)
  }
  console.log('\n若 median/masked 显著低于 adaptive 的残留 → 残留源自 adaptive 刻意保留印刷线条，非 mask 覆盖失败')
}
main().catch((e) => { console.error(e); process.exit(1) })
