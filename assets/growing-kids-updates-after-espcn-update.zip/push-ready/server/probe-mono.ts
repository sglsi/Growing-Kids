/**
 * 单色源检测验证探针（供 p1-guard C2 解析）
 * 样本：① 真扫描件 page-1.png（含红笔 → 应判非单色）② 其 b-w 灰度副本（应判单色）
 * 输出机器可读行：GUARD {"grayIsMono":true,"colorIsMono":false,...}
 */
import fs from 'fs'
import sharp from 'sharp'
import { detectMonoSource } from './src/image/image-doc-enhance'

const SRC = '/workspace/erase-work/page-1.png'
const GRAY = '/workspace/erase-work/probe-gray-sample.png'

async function main() {
  const colorBuf = fs.readFileSync(SRC)
  // 灰度副本：真实黑白打印件的最强代理（彩度恒为 0）
  const grayBuf = await sharp(colorBuf).toColourspace('b-w').png().toBuffer()
  fs.writeFileSync(GRAY, grayBuf)

  const g = await detectMonoSource(grayBuf)
  const c = await detectMonoSource(colorBuf)

  console.log('灰度样本:', JSON.stringify(g))
  console.log('彩色样本:', JSON.stringify(c))
  console.log(
    'GUARD ' +
      JSON.stringify({
        grayIsMono: g.isMono,
        colorIsMono: c.isMono,
        grayChromaP95: g.inkChromaP95,
        colorChromaP95: c.inkChromaP95,
        graySep: g.otsuSeparation,
        colorSep: c.otsuSeparation,
      }),
  )
}
main().catch((e) => {
  console.error(e)
  process.exit(1)
})
