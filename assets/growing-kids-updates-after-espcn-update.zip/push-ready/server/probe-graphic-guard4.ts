/**
 * 图形区判据标定 · 第 2 步：基于**目视确认标注**重测判据
 * ============================================================
 * ⭐ 本文件存在的唯一理由：probe-graphic-guard3 的结论是**无效的**。
 *   它的标注靠坐标猜，目检后发现 7 个"图形"样本里 5 个是印刷文字、
 *   4 个"文字"样本是纯白空白 —— 在错误标注上测出的 AUC 没有意义。
 *
 * ✅ 标注来源：probe-graphic-cand.ts 生成的 19 格对照图，**逐格目视确认**。
 *   真图形：#1 #2 #3 #9（4 个）
 *   文字  ：#4 #5 #7 #8 #11 #12 #13 #14 #15 #16 #17 #18（12 个）
 *   空白  ：#0 #6 #10（3 个，单独归类 —— 既不是文字也不是图形）
 *
 * 判据候选（在**正确标注**上重测）：
 *   midRatio(绝对带)   v3 —— 预期在偏暗照片上失效
 *   midRatioRel(相对带) v3 的尺度不变修正
 *   flatRatio          局部梯度平坦度（绝对亮度无关）
 *   edgeDensity        强边缘占比
 *   lumaStd            灰度标准差
 *
 * 输出各判据 AUC + 阈值扫描。**AUC<0.85 一律否决，不硬凑**（G1）。
 */
import sharp from 'sharp'
import * as fs from 'fs'

const IN_DIR = '/workspace/wrongq-test'

type Label = 'G' | 'T' | 'B'   // Graphic / Text / Blank

interface Sample { no: number; file: string; box: [number, number, number, number]; what: string; label: Label }

// ⭐ 全部来自 probe-graphic-cand 对照图的逐格目视确认
const SAMPLES: Sample[] = [
  { no: 1, file: 'page28.png', box: [690, 60, 740, 110], what: '灰度照片', label: 'G' },
  { no: 2, file: 'page28.png', box: [255, 255, 306, 306], what: '照片·物体', label: 'G' },
  { no: 3, file: 'page28.png', box: [430, 300, 480, 350], what: '照片·物体2', label: 'G' },
  { no: 9, file: 'page30.png', box: [390, 1270, 440, 1320], what: '选项图片', label: 'G' },
  { no: 4, file: 'page29.png', box: [360, 150, 410, 200], what: '表格区', label: 'T' },
  { no: 5, file: 'page29.png', box: [440, 150, 490, 200], what: '表格区2', label: 'T' },
  { no: 7, file: 'page30.png', box: [310, 570, 360, 620], what: '印刷选项', label: 'T' },
  { no: 8, file: 'page30.png', box: [400, 570, 450, 620], what: '印刷选项2', label: 'T' },
  { no: 11, file: 'page31.png', box: [60, 60, 110, 110], what: '页眉文字', label: 'T' },
  { no: 12, file: 'page28.png', box: [60, 330, 110, 380], what: '左栏英文段', label: 'T' },
  { no: 13, file: 'page29.png', box: [55, 100, 105, 150], what: '左栏正文', label: 'T' },
  { no: 14, file: 'page30.png', box: [55, 1050, 105, 1100], what: '左栏正文', label: 'T' },
  { no: 15, file: 'page31.png', box: [280, 250, 330, 300], what: '中栏正文', label: 'T' },
  { no: 16, file: 'page31.png', box: [700, 300, 750, 350], what: '右栏手写区', label: 'T' },
  { no: 17, file: 'page29.png', box: [700, 620, 750, 670], what: '右栏红笔区', label: 'T' },
  { no: 18, file: 'page29.png', box: [660, 1220, 710, 1270], what: '底部署名', label: 'T' },
  { no: 0, file: 'page28.png', box: [690, 60, 740, 110], what: '页眉横线(与#1重叠,此处记B)', label: 'B' },
  { no: 6, file: 'page30.png', box: [680, 90, 730, 140], what: '空白', label: 'B' },
  { no: 10, file: 'page30.png', box: [390, 1310, 440, 1360], what: '空白2', label: 'B' },
]

interface Metrics {
  midRatioAbs: number
  midRatioRel: number
  flatRatio: number
  edgeDensity: number
  lumaStd: number
  mean: number
  spread: number
}

async function loadGray(file: string) {
  const buf = fs.readFileSync(`${IN_DIR}/${file}`)
  const { data: g, info } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
  return { g, w: info.width, h: info.height }
}

function measure(g: Buffer, w: number, h: number, box: [number, number, number, number], paperL: number): Metrics | null {
  const [bx0, by0, bx1, by1] = box
  const hist = new Int32Array(256)
  const vals: number[] = []
  let tot = 0
  for (let y = Math.max(1, by0); y <= Math.min(h - 2, by1); y++) {
    for (let x = Math.max(1, bx0); x <= Math.min(w - 2, bx1); x++) {
      const v = g[y * w + x]
      hist[v]++; vals.push(v); tot++
    }
  }
  if (tot < 50) return null

  // ① 绝对带 midRatio（v3 现用）—— 偏暗照片必失效
  let midAbs = 0
  for (let v = Math.max(0, paperL - 70); v <= Math.round(paperL - 20); v++) midAbs += hist[v]

  // ② 相对带 midRatioRel：以**框内自身**灰阶范围为准，尺度/亮度不变
  vals.sort((a, b) => a - b)
  const lo = vals[Math.floor(vals.length * 0.05)]
  const hi = vals[Math.floor(vals.length * 0.95)]
  const band = Math.max(10, (hi - lo) * 0.45)
  let midRel = 0
  for (let v = Math.max(0, Math.round(lo + band)); v <= Math.min(255, Math.round(hi - band)); v++) midRel += hist[v]

  // ③ flatRatio：Sobel 幅度 < 10 的像素占比（绝对亮度无关）
  const EPS = 10
  let flat = 0, strong = 0, gradSum = 0
  let cx = 0, cy = 0, n2 = 0
  for (let y = Math.max(1, by0); y <= Math.min(h - 2, by1); y++) {
    for (let x = Math.max(1, bx0); x <= Math.min(w - 2, bx1); x++) {
      const p = y * w + x
      const gx = -g[p - w - 1] - 2 * g[p - 1] - g[p + w - 1] + g[p - w + 1] + 2 * g[p + 1] + g[p + w + 1]
      const gy = -g[p - w - 1] - 2 * g[p - w] - g[p - w + 1] + g[p + w - 1] + 2 * g[p + w] + g[p + w + 1]
      const mag = Math.sqrt(gx * gx + gy * gy)
      gradSum += mag
      if (mag < EPS) flat++
      if (mag >= 40) strong++
      cx += g[p]; cy += g[p]; n2++
    }
  }
  const mean = cx / n2
  let varSum = 0
  for (let y = Math.max(1, by0); y <= Math.min(h - 2, by1); y++) {
    for (let x = Math.max(1, bx0); x <= Math.min(w - 2, bx1); x++) {
      const d = g[y * w + x] - mean
      varSum += d * d
    }
  }

  return {
    midRatioAbs: midAbs / tot,
    midRatioRel: midRel / tot,
    flatRatio: flat / tot,
    edgeDensity: strong / tot,
    lumaStd: Math.sqrt(varSum / n2),
    mean,
    spread: hi - lo,
  }
}

async function main() {
  const papers: Record<string, number> = {}
  for (const f of [...new Set(SAMPLES.map((s) => s.file))]) {
    const { g } = await loadGray(f)
    const ls: number[] = []
    for (let p = 0; p < g.length; p += 7) ls.push(g[p])
    ls.sort((a, b) => a - b)
    papers[f] = ls[Math.floor(ls.length * 0.98)]
  }

  const rows: Array<{ s: Sample; m: Metrics }> = []
  for (const s of SAMPLES) {
    const { g, w, h } = await loadGray(s.file)
    const m = measure(g, w, h, s.box, papers[s.file])
    if (m) rows.push({ s, m })
  }

  const keys = ['midRatioAbs', 'midRatioRel', 'flatRatio', 'edgeDensity', 'lumaStd', 'spread', 'mean'] as const
  console.log('\n| 标注 | # | 样本 | midAbs | midRel | flatRatio | edgeDens | lumaStd | mean |')
  console.log('|---|---|---|---|---|---|---|---|---|')
  for (const { s, m } of rows) {
    const L = s.label === 'G' ? '**图形**' : s.label === 'T' ? '文字' : '空白'
    console.log(`| ${L} | ${s.no} | ${s.what} | ${m.midRatioAbs.toFixed(3)} | ${m.midRatioRel.toFixed(3)} | ` +
      `${m.flatRatio.toFixed(3)} | ${m.edgeDensity.toFixed(3)} | ${m.lumaStd.toFixed(1)} | ${m.mean.toFixed(0)} |`)
  }

  // AUC：P(score(G) > score(T))，衡量"分数越大越是图形"
  const auc = (get: (m: Metrics) => number) => {
    const G = rows.filter((r) => r.s.label === 'G').map((r) => get(r.m))
    const T = rows.filter((r) => r.s.label === 'T').map((r) => get(r.m))
    let s = 0
    for (const g of G) for (const t of T) s += g > t ? 1 : g === t ? 0.5 : 0
    return s / (G.length * T.length)
  }

  console.log('\n| 判据 | AUC | 方向 | G范围 | T范围 | 结论 |')
  console.log('|---|---|---|---|---|---|')
  const verdict: Record<string, string> = {}
  for (const k of keys) {
    const a = auc((m) => m[k])
    const best = Math.max(a, 1 - a)
    const G = rows.filter((r) => r.s.label === 'G').map((r) => r.m[k])
    const T = rows.filter((r) => r.s.label === 'T').map((r) => r.m[k])
    const fmt = (x: number[]) => `${Math.min(...x).toFixed(3)}~${Math.max(...x).toFixed(3)}`
    const ok = best >= 0.85
    verdict[k] = ok ? '✅ 可用' : '❌ 否决'
    console.log(`| ${k} | ${a.toFixed(3)} | ${a >= 0.5 ? '越大越是图形' : '越小越是图形'} | ${fmt(G)} | ${fmt(T)} | ${verdict[k]} |`)
  }

  // 对可用判据做阈值扫描：找能 4/4 命中图形 且 0/12 误伤文字 的阈值
  for (const k of keys) {
    const a = auc((m) => m[k])
    const G = rows.filter((r) => r.s.label === 'G').map((r) => r.m[k])
    const T = rows.filter((r) => r.s.label === 'T').map((r) => r.m[k])
    if (Math.max(a, 1 - a) < 0.85) continue
    const dirHigh = a >= 0.5
    console.log(`\n【${k}】阈值扫描 (${dirHigh ? '分数>阈值为图形' : '分数<阈值为图形'}):`)
    const cand = dirHigh
      ? [...new Set([...G, ...T])].sort((x, y) => x - y)
      : [...new Set([...G, ...T])].sort((x, y) => x - y)
    let bestHit = 0, bestTh = NaN, bestFp = 999
    for (const th of cand) {
      const hit = G.filter((v) => (dirHigh ? v > th : v < th)).length
      const fp = T.filter((v) => (dirHigh ? v > th : v < th)).length
      if (hit > bestHit || (hit === bestHit && fp < bestFp)) {
        if (hit >= bestHit) { bestHit = hit; bestTh = th; bestFp = fp }
      }
    }
    // 找满足 hit=G.length && fp=0 的最宽阈值区间中点
    let lo = NaN, hi = NaN
    for (const th of [...cand].sort((x, y) => x - y)) {
      const hit = G.filter((v) => (dirHigh ? v > th : v < th)).length
      const fp = T.filter((v) => (dirHigh ? v > th : v < th)).length
      if (hit === G.length && fp === 0) {
        if (Number.isNaN(lo)) lo = th
        hi = th
      }
    }
    const hasClean = !Number.isNaN(lo)
    console.log(`  全命中且零误伤区间: ${hasClean ? `[${lo.toFixed(4)}, ${hi.toFixed(4)}] → 建议阈值 ${((lo + hi) / 2).toFixed(4)}` : '**不存在**（无法零误伤）'}`)
    if (!hasClean) {
      // 放宽：允许误伤最少
      let bh = 0, bfp = 1e9, bth = NaN
      for (const th of cand) {
        const hit = G.filter((v) => (dirHigh ? v > th : v < th)).length
        const fp = T.filter((v) => (dirHigh ? v > th : v < th)).length
        if (hit > bh || (hit === bh && fp < bfp)) { bh = hit; bfp = fp; bth = th }
      }
      console.log(`  最优折中: 阈值 ${bth.toFixed(4)} → 命中 ${bh}/${G.length}，误伤 ${bfp}/${T.length}`)
    }
  }

  console.log(`\nGUARD_RANGE ${JSON.stringify({ AUC_best: [0.85, 1.0] })}`)
}

main().catch((e) => { console.error(e); process.exit(1) })