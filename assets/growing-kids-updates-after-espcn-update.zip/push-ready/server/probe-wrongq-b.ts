/**
 * 路径 B 验证探针：4 张《学英语》报纸样例端到端
 *
 * 覆盖：
 *  A. 版面：三栏切分 + 栏内行切分（用户反馈 1）
 *  B. 红笔标记：家具排除 + 闭运算补连 + 形态分类（用户反馈 2）
 *  C. 题块构建（红笔簇为锚点）+ 本地判定
 *  D. VLM：契约测试（解析纯函数）+ 真实调用探针（预期 fail-open）
 *  E. 诊断图：布局图 / 题块图 / 去红预览
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildLayoutContext } from './src/image/wrongq-layout'
import { detectRedMarks } from './src/image/wrongq-mark'
import { buildBlocks } from './src/image/wrongq-block'
import { decideLocal } from './src/image/wrongq-decide'
import { parseVlmItems, vlmQuestionBlocks } from './src/image/wrongq-vlm'
import type { MarkKind } from './src/image/wrongq.types'

const IN_DIR = '/workspace/wrongq-test'

async function probePage(file: string) {
  const buf = fs.readFileSync(file)
  const ctx = await buildLayoutContext(buf)
  const { w, h, medH, cols, colRows, luma, flatBuf } = ctx
  const red = await detectRedMarks(flatBuf, ctx, { chromaMin: 14 })
  const blocks = buildBlocks(red.marks, ctx)
  decideLocal(blocks, red.marks)

  const kindDist: Record<string, number> = {}
  for (const m of red.marks) kindDist[m.kind] = (kindDist[m.kind] ?? 0) + 1
  const verdictDist: Record<string, number> = {}
  for (const b of blocks) verdictDist[b.verdict] = (verdictDist[b.verdict] ?? 0) + 1

  // ── 诊断图 ──
  const dw = 900
  const dh = Math.round((h / w) * dw)
  const baseGray = await sharp(flatBuf).resize(dw, dh, { fit: 'fill' }).grayscale().removeAlpha().raw().toBuffer()
  const sx = dw / w, sy = dh / h
  const put = (b3: Buffer, x: number, y: number, r: number, g: number, bl: number) => {
    if (x < 0 || y < 0 || x >= dw || y >= dh) return
    const q3 = (y * dw + x) * 3; b3[q3] = r; b3[q3 + 1] = g; b3[q3 + 2] = bl
  }
  const grayBase = (b3: Buffer) => {
    for (let i = 0, q3 = 0; i < dw * dh; i++, q3 += 3) { const g = baseGray[i]; b3[q3] = g; b3[q3 + 1] = g; b3[q3 + 2] = g }
  }

  // ① 布局图：绿=栏界，蓝=栏内行界
  const out1 = Buffer.alloc(dw * dh * 3)
  grayBase(out1)
  for (const [a, b] of cols) for (const gx of [a, b]) { const dx = Math.round(gx * sx); for (let y = 0; y < dh; y++) put(out1, dx, y, 0, 200, 0) }
  cols.forEach(([a, b], ci) => {
    for (const r of colRows[ci]) {
      const dy = Math.round(r.y0 * sy)
      for (let x = Math.round(a * sx); x <= Math.round(b * sx); x += 2) put(out1, x, dy, 40, 120, 255)
    }
  })
  const f1 = path.join(IN_DIR, 'diagB-col-' + path.basename(file))
  await sharp(out1, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(f1)

  // ② 题块图：按判定着色（wrong=红, correct=绿, unknown=橙）
  const out2 = Buffer.alloc(dw * dh * 3)
  grayBase(out2)
  const vColor: Record<string, [number, number, number]> = { wrong: [255, 60, 60], correct: [60, 220, 90], blank: [160, 160, 255], unknown: [255, 170, 40] }
  for (const b of blocks) {
    const [r, g, bl] = vColor[b.verdict] ?? [255, 255, 255]
    const x0 = Math.round(b.box.x0 * sx), x1 = Math.round(b.box.x1 * sx)
    const y0 = Math.round(b.box.y0 * sy), y1 = Math.round(b.box.y1 * sy)
    for (let x = x0; x <= x1; x++) { put(out2, x, y0, r, g, bl); put(out2, x, y1, r, g, bl) }
    for (let y = y0; y <= y1; y++) { put(out2, x0, y, r, g, bl); put(out2, x1, y, r, g, bl) }
  }
  const f2 = path.join(IN_DIR, 'diagB-block-' + path.basename(file))
  await sharp(out2, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(f2)

  // ③ 去红预览（仅删保留的批改标记）
  const color = await sharp(flatBuf).resize(dw, dh, { fit: 'fill' }).removeAlpha().toColourspace('srgb').raw().toBuffer()
  const out3 = Buffer.alloc(dw * dh * 3)
  for (let y = 0; y < dh; y++) {
    const my = Math.min(h - 1, Math.round(y / sy))
    for (let x = 0; x < dw; x++) {
      const mx = Math.min(w - 1, Math.round(x / sx))
      const q3 = (y * dw + x) * 3
      if (red.keptMask[my * w + mx]) {
        const lum = Math.max(0, Math.min(255, Math.round(luma[my * w + mx])))
        out3[q3] = lum; out3[q3 + 1] = lum; out3[q3 + 2] = lum
      } else { out3[q3] = color[q3]; out3[q3 + 1] = color[q3 + 1]; out3[q3 + 2] = color[q3 + 2] }
    }
  }
  const f3 = path.join(IN_DIR, 'diagB-clean-' + path.basename(file))
  await sharp(out3, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(f3)

  console.log('GUARD ' + JSON.stringify({
    file: path.basename(file),
    size: `${w}x${h}`,
    medH: +medH.toFixed(1),
    inkRatio: +ctx.inkRatio.toFixed(4),
    cols: cols.map(([a, b]) => b - a),
    colRowCounts: colRows.map((r) => r.length),
    red: {
      marks: red.marks.length,
      coverage: +red.coverage.toFixed(4),
      furniture: red.furnitureCount,
      kindDist,
    },
    blocks: {
      count: blocks.length,
      verdictDist,
      avgMarksPerBlock: +(blocks.reduce((s, b) => s + b.markIds.length, 0) / Math.max(1, blocks.length)).toFixed(2),
      sample: blocks.slice(0, 3).map((b) => ({ col: b.col, verdict: b.verdict, conf: b.confidence, normBox: b.normBox.map((v) => +v.toFixed(3)) })),
    },
    diag: [path.basename(f1), path.basename(f2), path.basename(f3)],
  }))
}

async function main() {
  // D. VLM 契约测试（纯函数，用固定响应）
  const canned = '```json\n{"items":[{"no":"26","box":[0.1,0.2,0.3,0.05],"verdict":"wrong","reason":"红叉","confidence":0.9},{"no":"27","box":[0.1,0.3,0.3,0.05],"verdict":"correct","reason":"对勾","confidence":0.8}]}\n```'
  const parsed = parseVlmItems(canned)
  console.log('GUARD ' + JSON.stringify({
    contract: 'parseVlmItems',
    ok: parsed.length === 2 && parsed[0].verdict === 'wrong' && parsed[0].box?.[0] === 0.1,
    items: parsed.length,
  }))

  // D2. VLM 真实调用探针（预期 fail-open：本环境无 COZE_API_TOKEN）
  const v = await vlmQuestionBlocks('https://example.com/not-a-real-image.png', 0)
  console.log('GUARD ' + JSON.stringify({ vlmProbe: { used: v.used, error: v.error ?? null } }))

  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const f of files) {
    try {
      await probePage(path.join(IN_DIR, f))
    } catch (e) {
      console.log(`GUARD {"file":"${f}","error":${JSON.stringify(String((e as Error)?.message ?? e))}}`)
    }
  }
}
main().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })
