/**
 * 通道拆分探针:对 page-1/3 分别生成 chroma / dark / layoutSlots 三个通道的 mask,
 * 量化各通道 mask 内吞掉的"黑色印刷"像素(原图非红、亮度<120 的像素),
 * 并与"实际被删(miss)"求重叠,定位罪魁通道。
 * 输出 /workspace/erase-work/chan-{name}-page-{n}.png (mask 可视化)
 */
import fs from 'fs'
import sharp from 'sharp'
import { normalizeIlluminationForDetection, maskFromColorThreshold, maskFromDarkInk, maskFromLayoutSlots } from './src/image/handwriting-mask'

const IN = '/workspace/erase-work'

async function main() {
  for (const n of [1, 3]) {
    const buf = fs.readFileSync(`${IN}/page-${n}.png`)
    const pre = await normalizeIlluminationForDetection(buf)
    const detectBuf = pre.buffer
    const meta = await sharp(buf).metadata()
    const W = meta.width!, H = meta.height!

    const chan: Record<string, Uint8Array> = {}
    try { const c = await maskFromColorThreshold(detectBuf); chan['chroma'] = c.data } catch (e: any) { console.log('chroma fail', e.message) }
    try { const d = await maskFromDarkInk(detectBuf); chan['dark'] = d.data } catch (e: any) { console.log('dark fail', e.message) }
    try { const l = await maskFromLayoutSlots(detectBuf); chan['slots'] = l.data } catch (e: any) { console.log('slots fail', e.message) }

    // 保存 merged(三通道并集,保护闸前) mask 供 python 复现保护逻辑
    if (chan['chroma'] && chan['dark'] && chan['slots']) {
      const n0 = W * H
      const merged = Buffer.alloc(n0, 0)
      for (let i = 0; i < n0; i++) merged[i] = Math.max(chan['chroma'][i] ?? 0, chan['dark'][i] ?? 0, chan['slots'][i] ?? 0)
      await sharp(merged, { raw: { width: W, height: H, channels: 1 } }).png().toFile(`${IN}/merged-page-${n}.png`)
      console.log(`merged-page-${n}.png saved`)
    }

    // 原图像素分类(统一 removeAlpha + srgb,避免 RGBA 错位)
    const rgb = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer()
    const tot = W * H
    const isRed = new Uint8Array(tot)
    const isBlack = new Uint8Array(tot)
    for (let i = 0; i < tot; i++) {
      const r = rgb[i * 3], g = rgb[i * 3 + 1], b = rgb[i * 3 + 2]
      if (r > 110 && r - g > 40 && r - b > 40) isRed[i] = 1
      const lum = 0.299 * r + 0.587 * g + 0.114 * b
      if (lum < 120) isBlack[i] = 1
    }
    // 实际被删(miss) 从 python 分析结果读:重新算
    const outRaw = await sharp(fs.readFileSync(`${IN}/out-page-${n}.png`)).removeAlpha().toColourspace('srgb').raw().toBuffer()
    const miss = new Uint8Array(tot)
    for (let i = 0; i < tot; i++) {
      const d = (Math.abs(rgb[i*3]-outRaw[i*3]) + Math.abs(rgb[i*3+1]-outRaw[i*3+1]) + Math.abs(rgb[i*3+2]-outRaw[i*3+2])) / 3
      if (d > 60 && !isRed[i]) miss[i] = 1
    }

    console.log(`\n===== page-${n} (W=${W} H=${H}) =====`)
    for (const [name, data] of Object.entries(chan)) {
      let cov = 0, blackIn = 0, redIn = 0, hitMiss = 0
      for (let i = 0; i < tot; i++) {
        if (data[i]) {
          cov++
          if (isBlack[i] && !isRed[i]) blackIn++
          if (isRed[i]) redIn++
        }
        if (data[i] && miss[i]) hitMiss++
      }
      const missTotal = miss.reduce((a, b) => a + b, 0)
      console.log(`  [${name}] 覆盖=${(100*cov/tot).toFixed(2)}% | 吞黑字=${blackIn} | 含红笔=${redIn} | 与实际误删重叠=${hitMiss}/${missTotal} (${(100*hitMiss/Math.max(1,missTotal)).toFixed(1)}%)`)
      // 存可视化
      const vis = Buffer.alloc(tot * 3)
      for (let i = 0; i < tot; i++) {
        vis[i*3] = data[i] ? 255 : 0; vis[i*3+1] = 0; vis[i*3+2] = 0
      }
      await sharp(vis, { raw: { width: W, height: H, channels: 3 } }).png().toFile(`${IN}/chan-${name}-page-${n}.png`)
    }
  }
}
main().catch(e => { console.error(e); process.exit(1) })
