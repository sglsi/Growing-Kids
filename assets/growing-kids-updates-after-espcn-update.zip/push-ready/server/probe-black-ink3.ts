/**
 * 「黑笔为什么擦不掉」诊断探针 · 第三轮（色域盲区量化 + 前提证伪）
 * ============================================================
 * 要回答的两个决定性问题：
 *   Q1 ★ 色域法的**原理性盲区**：黑笔候选像素的 chroma 分布。
 *      若绝大多数黑笔像素 chroma < 14（甚至 < 8），则 maskFromColorThreshold
 *      在数学上就不可能抓到它们——不是"调参没调好"，是判据选错了维度。
 *   Q2 ★ 「手写比印刷大」这个 rowRatio=1.15 的前提是否成立。
 *      对比黑笔候选域与印刷域的 bbox 尺寸分布。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { maskFromColorThreshold, normalizeIlluminationForDetection } from './src/image/handwriting-mask'
import { connectedComponents } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

function lumaOf(d: Buffer, p: number) {
  return 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const file of files) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const o = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
      const w = o.info.width, h = o.info.height, ch = o.info.channels

      const pre = await normalizeIlluminationForDetection(buf)
      const redThin = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
      const near = new Uint8Array(w * h)
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          if (!redThin.data[y * w + x]) continue
          for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
            for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near[yy * w + xx] = 1
        }
      }

      const lumas: number[] = []
      for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(o.data, i * ch))
      lumas.sort((a, b) => a - b)
      const paper = lumas[Math.floor(lumas.length * 0.9)] ?? 240
      const darkTh = paper * 0.62

      // Q1：黑笔候选像素的 chroma 直方图
      const buckets = [0, 0, 0, 0, 0, 0] // [<4, 4-8, 8-14, 14-22, 22-40, >=40]
      let penPx = 0
      const penInk = new Uint8Array(w * h)
      for (let i = 0; i < w * h; i++) {
        const p = i * ch
        const c = Math.max(o.data[p], o.data[p + 1], o.data[p + 2]) - Math.min(o.data[p], o.data[p + 1], o.data[p + 2])
        const lo = lumaOf(o.data, p)
        if (c >= 14 || lo >= darkTh) continue
        if (!near[i]) continue
        penPx++
        penInk[i] = 1
        if (c < 4) buckets[0]++
        else if (c < 8) buckets[1]++
        else if (c < 14) buckets[2]++
        else if (c < 22) buckets[3]++
        else if (c < 40) buckets[4]++
        else buckets[5]++
      }

      // Q2：黑笔候选域 vs 印刷域 的 bbox 尺寸
      const printInk = new Uint8Array(w * h)
      for (let i = 0; i < w * h; i++) {
        const p = i * ch
        const c = Math.max(o.data[p], o.data[p + 1], o.data[p + 2]) - Math.min(o.data[p], o.data[p + 1], o.data[p + 2])
        if (c >= 14 || lumaOf(o.data, p) >= darkTh) continue
        printInk[i] = 1
      }
      const dim = (ink: Uint8Array) => {
        const { comps } = connectedComponents(ink, w, h, false)
        const hs = comps.map((c) => c.y1 - c.y0 + 1)
        const ws = comps.map((c) => c.x1 - c.x0 + 1)
        const q = (xs: number[], p: number) => {
          if (!xs.length) return -1
          const a = [...xs].sort((m, n) => m - n)
          return a[Math.floor(a.length * p)]
        }
        return {
          n: comps.length,
          hP25: q(hs, 0.25), hMed: q(hs, 0.5), hP75: q(hs, 0.75), hMax: Math.max(0, ...hs),
          wMed: q(ws, 0.5),
          // 大域（可能含多字连笔）占比
          bigShare: +(comps.filter((c) => c.y1 - c.y0 + 1 >= 15).length / Math.max(1, comps.length)).toFixed(3),
        }
      }

      const penS = dim(penInk)
      const prtS = dim(printInk)
      const pct = (a: number, b: number) => +((a / Math.max(1, b)) * 100).toFixed(1)

      console.log('GUARD ' + JSON.stringify({
        file,
        paperLuma: +paper.toFixed(0),
        chromaOfPenPixels: {
          total: penPx,
          'chroma<4': buckets[0],
          'chroma4-8': buckets[1],
          'chroma8-14': buckets[2],
          'chroma>=14(色域阈值之上)': buckets[3] + buckets[4] + buckets[5],
          'pct_invisible_to_chroma<14': pct(buckets[0] + buckets[1] + buckets[2], penPx),
          'pct_below_4': pct(buckets[0], penPx),
        },
        penDomains: penS,
        printDomains: prtS,
      }))
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 250))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
