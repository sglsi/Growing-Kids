// probe-structural-ab.ts —— 结构判别器「擦得对」影子对照（任务 B-2）
//
// 设计依据：去手写-结构一致性判别器-实施设计-v21.2.md §4 probe-structural-ab + §8 S2/S3/S4
//
// 对照：结构判别掩码(structural, 工作尺度 labels==1) vs 现状 hybrid 掩码(原图尺度, 降采样到工作尺度)
//   · 印刷真值代理 = 保护链判定为印刷的 ink 像素（furniturePrior）
//   · S2  keepPrint   = 1 − |结构擦除 ∩ 印刷| / |印刷|      （≥0.985，与 E7 同阈）
//   · S3  hwRecall增  = 100·(1 − hybrid 对 T 的召回)        （T=结构判手写且非印刷；最差页 ≥ 现状+15pp）
//   · S4  增擦可解释  = |新增擦除 ∩ explain| / |新增擦除|    （≥0.70，防"数字好看但擦错地方"）
//   现状基线冻结进 worksheet-test/ab-baseline.json（参数不在 4 页上拍脑袋调，见 §6 标定纪律）。
//
// 纪律：本探针只读、只取证、不改主路径；STRUCT_ADAPTIVE 仍为 off。

import sharp from 'sharp'
import { readdirSync, existsSync, mkdirSync, writeFileSync } from 'fs'
import { join } from 'path'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminate } from './src/image/structural-discriminator'
import { protectPrintUnderColorHandwriting, type HandwritingMask } from './src/image/handwriting-mask'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'

const IN_DIR = '/workspace/worksheet-test'
const OUT_DIR = '/workspace/worksheet-test/ab'
const BASELINE = join(OUT_DIR, 'ab-baseline.json')
if (!existsSync(OUT_DIR)) mkdirSync(OUT_DIR, { recursive: true })

const files = readdirSync(IN_DIR).filter((f) => /^phys\d+\.png$/.test(f)).sort()
if (!files.length) { console.error('未找到 phys*.png 验证集'); process.exit(1) }

// 硬判据阈值（设计 §8，先声明后跑数）
const S2_TAU = 0.985 // keepPrint 下限
const S3_GAIN_PP = 15 // 最差页手写召回相对现状增量下限（pp）
const S4_TAU = 0.70 // 增擦可解释比例下限

async function main() {
  const rows: any[] = []
  for (const f of files) {
    const p = join(IN_DIR, f)
    const buf = await sharp(p).toBuffer()
    const meta = await sharp(buf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(buf, { width: W, height: H, isGray: false })
    const { w: ww, h: wh, ink } = ctx.work
    const inkLocal = ctx.inkLocal

    // 家具/印刷先验（与 inventory 探针同口径）
    const work = await sharp(buf).resize(ww, wh, { fit: 'fill' }).removeAlpha().raw().toBuffer({ resolveWithObject: true })
    let furniturePrior: Uint8Array | undefined
    try {
      const chromaMask = maskFromChroma(work.data, work.info.width, work.info.height, work.info.channels)
      const chromaBuf = Buffer.from(chromaMask.data)
      const rgbBuf = await sharp(work.data, { raw: { width: work.info.width, height: work.info.height, channels: work.info.channels } }).png().toBuffer()
      const chromaHM: HandwritingMask = {
        width: work.info.width, height: work.info.height, data: chromaBuf,
        coverage: chromaBuf.reduce((a, b) => a + b, 0) / chromaBuf.length, source: 'threshold',
      }
      const prot = await protectPrintUnderColorHandwriting(rgbBuf, chromaHM)
      furniturePrior = new Uint8Array(inkLocal.length)
      const protData = Buffer.from(prot.data)
      for (let i = 0; i < inkLocal.length; i++) if (inkLocal[i] && !protData[i]) furniturePrior[i] = 255
    } catch (e) {
      console.warn(`[${f}] 家具先验失败：${e instanceof Error ? e.message : e}`)
    }

    const sres = discriminate({ ctx, furniturePrior })
    const labels = sres.labels
    const explain = sres.explain

    // 现状 hybrid 掩码（原图尺度）→ 降采样到工作尺度
    const hybrid = await buildHandwritingMask(buf, '', {}, { eraseMode: 'hybrid', allowVlm: false, manualRects: [] })
    const hm = hybrid.mask as HandwritingMask
    const hw = hm.width, hh = hm.height
    const hybridWork = new Uint8Array(ww * wh)
    for (let y = 0; y < wh; y++) {
      const oy = Math.min(hh - 1, Math.round(y * hh / wh))
      const baseO = oy * hw
      const baseW = y * ww
      for (let x = 0; x < ww; x++) {
        const ox = Math.min(hw - 1, Math.round(x * hw / ww))
        hybridWork[baseW + x] = hm.data[baseO + ox] > 127 ? 1 : 0
      }
    }

    // 统计
    let printN = 0, structPrint = 0, hybridPrint = 0
    let tN = 0, hybridT = 0
    let structHW = 0, hybridHW = 0, overlapHW = 0, added = 0, addedExpl = 0
    for (let i = 0; i < ww * wh; i++) {
      if (!inkLocal[i]) continue
      const isPrint = furniturePrior ? furniturePrior[i] : 0
      const sHW = labels[i] === 1 ? 1 : 0
      const hHW = hybridWork[i]
      if (isPrint) {
        printN++
        if (sHW) structPrint++
        if (hHW) hybridPrint++
      } else {
        // T = 结构判手写且非印刷（即结构声称的手写目标）
        if (sHW) {
          tN++
          if (hHW) hybridT++
        }
      }
      if (sHW) structHW++
      if (hHW) hybridHW++
      if (sHW && hHW) overlapHW++
      if (sHW && !hHW) { added++; if (explain[i]) addedExpl++ }
    }

    const s2Struct = printN ? 1 - structPrint / printN : 1
    const s2Hybrid = printN ? 1 - hybridPrint / printN : 1
    const hybridRecallT = tN ? hybridT / tN : 1 // hybrid 对 T 的召回
    const s3Gain = +(100 * (1 - hybridRecallT)).toFixed(1) // 结构相对现状新增手写召回(pp)
    const s4 = added ? addedExpl / added : 1

    rows.push({
      file: f,
      printN, structPrint, hybridPrint,
      s2_keepPrint_struct: +s2Struct.toFixed(4),
      s2_keepPrint_hybrid_baseline: +s2Hybrid.toFixed(4),
      T_n: tN, hybridRecallOfT: +(hybridRecallT).toFixed(4),
      s3_hwRecallGain_pp: s3Gain,
      structHW_inkN: structHW, hybridHW_inkN: hybridHW, overlapHW,
      added_inkN: added, addedExplain: addedExpl, s4_addedInterpretable: +s4.toFixed(4),
    })
    console.log(JSON.stringify(rows[rows.length - 1]))
  }

  // 冻结现状基线（首次写入；之后只对照）
  const worstS2 = Math.min(...rows.map((r) => r.s2_keepPrint_struct))
  const worstS3 = Math.min(...rows.map((r) => r.s3_hwRecallGain_pp))
  const worstS4 = Math.min(...rows.map((r) => r.s4_addedInterpretable))
  const baseline = {
    generatedBy: 'probe-structural-ab.ts',
    note: '现状 hybrid 基线（冻结，参数未在 4 页上拍脑袋调；B-3 合成集标定前只对照不调）',
    hybrid_baseline: rows.map((r) => ({
      file: r.file, keepPrint: r.s2_keepPrint_hybrid_baseline, hybridRecallOfT: r.hybridRecallOfT,
    })),
  }
  if (!existsSync(BASELINE)) writeFileSync(BASELINE, JSON.stringify(baseline, null, 2))

  // 判据
  const s2Pass = worstS2 >= S2_TAU
  const s3Pass = worstS3 >= S3_GAIN_PP
  const s4Pass = worstS4 >= S4_TAU
  const verdict = { S2_TAU, s2_worst: +worstS2.toFixed(4), s2Pass, S3_GAIN_PP, s3_worst_pp: +worstS3.toFixed(1), s3Pass, S4_TAU, s4_worst: +worstS4.toFixed(4), s4Pass }

  console.log('\n=== S2~S4 影子对照判据（设计 §8）===')
  console.log(JSON.stringify(verdict, null, 2))
  console.log(`基线已冻结于 ${BASELINE}`)
  console.log(`\nS2 keepPrint ≥${S2_TAU}: ${s2Pass ? 'PASS' : 'FAIL'} (worst ${worstS2.toFixed(4)})`)
  console.log(`S3 手写召回增量 ≥${S3_GAIN_PP}pp: ${s3Pass ? 'PASS' : 'FAIL'} (worst ${worstS3.toFixed(1)}pp)`)
  console.log(`S4 增擦可解释 ≥${S4_TAU}: ${s4Pass ? 'PASS' : 'FAIL'} (worst ${worstS4.toFixed(4)})`)
  const allPass = s2Pass && s3Pass && s4Pass
  console.log(`\nB-2 影子对照：${allPass ? 'ALL PASS ✅ → 可进入 B-3 标定 + E9 门禁' : 'NOT ALL PASS ❌ → 判别器留 shadow，主路径零变化'}`)
}

/** 工作尺度彩色 mask（粗 chroma 阈值），喂给保护链。 */
function maskFromChroma(data: Buffer, w: number, h: number, channels: number): { data: Uint8Array; width: number; height: number } {
  const n = w * h
  const m = new Uint8Array(n)
  for (let i = 0, p = 0; i < n; i++, p += channels) {
    const r = data[p], g = data[p + 1], b = data[p + 2]
    if (Math.max(r, g, b) - Math.min(r, g, b) >= 14) m[i] = 1
  }
  return { data: m, width: w, height: h }
}

main().catch((e) => { console.error(e); process.exit(1) })
