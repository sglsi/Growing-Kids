/**
 * 通道消融实验：为什么用户建议的「括号内/横线上/字号/间距/粗细」思想没生效
 * ============================================================
 * 事实基础（已查证源码）：
 *   - maskFromLayoutSlots  → 「括号内 + 横线上」（srcTag 1=line槽 2=paren槽）
 *   - bhCV（块高一致性）    → 「字号」
 *   - gapCV（间距离散度）    → 「间距」
 *   - erodeSurvivalRate     → 「粗细」（1轮腐蚀存活率，v14）
 *   四条思路**全部已实现**，但它们都在 maskFromDarkInk / maskFromLayoutSlots 里，
 *   而 eraseMode:'color' 分支**一条都不调用**——只调色域。
 *
 * 本实验回答：
 *   Q1 每条通道单独对「黑笔候选」的覆盖率是多少？
 *   Q2 每条通道单独会误圈多少印刷？
 *   Q3 只用「黑笔该走的通道」(dark+slots) 能到多少覆盖率、代价多大？
 *   Q4 叠加红笔色域后，整体表现如何（这才是正确形态：红笔+黑笔一起擦）？
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import {
  maskFromColorThreshold,
  maskFromDarkInk,
  maskFromLayoutSlots,
  normalizeIlluminationForDetection,
} from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}
function lumaOf(d: Buffer, p: number) {
  return 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
}
function orInto(dst: Uint8Array, src: Buffer) {
  for (let i = 0; i < dst.length; i++) if (src[i]) dst[i] = 1
}
function andCount(a: Uint8Array, b: Uint8Array) {
  let n = 0
  for (let i = 0; i < a.length; i++) if (a[i] && b[i]) n++
  return n
}

async function main() {
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const o = await raw(buf)
      const w = o.info.width, h = o.info.height, ch = o.info.channels
      const pre = await normalizeIlluminationForDetection(buf)

      // 四条通道各自产出
      const chroma = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
      const dark = await maskFromDarkInk(pre.buffer)
      const slots = await maskFromLayoutSlots(pre.buffer)

      // 真值集合：黑笔候选（红笔邻域内的低彩度暗像素）/ 印刷暗像素 / 红笔像素
      const red = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
      const near = new Uint8Array(w * h)
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          if (!red.data[y * w + x]) continue
          for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
            for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) near[yy * w + xx] = 1
        }
      }
      const lumas: number[] = []
      for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(o.data, i * ch))
      lumas.sort((a, b) => a - b)
      const darkTh = (lumas[Math.floor(lumas.length * 0.9)] ?? 240) * 0.62
      const penCand = new Uint8Array(w * h)
      const printPx = new Uint8Array(w * h)
      const redPx = new Uint8Array(w * h)
      for (let i = 0; i < w * h; i++) {
        if (red.data[i]) redPx[i] = 1
        const p = i * ch
        const c = Math.max(o.data[p], o.data[p + 1], o.data[p + 2]) - Math.min(o.data[p], o.data[p + 1], o.data[p + 2])
        if (c >= 14 || lumaOf(o.data, p) >= darkTh) continue
        printPx[i] = 1
        if (near[i]) penCand[i] = 1
      }
      const nPen = penCand.reduce((a, b) => a + b, 0)
      const nPrint = printPx.reduce((a, b) => a + b, 0)
      const nRed = redPx.reduce((a, b) => a + b, 0)
      const pc = (a: Uint8Array) => +((andCount(a, penCand) / Math.max(1, nPen)) * 100).toFixed(1)
      const rc = (a: Uint8Array) => +((andCount(a, redPx) / Math.max(1, nRed)) * 100).toFixed(1)
      const prc = (a: Uint8Array) => +((andCount(a, printPx) / Math.max(1, nPrint)) * 100).toFixed(1)

      const ch14 = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
      const unionAll = new Uint8Array(w * h)
      orInto(unionAll, ch14.data); orInto(unionAll, dark.data); orInto(unionAll, slots.data)
      const blackOnly = new Uint8Array(w * h)
      orInto(blackOnly, dark.data); orInto(blackOnly, slots.data)

      console.log('GUARD ' + JSON.stringify({
        file,
        truth: { penCand: nPen, printPx: nPrint, redPx: nRed },
        channels: {
          chroma14: { cov: +chroma.coverage.toFixed(4), pen: pc(chroma.data), red: rc(chroma.data), print: prc(chroma.data) },
          dark: { cov: +dark.coverage.toFixed(4), pen: pc(dark.data), red: rc(dark.data), print: prc(dark.data) },
          slots: { cov: +slots.coverage.toFixed(4), pen: pc(slots.data), red: rc(slots.data), print: prc(slots.data) },
        },
        combos: {
          blackOnly_dark_slots: { cov: +(blackOnly.reduce((a, b) => a + b, 0) / (w * h)).toFixed(4), pen: pc(blackOnly), red: rc(blackOnly), print: prc(blackOnly) },
          full_chroma_dark_slots: { cov: +(unionAll.reduce((a, b) => a + b, 0) / (w * h)).toFixed(4), pen: pc(unionAll), red: rc(unionAll), print: prc(unionAll) },
        },
      }))
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 250))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
