/**
 * 去手写 v19.2 · 种子生长参数扫描（英语灰报 4 张）
 * ============================================================
 * 背景：v19.1 试图"放宽触边家具判据"已实测否决——
 *   去红率确实升到 0.79~0.90，但家具保留率从 1.000 崩到 0.24~0.87（属错擦）。
 *   根因：这 4 张的印刷红家具像素总量只有 212~11231px²，是**细碎的字/小标记**，
 *         不是"成片实心块"，面积门槛区分不了。
 *
 * v19.2 换方向：**只增不减**——不去动家具判据，而是在已确认的红笔周围
 * 补抓彩度落在 8~14 之间的淡红边缘（种子生长）。家具邻域没有种子，故不受影响。
 *
 * 扫描：
 *   A    v19 基线（不生长）
 *   G1   半径 2 / 彩度 ≥8
 *   G2   半径 3 / 彩度 ≥8
 *   G3   半径 3 / 彩度 ≥6
 *   G4   半径 5 / 彩度 ≥8
 *
 * 判据（三者互斥，与 probe-erase-verify 完全一致）：
 *   教师红笔擦除率↑ / 印刷红家具保留率↑ / 低色度印刷损伤率↓
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, inpaint, blendWithMask } from './src/image/handwriting-mask'
import { connectedComponents, estimateCharMetrics } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

async function rawPixels(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

function lumaOf(d: Buffer, p: number) {
  return 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
}

function furnitureSet(data: Buffer, w: number, h: number, medH: number) {
  const ink = new Uint8Array(w * h)
  for (let i = 0; i < w * h; i++) ink[i] = data[i] ? 1 : 0
  const { comps } = connectedComponents(ink, w, h, false)
  const edgeTol = Math.max(4, Math.round(medH * 0.8))
  const f = new Uint8Array(w * h)
  let px = 0
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1
    const bh = c.y1 - c.y0 + 1
    const isF =
      c.x0 <= edgeTol || c.x1 >= w - 1 - edgeTol || c.y0 <= edgeTol || c.y1 >= h - 1 - edgeTol ||
      (bw > w * 0.8 && bh < medH * 3) ||
      (bh > h * 0.8 && bw < medH * 3)
    if (!isF) continue
    px += c.n
    for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x]) f[b + x] = 1 }
  }
  return { f, px }
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const file of files) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const { info } = await rawPixels(buf)
      const w = info.width
      const h = info.height
      const m = await estimateCharMetrics(buf, {})
      const prior = w / 70
      const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, m.medH > 0 ? m.medH : prior))

      const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
      const { f: furn, px: furnPx } = furnitureSet(redO.data, w, h, medH)
      const o = await rawPixels(buf)
      const od = o.data
      const ch = o.info.channels
      const lumas: number[] = []
      for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(od, i * ch))
      lumas.sort((a, b) => a - b)
      const darkTh = (lumas[Math.floor(lumas.length * 0.9)] ?? 240) * 0.62

      const variants: Array<[string, { growRadius?: number; growChroma?: number }]> = [
        ['A-v19', {}],
        ['G1-r2c8', { growRadius: 2, growChroma: 8 }],
        ['G2-r3c8', { growRadius: 3, growChroma: 8 }],
        ['G3-r3c6', { growRadius: 3, growChroma: 6 }],
        ['G4-r5c8', { growRadius: 5, growChroma: 8 }],
      ]

      for (const [tag, ref] of variants) {
        const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'color', colorRefine: ref })
        const repaired = await inpaint(buf, 'adaptive', seg.mask)
        const out = await blendWithMask(buf, repaired, seg.mask)
        if (tag !== 'A-v19') fs.writeFileSync(path.join(IN_DIR, `erase-grow${tag.slice(1)}-` + file), out)

        const redN = await maskFromColorThreshold(out, { chromaMin: 14 })
        let penTotal = 0, penStill = 0, furnTotal = 0, furnStill = 0
        for (let i = 0; i < w * h; i++) {
          if (!redO.data[i]) continue
          if (furn[i]) { furnTotal++; if (redN.data[i]) furnStill++ }
          else { penTotal++; if (redN.data[i]) penStill++ }
        }
        const n2 = await rawPixels(out)
        const nd = n2.data
        let printTotal = 0, printChanged = 0
        for (let i = 0; i < w * h; i++) {
          const p = i * ch
          const chroma = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
          const lo = lumaOf(od, p)
          if (chroma >= 14 || lo >= darkTh) continue
          printTotal++
          if (Math.abs(lumaOf(nd, p) - lo) > 30) printChanged++
        }
        const dbg = (seg.mask.debug ?? {}) as Record<string, unknown>
        console.log('GUARD ' + JSON.stringify({
          file,
          variant: tag,
          medH: +medH.toFixed(1),
          coverage: +seg.mask.coverage.toFixed(4),
          penRemoval: +(1 - penStill / Math.max(1, penTotal)).toFixed(4),
          furnitureKeep: +(furnStill / Math.max(1, furnTotal)).toFixed(4),
          printDamage: +(printChanged / Math.max(1, printTotal)).toFixed(5),
          growPx: dbg.growPx,
          furnDomains: dbg.furnitureDomains,
        }))
      }
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 200))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
