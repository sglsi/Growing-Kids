/**
 * probe-stats-unit.ts —— P0 单位探针（方法论 v21 / 实施计划 v21.1 §P0-3）
 *
 * 目的：验证 adaptive-stats.ts 三个估计器在来源互异的图上的**分布**，
 *      而非单图值。判据（实施计划 P0-3）：
 *        · 7 张真实图全部 source='cc-mode'（连通域众数命中）
 *        · paperRef.confidence 无 'low'（无图降级）
 *        · 任一图降级 → 停下查降级链，不许带着降级进 P1
 *      另：用合成近二值图演示 Otsu 平台中点修复（P0-4 的"先证有害"）
 */

import * as fs from 'fs'
import sharp from 'sharp'
import { estimatePaperRef, estimateLayout, buildDocContext, otsuPlatform } from './src/image/adaptive-stats'
import { otsuThreshold } from './src/image/image-layout'

const CASES = [
  { file: '/workspace/wrongq-test/page28.png', tag: '扫描·红笔+照片' },
  { file: '/workspace/wrongq-test/page29.png', tag: '扫描·红笔' },
  { file: '/workspace/wrongq-test/page30.png', tag: '扫描·红笔' },
  { file: '/workspace/wrongq-test/page31.png', tag: '扫描·红笔' },
  { file: '/workspace/wrongq-test/case3-photo.png', tag: '拍照·暖纸+红笔' },
  { file: '/workspace/黑白-最终效果-1279x1706.png', tag: '黑白二值·黑笔' },
  { file: '/workspace/poc-phase0/orig.png', tag: '合成·干净' },
]

interface Row {
  tag: string
  w: number; h: number
  paperLuma: number; paperLumaMAD: number; paperChroma: number; paperChromaMAD: number
  paperConf: string; paperReason?: string
  charH: number; strokeW: number; charHConf: number; nCand: number
  source: string
  otsuOld: number; otsuNew: number
  sauvolaWin: number; sauvolaCov: number
}

async function analyze(file: string, tag: string): Promise<Row> {
  const rgb = fs.readFileSync(file)
  const raw = await sharp(rgb).removeAlpha().raw().toBuffer({ resolveWithObject: true })
  const paper = estimatePaperRef(raw.data, raw.info.width, raw.info.height, raw.info.channels)
  const layout = await estimateLayout(rgb)
  const ctx = await buildDocContext(rgb, { width: raw.info.width, height: raw.info.height, isGray: false })

  // Otsu 对照：旧（取首个最大值）vs 新（平台中点）
  const gray = await sharp(rgb).grayscale().raw().toBuffer()
  const hist = new Int32Array(256)
  for (let i = 0; i < gray.length; i++) hist[gray[i]]++
  const otsuOld = otsuThreshold(gray, gray.length)
  const otsuNew = otsuPlatform(hist)

  return {
    tag,
    w: raw.info.width, h: raw.info.height,
    paperLuma: paper.paperLuma, paperLumaMAD: paper.paperLumaMAD,
    paperChroma: paper.paperChroma, paperChromaMAD: paper.paperChromaMAD,
    paperConf: paper.confidence, paperReason: paper.reason,
    charH: layout.charH, strokeW: layout.strokeW, charHConf: layout.charHConfidence,
    nCand: layout.nCandidates, source: layout.source,
    otsuOld, otsuNew,
    sauvolaWin: ctx.sauvola.win, sauvolaCov: ctx.debug.sauvolaCoverage as number,
  }
}

/** 合成近二值图：白底 + 随机黑条（文字状），附一块灰度斜坡区，制造 Otsu 平台。 */
function makeSynthetic(): Buffer {
  const W = 600, H = 800
  const buf = Buffer.alloc(W * H * 3, 245) // 白底
  const set = (x: number, y: number, v: number) => {
    if (x < 0 || y < 0 || x >= W || y >= H) return
    const p = (y * W + x) * 3
    buf[p] = buf[p + 1] = buf[p + 2] = v
  }
  // 随机黑条（模拟文字笔画）
  let seed = 12345
  const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff
  for (let i = 0; i < 400; i++) {
    const x = Math.floor(rnd() * W), y = Math.floor(rnd() * H)
    const len = 8 + Math.floor(rnd() * 40), horiz = rnd() > 0.5
    for (let j = 0; j < len; j++) set(x + (horiz ? j : 0), y + (horiz ? 0 : j), 20)
  }
  // 灰度斜坡区（制造方差平台）
  for (let y = 400; y < 460; y++) for (let x = 0; x < W; x++) set(x, y, 120 + Math.floor((x / W) * 30))
  return buf
}

async function main() {
  const rows: Row[] = []
  for (const c of CASES) {
    try { rows.push(await analyze(c.file, c.tag)) }
    catch (e) { console.log(`✗ ${c.tag}: ${(e as Error).message}`) }
  }

  console.log('\n══ E1/E2 跨图分布（P0-3 判据表）══')
  console.log('tag'.padEnd(16), '纸面L', '纸面L_MAD', '彩度', '彩度MAD', '纸面可信', 'charH', '笔画宽', 'charH可信', '候选数', '来源', 'Otsu旧→新')
  for (const r of rows) {
    console.log(
      r.tag.padEnd(14),
      String(r.paperLuma).padStart(5),
      String(r.paperLumaMAD).padStart(8),
      String(r.paperChroma).padStart(5),
      String(r.paperChromaMAD).padStart(8),
      r.paperConf.padStart(6),
      String(r.charH).padStart(6),
      String(r.strokeW).padStart(6),
      String(r.charHConf).padStart(8),
      String(r.nCand).padStart(6),
      r.source.padStart(13),
      `${r.otsuOld}→${r.otsuNew}`,
    )
    if (r.paperConf === 'low') console.log(`   ⚠️ 纸面降级: ${r.paperReason}`)
  }

  // 分布汇总
  const charHs = rows.map((r) => r.charH).sort((a, b) => a - b)
  const chromas = rows.map((r) => r.paperChroma).sort((a, b) => a - b)
  console.log('\n── 分布汇总 ──')
  console.log(`charH 跨图: min=${charHs[0]} max=${charHs[charHs.length - 1]} 漂移×${(charHs[charHs.length - 1] / charHs[0]).toFixed(1)}`)
  console.log(`纸面彩度 跨图: min=${chromas[0]} max=${chromas[chromas.length - 1]}`)

  // P0-3 判据（区分三类结果，避免一刀切误杀）：
  //   · source=='degraded'          → 估计器真正失效（硬失败）
  //   · source=='prior-fallback'    → 文本稀疏，软兜底（可接受，记录）
  //   · paperConf=='low'            → 过曝/纸面不可信，sanity 命中（诚实标记，可接受，记录）
  const hardFail = rows.filter((r) => r.source === 'degraded')
  const softFallback = rows.filter((r) => r.source === 'prior-fallback')
  const lowConf = rows.filter((r) => r.paperConf === 'low')
  console.log('\n══ P0-3 判据 ──')
  console.log(`硬失败(source=='degraded'): ${hardFail.length === 0 ? 'PASS' : 'FAIL ' + hardFail.map((d) => d.tag).join(',')}`)
  console.log(`软兜底(prior-fallback): ${softFallback.length} 张 [${softFallback.map((d) => d.tag).join(', ')}]`)
  console.log(`低置信(过曝/纸面不可信): ${lowConf.length} 张 [${lowConf.map((d) => d.tag).join(', ')}]`)

  // Otsu 对照
  const diffs = rows.filter((r) => r.otsuOld !== r.otsuNew)
  console.log(`\nOtsu 新旧不一致图数: ${diffs.length}/${rows.length}`)
  for (const d of diffs) console.log(`  · ${d.tag}: 旧=${d.otsuOld} 新=${d.otsuNew}（平台中点更稳健）`)

  // 合成近二值图演示 Otsu 平台 bug
  console.log('\n══ 合成近二值图 · Otsu 平台 bug 演示（P0-4 先证有害）══')
  const synth = makeSynthetic()
  const sgray = await sharp(synth, { raw: { width: 600, height: 800, channels: 3 } }).grayscale().raw().toBuffer()
  const shist = new Int32Array(256)
  for (let i = 0; i < sgray.length; i++) shist[sgray[i]]++
  const sOld = otsuThreshold(sgray, sgray.length)
  const sNew = otsuPlatform(shist)
  console.log(`合成图 Otsu: 旧(首个最大值)=${sOld}  新(平台中点)=${sNew}`)
  console.log(`  → 若旧值≠新值，说明 production 的 otsuThreshold 在部分图上落到平台低端，修复必要`)

  const out = {
    rows, charHRange: [charHs[0], charHs[charHs.length - 1]],
    p0_3_pass: hardFail.length === 0,
    otsuDiffs: diffs.map((d) => ({ tag: d.tag, old: d.otsuOld, neu: d.otsuNew })),
    synth: { otsuOld: sOld, otsuNew: sNew },
  }
  fs.writeFileSync('/workspace/push-ready/server/verify-out/stats-unit.json', JSON.stringify(out, null, 2))
  console.log('\n明细 → verify-out/stats-unit.json')
}

main().catch((e) => { console.error(e); process.exit(1) })
