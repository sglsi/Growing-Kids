/**
 * 独立去手写脚本（不走 VLM，纯本地三通道 mask + 局部修复）。
 * 用法：npx tsx run-erase.ts
 * 输入：/workspace/erase-work/page-*.png
 * 输出：/workspace/erase-work/out-page-N.png（去手写结果）
 *       /workspace/erase-work/cmp-page-N.png（左原图 / 右去手写 对照）
 *       /workspace/erase-work/summary.json（各页指标）
 */
import fs from 'fs'
import sharp from 'sharp'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask, unmodifiedRegionSimilarity, type HandwritingMask, type InpaintStrategy } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/erase-work'
const files = fs.readdirSync(IN_DIR).filter((f) => /^page-\d+\.png$/.test(f)).sort()

async function main() {
  const summary: any[] = []
  for (const f of files) {
    const path = `${IN_DIR}/${f}`
    const buf = fs.readFileSync(path)
    const meta = await sharp(buf).metadata()
    const W = meta.width!, H = meta.height!
    const pageNo = f.match(/page-(\d+)\.png$/)![1]
    try {
      // ① 分割:ERASE_MODE=color-only 时仅用色域通道(红/蓝笔卷的保守精准模式)
      const mode = process.env.ERASE_MODE ?? 'union'
      let mask: HandwritingMask
      let seg: any
      if (mode === 'color-only') {
        seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'color' })
        mask = seg.mask
      } else {
        // 本地三通道（色域阈值 + 深色墨迹 + 布局槽位），allowVlm:false
        seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false })
        mask = seg.mask
      }
      const coverage = mask?.coverage ?? 0

      let mergedBuf: Buffer = buf
      let sim = 1
      let strategy: InpaintStrategy = 'adaptive'
      if (coverage > 0.0001 && coverage <= 0.7) {
        strategy = 'adaptive'
        const inpainted = await inpaint(buf, strategy, mask)
        mergedBuf = await blendWithMask(buf, inpainted, mask)
        sim = (await unmodifiedRegionSimilarity(buf, mergedBuf, mask)).similarity
      } else if (coverage > 0.7) {
        console.log(`[${f}] coverage=${(coverage*100).toFixed(1)}% > 70%，中止以防误擦整页，原样返回`)
      } else {
        console.log(`[${f}] coverage≈0，未检出手写，原样返回`)
      }

      const tag = mode === 'union' ? '' : `-${mode}${process.env.ERASE_PROTECT === '1' ? '-prot' : ''}`
      const outPath = `${IN_DIR}/out-page-${pageNo}${tag}.png`
      fs.writeFileSync(outPath, mergedBuf)

      // 保存手写 mask（灰度，255=手写）便于可视化与量化
      const maskPng = await sharp(mask.data, { raw: { width: W, height: H, channels: 1 } })
        .png().toBuffer()
      fs.writeFileSync(`${IN_DIR}/mask-page-${pageNo}${tag}.png`, maskPng)

      // 对照图：左原图 / 右去手写
      const gap = 16
      const bg = await sharp({
        create: { width: W * 2 + gap, height: H, channels: 3, background: { r: 245, g: 245, b: 245 } },
      }).png().toBuffer()
      const cmp = await sharp(bg)
        .composite([
          { input: buf, left: 0, top: 0 },
          { input: mergedBuf, left: W + gap, top: 0 },
        ])
        .png()
        .toBuffer()
      const cmpPath = `${IN_DIR}/cmp-page-${pageNo}${tag}.png`
      fs.writeFileSync(cmpPath, cmp)

      summary.push({
        page: pageNo,
        size: `${W}x${H}`,
        source: seg.usedVlm ? 'vlm' : 'local-threshold',
        coverage: +coverage.toFixed(4),
        strategy,
        unmodifiedSimilarity: +sim.toFixed(4),
        out: outPath,
        compare: cmpPath,
        debug: seg.debug,
      })
      console.log(
        `[${f}] ${W}x${H} | 来源=${seg.usedVlm ? 'VLM' : '本地阈值'} | 覆盖=${(coverage*100).toFixed(2)}% | ` +
        `策略=${strategy} | 非手写一致性=${(sim*100).toFixed(2)}%`,
      )
    } catch (e: any) {
      console.error(`[${f}] 失败：${e?.message ?? e}`)
      summary.push({ page: pageNo, error: e?.message ?? String(e) })
    }
  }
  fs.writeFileSync(`${IN_DIR}/summary.json`, JSON.stringify(summary, null, 2))
  console.log('\n汇总写入', `${IN_DIR}/summary.json`)
}

main().catch((e) => { console.error(e); process.exit(1) })
