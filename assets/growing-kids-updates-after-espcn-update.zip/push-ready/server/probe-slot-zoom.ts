/**
 * v20.9 · 槽位逐一放大核对（目检的分辨率必须够）
 * ============================================================
 * 本探针的诞生原因：v3 之前，我一直在**整页缩略图**上目检 10px 大小的括号，
 * 然后声称"目检过了"。但 1024px 宽的页缩到 800px 显示后，一个 10px 的括号
 * 只剩不到 8px —— **根本看不清是 `(` 还是 `A`，更别说判断框内有没有墨**。
 * 在看不清的图上做判断 = 假装验证。
 *
 * 这不是"再改一次算法"，而是换验证手段：
 *   每个槽位单独裁出 → 放大 8 倍 → 标注编号与实测值 → 拼成对照图。
 *   一次目检就能同时看清：框是否套在括号上、框内是否有墨、是红笔还是黑笔。
 *
 * 同时实测**红笔的实际彩度分布** —— v3 假设"红笔 chrom≥14"，
 * 这个数字来自 v20.2 时期的另一批图，未经本批验证。若红笔实际 chrom<14，
 * 它会被归入 printInk，导致"学生写了答案的答题槽"被判成"选项括号"。
 *   v3 结果 `writtenSlots=0 / colorPx=0` 强烈暗示这个假设有问题，**必须量**。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { connectedComponents, closeInk3x3 } from './src/image/image-layout'

const PAD = 14
const IN_DIR = '/workspace/wrongq-test'
const OUT_DIR = '/workspace/v20-槽位目检'

function otsu(g: Buffer): number {
  const hist = new Int32Array(256)
  for (let i = 0; i < g.length; i++) hist[g[i]]++
  const total = g.length
  let sum = 0
  for (let i = 0; i < 256; i++) sum += i * hist[i]
  let sumB = 0, wB = 0, best = 0, bt = 128
  for (let t = 0; t < 256; t++) {
    wB += hist[t]
    if (!wB) continue
    const wF = total - wB
    if (!wF) break
    sumB += t * hist[t]
    const mB = sumB / wB, mF = (sum - sumB) / wF
    const v = wB * wF * (mB - mF) * (mB - mF)
    if (v > best) { best = v; bt = t }
  }
  return bt
}

function measure(inkC: Uint8Array, w: number, h: number) {
  const { comps } = connectedComponents(inkC, w, h, false)
  const glyphs: Array<{ bw: number; bh: number; n: number; x0: number; y0: number; x1: number; y1: number }> = []
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1, bh = c.y1 - c.y0 + 1
    if (c.n < 3 || c.n > 400) continue
    if (bw > 60 || bh > 60) continue
    if (bw / bh > 5 || bh / bw > 5) continue
    glyphs.push({ bw, bh, n: c.n, x0: c.x0, y0: c.y0, x1: c.x1, y1: c.y1 })
  }
  const hH = new Int32Array(80), hW = new Int32Array(80)
  for (const c of glyphs) if (c.bh < 80) hH[c.bh]++
  let modeH = 0, mc = 0
  for (let i = 0; i < 80; i++) if (hH[i] > mc) { mc = hH[i]; modeH = i }
  for (const c of glyphs) if (c.bw < 80) hW[c.bw]++
  let modeW = 0, mw = 0
  for (let i = 0; i < 80; i++) if (hW[i] > mw) { mw = hW[i]; modeW = i }
  return { glyphs, modeH, modeW }
}

/** SVG 文本渲染（sharp 无 drawText，用 SVG 叠加标注） */
function label(w: number, h: number, lines: string[]): Buffer {
  const fs2 = Math.max(9, Math.round(w / 26))
  const lh = fs2 * 1.25
  const body = lines.map((t, i) => `<text x="2" y="${fs2 + i * lh}" font-size="${fs2}" fill="#c00" font-family="monospace">${t.replace(/[<>&]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]!))}</text>`).join('')
  return Buffer.from(`<svg width="${w}" height="${h}"><rect width="${w}" height="${h}" fill="rgba(255,255,220,0.92)"/>${body}</svg>`)
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const file = process.argv[2] ?? 'page30.png'
  const buf = fs.readFileSync(`${IN_DIR}/${file}`)
  const { data: od, info } = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
  const { data: g } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
  const w = info.width, h = info.height, n = w * h
  const rgb = (p: number) => { const i = p * 3; return [od[i], od[i + 1], od[i + 2]] as const }
  const chrom = (p: number) => { const [r, gg, b] = rgb(p); return Math.max(r, gg, b) - Math.min(r, gg, b) }
  const thr = otsu(g)

  const printInk = new Uint8Array(n)
  for (let p = 0; p < n; p++) if (g[p] < thr && chrom(p) < 14) printInk[p] = 1
  const printC = closeInk3x3(printInk, w, h)
  const { glyphs, modeH, modeW } = measure(printC, w, h)

  // ── ⭐ 红笔彩度实测：不猜，直接量"暗像素"的彩度分布 ──
  const darkChroma: number[] = []
  for (let p = 0; p < n; p += 3) {
    if (g[p] < thr) darkChroma.push(chrom(p))
  }
  darkChroma.sort((a, b) => a - b)
  const q = (a: number[], pp: number) => (a.length ? a[Math.floor(a.length * pp)] : 0)
  const chromDist = {
    darkPixels: darkChroma.length,
    p10: q(darkChroma, 0.1), p25: q(darkChroma, 0.25), p50: q(darkChroma, 0.5),
    p75: q(darkChroma, 0.75), p90: q(darkChroma, 0.9), p95: q(darkChroma, 0.95), p99: q(darkChroma, 0.99),
    max: darkChroma[darkChroma.length - 1],
    frac_ge14: +(darkChroma.filter((c) => c >= 14).length / darkChroma.length).toFixed(4),
    frac_ge22: +(darkChroma.filter((c) => c >= 22).length / darkChroma.length).toFixed(4),
    frac_ge40: +(darkChroma.filter((c) => c >= 40).length / darkChroma.length).toFixed(4),
  }

  // 候选 + 配对（同 v3）
  const H_LO = Math.max(5, Math.round(modeH * 0.8)), H_HI = Math.round(modeH * 2.4)
  const W_HI = Math.max(4, Math.round(modeW * 1.3))
  const cands = glyphs.filter((c) => c.bh >= H_LO && c.bh <= H_HI && c.bw >= 2 && c.bw <= W_HI)
    .map((c) => ({ ...c, fill: c.n / (c.bw * c.bh) }))
  const thin = cands.filter((c) => c.fill <= 0.55)
  const slots: Array<{ a: typeof thin[0]; b: typeof thin[0]; gap: number }> = []
  const used = new Set<number>()
  for (let i = 0; i < thin.length; i++) {
    if (used.has(i)) continue
    for (let j = i + 1; j < thin.length; j++) {
      if (used.has(j)) continue
      const a = thin[i], b = thin[j]
      const ov = Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0)
      if (ov < 0.6 * Math.min(a.bh, b.bh)) continue
      if (Math.abs(a.bh - b.bh) > Math.max(3, modeH * 0.5)) continue
      const gap = b.x0 - a.x1
      if (gap < 1 || gap > modeH * 4) continue
      used.add(i); used.add(j); slots.push({ a, b, gap }); break
    }
  }

  // ── 槽位逐一裁出放大（每格：放大图 + 标注）──
  const COLS = 4, CELL_W = 320, CELL_H = 210
  const rows = Math.ceil(slots.length / COLS)
  const comps: Array<{ input: Buffer; left: number; top: number }> = []

  for (let i = 0; i < slots.length; i++) {
    const s = slots[i]
    const x0 = Math.max(0, s.a.x0 - PAD), y0 = Math.max(0, Math.min(s.a.y0, s.b.y0) - PAD)
    const x1 = Math.min(w - 1, Math.max(s.a.x1, s.b.x1) + PAD), y1 = Math.min(h - 1, Math.max(s.a.y1, s.b.y1) + PAD)
    const cw = x1 - x0 + 1, ch = y1 - y0 + 1

    // 统计槽内（严格取两括号之间）
    const ix0 = s.a.x1 + 1, ix1 = s.b.x0 - 1
    let c14 = 0, c22 = 0, c40 = 0, pInk = 0, nIn = 0, maxCh = 0
    for (let y = y0; y <= y1; y++) {
      for (let x = ix0; x <= ix1; x++) {
        if (x < 0 || x >= w) continue
        nIn++
        if (g[y * w + x] >= thr) continue
        const c = chrom(y * w + x)
        if (c >= 14) c14++
        if (c >= 22) c22++
        if (c >= 40) c40++
        if (c > maxCh) maxCh = c
        if (printInk[y * w + x]) pInk++
      }
    }

    // 放大到格子内
    const availW = CELL_W - 16, availH = CELL_H - 66
    const Z = Math.max(1, Math.min(9, Math.floor(Math.min(availW / cw, availH / ch))))
    const cx = (i % COLS) * CELL_W, cy = Math.floor(i / COLS) * CELL_H
    const lines = [
      `#${i}  gap=${s.gap}  bwA=${s.a.bw} bwB=${s.b.bw}`,
      `inner=${nIn}px  c14:${c14} c22:${c22} c40:${c40}`,
      `maxChroma=${maxCh}  printInk=${pInk}`,
      `at (${x0},${y0}) x${Z}`,
    ]
    const fs2 = 13, lh = 16
    const svg = `<svg width="${CELL_W}" height="${CELL_H}">
<rect width="${CELL_W}" height="${CELL_H}" fill="#fffbe8"/>
<rect x="0" y="0" width="${CELL_W}" height="${CELL_H}" fill="none" stroke="#bbb" stroke-width="1"/>
${lines.map((t, k) => `<text x="6" y="${16 + k * lh}" font-size="${fs2}" fill="#b00" font-family="monospace">${t.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</text>`).join('')}
<rect x="6" y="${60}" width="${CELL_W - 12}" height="${CELL_H - 66}" fill="none" stroke="#ddd"/>
</svg>`
    const frame = await sharp(Buffer.from(svg)).png().toBuffer()
    const crop = await sharp(buf).extract({ left: x0, top: y0, width: cw, height: ch })
      .resize({ width: Math.min(availW, cw * Z), height: Math.min(availH, ch * Z), kernel: 'nearest' })
      .png().toBuffer()
    comps.push({ input: frame, left: cx, top: cy })
    comps.push({ input: crop, left: cx + 8, top: cy + 62 })
  }

  const merged = await sharp({
    create: { width: COLS * CELL_W, height: rows * CELL_H, channels: 3, background: { r: 255, g: 255, b: 255 } },
  }).composite(comps).png().toBuffer()
  await sharp(merged).toFile(`${OUT_DIR}/${file.replace('.png', '')}-slots-zoom.png`)

  console.log('RESULT ' + JSON.stringify({
    file, modeH, modeW, thr, slots: slots.length, chromDist,
    gapList: slots.map((s) => s.gap).sort((a, b) => a - b),
  }, null, 1))
}

main().catch((e) => { console.error(e); process.exit(1) })
