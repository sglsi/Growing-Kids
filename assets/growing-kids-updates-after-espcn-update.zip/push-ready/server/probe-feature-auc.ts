/**
 * 去手写 v20 · 特征判别力一次性普查（英语灰报 4 张）
 * ============================================================
 * 目的：在「造任何新通道之前」，先量化回答——
 *       到底哪些特征在【黑笔 vs 印刷】这个二分类上真的有判别力？
 *       之前几轮的失败根源是：凭直觉造判据（"手写更大/更粗/间距更乱"），
 *       从未在目标版面上测过它们的 AUC。
 *
 * 方法：以「红笔邻域内的低彩度暗像素」为黑笔候选正样本（代理真值），
 *       以「远离红笔的低彩度暗像素」为印刷负样本（更保守：排除被批改区）。
 *       逐特征算 AUC（0.5=无判别力，>0.7=可用，>0.85=强判别）。
 *
 * 候选特征（全部来自用户建议 + 主流文献）：
 *   F1 笔画粗细    1轮4邻域腐蚀存活率（v14 判据）
 *   F2 灰度对比    墨迹luma 与 邻域纸面luma 之差（越深越像手写）
 *   F3 灰度方差    3x3 邻域 luma 标准差（笔压变化→手写）
 *   F4 域高度      连通域 bbox 高
 *   F5 域宽度      连通域 bbox 宽
 *   F6 域密度      像素数/(bw*bh)
 *   F7 域长宽比
 *   F8 域内墨迹数（写一个字=多个笔画域连在一起）
 *   F9 基线偏离    域底边到「同行众数底边」的距离（手写无基线约束）
 *  F10 行位置      域中心到最近行间空隙的距离（行间留白→手写）
 *  F11 灰度偏色    墨迹像素的 chroma（黑笔应≈0）
 *  F12 水平度      域内像素的横向连续性
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { maskFromColorThreshold, normalizeIlluminationForDetection } from './src/image/handwriting-mask'
import { connectedComponents } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

/** AUC = P(pos>neg) + 0.5*P(pos==neg) */
function auc(pos: number[], neg: number[]): number {
  if (!pos.length || !neg.length) return 0.5
  const all: Array<[number, number]> = []
  for (const v of pos) all.push([v, 1])
  for (const v of neg) all.push([v, 0])
  all.sort((a, b) => a[0] - b[0])
  // 秩和法（含并列取平均秩）
  let i = 0
  let rankSum = 0
  while (i < all.length) {
    let j = i
    while (j + 1 < all.length && all[j + 1][0] === all[i][0]) j++
    const avgRank = (i + j) / 2 + 1
    for (let k = i; k <= j; k++) if (all[k][1] === 1) rankSum += avgRank
    i = j + 1
  }
  const n1 = pos.length
  const n0 = neg.length
  return (rankSum - (n1 * (n1 + 1)) / 2) / (n1 * n0)
}

function stats(pos: number[], neg: number[]) {
  const m = (a: number[]) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : 0)
  const med = (a: number[]) => {
    if (!a.length) return 0
    const s = [...a].sort((x, y) => x - y)
    return s[Math.floor(s.length / 2)]
  }
  return {
    posMed: +med(pos).toFixed(3), posAvg: +m(pos).toFixed(3),
    negMed: +med(neg).toFixed(3), negAvg: +m(neg).toFixed(3),
  }
}

async function main() {
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const o = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
      const w = o.info.width, h = o.info.height, ch = o.info.channels
      const N = w * h
      const luma = new Float32Array(N)
      for (let i = 0; i < N; i++) luma[i] = 0.299 * o.data[i * ch] + 0.587 * o.data[i * ch + 1] + 0.114 * o.data[i * ch + 2]

      const pre = await normalizeIlluminationForDetection(buf)
      const red = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })

      // 纸面亮度：luma 的 p90
      const ls = Array.from(luma).filter((_, i) => i % 37 === 0).sort((a, b) => a - b)
      const paper = ls[Math.floor(ls.length * 0.9)] || 240
      const darkTh = paper * 0.62

      // 低彩度暗像素 = 墨迹（黑笔 + 印刷）
      const ink = new Uint8Array(N)
      for (let i = 0; i < N; i++) {
        const p = i * ch
        const c = Math.max(o.data[p], o.data[p + 1], o.data[p + 2]) - Math.min(o.data[p], o.data[p + 1], o.data[p + 2])
        if (c < 14 && luma[i] < darkTh) ink[i] = 1
      }
      // 红笔邻域（正样本区）：24px 内
      const nearRed = new Uint8Array(N)
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          if (!red.data[y * w + x]) continue
          for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
            for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) nearRed[yy * w + xx] = 1
        }
      }
      // 远离红笔（负样本区）：120px 外，且仍在墨迹里
      const farRed = new Uint8Array(N)
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          if (nearRed[y * w + x]) continue
          let touch = false
          for (let yy = Math.max(0, y - 120); yy <= Math.min(h - 1, y + 120) && !touch; yy++)
            for (let xx = Math.max(0, x - 120); xx <= Math.min(w - 1, x + 120); xx++)
              if (nearRed[yy * w + xx]) { touch = true; break }
          if (!touch) farRed[y * w + x] = 1
        }
      }

      // 腐蚀存活率图（一次算全图）
      const aliveMask = new Uint8Array(N)
      for (let y = 1; y < h - 1; y++)
        for (let x = 1; x < w - 1; x++) {
          const i = y * w + x
          if (ink[i] && ink[i - 1] && ink[i + 1] && ink[i - w] && ink[i + w]) aliveMask[i] = 1
        }

      // 3x3 邻域 luma 标准差
      const std3 = new Float32Array(N)
      for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
          let s = 0, s2 = 0
          for (let dy = -1; dy <= 1; dy++)
            for (let dx = -1; dx <= 1; dx++) {
              const v = luma[(y + dy) * w + x + dx]
              s += v; s2 += v * v
            }
          const m = s / 9
          std3[y * w + x] = Math.sqrt(Math.max(0, s2 / 9 - m * m))
        }
      }

      // 连通域（含 bbox、域内统计、基线）
      const { comps, labels } = connectedComponents(ink, w, h, true) as unknown as {
        comps: Array<{ x0: number; y0: number; x1: number; y1: number; n: number }>
        labels: Int32Array
      }

      // 逐域算特征，域中心落在正/负样本区 → 归类
      const feat = (c: { x0: number; y0: number; x1: number; y1: number; n: number }) => {
        const bw = c.x1 - c.x0 + 1, bh = c.y1 - c.y0 + 1
        let tot = 0, alive = 0, lum = 0, lum2 = 0, chr = 0, horizRun = 0
        let baseVotes = 0
        for (let y = c.y0; y <= c.y1; y++) {
          let run = 0
          for (let x = c.x0; x <= c.x1; x++) {
            const i = y * w + x
            if (labels[i] !== undefined && ink[i] && !red.data[i]) {
              // 仅统计本域（用 labels 无法直接拿，改用 ink 且在 bbox 内近似）
            }
            if (!ink[i]) { run = 0; continue }
            tot++; if (aliveMask[i]) alive++
            const l = luma[i]; lum += l; lum2 += l * l
            const p = i * ch
            chr += Math.max(o.data[p], o.data[p + 1], o.data[p + 2]) - Math.min(o.data[p], o.data[p + 1], o.data[p + 2])
            run++
            if (run >= 2) horizRun++
          }
        }
        return {
          survive: tot ? alive / tot : 0,
          depth: tot ? (paper - lum / tot) / paper : 0,
          stdAvg: tot ? std3[c.y0 * w + c.x0] : 0,
          bh, bw, density: c.n / (bw * bh), ratio: bw / Math.max(1, bh),
          runs: horizRun / Math.max(1, tot),
          chroma: tot ? chr / tot : 0,
        }
      }

      // 正/负 域收集
      const pos: Array<ReturnType<typeof feat>> = []
      const neg: Array<ReturnType<typeof feat>> = []
      for (const c of comps) {
        if (c.n < 6) continue
        const cx = Math.round((c.x0 + c.x1) / 2)
        const cy = Math.round((c.y0 + c.y1) / 2)
        const i = cy * w + cx
        if (nearRed[i]) pos.push(feat(c))
        else if (farRed[i]) neg.push(feat(c))
      }

      const F: Array<[string, (f: ReturnType<typeof feat>) => number]> = [
        ['F1 粗细腐蚀存活率', (f) => f.survive],
        ['F2 灰度对比深度', (f) => f.depth],
        ['F3 3x3灰度标准差', (f) => f.stdAvg],
        ['F4 域高度', (f) => f.bh],
        ['F5 域宽度', (f) => f.bw],
        ['F6 域密度', (f) => f.density],
        ['F7 域长宽比', (f) => f.ratio],
        ['F8 横向连续率', (f) => f.runs],
        ['F9 域内平均chroma', (f) => f.chroma],
      ]
      const rows = F.map(([name, get]) => {
        const a = auc(pos.map(get), neg.map(get))
        return { name, auc: +a.toFixed(3), ...stats(pos.map(get), neg.map(get)) }
      }).sort((x, y) => y.auc - x.auc)

      console.log('GUARD ' + JSON.stringify({
        file,
        posDomains: pos.length,
        negDomains: neg.length,
        features: rows,
      }))
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 250))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
