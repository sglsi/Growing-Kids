/**
 * 错题区域提取 · 前期测试探针 v2（针对 v1 暴露的 4 个问题）
 *
 * 假设与验证：
 *  H1 分辨率红线：1024 宽导致笔画粘连 → 行切分失效。
 *     验证：2x lanczos 放大 + 锐化后重跑度量/行切分，对比 medH / rows。
 *  H2 mono 判据缺陷：红笔占比低被印刷黑字淹没 → 误判单色。
 *     验证：改用「红笔像素占比」(colorMask.coverage) 判断是否含批改笔迹。
 *  H3 分栏失败：栏间隙窄 + 阈值不适配。
 *     验证：扣除红笔像素后再做列投影，colTh / gapMin 参数扫描。
 *  H4 悬挂缩进：分栏成功后每栏行切分 + 行首聚类是否成立。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import {
  normalizeIlluminationForDetection,
  maskFromColorThreshold,
  segmentTextRows,
} from './src/image/handwriting-mask'
import {
  otsuThreshold,
  connectedComponents,
  quantileSorted,
} from './src/image/image-layout'
import { estimateCharMetrics } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const f of files) {
    try {
      await probePage(path.join(IN_DIR, f))
    } catch (e) {
      console.log(`GUARD {"file":"${f}","error":${JSON.stringify(String((e as Error)?.message ?? e))}}`)
    }
  }
}

/** 通用：由 RGB raw 计算 gray + 可选排除红笔像素的 ink */
function buildInk(
  data: Buffer, w: number, h: number, ch: number,
  opts: { excludeRed?: boolean; chromaMin?: number } = {},
) {
  const n = w * h
  const gray = new Uint8Array(n)
  for (let i = 0, p = 0; i < n; i++, p += ch) {
    gray[i] = Math.max(0, Math.min(255, Math.round(0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2])))
  }
  const thr = otsuThreshold(gray, n)
  const ink = new Uint8Array(n)
  let redExcluded = 0
  for (let i = 0, p = 0; i < n; i++, p += ch) {
    if (gray[i] >= thr) continue
    if (opts.excludeRed) {
      const r = data[p], g = data[p + 1], b = data[p + 2]
      const chroma = Math.max(r, g, b) - Math.min(r, g, b)
      if (chroma >= (opts.chromaMin ?? 22)) { redExcluded++; continue } // 彩色笔迹不算版面墨
    }
    ink[i] = 1
  }
  return { gray, ink, thr, redExcluded }
}

/** 列投影分栏（参数可调） */
function findCols(ink: Uint8Array, w: number, h: number, colThRatio: number, gapMin: number) {
  const colProfile = new Int32Array(w)
  for (let y = 0; y < h; y++) {
    const base = y * w
    for (let x = 0; x < w; x++) if (ink[base + x]) colProfile[x]++
  }
  const colMax = Math.max(...colProfile)
  const colTh = Math.max(1, Math.round(colMax * colThRatio))
  const gaps: Array<[number, number]> = []
  let x = 0
  while (x < w) {
    if (colProfile[x] > colTh) { x++; continue }
    const x0 = x
    while (x < w && colProfile[x] <= colTh) x++
    if (x - x0 >= gapMin) gaps.push([x0, x])
  }
  const cols: Array<[number, number]> = []
  let cur = 0
  for (const [g0, g1] of gaps) {
    if (g0 > cur) cols.push([cur, g0])
    cur = g1
  }
  if (cur < w) cols.push([cur, w])
  return { gaps, cols }
}

/** 栏内行切分 + 行首 x */
function colRows(ink: Uint8Array, w: number, h: number, x0: number, x1: number) {
  const prof = new Int32Array(h)
  for (let y = 0; y < h; y++) {
    const base = y * w
    let c = 0
    for (let x = x0; x < x1; x++) if (ink[base + x]) c++
    prof[y] = c
  }
  const profMax = Math.max(...prof)
  const th = Math.max(1, Math.round(profMax * 0.04))
  const rows: Array<{ y0: number; y1: number; xLeft: number }> = []
  let y = 0
  while (y < h) {
    if (prof[y] < th) { y++; continue }
    const y0 = y
    while (y < h && prof[y] >= th) y++
    let xLeft = x1 - x0
    for (let yy = y0; yy < y && xLeft === x1 - x0; yy++) {
      const base = yy * w
      for (let x = x0; x < x1; x++) if (ink[base + x]) { xLeft = x - x0; break }
    }
    rows.push({ y0, y1: y, xLeft })
  }
  return rows
}

async function probePage(file: string) {
  const buf = fs.readFileSync(file)
  const meta = await sharp(buf).metadata()
  const W0 = meta.width || 0
  const H0 = meta.height || 0

  const pre = await normalizeIlluminationForDetection(buf, {})

  // ═══ H1：2x 放大 + 锐化 vs 原尺度 ═══
  const up = await sharp(pre.buffer)
    .resize(W0 * 2, H0 * 2, { fit: 'fill', kernel: 'lanczos3' })
    .sharpen({ sigma: 1 })
    .removeAlpha()
    .toColourspace('srgb')
    .raw()
    .toBuffer({ resolveWithObject: true })
  const upW = up.info.width, upH = up.info.height, upCh = up.info.channels

  const mOrig = await estimateCharMetrics(pre.buffer, {})
  const { ink: inkUp, thr: thrUp } = buildInk(up.data, upW, upH, upCh, {})
  const segUp = segmentTextRows(inkUp, upW, upH, { rowProfileRatio: 0.05 })
  const upRowHeights = segUp.rows.map((r) => r.y1 - r.y0).sort((a, b) => a - b)

  // ═══ H2：红笔占比 ═══
  const cm = await maskFromColorThreshold(pre.buffer, {})
  const hasRed = cm.coverage >= 0.002 // ≥0.2% 即认为存在批改笔迹（待标定）

  // ═══ H3：分栏（2x 放大图上，扣红笔后列投影，参数扫描）═══
  const { ink: inkUpNoRed, redExcluded } = buildInk(up.data, upW, upH, upCh, { excludeRed: true })
  // 行高估计：用放大图行切分的行高 p40（比 medH 稳）
  const medHup = upRowHeights.length
    ? quantileSorted(upRowHeights, 0.4)
    : Math.round(upH * 0.012)
  const scan: Array<{ colTh: number; gapMin: number; cols: number; ranges: Array<[number, number]> }> = []
  for (const colThRatio of [0.005, 0.01, 0.02]) {
    for (const gapFactor of [0.4, 0.8]) {
      const gapMin = Math.max(4, Math.round(medHup * gapFactor))
      const { cols } = findCols(inkUpNoRed, upW, upH, colThRatio, gapMin)
      const real = cols.filter(([a, b]) => b - a >= medHup * 6)
      scan.push({ colTh: colThRatio, gapMin, cols: real.length, ranges: real })
    }
  }
  // 取 3 栏（报纸版式预期）或最多栏数的配置
  const best = scan.slice().sort((a, b) => b.cols - a.cols)[0]

  // ═══ H4：最优分栏下每栏行切分 + 悬挂缩进 ═══
  const gapMinBest = Math.max(4, Math.round(medHup * 0.4))
  const { cols: bestColsRaw } = findCols(inkUpNoRed, upW, upH, 0.01, gapMinBest)
  const bestCols = bestColsRaw.filter(([a, b]) => b - a >= medHup * 6)
  const colDetail = bestCols.map(([a, b], i) => {
    const rows = colRows(inkUpNoRed, upW, upH, a, b)
    // 合并小间隙
    const merged: Array<{ y0: number; y1: number; xLeft: number }> = []
    for (const r of rows) {
      const last = merged[merged.length - 1]
      if (last && r.y0 - last.y1 <= medHup * 0.5) {
        last.y1 = r.y1
        last.xLeft = Math.min(last.xLeft, r.xLeft)
      } else merged.push({ ...r })
    }
    // 行首聚类
    const xs = merged.map((r) => r.xLeft).sort((p, q2) => p - q2)
    const clusters: Array<{ sum: number; count: number }> = []
    for (const x of xs) {
      const last = clusters[clusters.length - 1]
      if (last && x - last.sum / last.count <= medHup * 0.6) { last.sum += x; last.count++ }
      else clusters.push({ sum: x, count: 1 })
    }
    const cl = clusters
      .map((c) => ({ center: Math.round(c.sum / c.count), count: c.count }))
      .sort((p, q2) => q2.count - p.count)
      .slice(0, 5)
    // 行高分布（行切分质量指标）
    const hs = merged.map((r) => r.y1 - r.y0).sort((p, q2) => p - q2)
    return {
      col: i + 1,
      x: [a, b],
      rows: merged.length,
      rowH: { p25: quantileSorted(hs, 0.25), p50: quantileSorted(hs, 0.5), p75: quantileSorted(hs, 0.75) },
      xLeftClusters: cl,
      topFlushShare: cl.length ? +(cl[0].count / merged.length).toFixed(2) : 0,
    }
  })

  // ═══ 红笔连通域（放大图，供形态标定）═══
  // ⚠️ maskFromColorThreshold 接收的是**编码图像** Buffer（内部自己 sharp 解码），
  //    必须先把 raw 像素编码为 PNG，否则报 unsupported image format。
  const upPng = await sharp(up.data, { raw: { width: upW, height: upH, channels: upCh } })
    .png()
    .toBuffer()
  const cmUp = await maskFromColorThreshold(upPng, {})
  const mInk = new Uint8Array(upW * upH)
  for (let i = 0; i < upW * upH; i++) mInk[i] = cmUp.data[i] ? 1 : 0
  const { comps } = connectedComponents(mInk, upW, upH, false)
  const marks = comps.filter((c) => c.n >= 10)
  const ars = marks
    .map((c) => (c.x1 - c.x0 + 1) / Math.max(1, c.y1 - c.y0 + 1))
    .sort((a, b) => a - b)
  const fills = marks
    .map((c) => c.n / Math.max(1, (c.x1 - c.x0 + 1) * (c.y1 - c.y0 + 1)))
    .sort((a, b) => a - b)
  const areas = marks.map((c) => c.n).sort((a, b) => a - b)

  const q = (a: number[], p: number) => (a.length ? +quantileSorted(a, p).toFixed(2) : 0)
  console.log(
    'GUARD ' +
      JSON.stringify({
        file: path.basename(file),
        size: `${W0}x${H0}`,
        H1_resolution: {
          orig: { medH: +mOrig.medH.toFixed(1), conf: +mOrig.confidence.toFixed(2) },
          up2x: {
            medH_est_rowH_p40: medHup,
            rows: segUp.rows.length,
            glyphH: segUp.glyphH,
            rowH: { p25: q(upRowHeights, 0.25), p50: q(upRowHeights, 0.5), p90: q(upRowHeights, 0.9) },
            otsu: thrUp,
          },
        },
        H2_redPen: {
          coverage: +cm.coverage.toFixed(4),
          hasRed,
          verdict: hasRed ? '批改笔迹存在(mono判据不适用)' : '无批改笔迹',
        },
        H3_columns: { redExcluded, scan: scan.map((s) => ({ th: s.colTh, gap: s.gapMin, cols: s.cols })) },
        H4_colDetail: colDetail,
        marks2x: {
          count: marks.length,
          area: { p50: q(areas, 0.5), p90: q(areas, 0.9), max: areas[areas.length - 1] ?? 0 },
          aspect: { p10: q(ars, 0.1), p50: q(ars, 0.5), p90: q(ars, 0.9) },
          fill: { p10: q(fills, 0.1), p50: q(fills, 0.5), p90: q(fills, 0.9) },
        },
      }),
  )
}

main().catch((e) => {
  console.error('PROBE FAILED:', e)
  process.exit(1)
})
