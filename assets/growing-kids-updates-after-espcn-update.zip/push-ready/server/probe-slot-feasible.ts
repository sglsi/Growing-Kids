/**
 * v20.9 · 答题槽位检测 v3（彩度分离 + 槽位类型判定）
 * ============================================================
 * v2 目检（v20-槽位目检/page30-slots.png）发现的两个问题：
 *
 *   ① **槽位找错了对象**：品红框大多圈住**选项括号** `( A ) Maridio…` ——
 *      选项字母 A/B/C/D 是**印刷体**，槽内本来就不该有手写，检测链不判手写是
 *      **正确行为**。真正要找的是**题号答题括号** `( )1.`（学生写答案的地方）。
 *      ⇒ v3 用「槽内印刷墨像素」区分：选项括号槽内 printInk>0，答题括号 ==0。
 *
 *   ② **红笔与印刷括号粘连**：括号检测在灰度 Otsu 墨迹上做，红笔手写 D 与
 *      印刷 `(` `)` 粘成一个连通域 → 形状不再是细长括号 → 被筛选排除。
 *      ⇒ v3 把墨迹按彩度分离：**printInk = ink && chrom<14**（印刷），
 *        **colorInk = ink && chrom≥14**（红/蓝笔）。括号检测只在 printInk 上做。
 *
 * 版面事实（目检确认）：
 *   `( D )1. …` 题号前有答题括号（印刷），学生在里面写答案字母；
 *   `( A ) xxx` 选项前也有括号（印刷），里面印着选项字母 —— **不是**答题位。
 *
 * 已知边界（第一版）：
 *   黑笔/铅笔手写也是低彩度，会混进 printInk。本版先验证红笔场景；
 *   黑笔场景需要"槽内低彩度墨是否为印刷字形"的二级判据，后续版本处理。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { connectedComponents, closeInk3x3 } from './src/image/image-layout'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'

const IN_DIR = '/workspace/wrongq-test'
const OUT_DIR = '/workspace/v20-槽位目检'
const CHROM_TH = 14 // 与生产口径一致（红笔 chrom≥14）

function otsu(g: Buffer): number {
  const hist = new Int32Array(256)
  for (let i = 0; i < g.length; i++) hist[g[i]]++
  const total = g.length
  let sum = 0
  for (let i = 0; i < 256; i++) sum += i * hist[i]
  let sumB = 0, wB = 0, best = 0, bt = 128
  for (let t = 0; t < 256; t++) {
    wB += hist[t]
    if (!wB) continue
    const wF = total - wB
    if (!wF) break
    sumB += t * hist[t]
    const mB = sumB / wB, mF = (sum - sumB) / wF
    const v = wB * wF * (mB - mF) * (mB - mF)
    if (v > best) { best = v; bt = t }
  }
  return bt
}

function measureGlyphs(inkC: Uint8Array, w: number, h: number) {
  const { comps } = connectedComponents(inkC, w, h, false)
  const glyphs: Array<{ bw: number; bh: number; n: number; x0: number; y0: number; x1: number; y1: number }> = []
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1, bh = c.y1 - c.y0 + 1
    if (c.n < 3 || c.n > 400) continue
    if (bw > 60 || bh > 60) continue
    if (bw / bh > 5 || bh / bw > 5) continue
    glyphs.push({ bw, bh, n: c.n, x0: c.x0, y0: c.y0, x1: c.x1, y1: c.y1 })
  }
  const histH = new Int32Array(80)
  for (const c of glyphs) if (c.bh < 80) histH[c.bh]++
  let modeH = 0, mc = 0
  for (let i = 0; i < 80; i++) if (histH[i] > mc) { mc = histH[i]; modeH = i }
  const histW = new Int32Array(80)
  for (const c of glyphs) if (c.bw < 80) histW[c.bw]++
  let modeW = 0, mcw = 0
  for (let i = 0; i < 80; i++) if (histW[i] > mcw) { mcw = histW[i]; modeW = i }
  return { glyphs, modeH, modeW }
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  const out: any[] = []

  for (const file of files) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const { data: g } = await sharp(buf).grayscale().raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height, n = w * h
    const chrom = (p: number) => {
      const i = p * 3
      return Math.max(od[i], od[i + 1], od[i + 2]) - Math.min(od[i], od[i + 1], od[i + 2])
    }

    const thr = otsu(g)
    // ⭐ 彩度分离的墨迹图
    const printInk = new Uint8Array(n) // 印刷（低彩度暗像素）
    const colorInk = new Uint8Array(n) // 彩色手写
    for (let p = 0; p < n; p++) {
      if (g[p] >= thr) continue
      if (chrom(p) >= CHROM_TH) colorInk[p] = 1
      else printInk[p] = 1
    }
    const printC = closeInk3x3(printInk, w, h)

    const { glyphs, modeH, modeW } = measureGlyphs(printC, w, h)

    // 括号候选（阈值基于**印刷墨**的实测众数）
    const H_LO = Math.max(5, Math.round(modeH * 0.8))
    const H_HI = Math.round(modeH * 2.4)
    const W_HI = Math.max(4, Math.round(modeW * 1.3))
    const cands = glyphs
      .filter((c) => c.bh >= H_LO && c.bh <= H_HI && c.bw >= 2 && c.bw <= W_HI)
      .map((c) => ({ ...c, fill: +(c.n / (c.bw * c.bh)).toFixed(3) }))
    const thin = cands.filter((c) => c.fill <= 0.55)

    // 槽位配对（保留左右括号 bbox —— "括号内"必须严格取两括号之间的区域）
    const slots: Array<{ x0: number; y0: number; x1: number; y1: number; gap: number; innerX0: number; innerX1: number }> = []
    const used = new Set<number>()
    for (let i = 0; i < thin.length; i++) {
      if (used.has(i)) continue
      for (let j = i + 1; j < thin.length; j++) {
        if (used.has(j)) continue
        const a = thin[i], b = thin[j]
        const ov = Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0)
        if (ov < 0.6 * Math.min(a.bh, b.bh)) continue
        if (Math.abs(a.bh - b.bh) > Math.max(3, modeH * 0.5)) continue
        const gap = b.x0 - a.x1
        if (gap < 1 || gap > modeH * 4) continue
        used.add(i); used.add(j)
        // ⭐ v3 修正：innerX0/X1 = 左括号右缘+1 / 右括号左缘-1。
        //   之前用整槽 bbox 按 12% 内缩，pad=1 时"槽内"仍含两个括号自己的弧身，
        //   导致 printInk>0 恒成立、所有槽位被判成"选项括号"。
        slots.push({
          x0: a.x0, y0: Math.min(a.y0, b.y0), x1: b.x1, y1: Math.max(a.y1, b.y1), gap,
          innerX0: a.x1 + 1, innerX1: b.x0 - 1,
        })
        break
      }
    }
    // gap 分布（观察答题括号 vs 选项括号是否双峰）
    const gaps = slots.map((s) => s.gap).sort((a, b) => a - b)

    // ── 槽位分类：槽内印刷墨 ==0 → 答题括号；>0 → 选项括号 ──
    let answerSlots = 0, optionSlots = 0
    let writtenSlots = 0           // 答题槽且槽内有彩色墨（= 学生写了）
    let writtenColorPx = 0         // 被写答题槽内的彩色墨总量
    const slotKind: Array<{ s: typeof slots[0]; kind: 'answer' | 'option'; colorPx: number; printPx: number }> = []
    for (const s of slots) {
      let cInk = 0, pInk = 0
      if (s.innerX1 >= s.innerX0) {
        for (let y = s.y0; y <= s.y1; y++) {
          const b = y * w
          for (let x = s.innerX0; x <= s.innerX1; x++) {
            if (colorInk[b + x]) cInk++
            if (printInk[b + x]) pInk++
          }
        }
      }
      const kind = pInk > 0 ? 'option' : 'answer'
      if (kind === 'answer') { answerSlots++; if (cInk > 0) { writtenSlots++; writtenColorPx += cInk } }
      else optionSlots++
      slotKind.push({ s, kind, colorPx: cInk, printPx: pInk })
    }

    // ── 与现有检测链对照：被写答题槽内的彩色墨，检测链覆盖了多少 ──
    const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
    let covered = 0
    for (const k of slotKind) {
      if (k.kind !== 'answer' || k.colorPx === 0) continue
      const s = k.s
      const pad = Math.max(1, Math.round((s.x1 - s.x0) * 0.12))
      for (let y = s.y0; y <= s.y1; y++) {
        const b = y * w
        for (let x = Math.max(0, s.x0 + pad); x <= Math.min(w - 1, s.x1 - pad); x++) {
          if (colorInk[b + x] && seg.mask.data[b + x] > 127) covered++
        }
      }
    }

    // ── 可视化 ──
    const vis = Buffer.from(od)
    const box = (x0: number, y0: number, x1: number, y1: number, rgb: [number, number, number], t = 1) => {
      for (let x = x0; x <= x1; x++) for (const y of [y0, y0 + t, y1 - t, y1]) {
        if (x < 0 || x >= w || y < 0 || y >= h) continue
        const p = (y * w + x) * 3
        vis[p] = rgb[0]; vis[p + 1] = rgb[1]; vis[p + 2] = rgb[2]
      }
      for (let y = y0; y <= y1; y++) for (const x of [x0, x0 + t, x1 - t, x1]) {
        if (x < 0 || x >= w || y < 0 || y >= h) continue
        const p = (y * w + x) * 3
        vis[p] = rgb[0]; vis[p + 1] = rgb[1]; vis[p + 2] = rgb[2]
      }
    }
    for (const k of slotKind) {
      if (k.kind === 'answer' && k.colorPx > 0) box(k.s.x0, k.s.y0, k.s.x1, k.s.y1, [255, 0, 255], 1)      // 品红=被写的答题槽
      else if (k.kind === 'answer') box(k.s.x0, k.s.y0, k.s.x1, k.s.y1, [0, 200, 0], 1)                     // 绿=空答题槽
      else box(k.s.x0, k.s.y0, k.s.x1, k.s.y1, [0, 180, 180], 1)                                            // 青=选项括号
    }
    const stem = file.replace('.png', '')
    await sharp(vis, { raw: { width: w, height: h, channels: 3 } }).png().toFile(`${OUT_DIR}/${stem}-slots-v3.png`)

    out.push({
      file,
      modeH, modeW, thr, chromTH: CHROM_TH,
      printGlyphs: glyphs.length,
      candidates: cands.length, thin: thin.length,
      slots: slots.length,
      gap_p25: gaps.length ? gaps[Math.floor(gaps.length * 0.25)] : null,
      gap_p50: gaps.length ? gaps[Math.floor(gaps.length * 0.5)] : null,
      gap_p75: gaps.length ? gaps[Math.floor(gaps.length * 0.75)] : null,
      answerSlots, optionSlots, writtenSlots, writtenColorPx,
      detectChainCoveredPx: covered,
      coverRate: writtenColorPx ? +(covered / writtenColorPx).toFixed(4) : null,
    })
    console.error(`[${file}] modeH=${modeH} 槽位=${slots.length}(答题${answerSlots}/选项${optionSlots}) 被写=${writtenSlots} 彩墨=${writtenColorPx} 检测链覆盖=${covered}`)
  }

  console.log('RESULT ' + JSON.stringify(out, null, 1))
  // ── G1 量级门禁 ──
  // 注意：本探针 v20.9 已**否决**（黑笔答案与印刷体在所有可测维度重叠，
  // 见 工程教训录-探针反复失效根因.md §6）。区间声明保留作为历史记录，
  // 且一旦有人重启这条路线，modeH 越界会立刻暴露"又用了失真度量"。
  console.error('GUARD_RANGE ' + JSON.stringify({
    modeH: [5, 20],   // 权威函数给 29.3~105（失真 2.7~2.9x）
    coverRate: [0, 1],
  }))
}

main().catch((e) => { console.error(e); process.exit(1) })
