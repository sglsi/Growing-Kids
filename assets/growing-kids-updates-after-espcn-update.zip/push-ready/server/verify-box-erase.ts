import sharp from '/workspace/push-ready/server/node_modules/sharp'
import { buildHandwritingMask } from '/workspace/push-ready/server/src/image/handwriting-segmenter'
// ⚠️ inpaint / blendWithMask 实际导出自 handwriting-mask（segmenter 只导出 VLM 分割与合成入口）
import { inpaint, blendWithMask, unmodifiedRegionSimilarity } from '/workspace/push-ready/server/src/image/handwriting-mask'

// case1 GT（原图 1279x1706）。前 5 个为手写区（应擦净），最后 1 个为印刷题干（应 100% 保留）
const PATH = '/root/uploads/1790697352956629135-1790697330026-hq5z96hx-9e12369282df0f327502a0364da8ea20.jpg'
const W = 1279, H = 1706
const HAND: Array<[string, number, number, number, number]> = [
  ['7题-括号答案', 680, 70, 260, 130],
  ['13题-取值范围', 880, 440, 400, 90],
  ['14题-填空', 340, 520, 480, 110],
  ['16题-填空线序号', 820, 985, 460, 70],
  ['20题-手写', 30, 1225, 950, 480],
]
const PROTECT: [string, number, number, number, number] = ['16题-印刷题干', 10, 950, 820, 100]

async function darkInk(src: Buffer, x: number, y: number, w: number, h: number) {
  const { data } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true })
  const Wd = (await sharp(src).metadata()).width!
  let n = 0
  for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) {
    const p = (yy * Wd + xx) * 3
    const l = 0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2]
    if (l < 140) n++
  }
  return n
}

async function main() {
  const src = await sharp(PATH).rotate().png().toBuffer()
  // 紧框 → 归一化 manual_regions
  const manual = HAND.map(([, x, y, w, h]) => ({ x: x / W, y: y / H, w: w / W, h: h / H }))

  const seg = await buildHandwritingMask(src, '', {}, { allowVlm: false, manualRects: manual })
  const mask = seg.mask
  console.log(`框选 mask: source=${mask.source} coverage=${(mask.coverage * 100).toFixed(2)}%`)

  const inpainted = await inpaint(src, 'adaptive', mask)
  const merged = await blendWithMask(src, inpainted, mask)

  console.log('\n框内手写擦净率（墨迹像素 before→after）：')
  let allOk = true
  for (const [name, x, y, w, h] of HAND) {
    const b = await darkInk(src, x, y, w, h)
    const a = await darkInk(merged, x, y, w, h)
    const rate = b ? ((b - a) / b * 100).toFixed(1) : 'NA(无墨)'
    const ok = b === 0 || a / b < 0.1
    if (!ok) allOk = false
    console.log(`  ${name.padEnd(16)} ${String(b).padStart(5)} → ${String(a).padStart(5)}  擦净率 ${rate}%  ${ok ? '✅' : '❌'}`)
  }

  // 框外印刷保护区一致性
  const sim = await unmodifiedRegionSimilarity(src, merged, mask)
  console.log(`\n框外非 mask 区一致性 = ${(sim.similarity * 100).toFixed(2)}% ${sim.similarity > 0.999 ? '✅(印刷零损伤)' : '❌'}`)

  // 印刷保护区（应在 mask 外，毫发无损）
  const pb = await darkInk(src, ...PROTECT.slice(1) as [number, number, number, number])
  const pa = await darkInk(merged, ...PROTECT.slice(1) as [number, number, number, number])
  console.log(`印刷保护区墨迹 ${pb} → ${pa}（应完全相等）  ${pb === pa ? '✅' : '❌ 印刷被改动!'}`)

  await sharp(merged).png().toFile('/workspace/主流方案对比/框选补擦-case1.png')
  console.log('\n结论：框选路径', allOk ? '✅ 全部手写 100% 擦净且印刷零损伤' : '❌ 仍有残留')
}
main().catch(e => { console.error(e); process.exit(1) })
