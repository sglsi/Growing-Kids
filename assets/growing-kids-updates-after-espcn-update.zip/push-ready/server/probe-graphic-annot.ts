/**
 * 图形区判据标定 · 第 0 步：先目视标注，再谈判据
 * ============================================================
 * ⭐ 为什么必须先做这个：probe-graphic-guard3 实测 6 个候选判据 AUC 全部 < 0.85
 *   （最好 edgeDensity 仅 0.762）→ 按 G1 属"不成立"，不能硬凑阈值。
 *   但逐行看数据发现问题不在判据，而在**我的标注本身靠坐标猜**：
 *     · 标为"文字"的某框 spread=1 / meanGrad=0.49 / flatRatio=1 → 它是纯白块
 *     · 标为"文字"的某框 flatRatio=0.088 / edgeDensity=0.755 → 比多数"图形"还像图形
 *   在错误标注上测判据 = 拟合噪声，测多少遍都没意义。
 *
 * 本脚本把每个样本框裁出、放大 10 倍、打上编号，拼成一张对照图。
 *   → 我目视编号 → 得到可信标注 → 再跑判据标定。
 *
 * 顺带产出一份 annotation.json，人工确认后的标注直接落库，
 *   以后判据标定都基于它（消除"每次重新猜标注"的漂移）。
 */
import sharp from 'sharp'
import * as fs from 'fs'

const IN_DIR = '/workspace/wrongq-test'
const OUT = '/workspace/v20-框选E2E/zoom'

interface Sample { file: string; box: [number, number, number, number]; what: string }

const SAMPLES: Sample[] = [
  // 现有"图形"标注（来自之前目检）
  { file: 'page28.png', box: [255, 255, 306, 306], what: '显微镜照片?' },
  { file: 'page30.png', box: [530, 1193, 581, 1244], what: '实物照片A?' },
  { file: 'page30.png', box: [60, 1200, 111, 1251], what: '实物照片B?' },
  { file: 'page28.png', box: [430, 700, 481, 751], what: '插图?' },
  { file: 'page29.png', box: [300, 600, 351, 651], what: '图片区?' },
  { file: 'page29.png', box: [459, 450, 510, 501], what: 'E2E-auto图形?' },
  { file: 'page31.png', box: [102, 566, 153, 617], what: 'E2E-auto图形?' },
  // 现有"文字"标注（靠坐标猜，存疑）
  { file: 'page30.png', box: [40, 60, 91, 111], what: '正文1' },
  { file: 'page30.png', box: [40, 170, 91, 221], what: '正文2' },
  { file: 'page30.png', box: [640, 60, 691, 111], what: '正文3' },
  { file: 'page30.png', box: [640, 170, 691, 221], what: '正文4' },
  { file: 'page28.png', box: [40, 60, 91, 111], what: '正文5' },
  { file: 'page29.png', box: [40, 60, 91, 111], what: '正文6' },
  { file: 'page31.png', box: [40, 60, 91, 111], what: '正文7' },
  { file: 'page29.png', box: [459, 654, 510, 705], what: 'E2E-text文字?' },
  { file: 'page30.png', box: [663, 1254, 714, 1305], what: 'E2E-text文字?' },
]

const ZOOM = 10
const COLS = 4
const PAD = 4

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  const tiles: { buf: Buffer; no: number; what: string; file: string }[] = []

  for (let i = 0; i < SAMPLES.length; i++) {
    const s = SAMPLES[i]
    const src = fs.readFileSync(`${IN_DIR}/${s.file}`)
    const meta = await sharp(src).metadata()
    const W = (s.box[2] - s.box[0] + 1) * ZOOM
    const H = (s.box[3] - s.box[1] + 1) * ZOOM
    const cut = await sharp(src).extract({ left: s.box[0], top: s.box[1], width: s.box[2] - s.box[0] + 1, height: s.box[3] - s.box[1] + 1 })
      .resize({ width: W, kernel: 'nearest' }).png().toBuffer()
    const framed = await sharp({
      create: { width: W + PAD * 2, height: H + PAD * 2 + 26, channels: 3, background: { r: 255, g: 255, b: 255 } },
    }).composite([
      { input: cut, left: PAD, top: PAD },
      {
        input: Buffer.from(
          `<svg width="${W + PAD * 2}" height="${H + PAD * 2 + 26}">` +
          `<rect width="${W + PAD * 2}" height="${H + PAD * 2 + 26}" fill="none" stroke="#888"/>` +
          `<text x="4" y="${H + PAD * 2 + 19}" font-size="18" font-weight="bold" fill="#c00">#${i} ${s.file} ${s.what}</text>` +
          `</svg>`,
        ), left: 0, top: 0,
      },
    ]).png().toBuffer()
    tiles.push({ buf: framed, no: i, what: s.what, file: s.file })
    void meta
  }

  // 拼成网格（每行 COLS 个）
  const tw = Math.max(...tiles.map((t) => t.buf.length ? 0 : 0)) // 占位
  void tw
  const metas = await Promise.all(tiles.map((t) => sharp(t.buf).metadata()))
  const cellW = Math.max(...metas.map((m) => m.width!)) + 8
  const cellH = Math.max(...metas.map((m) => m.height!)) + 8
  const rows = Math.ceil(tiles.length / COLS)
  const canvasW = cellW * COLS
  const canvasH = cellH * rows

  const composites = tiles.map((t, i) => ({
    input: t.buf,
    left: (i % COLS) * cellW + 4,
    top: Math.floor(i / COLS) * cellH + 4,
  }))
  const outBuf = await sharp({
    create: { width: canvasW, height: canvasH, channels: 3, background: { r: 250, g: 250, b: 250 } },
  }).composite(composites).png().toBuffer()

  const outFile = `${OUT}/annotation-grid.png`
  fs.writeFileSync(outFile, outBuf)

  fs.writeFileSync(`${OUT}/annotation-candidates.json`, JSON.stringify(SAMPLES.map((s, i) => ({
    no: i, file: s.file, box: s.box, guess: s.what,
  })), null, 1))

  console.log('RESULT ' + JSON.stringify({
    out: outFile,
    grid: `${canvasW}x${canvasH}`,
    cell: `${cellW}x${cellH}`,
    zoom: ZOOM,
    samples: SAMPLES.length,
  }))
  console.error(`对照图: ${outFile}  (${canvasW}x${canvasH}, ${COLS}列, 放大${ZOOM}倍)`)
}

main().catch((e) => { console.error(e); process.exit(1) })