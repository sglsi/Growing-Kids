/**
 * 框选补擦效果取证：原图 / 自动检测结果 / 框选补擦后（三联 slider）
 * ============================================================
 * 目的：整页图看不出"框选那一块"补擦了什么（框只占全图 ~0.2%）。
 *   必须裁出**框选区域及其周边**做三联对比，才能目检。
 *
 * 遵循 G3（目检分辨率门禁）：逐目标放大 ≥6 倍，带实测标注。
 * 遵循用户的既有要求：对比一律用 slider（底图恒为原图，上层切换）。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'
const OUT_DIR = '/workspace/v20-框选取证'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  const stats: any[] = []

  for (const file of files) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, n = w * h
    const luma = (p: number) => 0.299 * od[p * 3] + 0.587 * od[p * 3 + 1] + 0.114 * od[p * 3 + 2]

    const base = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
    const baseImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', base.mask), base.mask)
    const { data: baseNd } = await raw(baseImg)

    const diffs: number[] = []
    for (let k = 0; k < 1500; k++) {
      const p = Math.floor((k / 1500) * n)
      diffs.push(Math.max(
        Math.abs(od[p * 3] - baseNd[p * 3]),
        Math.abs(od[p * 3 + 1] - baseNd[p * 3 + 1]),
        Math.abs(od[p * 3 + 2] - baseNd[p * 3 + 2]),
      ))
    }
    diffs.sort((a, b) => a - b)
    const TH = Math.max(12, Math.min(40, diffs[Math.floor(diffs.length * 0.99)]))
    const changed = (d: Buffer, p: number) => {
      const i = p * 3
      return Math.abs(od[i] - d[i]) > TH || Math.abs(od[i + 1] - d[i + 1]) > TH || Math.abs(od[i + 2] - d[i + 2]) > TH
    }

    // 找漏擦区（与 verify-manual-e2e 同一口径）
    const BS = Math.max(24, Math.round(Math.min(w, h) * 0.05))
    const ls: number[] = []
    for (let p = 0; p < n; p += 13) ls.push(luma(p))
    ls.sort((a, b) => a - b)
    const inkTh = ls[Math.floor(ls.length * 0.98)] - 45
    let best: { x: number; y: number; ink: number } | null = null
    for (let by = 0; by + BS <= h; by += BS) {
      for (let bx = 0; bx + BS <= w; bx += BS) {
        let ink = 0, chg = 0
        for (let y = by; y < by + BS; y++) {
          const b = y * w
          for (let x = bx; x < bx + BS; x++) {
            const p = b + x
            if (luma(p) < inkTh) ink++
            if (changed(baseNd, p)) chg++
          }
        }
        if (ink > BS * BS * 0.02 && chg === 0 && (!best || ink > best.ink)) best = { x: bx, y: by, ink }
      }
    }
    if (!best) continue

    const regions = [{
      x: +(best.x / w).toFixed(4), y: +(best.y / h).toFixed(4),
      w: +(BS / w).toFixed(4), h: +(BS / h).toFixed(4),
    }]
    const man = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid', manualRects: regions })
    const manImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)

    // 取证裁剪：框选区 + 60% 边距（看得到上下文，且能看出有无伤到邻近印刷）
    const M = Math.round(BS * 0.6)
    const cx0 = Math.max(0, best.x - M), cy0 = Math.max(0, best.y - M)
    const cw = Math.min(w - cx0, BS + M * 2), ch = Math.min(h - cy0, BS + M * 2)
    const Z = Math.max(2, Math.min(6, Math.floor(900 / Math.max(cw, ch))))
    const stem = file.replace('.png', '')

    // mask 品红叠加（第二层用）
    const mv = Buffer.from(od)
    for (let y = 0; y < h; y++) {
      const b = y * w
      for (let x = 0; x < w; x++) {
        if (man.mask.data[b + x] <= 127) continue
        const p = (b + x) * 3
        mv[p] = Math.min(255, mv[p] * 0.5 + 255 * 0.5)
        mv[p + 1] = mv[p + 1] * 0.5
        mv[p + 2] = Math.min(255, mv[p + 2] * 0.5 + 255 * 0.5)
      }
    }
    // 框线（绿框=用户框选范围）
    for (let x = best.x; x < best.x + BS; x++) {
      for (const y of [best.y, best.y + BS - 1]) {
        const p = (y * w + x) * 3; mv[p] = 0; mv[p + 1] = 200; mv[p + 2] = 0
      }
    }
    for (let y = best.y; y < best.y + BS; y++) {
      for (const x of [best.x, best.x + BS - 1]) {
        const p = (y * w + x) * 3; mv[p] = 0; mv[p + 1] = 200; mv[p + 2] = 0
      }
    }

    const imgs: Record<string, Buffer> = {
      orig: buf,
      mask: await sharp(mv, { raw: { width: w, height: h, channels: 3 } }).png().toBuffer(),
      auto: baseImg,
      after: manImg,
    }
    for (const [k, b] of Object.entries(imgs)) {
      await sharp(b).extract({ left: cx0, top: cy0, width: cw, height: ch })
        .resize({ width: cw * Z, height: ch * Z, kernel: 'nearest' })
        .png().toFile(`${OUT_DIR}/${stem}-${k}.png`)
    }
    // 裁剪坐标存盘，供 HTML 标注
    fs.appendFileSync(`${OUT_DIR}/_meta.txt`,
      `${stem} cx=${cx0} cy=${cy0} cw=${cw} ch=${ch} Z=${Z} rect=${best.x},${best.y},${BS},${BS} darkPx=${best.ink}\n`)

    stats.push({ file: stem, rect: `${best.x},${best.y} ${BS}x${BS}`, darkPx: best.ink, crop: `${cx0},${cy0} ${cw}x${ch} x${Z}` })
    console.error(`[${file}] 框选区=${best.ink}暗像素 裁剪=${cx0},${cy0} ${cw}x${ch} x${Z}`)
  }
  console.log('RESULT ' + JSON.stringify(stats, null, 1))
}

main().catch((e) => { console.error(e); process.exit(1) })
