/**
 * TSX 语法校验（不加载任何类型/模块，纯 parser 层面）
 * ============================================================
 * 前端工程（/workspace/push-ready/src）在本沙箱**没有独立 tsconfig / package.json**，
 * 无法跑真实编译；但改动最容易出错的是 JSX/花括号配对这类**语法**问题，
 * 用 TypeScript 解析器即可零依赖检出。
 *
 * 用法：npx tsx tsx-syntax-check.ts [文件...]   （缺省校验去手写相关前端文件）
 * 全部语法正确 → exit 0；存在语法错误 → 打印位置并 exit 1。
 */
import ts from 'typescript'
import { readFileSync } from 'node:fs'

const DEFAULTS = [
  '/workspace/push-ready/src/components/image-editor.tsx',
  '/workspace/push-ready/src/services/api.ts',
]

function checkFile(file: string): { file: string; errors: string[] } {
  const out: string[] = []
  try {
    const code = readFileSync(file, 'utf8')
    const sf = ts.createSourceFile(file, code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)
    // parseDiagnostics 只含语法错误（不含类型错误），正是我们要的最小保证
    const diags = (sf as unknown as { parseDiagnostics?: ts.Diagnostic[] }).parseDiagnostics ?? []
    for (const d of diags) {
      const pos = d.file ? d.file.getLineAndCharacterOfPosition(d.start) : { line: 0, character: 0 }
      out.push(`  L${pos.line + 1}:${pos.character + 1}  ${ts.flattenDiagnosticMessageText(d.messageText, ' ')}`)
    }
  } catch (e: unknown) {
    out.push(`  读取/解析失败: ${String((e as Error)?.message ?? e)}`)
  }
  return { file, errors: out }
}

function main(): void {
  const files = process.argv.slice(2).length ? process.argv.slice(2) : DEFAULTS
  let bad = 0
  for (const f of files) {
    const r = checkFile(f)
    const name = f.split('/').pop()
    if (r.errors.length === 0) {
      console.log(`[✓] ${name} 语法正确`)
    } else {
      bad++
      console.log(`[✗] ${name} 存在 ${r.errors.length} 处语法问题:`)
      r.errors.slice(0, 8).forEach((e) => console.log(e))
    }
  }
  console.log(bad === 0 ? '\n全部语法校验通过' : `\n${bad} 个文件语法异常，请修复`)
  process.exit(bad === 0 ? 0 : 1)
}

main()
