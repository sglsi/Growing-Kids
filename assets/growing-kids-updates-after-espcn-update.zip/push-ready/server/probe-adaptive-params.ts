/**
 * probe-adaptive-params.ts —— 自适应参数方法论·实证探针
 *
 * 目的：用一组**来源互不相同**的图，验证方法论的两个前提：
 *   A. 图像统计量在不同图之间差异巨大 ⇒ 任何固定参数必然在某些图上失效
 *   B. 这些统计量可以从每张图自身稳定估计 ⇒ 自适应参数可行
 *
 * 三层估计量：
 *   L1 纸面统计：paperLuma(最亮25%中位,现行做法)、p95、纸面彩度中位/MAD
 *   L2 局部统计：积分图算 m(x,y)/s(x,y)，Sauvola T=m(1+k(s/R-1)) k=0.34 R=128
 *   L3 版面统计：连通域高度众数(≈字高 charH)、横向游程众数(≈笔画宽 strokeW)
 *
 * 对照：
 *   · 现行全局判定  luma < 0.62×p95            （黑笔路径的固定比值）
 *   · Sauvola 局部判定 窗口 w=2×charH          （自适应）
 *   · 在"大片深色连通域"（照片/插图）内部，两种判定各标记多少像素
 *     —— page28 照片被整块涂白事故的量化复现
 *   · R=24px 膨胀半径 ÷ charH —— 同一绝对像素值在不同图上的语义尺度漂移
 *   · chromaMin=22 ÷ 纸面彩度噪声(3×MAD) —— 同一绝对彩度值的相对位置漂移
 */

import * as fs from 'fs'
import sharp from 'sharp'

const CASES = [
  { file: '/workspace/wrongq-test/page28.png', tag: '扫描·红笔+照片' },
  { file: '/workspace/wrongq-test/page29.png', tag: '扫描·红笔' },
  { file: '/workspace/wrongq-test/page30.png', tag: '扫描·红笔' },
  { file: '/workspace/wrongq-test/page31.png', tag: '扫描·红笔' },
  { file: '/workspace/wrongq-test/case3-photo.png', tag: '拍照·暖纸+红笔' },
  { file: '/workspace/黑白-最终效果-1279x1706.png', tag: '黑白二值·黑笔' },
  { file: '/workspace/poc-phase0/orig.png', tag: '合成·干净' },
]

interface Stats {
  tag: string
  w: number; h: number
  paperLuma: number; p95: number; paperChroma: number; chromaMAD: number
  otsuT: number; otsuInkPct: number
  charH: number; strokeW: number; nCC: number
  sauvolaW: number
  globalInkPct: number; sauvolaInkPct: number
  blobPx: number; blobByGlobal: number; blobBySauvola: number
  r24_over_charH: string; chromaFPppm: number
}

function mode(hist: Map<number, number>, lo: number, hi: number): number {
  let best = 0, bestN = 0
  for (const [v, n] of hist) if (v >= lo && v <= hi && n > bestN) { best = v; bestN = n }
  return best
}

async function analyze(file: string, tag: string): Promise<Stats> {
  const { data, info } = await sharp(fs.readFileSync(file)).removeAlpha().raw().toBuffer({ resolveWithObject: true })
  const W = info.width, H = info.height, C = info.channels
  const N = W * H
  const luma = new Float32Array(N)
  const chroma = new Float32Array(N)
  const hist = new Int32Array(256)
  for (let i = 0, p = 0; i < N; i++, p += C) {
    const r = data[p], g = data[p + 1], b = data[p + 2]
    const l = 0.299 * r + 0.587 * g + 0.114 * b
    luma[i] = l
    chroma[i] = Math.max(r, g, b) - Math.min(r, g, b)
    hist[Math.min(255, Math.round(l))]++
  }

  // ── L1 纸面统计 ──────────────────────────────────────────
  let acc = 0, brightThr = 200
  for (let t = 255; t >= 0; t--) { acc += hist[t]; if (acc >= N * 0.25) { brightThr = t; break } }
  let acc95 = 0, p95 = 235
  for (let t = 255; t >= 0; t--) { acc95 += hist[t]; if (acc95 >= N * 0.05) { p95 = t; break } }
  const brightL: number[] = [], brightC: number[] = []
  const step = Math.max(1, Math.floor(Math.sqrt(N / 200000)))
  for (let i = 0; i < N; i += step) if (luma[i] >= brightThr) { brightL.push(luma[i]); brightC.push(chroma[i]) }
  brightL.sort((a, b) => a - b); brightC.sort((a, b) => a - b)
  const medL = brightL[brightL.length >> 1] ?? 235
  const medC = brightC[brightC.length >> 1] ?? 0
  const madArr = brightC.map(c => Math.abs(c - medC)).sort((a, b) => a - b)
  const madC = (madArr[madArr.length >> 1] ?? 1) * 1.4826

  // Otsu（双峰平台取中点：二值化图上 0~255 全是最优解，取首个会得 T=0）
  let sum = 0; for (let t = 0; t < 256; t++) sum += t * hist[t]
  let sumB = 0, wB = 0, maxVar = 0
  const plateau: number[] = []
  for (let t = 0; t < 256; t++) {
    wB += hist[t]; if (!wB) continue
    const wF = N - wB; if (!wF) break
    sumB += t * hist[t]
    const mB = sumB / wB, mF = (sum - sumB) / wF
    const v = wB * wF * (mB - mF) ** 2
    if (v > maxVar * 1.0000001) { maxVar = v; plateau.length = 0; plateau.push(t) }
    else if (v >= maxVar * 0.9999999) plateau.push(t)
  }
  const otsuT = plateau.length ? plateau[plateau.length >> 1] : 127

  //  provisional 暗mask（Otsu）→ CC → charH/strokeW
  const dark = new Uint8Array(N)
  for (let i = 0; i < N; i++) dark[i] = luma[i] < otsuT ? 1 : 0
  const label = new Int32Array(N).fill(-1)
  const hHist = new Map<number, number>(), runHist = new Map<number, number>()
  let nCC = 0
  const stack: number[] = []
  for (let s = 0; s < N; s++) {
    if (!dark[s] || label[s] >= 0) continue
    let x0 = W, x1 = 0, y0 = H, y1 = 0, cnt = 0
    label[s] = nCC; stack.push(s)
    while (stack.length) {
      const q = stack.pop()!
      const qx = q % W, qy = (q / W) | 0
      if (qx < x0) x0 = qx; if (qx > x1) x1 = qx
      if (qy < y0) y0 = qy; if (qy > y1) y1 = qy
      cnt++
      const nb = [q - 1, q + 1, q - W, q + W]
      for (const u of nb) {
        if (u < 0 || u >= N || label[u] >= 0 || !dark[u]) continue
        if (Math.abs((u % W) - qx) > 1) continue
        label[u] = nCC; stack.push(u)
      }
    }
    const cw = x1 - x0 + 1, ch = y1 - y0 + 1
    // 字高候选：面积别太大(排除照片/大插图)、别太小(排除噪点)、宽高比合理
    if (ch >= 5 && ch <= 120 && cnt < N * 0.02 && cw / ch > 0.05 && cw / ch < 20)
      hHist.set(ch, (hHist.get(ch) ?? 0) + 1)
    nCC++
  }
  // 横向游程 → 笔画宽
  for (let y = 0; y < H; y += 2) {
    let run = 0
    for (let x = 0; x < W; x++) {
      if (dark[y * W + x]) run++
      else { if (run >= 1 && run <= 30) runHist.set(run, (runHist.get(run) ?? 0) + 1); run = 0 }
    }
  }
  const charH = mode(hHist, 5, 120) || 16
  const strokeW = mode(runHist, 1, 30) || 2

  // ── L2 局部统计（积分图 + Sauvola）────────────────────────
  const sauW = Math.max(15, Math.min(61, Math.round(charH * 2) | 1)) // 奇数窗口
  const iS = new Float64Array((W + 1) * (H + 1))
  const iS2 = new Float64Array((W + 1) * (H + 1))
  for (let y = 0; y < H; y++) {
    let rs = 0, rs2 = 0
    for (let x = 0; x < W; x++) {
      const v = luma[y * W + x]
      rs += v; rs2 += v * v
      const o = (y + 1) * (W + 1) + x + 1
      iS[o] = iS[o - W - 1] + rs
      iS2[o] = iS2[o - W - 1] + rs2
    }
  }
  const r = sauW >> 1
  const sauMask = new Uint8Array(N)
  const globMask = new Uint8Array(N)
  const globThr = p95 * 0.62 // 现行黑笔路径的比值
  let sauN = 0, globN = 0
  const K = 0.34, R = 128
  for (let y = 0; y < H; y++) {
    const ya = Math.max(0, y - r), yb = Math.min(H - 1, y + r)
    for (let x = 0; x < W; x++) {
      const i = y * W + x
      if (luma[i] < globThr) { globMask[i] = 1; globN++ }
      const xa = Math.max(0, x - r), xb = Math.min(W - 1, x + r)
      const A = ya * (W + 1) + xa, B = ya * (W + 1) + xb + 1
      const Cc = (yb + 1) * (W + 1) + xa, D = (yb + 1) * (W + 1) + xb + 1
      const n = (yb - ya + 1) * (xb - xa + 1)
      const m = (iS[D] - iS[B] - iS[Cc] + iS[A]) / n
      const m2 = (iS2[D] - iS2[B] - iS2[Cc] + iS2[A]) / n
      const s = Math.sqrt(Math.max(0, m2 - m * m))
      const T = m * (1 + K * (s / R - 1))
      if (luma[i] < T) { sauMask[i] = 1; sauN++ }
    }
  }

  // 大片深色连通域（照片/插图候选）内，两种判定各标记多少
  const seen = new Uint8Array(N)
  let blobPx = 0, blobG = 0, blobS = 0
  for (let s = 0; s < N; s++) {
    if (!dark[s] || seen[s]) continue
    const comp: number[] = []
    seen[s] = 1; stack.push(s)
    let x0 = W, x1 = 0, y0 = H, y1 = 0
    while (stack.length) {
      const q = stack.pop()!
      comp.push(q)
      const qx = q % W, qy = (q / W) | 0
      if (qx < x0) x0 = qx; if (qx > x1) x1 = qx
      if (qy < y0) y0 = qy; if (qy > y1) y1 = qy
      const nb = [q - 1, q + 1, q - W, q + W]
      for (const u of nb) {
        if (u < 0 || u >= N || seen[u] || !dark[u]) continue
        if (Math.abs((u % W) - qx) > 1) continue
        seen[u] = 1; stack.push(u)
      }
    }
    const bw = x1 - x0 + 1, bh = y1 - y0 + 1
    const fill = comp.length / (bw * bh)
    if (comp.length > 4000 && fill > 0.75) { // 致密大块 = 照片/插图
      blobPx += comp.length
      for (const q of comp) { if (globMask[q]) blobG++; if (sauMask[q]) blobS++ }
    }
  }

  // chromaMin=22 在纸面上的虚警率：亮部像素里 chromaExcess≥22 的比例（ppm）
  // —— 直接度量"固定彩度阈值在每张图的纸面噪声上会不会误报"
  let fpN = 0, brightN = 0
  for (let i = 0; i < N; i += step) {
    if (luma[i] < brightThr) continue
    brightN++
    if (chroma[i] - medC >= 22) fpN++
  }
  const chromaFPppm = brightN ? Math.round((fpN / brightN) * 1e6) : 0

  const pct = (n: number) => +((n / N) * 100).toFixed(2)
  return {
    tag, w: W, h: H,
    paperLuma: +medL.toFixed(1), p95, paperChroma: medC, chromaMAD: +madC.toFixed(1),
    otsuT, otsuInkPct: pct(dark.reduce((a, b) => a + b, 0)),
    charH, strokeW, nCC,
    sauvolaW: sauW,
    globalInkPct: pct(globN), sauvolaInkPct: pct(sauN),
    blobPx, blobByGlobal: blobG, blobBySauvola: blobS,
    r24_over_charH: (24 / charH).toFixed(2),
    chromaFPppm,
  }
}

async function main() {
const out: Stats[] = []
for (const c of CASES) {
  try { out.push(await analyze(c.file, c.tag)) }
  catch (e) { console.log(`✗ ${c.tag}: ${(e as Error).message}`) }
}

// G5 自检：所有数值必须有限
let sane = true
for (const s of out)
  for (const [k, v] of Object.entries(s))
    if (typeof v === 'number' && !Number.isFinite(v)) { console.log(`⚠️ 非有限值 ${s.tag}.${k}`); sane = false }

console.log('\n══ L1 纸面统计（每张图自己估计）══')
console.log('图型\t\t\tpaperLuma\tp95\tpaperChroma\tchromaMAD\tOtsuT\tOtsu墨%')
for (const s of out)
  console.log(`${s.tag.padEnd(12)}\t${s.paperLuma}\t\t${s.p95}\t${s.paperChroma}\t\t${s.chromaMAD}\t\t${s.otsuT}\t${s.otsuInkPct}%`)

console.log('\n══ L3 版面统计（连通域自举）══')
console.log('图型\t\t\tcharH众数\tstrokeW众数\t#CC\tR=24÷charH(语义漂移)')
for (const s of out)
  console.log(`${s.tag.padEnd(12)}\t${s.charH}px\t\t${s.strokeW}px\t\t${s.nCC}\t${s.r24_over_charH} 个字高`)

console.log('\n══ L2 全局 vs Sauvola 局部（窗口=2×charH）══')
console.log('图型\t\t\t窗口w\t全局0.62×p95墨%\tSauvola墨%\t照片块px\t全局误吞%\tSauvola误吞%')
for (const s of out) {
  const g = s.blobPx ? ((s.blobByGlobal / s.blobPx) * 100).toFixed(1) : '-'
  const v = s.blobPx ? ((s.blobBySauvola / s.blobPx) * 100).toFixed(1) : '-'
  console.log(`${s.tag.padEnd(12)}\t${s.sauvolaW}\t${s.globalInkPct}%\t\t${s.sauvolaInkPct}%\t\t${s.blobPx}\t\t${g}%\t\t${v}%`)
}

console.log('\n══ chromaMin=22 在纸面亮部的虚警率（ppm，越低越保守）══')
for (const s of out)
  console.log(`${s.tag.padEnd(12)}\t纸面彩度中位=${s.paperChroma} MAD=${s.chromaMAD}\t虚警=${s.chromaFPppm}ppm`)

console.log(`\nG5自检: ${sane ? '✓ 全部数值有限' : '✗ 存在非有限值'}`)
fs.writeFileSync('/workspace/push-ready/server/verify-out/adaptive-params.json', JSON.stringify(out, null, 2))
console.log('明细 → verify-out/adaptive-params.json')
}
main().catch(e => { console.error(e); process.exit(1) })
