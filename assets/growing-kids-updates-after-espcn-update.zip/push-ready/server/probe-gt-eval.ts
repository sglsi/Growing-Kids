/**
 * 独立真值评估探针（v21.3 验证口径修正的落地）。
 *
 * 真值来源：用户人工标注（红框=手写、蓝框=插图），仅用于验证，不参与设计/调参。
 * 评估对象：
 *   A) 现行结构判别器 discriminate()（B-2 影子版，无家具先验——裸基线）
 *   B) 现行生产 hybrid 掩码 buildHandwritingMask()（红笔先验路径）
 * 指标（框级）：
 *   手写框命中：框内被标记像素 / 框内墨迹像素 ≥0.5 记命中 → 报告命中率
 *   插图框误标：框内被标记墨迹像素占比（应≈0）
 * 运行：npx tsx probe-gt-eval.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminate } from './src/image/structural-discriminator'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
const WORK_MAX = 800

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

function boxInkStats(
  box: Box, flagged: Uint8Array, ink: Uint8Array, w: number,
): { inkN: number; hitN: number; share: number } {
  let inkN = 0, hitN = 0
  for (let y = box.y0; y <= Math.min(box.y1, /* clamp */ 1e9); y++) {
    for (let x = box.x0; x <= box.x1; x++) {
      const i = y * w + x
      if (!ink[i]) continue
      inkN++
      if (flagged[i]) hitN++
    }
  }
  return { inkN, hitN, share: inkN ? hitN / inkN : 0 }
}

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const summary: Record<string, unknown>[] = []

  for (const f of PAGES) {
    const buf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(buf).metadata()
    const W = meta.width!, H = meta.height!
    const s = WORK_MAX / Math.max(W, H)
    const w = Math.round(W * s), h = Math.round(H * s)

    // --- 墨迹（原图尺度，用作分母）：亮度 < 128 视为墨 ---
    const { data, info } = await sharp(buf).raw().toBuffer({ resolveWithObject: true })
    const ch = info.channels
    const ink = new Uint8Array(W * H)
    for (let i = 0; i < W * H; i++) {
      const lum = 0.299 * data[i * ch] + 0.587 * data[i * ch + 1] + 0.114 * data[i * ch + 2]
      if (lum < 128) ink[i] = 1
    }

    // --- A) 结构判别器（裸，无家具先验）---
    const ctx = await buildDocContext(buf, { width: W, height: H, isGray: false })
    const sres = discriminate({ ctx })
    // 把工作尺度 labels 放大回原图尺度
    const structFlag = new Uint8Array(W * H)
    for (let y = 0; y < h; y++) {
      const oy0 = Math.floor(y / s), oy1 = Math.min(H - 1, Math.floor((y + 1) / s))
      for (let x = 0; x < w; x++) {
        if (sres.labels[y * w + x] !== 1) continue
        const ox0 = Math.floor(x / s), ox1 = Math.min(W - 1, Math.floor((x + 1) / s))
        for (let oy = oy0; oy <= oy1; oy++) for (let ox = ox0; ox <= ox1; ox++) structFlag[oy * W + ox] = 1
      }
    }

    // --- B) 生产 hybrid（离线：禁 VLM）---
    let hybridFlag = new Uint8Array(W * H)
    try {
      const res = await buildHandwritingMask(buf, '', {}, { eraseMode: 'hybrid', allowVlm: false })
      const hm = res.mask
      if (hm.width === W && hm.height === H) {
        hybridFlag = new Uint8Array(hm.data.buffer, hm.data.byteOffset, W * H)
      } else {
        const rs = await sharp(hm.data, { raw: { width: hm.width, height: hm.height, channels: 1 } })
          .resize(W, H, { fit: 'fill' }).raw().toBuffer()
        hybridFlag = new Uint8Array(rs.buffer, rs.byteOffset, W * H)
      }
    } catch (e) {
      console.warn(`[${f}] hybrid 失败：${e instanceof Error ? e.message : e}`)
    }

    // --- 框级统计 ---
    const evalOne = (flag: Uint8Array, name: string) => {
      const hw = gt[f].filter((b) => b.cls === 'handwriting')
      const il = gt[f].filter((b) => b.cls === 'illustration')
      const am = gt[f].filter((b) => b.cls === 'ambiguous')
      const hwStats = hw.map((b) => ({ box: b, ...boxInkStats(b, flag, ink, W) }))
      const ilStats = il.map((b) => ({ box: b, ...boxInkStats(b, flag, ink, W) }))
      const hits = hwStats.filter((r) => r.share >= 0.5).length
      const hwRecall = hw.length ? hits / hw.length : 1
      const avgHwShare = hwStats.length ? hwStats.reduce((a, r) => a + r.share, 0) / hwStats.length : 0
      const worstIl = ilStats.reduce((a, r) => Math.max(a, r.share), 0)
      const ilFlagged = ilStats.filter((r) => r.share >= 0.3).length
      console.log(`  ${name}: 手写框命中 ${hits}/${hw.length} (avgShare=${avgHwShare.toFixed(2)}) | 插图框误标 ${ilFlagged}/${il.length} (worst=${worstIl.toFixed(2)})${am.length ? ` | 待复核框${am.length}个(不计分)` : ''}`)
      for (const r of hwStats) if (r.share < 0.5) console.log(`    [漏] 手写框 (${r.box.x0},${r.box.y0}) ${r.box.x1 - r.box.x0}x${r.box.y1 - r.box.y0} share=${r.share.toFixed(2)}`)
      for (const r of ilStats) if (r.share >= 0.3) console.log(`    [误] 插图框 (${r.box.x0},${r.box.y0}) ${r.box.x1 - r.box.x0}x${r.box.y1 - r.box.y0} share=${r.share.toFixed(2)}`)
      return { hits, hwN: hw.length, hwRecall: +hwRecall.toFixed(3), avgHwShare: +avgHwShare.toFixed(3), ilFlagged, ilN: il.length, worstIl: +worstIl.toFixed(3) }
    }

    console.log(`${f} (charH=${(sres.debug.charH as number)?.toFixed?.(1) ?? sres.debug.charH})`)
    const a = evalOne(structFlag, 'A结构判别器')
    const b = evalOne(hybridFlag, 'B生产hybrid')
    summary.push({ file: f, structural: a, hybrid: b })
  }
  fs.writeFileSync(`${DIR}/gt-eval-baseline.json`, JSON.stringify(summary, null, 2))
  console.log('saved gt-eval-baseline.json')
}
main().catch((e) => { console.error(e); process.exit(1) })
