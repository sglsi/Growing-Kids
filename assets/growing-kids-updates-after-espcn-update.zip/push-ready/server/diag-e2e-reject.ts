/**
 * 诊断：verify-manual-e2e 为何把「正确拒擦」报成 FAIL
 * 一次性打印：探针选的框 → regions → 后端 debug → 框内实际擦除数
 */
import * as fs from 'fs'
import sharp from 'sharp'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  const file = process.argv[2] ?? 'page30.png'
  const buf = fs.readFileSync(`/workspace/wrongq-test/${file}`)
  const { data: od, info } = await raw(buf)
  const w = info.width, h = info.height, n = w * h
  const luma = (p: number) => 0.299 * od[p * 3] + 0.587 * od[p * 3 + 1] + 0.114 * od[p * 3 + 2]

  const base = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
  const baseImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', base.mask), base.mask)
  const { data: baseNd } = await raw(baseImg)

  const diffs: number[] = []
  for (let k = 0; k < 1500; k++) {
    const p = Math.floor((k / 1500) * n)
    diffs.push(Math.max(
      Math.abs(od[p * 3] - baseNd[p * 3]),
      Math.abs(od[p * 3 + 1] - baseNd[p * 3 + 1]),
      Math.abs(od[p * 3 + 2] - baseNd[p * 3 + 2]),
    ))
  }
  diffs.sort((a, b) => a - b)
  const TH = Math.max(12, Math.min(40, diffs[Math.floor(diffs.length * 0.99)]))
  const changed = (d: Buffer, p: number) => {
    const i = p * 3
    return Math.abs(od[i] - d[i]) > TH || Math.abs(od[i + 1] - d[i + 1]) > TH || Math.abs(od[i + 2] - d[i + 2]) > TH
  }

  const ls: number[] = []
  for (let p = 0; p < n; p += 13) ls.push(luma(p))
  ls.sort((a, b) => a - b)
  const inkTh = ls[Math.floor(ls.length * 0.98)] - 45
  const BS = Math.max(24, Math.round(Math.min(w, h) * 0.05))

  let best: { x: number; y: number; ink: number } | null = null
  for (let by = 0; by + BS <= h; by += BS) {
    for (let bx = 0; bx + BS <= w; bx += BS) {
      let ink = 0, c = 0
      for (let y = by; y < by + BS; y++) {
        const b = y * w
        for (let x = bx; x < bx + BS; x++) {
          const p = b + x
          if (luma(p) < inkTh) ink++
          if (changed(baseNd, p)) c++
        }
      }
      if (ink > BS * BS * 0.02 && c === 0 && (!best || ink > best.ink)) best = { x: bx, y: by, ink }
    }
  }
  if (!best) { console.log('no best'); return }

  const regions = [{
    x: +(best.x / w).toFixed(4), y: +(best.y / h).toFixed(4),
    w: +(BS / w).toFixed(4), h: +(BS / h).toFixed(4),
  }]
  const man = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid', manualRects: regions })
  const manImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)
  const { data: manNd } = await raw(manImg)

  let before = 0, after = 0
  for (let y = best.y; y < best.y + BS; y++) {
    const b = y * w
    for (let x = best.x; x < best.x + BS; x++) {
      if (changed(baseNd, b + x)) before++
      if (changed(manNd, b + x)) after++
    }
  }

  console.log('RESULT ' + JSON.stringify({
    file, TH, BS,
    boxPx: `${best.x},${best.y} ${BS}x${BS}`,
    darkPx: best.ink,
    regions,
    debugManualRects: man.mask.debug?.manualRects,
    debugRejected: man.mask.debug?.manualRejected,
    debugRejectDetail: man.mask.debug?.manualRejectDetail,
    inRectBefore: before,
    inRectAfter: after,
    eraseInRect: after - before,
  }, null, 1))
}

main().catch((e) => { console.error(e); process.exit(1) })
