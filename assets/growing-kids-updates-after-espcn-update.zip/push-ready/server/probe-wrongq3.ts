/**
 * 错题区域提取 · 前期测试探针 v3
 *
 * v2 结论：行切分/分栏全灭的根因是【拍照背景污染】——纸张未占满画面，
 * 桌面被 Otsu 判为墨迹，四周连片堵死投影。
 *
 * v3 流程 = 设计文档阶段①的完整实现：
 *   straightenImage(auto 纸张检测+透视压平) → 度量 → 行切分 → 分栏 → 栏内行 → 悬挂缩进 → 红笔统计
 *   + 诊断图（压平图 + 红mask + 栏绿线 + 行蓝线），供人工目检。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import {
  normalizeIlluminationForDetection,
  maskFromColorThreshold,
} from './src/image/handwriting-mask'
import {
  otsuThreshold,
  connectedComponents,
  quantileSorted,
  estimateCharMetrics,
} from './src/image/image-layout'
import { segmentTextRows } from './src/image/handwriting-mask'
import { straightenImage } from './src/image/image-dewarp'

const IN_DIR = '/workspace/wrongq-test'

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const f of files) {
    try {
      await probePage(path.join(IN_DIR, f))
    } catch (e) {
      console.log(`GUARD {"file":"${f}","error":${JSON.stringify(String((e as Error)?.message ?? e))}}`)
    }
  }
}

function buildInk(data: Buffer, w: number, h: number, ch: number, excludeRedChroma = 0) {
  const n = w * h
  const gray = new Uint8Array(n)
  for (let i = 0, p = 0; i < n; i++, p += ch) {
    gray[i] = Math.max(0, Math.min(255, Math.round(0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2])))
  }
  const thr = otsuThreshold(gray, n)
  const ink = new Uint8Array(n)
  let redExcluded = 0
  for (let i = 0, p = 0; i < n; i++, p += ch) {
    if (gray[i] >= thr) continue
    if (excludeRedChroma > 0) {
      const r = data[p], g = data[p + 1], b = data[p + 2]
      if (Math.max(r, g, b) - Math.min(r, g, b) >= excludeRedChroma) { redExcluded++; continue }
    }
    ink[i] = 1
  }
  return { gray, ink, thr, redExcluded }
}

function findCols(ink: Uint8Array, w: number, h: number, colThRatio: number, gapMin: number) {
  const colProfile = new Int32Array(w)
  for (let y = 0; y < h; y++) {
    const base = y * w
    for (let x = 0; x < w; x++) if (ink[base + x]) colProfile[x]++
  }
  const colMax = Math.max(...colProfile)
  const colTh = Math.max(1, Math.round(colMax * colThRatio))
  const gaps: Array<[number, number]> = []
  let x = 0
  while (x < w) {
    if (colProfile[x] > colTh) { x++; continue }
    const x0 = x
    while (x < w && colProfile[x] <= colTh) x++
    if (x - x0 >= gapMin) gaps.push([x0, x])
  }
  const cols: Array<[number, number]> = []
  let cur = 0
  for (const [g0, g1] of gaps) {
    if (g0 > cur) cols.push([cur, g0])
    cur = g1
  }
  if (cur < w) cols.push([cur, w])
  return { gaps, cols }
}

function colRows(ink: Uint8Array, w: number, h: number, x0: number, x1: number) {
  const prof = new Int32Array(h)
  for (let y = 0; y < h; y++) {
    const base = y * w
    let c = 0
    for (let x = x0; x < x1; x++) if (ink[base + x]) c++
    prof[y] = c
  }
  const profMax = Math.max(...prof)
  const th = Math.max(1, Math.round(profMax * 0.04))
  const rows: Array<{ y0: number; y1: number; xLeft: number }> = []
  let y = 0
  while (y < h) {
    if (prof[y] < th) { y++; continue }
    const y0 = y
    while (y < h && prof[y] >= th) y++
    let xLeft = x1 - x0
    for (let yy = y0; yy < y && xLeft === x1 - x0; yy++) {
      const base = yy * w
      for (let x = x0; x < x1; x++) if (ink[base + x]) { xLeft = x - x0; break }
    }
    rows.push({ y0, y1: y, xLeft })
  }
  return rows
}

async function probePage(file: string) {
  const buf = fs.readFileSync(file)
  const meta = await sharp(buf).metadata()
  const W0 = meta.width || 0
  const H0 = meta.height || 0

  // ═══ 阶段①：纸张检测 + 透视压平（复用自动调正）═══
  const st = await straightenImage(buf, { auto: true, curved: false })
  const flatBuf = st.buffer ?? buf
  const flatMeta = await sharp(flatBuf).metadata()
  const fw = flatMeta.width || 0
  const fh = flatMeta.height || 0

  // 压平图上的度量
  const flatMetrics = await estimateCharMetrics(flatBuf, {})

  const { data, info } = await sharp(flatBuf)
    .removeAlpha()
    .toColourspace('srgb')
    .raw()
    .toBuffer({ resolveWithObject: true })
  const w = info.width
  const h = info.height
  const ch = info.channels
  const n = w * h

  // ═══ 行切分（压平后）═══
  const { ink, thr, redExcluded } = buildInk(data, w, h, ch, 22)
  const seg = segmentTextRows(ink, w, h, { rowProfileRatio: 0.05 })
  const rowHeights = seg.rows.map((r) => r.y1 - r.y0).sort((a, b) => a - b)
  const medHup = rowHeights.length ? quantileSorted(rowHeights, 0.4) : Math.max(8, Math.round(h * 0.012))

  // ═══ 分栏（扣红笔）═══
  const { ink: inkNoRed, redExcluded: redEx2 } = buildInk(data, w, h, ch, 22)
  void redExcluded
  const gapMin = Math.max(4, Math.round(medHup * 0.5))
  const { gaps, cols } = findCols(inkNoRed, w, h, 0.01, gapMin)
  const realCols = cols.filter(([a, b]) => b - a >= medHup * 6)

  // ═══ 每栏：行切分 + 悬挂缩进 ═══
  const colDetail = realCols.map(([a, b], i) => {
    const rows = colRows(inkNoRed, w, h, a, b)
    const merged: Array<{ y0: number; y1: number; xLeft: number }> = []
    for (const r of rows) {
      const last = merged[merged.length - 1]
      if (last && r.y0 - last.y1 <= medHup * 0.5) {
        last.y1 = r.y1
        last.xLeft = Math.min(last.xLeft, r.xLeft)
      } else merged.push({ ...r })
    }
    const xs = merged.map((r) => r.xLeft).sort((p, q2) => p - q2)
    const clusters: Array<{ sum: number; count: number }> = []
    for (const x of xs) {
      const last = clusters[clusters.length - 1]
      if (last && x - last.sum / last.count <= medHup * 0.6) { last.sum += x; last.count++ }
      else clusters.push({ sum: x, count: 1 })
    }
    const cl = clusters
      .map((c) => ({ center: Math.round(c.sum / c.count), count: c.count }))
      .sort((p, q2) => q2.count - p.count)
      .slice(0, 6)
    const hs = merged.map((r) => r.y1 - r.y0).sort((p, q2) => p - q2)
    return {
      col: i + 1,
      x: [a, b],
      rows: merged.length,
      rowH: { p25: quantileSorted(hs, 0.25), p50: quantileSorted(hs, 0.5), p75: quantileSorted(hs, 0.75) },
      xLeftClusters: cl,
      topFlushShare: cl.length ? +(cl[0].count / Math.max(1, merged.length)).toFixed(2) : 0,
    }
  })

  // ═══ 红笔统计（压平图）═══
  const cm = await maskFromColorThreshold(flatBuf, {})
  const mInk = new Uint8Array(n)
  for (let i = 0; i < n; i++) mInk[i] = cm.data[i] ? 1 : 0
  const { comps } = connectedComponents(mInk, w, h, false)
  const marks = comps.filter((c) => c.n >= Math.max(8, Math.round(medHup * 0.3)))
  const ars = marks.map((c) => (c.x1 - c.x0 + 1) / Math.max(1, c.y1 - c.y0 + 1)).sort((a, b) => a - b)
  const fills = marks
    .map((c) => c.n / Math.max(1, (c.x1 - c.x0 + 1) * (c.y1 - c.y0 + 1)))
    .sort((a, b) => a - b)
  const areas = marks.map((c) => c.n).sort((a, b) => a - b)

  // ═══ 诊断图：压平底图 + 红mask + 栏绿线 + 栏行蓝线 ═══
  const dw = 900
  const dh = Math.round((h / w) * dw)
  const baseRgb = await sharp(flatBuf).resize(dw, dh, { fit: 'fill' }).grayscale().removeAlpha().raw().toBuffer()
  const out = Buffer.alloc(dw * dh * 3)
  for (let i = 0, q3 = 0; i < dw * dh; i++, q3 += 3) {
    const g = baseRgb[i]
    out[q3] = g; out[q3 + 1] = g; out[q3 + 2] = g
  }
  const sx = dw / w
  const sy = dh / h
  const put = (x: number, y: number, r: number, g: number, b: number) => {
    if (x < 0 || y < 0 || x >= dw || y >= dh) return
    const q3 = (y * dw + x) * 3
    out[q3] = r; out[q3 + 1] = g; out[q3 + 2] = b
  }
  for (let y = 0; y < dh; y++) {
    const my = Math.min(h - 1, Math.round(y / sy))
    for (let x = 0; x < dw; x++) {
      const mx = Math.min(w - 1, Math.round(x / sx))
      if (mInk[my * w + mx]) put(x, y, 255, 30, 30)
    }
  }
  for (const [g0, g1] of gaps) {
    for (const gx of [g0, g1]) {
      const dx = Math.round(gx * sx)
      for (let y = 0; y < dh; y++) put(dx, y, 0, 200, 0)
    }
  }
  for (const cd of colDetail) {
    const rows2 = colRows(inkNoRed, w, h, cd.x[0], cd.x[1])
    for (const r of rows2) {
      const dy = Math.round(r.y0 * sy)
      for (let x = Math.round(cd.x[0] * sx); x <= Math.round(cd.x[1] * sx); x += 2) put(x, dy, 40, 120, 255)
    }
  }
  const diagName = path.join(IN_DIR, 'diag3-' + path.basename(file))
  await sharp(out, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(diagName)

  const q = (a: number[], p: number) => (a.length ? +quantileSorted(a, p).toFixed(2) : 0)
  console.log(
    'GUARD ' +
      JSON.stringify({
        file: path.basename(file),
        straighten: {
          ok: !!st.buffer,
          method: st.method,
          needManual: st.needManual,
          conf: st.confidence != null ? +st.confidence.toFixed(2) : null,
          size: `${fw}x${fh}`,
        },
        flatMetrics: {
          medH: +flatMetrics.medH.toFixed(1),
          rowPitch: +flatMetrics.rowPitch.toFixed(1),
          confidence: +flatMetrics.confidence.toFixed(2),
        },
        rows: {
          count: seg.rows.length,
          glyphH: seg.glyphH,
          rowH: { p25: q(rowHeights, 0.25), p50: q(rowHeights, 0.5), p90: q(rowHeights, 0.9) },
          medH_est_p40: medHup,
          otsu: thr,
        },
        columns: { gapCount: gaps.length, colCount: realCols.length, ranges: realCols, redExcluded: redEx2 },
        colDetail,
        redMask: {
          coverage: +cm.coverage.toFixed(4),
          marks: marks.length,
          area: { p50: q(areas, 0.5), p90: q(areas, 0.9), max: areas[areas.length - 1] ?? 0 },
          aspect: { p10: q(ars, 0.1), p50: q(ars, 0.5), p90: q(ars, 0.9) },
          fill: { p10: q(fills, 0.1), p50: q(fills, 0.5), p90: q(fills, 0.9) },
        },
        diag: path.basename(diagName),
      }),
  )
}

main().catch((e) => {
  console.error('PROBE FAILED:', e)
  process.exit(1)
})
