/**
 * 探针：buildLocalBackgroundMap 里 mask 下采样为什么全是 hole=0？
 * 逐步打印 maskBuf / maskSmall 的值分布。
 */
import sharp from '/workspace/push-ready/server/node_modules/sharp'
import { buildHandwritingMask } from '/workspace/push-ready/server/src/image/handwriting-segmenter'
import { alignMask } from '/workspace/push-ready/server/src/image/handwriting-mask'

const PATH = '/root/uploads/1790697352956629135-1790697330026-hq5z96hx-9e12369282df0f327502a0364da8ea20.jpg'
const BOX = { x: 30, y: 1225, w: 950, h: 480 }

function dist(buf: Buffer | Uint8Array, label: string) {
  let mn = 255, mx = 0, sum = 0, gt76 = 0
  for (let i = 0; i < buf.length; i++) {
    const v = buf[i]
    if (v < mn) mn = v
    if (v > mx) mx = v
    sum += v
    if (v > 76) gt76++
  }
  console.log(`  ${label}: len=${buf.length} min=${mn} max=${mx} mean=${(sum / buf.length).toFixed(1)} >76占比=${((gt76 / buf.length) * 100).toFixed(1)}%`)
}

async function main() {
  const src = await sharp(PATH).rotate().png().toBuffer()
  const meta = await sharp(src).metadata()
  const W = meta.width!, H = meta.height!
  const manual = [{ x: BOX.x / W, y: BOX.y / H, w: BOX.w / W, h: BOX.h / H }]
  const seg = await buildHandwritingMask(src, '', {}, { allowVlm: false, manualRects: manual })
  const mask = seg.mask
  console.log(`mask: ${mask.width}x${mask.height} coverage=${(mask.coverage * 100).toFixed(2)}% source=${mask.source}`)
  dist(mask.data, 'mask.data')

  const maskBuf = await alignMask(mask, W, H)
  dist(maskBuf, 'alignMask')

  const WORK = 640
  const scale = Math.min(1, WORK / Math.max(W, H))
  const w = Math.max(8, Math.round(W * scale))
  const h = Math.max(8, Math.round(H * scale))
  console.log(`下采样目标 ${w}x${h} (scale=${scale.toFixed(3)})`)

  const maskSmall = await sharp(Buffer.from(maskBuf), { raw: { width: W, height: H, channels: 1 } })
    .resize(w, h, { fit: 'fill' })
    .raw()
    .toBuffer()
  dist(maskSmall, 'maskSmall')

  // 再试 png 中间格式（排查 raw→resize 的通道问题）
  const viaPng = await sharp(Buffer.from(maskBuf), { raw: { width: W, height: H, channels: 1 } })
    .png()
    .resize(w, h, { fit: 'fill' })
    .toColourspace('b-w')
    .raw()
    .toBuffer()
  dist(viaPng, 'maskSmall(via png)')

  // 打印 maskSmall 在框内位置的取样值
  const sx = Math.round(BOX.x * scale), sy = Math.round(BOX.y * scale)
  console.log(`\n框在 small 坐标: x=${sx}..${sx + Math.round(BOX.w * scale)}, y=${sy}..${sy + Math.round(BOX.h * scale)}`)
  for (const [xx, yy] of [[sx + 20, sy + 20], [Math.round(w / 2), sy + 80], [Math.round(w / 2), Math.min(h - 5, sy + 150)], [5, 5]] as const) {
    console.log(`  maskSmall(${xx},${yy}) = ${maskSmall[yy * w + xx]}`)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
