import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { maskFromColorThreshold, inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'
async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}
async function main() {
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(path.join(IN_DIR, file))
    const { info } = await raw(buf)
    const w = info.width, h = info.height
    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    let penTotal = 0
    for (let i = 0; i < w * h; i++) if (redO.data[i]) penTotal++
    const out: Record<string, unknown> = { file, redTotal: penTotal }
    for (const mode of ['color', 'union'] as const) {
      const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: mode })
      const rep = await inpaint(buf, 'adaptive', seg.mask)
      const o = await blendWithMask(buf, rep, seg.mask)
      const redN = await maskFromColorThreshold(o, { chromaMin: 14 })
      let still = 0
      for (let i = 0; i < w * h; i++) if (redO.data[i] && redN.data[i]) still++
      out[mode + 'RedRemoval'] = +(1 - still / Math.max(1, penTotal)).toFixed(4)
      out[mode + 'Cov'] = +seg.mask.coverage.toFixed(4)
    }
    console.log('GUARD ' + JSON.stringify(out))
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
