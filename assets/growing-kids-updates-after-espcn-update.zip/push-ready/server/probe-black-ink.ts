/**
 * 「黑笔为什么擦不掉」诊断探针（英语灰报 4 张）
 * ============================================================
 * 事实基础：这 4 张当前走的是 eraseMode:'color' 分支，该分支**只跑色域通道**，
 *          maskFromDarkInk 根本不会被调用；黑笔 chroma≈0 → 设计上不可见。
 *
 * 本探针回答四个问题：
 *   Q1 color 模式（现状）到底擦掉了多少"黑笔候选"？
 *   Q2 若切 union 模式，深色通道在这 4 张上产出多少？行级判据把多少行拦掉了？
 *   Q3 union 模式会不会"整页全擦"（把报纸正文一起吞）？
 *   Q4 union 与 color 的差集有多大？即"仅靠切模式"能多擦掉多少黑笔？
 *
 * ⚠️ 「黑笔候选」是代理真值，不是人工标注：
 *    教师红笔画在黑笔答案上（叉/圈/波浪线），两者空间强相关，
 *    故取「红笔 mask 外扩 24px 内、且 chroma<14 的暗像素」作为黑笔候选。
 *    该代理会掺入少量被红笔压住的印刷字，故只用于**量级比较**，不当作精确 GT。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import {
  maskFromColorThreshold,
  maskFromDarkInk,
  normalizeIlluminationForDetection,
} from './src/image/handwriting-mask'
import { estimateCharMetrics } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'

async function rawPixels(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

function lumaOf(d: Buffer, p: number) {
  return 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
}

/** 矩形膨胀（半径 r），返回 Uint8Array 邻域掩码 */
function dilateRect(src: Uint8Array, w: number, h: number, r: number) {
  const out = new Uint8Array(w * h)
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (!src[y * w + x]) continue
      const y0 = Math.max(0, y - r), y1 = Math.min(h - 1, y + r)
      const x0 = Math.max(0, x - r), x1 = Math.min(w - 1, x + r)
      for (let yy = y0; yy <= y1; yy++) for (let xx = x0; xx <= x1; xx++) out[yy * w + xx] = 1
    }
  }
  return out
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const file of files) {
    try {
      const buf = fs.readFileSync(path.join(IN_DIR, file))
      const { info } = await rawPixels(buf)
      const w = info.width, h = info.height, ch = info.channels
      const o = await rawPixels(buf)
      const od = o.data
      const m = await estimateCharMetrics(buf, {})
      const prior = w / 70
      const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, m.medH > 0 ? m.medH : prior))

      const pre = await normalizeIlluminationForDetection(buf)
      const detectBuf = pre.buffer

      // ── 各通道 mask ─────────────────────────────────────
      const colorMask = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'color' })
      const unionMask = await buildHandwritingMask(buf, '', {}, { allowVlm: false })
      const darkMask = await maskFromDarkInk(detectBuf)
      const chromaMask = await maskFromColorThreshold(detectBuf)

      // ── 黑笔候选（代理真值）──────────────────────────────
      const redThin = await maskFromColorThreshold(detectBuf, { chromaMin: 14 })
      const redNear = dilateRect(redThin.data, w, h, 24)
      const lumas: number[] = []
      for (let i = 0; i < w * h; i += 37) lumas.push(lumaOf(od, i * ch))
      lumas.sort((a, b) => a - b)
      const paper = lumas[Math.floor(lumas.length * 0.9)] ?? 240
      const darkTh = paper * 0.62

      const penCand = new Uint8Array(w * h)   // 黑笔候选
      const printPix = new Uint8Array(w * h)  // 全页印刷（低彩度暗像素）
      for (let i = 0; i < w * h; i++) {
        const p = i * ch
        const c = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
        const lo = lumaOf(od, p)
        if (c >= 14 || lo >= darkTh) continue
        printPix[i] = 1
        if (redNear[i]) penCand[i] = 1
      }
      const cnt = (a: Uint8Array) => { let n = 0; for (let i = 0; i < a.length; i++) if (a[i]) n++; return n }
      const inter = (a: Uint8Array, b: Uint8Array) => { let n = 0; for (let i = 0; i < a.length; i++) if (a[i] && b[i]) n++; return n }
      const penTotal = cnt(penCand)
      const printTotal = cnt(printPix)

      // ── 深色通道行级判据统计 ────────────────────────────
      const dd = (darkMask.debug ?? {}) as Record<string, unknown>
      const rowsDetail = Array.isArray(dd.rowsDetail) ? (dd.rowsDetail as Array<Record<string, unknown>>) : []
      const blocked: Record<string, number> = {}
      for (const r of rowsDetail) {
        const b = String(r.blocked ?? 'none')
        blocked[b] = (blocked[b] ?? 0) + 1
      }
      const noBlock = rowsDetail.filter((r) => !r.blocked).length

      console.log('GUARD ' + JSON.stringify({
        file,
        size: `${w}x${h}`,
        medH: +medH.toFixed(1),
        paperLuma: +paper.toFixed(0),
        // 各通道 mask 覆盖率
        cov: {
          colorCurrent: +colorMask.mask.coverage.toFixed(4),
          union: +unionMask.mask.coverage.toFixed(4),
          darkChannel: +darkMask.coverage.toFixed(4),
          chromaDefault22: +chromaMask.coverage.toFixed(4),
        },
        // 深色通道行级判据
        darkRows: {
          total: rowsDetail.length,
          blockedShort: blocked.short ?? 0,
          blockedBaseline: blocked.baseline ?? 0,
          blockedDensity: blocked.density ?? 0,
          passed: noBlock,
          reason: dd.reason ?? null,
        },
        unionDebug: Object.fromEntries(
          Object.entries((unionMask.debug ?? {}) as Record<string, unknown>)
            .filter(([k]) => /mode|reason|Coverage|share|print/i.test(k))
            .slice(0, 12),
        ),
        // Q1/Q4：黑笔候选被各 mask 覆盖
        penCandidatePx: penTotal,
        penCoveredByColor: +inter(penCand, colorMask.mask.data).toFixed(0),
        penCoveredByUnion: inter(penCand, unionMask.mask.data),
        penCoveredByDarkOnly: inter(penCand, darkMask.data),
        // Q3：union 把多少"印刷暗像素"圈进来了（误删风险上限）
        printTotalPx: printTotal,
        printInUnion: inter(printPix, unionMask.mask.data),
        printInColor: inter(printPix, colorMask.mask.data),
      }))
    } catch (e) {
      console.log(`GUARD {"file":"${file}","error":${JSON.stringify(String((e as Error)?.message ?? e).slice(0, 250))}}`)
    }
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
