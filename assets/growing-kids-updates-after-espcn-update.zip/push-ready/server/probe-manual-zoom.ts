/**
 * G3 目检取证：把 verify-manual-e2e 选的框裁出来放大，orig/base/after 三联
 * ⭐ 用途：抓「验收数字全绿但整块图被涂掉」这类盲区。
 *   触发原因：page28/auto 的 darkPx=2601 == BS²(2601)，即整框全暗，
 *   且擦除量也 == 2601（100% 全擦）。midRatio=0% 会被我的判据当成"纯文字"，
 *   但「整体暗、无中间调的照片/深色块」midRatio 同样是 0 —— 判据漏洞。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'
const OUT_DIR = '/workspace/v20-框选E2E/zoom'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

/** 从 E2E 的 RESULT 里读框坐标（复现同样的选框逻辑） */
async function pickBox(buf: Buffer, tag: 'auto' | 'text') {
  const { data: od, info } = await raw(buf)
  const w = info.width, h = info.height, n = w * h
  const luma = (p: number) => 0.299 * od[p * 3] + 0.587 * od[p * 3 + 1] + 0.114 * od[p * 3 + 2]

  const base = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
  const baseImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', base.mask), base.mask)
  const { data: baseNd } = await raw(baseImg)

  const diffs: number[] = []
  for (let k = 0; k < 1500; k++) {
    const p = Math.floor((k / 1500) * n)
    diffs.push(Math.max(
      Math.abs(od[p * 3] - baseNd[p * 3]),
      Math.abs(od[p * 3 + 1] - baseNd[p * 3 + 1]),
      Math.abs(od[p * 3 + 2] - baseNd[p * 3 + 2]),
    ))
  }
  diffs.sort((a, b) => a - b)
  const TH = Math.max(12, Math.min(40, diffs[Math.floor(diffs.length * 0.99)]))
  const changed = (d: Buffer, p: number) => {
    const i = p * 3
    return Math.abs(od[i] - d[i]) > TH || Math.abs(od[i + 1] - d[i + 1]) > TH || Math.abs(od[i + 2] - d[i + 2]) > TH
  }

  const BS = Math.max(24, Math.round(Math.min(w, h) * 0.05))
  const ls: number[] = []
  for (let p = 0; p < n; p += 13) ls.push(luma(p))
  ls.sort((a, b) => a - b)
  const inkTh = ls[Math.floor(ls.length * 0.98)] - 45
  const paperL = ls[Math.floor(ls.length * 0.98)]

  const midRatioOf = (bx: number, by: number) => {
    let mid = 0, tot = 0
    for (let y = by; y < by + BS; y++) {
      const b = y * w
      for (let x = bx; x < bx + BS; x++) {
        const v = Math.round(luma(b + x))
        if (v >= paperL - 70 && v <= paperL - 20) mid++
        tot++
      }
    }
    return tot ? mid / tot : 1
  }

  let best: any = null, bestText: any = null
  for (let by = 0; by + BS <= h; by += BS) {
    for (let bx = 0; bx + BS <= w; bx += BS) {
      let ink = 0, chg = 0
      for (let y = by; y < by + BS; y++) {
        const b = y * w
        for (let x = bx; x < bx + BS; x++) {
          const p = b + x
          if (luma(p) < inkTh) ink++
          if (changed(baseNd, p)) chg++
        }
      }
      if (ink > BS * BS * 0.02 && chg === 0) {
        if (!best || ink > best.ink) best = { x: bx, y: by, ink }
        const mid = midRatioOf(bx, by)
        if (!bestText || mid < bestText.mid) bestText = { x: bx, y: by, ink, mid }
      }
    }
  }
  if (tag === 'text' && bestText && (bestText.x !== best?.x || bestText.y !== best?.y)) return { box: bestText, BS, baseImg, TH, paperL, od, info }
  return { box: best, BS, baseImg, TH, paperL, od, info }
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const files = process.argv[2] ? [process.argv[2]] : ['page28.png']
  const ZOOM = 8

  for (const file of files) {
const buf = fs.readFileSync(`${IN_DIR}/${file}`)
      const meta0 = await sharp(buf).metadata()
      for (const tag of ['auto', 'text'] as const) {
      const { box, BS, baseImg } = await pickBox(buf, tag)
      if (!box) { console.error(`[${file}/${tag}] 无候选框`); continue }

      const regions = [{
        x: +(box.x / meta0.width!).toFixed(4),
        y: +(box.y / meta0.height!).toFixed(4),
        w: +(BS / meta0.width!).toFixed(4),
        h: +(BS / meta0.height!).toFixed(4),
      }]
      // ⚠️ 自检：坐标必须有限且在图内。本探针初版写了 `box.x / 0 + box.x/w`
      //   → Infinity → 框被 clamp 丢弃 → 三联图三个面板看起来一样，
      //   我差点据此误判"照片没被毁"。**探针自身的错会让验证结论完全无效**，
      //   与 E8 门禁"报通过时必须确认被测对象真的变了"同源。
      for (const r of [regions[0]]) {
        if (!Number.isFinite(r.x) || !Number.isFinite(r.y) || r.x < 0 || r.y < 0 ||
          r.x + r.w > 1.001 || r.y + r.h > 1.001) {
          throw new Error(`regions 非法：${JSON.stringify(r)} —— 探针有 bug，不要相信输出`)
        }
      }
      const man = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid', manualRects: regions })
      const manImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)

      // 裁剪 + 放大
      const pad = Math.round(BS * 0.6)
      const cx = box.x - pad, cy = box.y - pad
      const size = BS + pad * 2
      const meta = await sharp(buf).metadata()
      const left = Math.max(0, Math.min(meta.width! - size, cx))
      const top = Math.max(0, Math.min(meta.height! - size, cy))
      const cw = Math.min(size, meta.width! - left), ch = Math.min(size, meta.height! - top)

      const panels: sharp.Sharp[] = []
      for (const [lbl, src] of [['orig', buf], ['base', baseImg], ['after', manImg]] as const) {
        const cut = await sharp(src).extract({ left, top, width: cw, height: ch })
          .resize({ width: cw * ZOOM, kernel: 'nearest' }).png().toBuffer()
        panels.push(sharp(cut))
      }
      const W = cw * ZOOM, H = ch * ZOOM
      const merged = await sharp({
        create: { width: W, height: H * 3 + 24 * 3, channels: 3, background: { r: 255, g: 0, b: 255 } },
      }).composite([
        { input: await panels[0].toBuffer(), left: 0, top: 0 },
        { input: await panels[1].toBuffer(), left: 0, top: H + 24 },
        { input: await panels[2].toBuffer(), left: 0, top: (H + 24) * 2 },
        {
          input: Buffer.from(
            `<svg width="${W}" height="${H}"><rect x="${(box.x - left) * ZOOM}" y="${(box.y - top) * ZOOM}" ` +
            `width="${BS * ZOOM}" height="${BS * ZOOM}" fill="none" stroke="#00ff00" stroke-width="3"/></svg>`,
          ), left: 0, top: 0,
        },
        {
          input: Buffer.from(
            `<svg width="${W}" height="${H}"><rect x="${(box.x - left) * ZOOM}" y="${(box.y - top) * ZOOM}" ` +
            `width="${BS * ZOOM}" height="${BS * ZOOM}" fill="none" stroke="#00ff00" stroke-width="3"/></svg>`,
          ), left: 0, top: H + 24,
        },
        {
          input: Buffer.from(
            `<svg width="${W}" height="${H}"><rect x="${(box.x - left) * ZOOM}" y="${(box.y - top) * ZOOM}" ` +
            `width="${BS * ZOOM}" height="${BS * ZOOM}" fill="none" stroke="#00ff00" stroke-width="3"/></svg>`,
          ), left: 0, top: (H + 24) * 2,
        },
        {
          input: Buffer.from(
            `<svg width="600" height="${H * 3 + 72}">` +
            `<rect width="600" height="${H * 3 + 72}" fill="none"/>` +
            `<text x="8" y="${H - 8}" font-size="20" fill="#000">1. orig (绿框=用户框选区)</text>` +
            `<text x="8" y="${H + 24 + H - 8}" font-size="20" fill="#000">2. base 自动擦除后</text>` +
            `<text x="8" y="${(H + 24) * 2 + H - 8}" font-size="20" fill="#000">3. after 框选补擦后</text>` +
            `</svg>`,
          ), left: 0, top: 0,
        },
      ]).png().toBuffer()

      const out = `${OUT_DIR}/${file.replace('.png', '')}-${tag}-zoom.png`
      fs.writeFileSync(out, merged)
      const dbg = (man.mask.debug ?? {}) as Record<string, unknown>
      console.error(
        `[${file}/${tag}] ${out} 框=${box.x},${box.y} ${BS}x${BS} darkPx=${box.ink}/${BS * BS}` +
        ` midRatio=${((box.mid ?? 0) * 100).toFixed(0)}% 并入=${dbg.manualRects ?? '-'} 拒=${dbg.manualRejected ?? '-'}` +
        ` 放大${ZOOM}倍`,
      )
    }
  }
}

main().catch((e) => { console.error(e); process.exit(1) })