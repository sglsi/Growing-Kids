/**
 * 重阴影卷 v16 量化：检测覆盖 + 擦除后残留墨量（程序化，不读取图像本体）。
 * 复用生产三通道 union（与 buildHandwritingMask 内部一致），跑 inpaint+blend，
 * 统计各 HW 带与 PRINT 带：① 检测掩膜像素 ② 擦前暗墨px ③ 擦后暗墨px ④ 残留率%。
 */
import sharp from '/workspace/push-ready/server/node_modules/sharp'
import {
  normalizeIlluminationForDetection,
  maskFromColorThreshold,
  maskFromDarkInk,
  maskFromLayoutSlots,
  inpaintAdaptive,
  blendWithMask,
} from '/workspace/push-ready/server/src/image/handwriting-mask'

const SRC = '/root/uploads/1790775669972607783-1790775610826-cef9cqop-951fcd4d65880246844be84a18932803.jpg'
const DARK = 150

const BANDS: Record<string, [number, number, number, number, 'HW' | 'PRINT' | 'GRAPHIC']> = {
  '16题填空手写': [0.66, 0.88, 0.042, 0.088, 'HW'],
  '23题(1)填空手写': [0.13, 0.32, 0.362, 0.402, 'HW'],
  '23题(2)填空手写': [0.32, 0.50, 0.418, 0.462, 'HW'],
  '底部手写解答区': [0.02, 0.80, 0.775, 0.99, 'HW'],
  '23题题干行A(印刷)': [0.02, 0.98, 0.305, 0.336, 'PRINT'],
  '23题题干行B(印刷)': [0.02, 0.98, 0.474, 0.508, 'PRINT'],
  '图1区域(图形)': [0.13, 0.38, 0.60, 0.77, 'GRAPHIC'],
}

async function main() {
  const src = await sharp(SRC).rotate().png().toBuffer()
  const pre = await normalizeIlluminationForDetection(src)
  const meta = await sharp(pre.buffer).metadata()
  const W = meta.width!, H = meta.height!
  console.log(`尺寸 ${W}x${H}`)

  const chroma = await maskFromColorThreshold(pre.buffer)
  const dark = await maskFromDarkInk(pre.buffer)
  const layout = await maskFromLayoutSlots(pre.buffer)

  const mkUnion = (): Buffer => {
    const u = Buffer.alloc(W * H)
    for (let i = 0; i < W * H; i++) u[i] = (chroma.data[i] > 127 || dark.data[i] > 127 || layout.data[i] > 127) ? 255 : 0
    return u
  }
  const union = mkUnion()
  const maskLike = { width: W, height: H, data: union, coverage: 0, source: 'union' as const }

  const repaired = await inpaintAdaptive(pre.buffer, maskLike as never)
  const erased = await blendWithMask(pre.buffer, repaired, maskLike as never)

  const grayPre = await sharp(pre.buffer).grayscale().raw().toBuffer()
  const grayErased = await sharp(erased).grayscale().raw().toBuffer()

  const countMask = (x0: number, x1: number, y0: number, y1: number, which?: 'dark' | 'chroma' | 'layout') => {
    let c = 0
    const src = which === 'dark' ? dark.data : which === 'chroma' ? chroma.data : which === 'layout' ? layout.data : union
    for (let y = Math.round(y0 * H); y < Math.round(y1 * H); y++)
      for (let x = Math.round(x0 * W); x < Math.round(x1 * W); x++) if (src[y * W + x] > 127) c++
    return c
  }
  // 仅在检测掩膜覆盖范围内统计墨量（隔离"擦除质量"，排除带内印刷/图形干扰）
  const countInkInMask = (buf: Buffer, x0: number, x1: number, y0: number, y1: number) => {
    let c = 0
    for (let y = Math.round(y0 * H); y < Math.round(y1 * H); y++)
      for (let x = Math.round(x0 * W); x < Math.round(x1 * W); x++)
        if (union[y * W + x] > 127 && buf[y * W + x] < DARK) c++
    return c
  }

  console.log('\n【A】三通道检测掩膜像素（分带；dark 单列看误报）')
  console.log('区域                  | 类型   | dark   | chroma | layout | 并集')
  console.log('---|---|---|---|---|---')
  for (const [name, [x0, x1, y0, y1, kind]] of Object.entries(BANDS)) {
    const d = countMask(x0, x1, y0, y1, 'dark')
    const c = countMask(x0, x1, y0, y1, 'chroma')
    const l = countMask(x0, x1, y0, y1, 'layout')
    const u = countMask(x0, x1, y0, y1)
    console.log(`${name.padEnd(20)} | ${kind.padEnd(6)} | ${String(d).padStart(6)} | ${String(c).padStart(6)} | ${String(l).padStart(6)} | ${String(u).padStart(6)}`)
  }

  console.log('\n【B】掩膜范围内擦除质量（擦前vs擦后暗墨px，越低越好）')
  console.log('区域                  | 类型   | 掩膜内擦前墨 | 掩膜内擦后墨 | 残留率')
  console.log('---|---|---|---|---')
  for (const [name, [x0, x1, y0, y1, kind]] of Object.entries(BANDS)) {
    const i0 = countInkInMask(grayPre, x0, x1, y0, y1)
    const i1 = countInkInMask(grayErased, x0, x1, y0, y1)
    const rr = i0 ? ((i1 / i0) * 100).toFixed(1) : '-'
    console.log(`${name.padEnd(20)} | ${kind.padEnd(6)} | ${String(i0).padStart(10)} | ${String(i1).padStart(10)} | ${rr}%`)
  }
  console.log(`\n整体 coverage: chroma=${(chroma.coverage * 100).toFixed(2)}% dark=${(dark.coverage * 100).toFixed(2)}% layout=${(layout.coverage * 100).toFixed(2)}%`)

  // 机器可读汇总（供 task-guard 解析；不改变人类可读输出）
  const d = (b: keyof typeof BANDS) => countMask(...(BANDS[b].slice(0, 4) as [number, number, number, number]), 'dark')
  const i0 = (b: keyof typeof BANDS) => countInkInMask(grayPre, ...(BANDS[b].slice(0, 4) as [number, number, number, number]))
  const i1 = (b: keyof typeof BANDS) => countInkInMask(grayErased, ...(BANDS[b].slice(0, 4) as [number, number, number, number]))
  const sum = { ...{ '底部手写解答区': 0 } }
  void sum
  const guard = {
    bottomDark: d('底部手写解答区'),
    printDarkA: d('23题题干行A(印刷)'),
    printDarkB: d('23题题干行B(印刷)'),
    graphicDark: d('图1区域(图形)'),
    bottomResidualPct: i0('底部手写解答区') ? +((i1('底部手写解答区') / i0('底部手写解答区')) * 100).toFixed(1) : 0,
  }
  console.log(`GUARD ${JSON.stringify(guard)}`)
}
main().catch((e) => { console.error(e); process.exit(1) })
