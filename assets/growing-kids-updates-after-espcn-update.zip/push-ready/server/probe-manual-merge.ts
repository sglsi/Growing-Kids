/**
 * v20.8 · 手动框选补擦语义验证 v2
 * ============================================================
 * v1 探针自己的两处错误（**测量层错误，又一次**）：
 *   ① 判据用"结果图该位置 luma < darkTh"反推"是否被擦"。
 *      报纸底色偏灰，全图 90 分位亮度作纸白时 darkTh 过低，
 *      整页灰底都被算成"被擦"→ baseErasedPx 达 30 万（占全图 20%），
 *      而 mask 覆盖率只有 0.94%，量级自相矛盾。**指标量级必须先自洽再用**。
 *   ② Q2 选的测试块要求 bright > 170（近乎纯白），那里本来就没有暗像素，
 *      "框选区新增被擦"必然为 0 —— 测不出补擦是否生效。
 *
 * v2 改用两个**不依赖亮度假设**的判据：
 *   Q1 集合包含：base.mask ⊆ manual.mask（merge 语义的数学定义，像素级可验）
 *      再看结果图：基线"发生了改变"的像素（|结果-原图| 超过阈值），
 *      在框选版里是否**仍然发生了改变**。这才是用户视角的"擦除没被撤销"。
 *   Q2 补擦生效：选一块**有暗像素但基线未擦**的块（真实漏擦区），
 *      框选后该块内"发生改变"的像素应显著增加。
 *   变化量阈值用 max(12, 3σ) 逐通道估计，避免硬编码绝对亮度。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'

const IN_DIR = '/workspace/wrongq-test'

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

/** 估计"变化阈值"：对随机 2000 个像素求 |结果-原图| 的中位数 + 3 倍 MAD 兜底 */
function changeThreshold(od: Buffer, nd: Buffer, n: number): number {
  const diffs: number[] = []
  for (let k = 0; k < 2000; k++) {
    const p = Math.floor((k / 2000) * n)
    const d = Math.max(
      Math.abs(od[p * 3] - nd[p * 3]),
      Math.abs(od[p * 3 + 1] - nd[p * 3 + 1]),
      Math.abs(od[p * 3 + 2] - nd[p * 3 + 2]),
    )
    diffs.push(d)
  }
  diffs.sort((a, b) => a - b)
  const med = diffs[Math.floor(diffs.length / 2)]
  const p99 = diffs[Math.floor(diffs.length * 0.99)]
  return Math.max(12, Math.min(40, p99))
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  const out: any[] = []

  for (const file of files) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, n = w * h

    // ── 基线 ──
    const base = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
    const baseImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', base.mask), base.mask)
    const { data: baseNd } = await raw(baseImg)
    const TH = changeThreshold(od, baseNd, n)

    const changed = (d: Buffer, p: number) => {
      const i = p * 3
      return (
        Math.abs(od[i] - d[i]) > TH ||
        Math.abs(od[i + 1] - d[i + 1]) > TH ||
        Math.abs(od[i + 2] - d[i + 2]) > TH
      )
    }

    const baseChanged = new Uint8Array(n)
    let baseChangedCnt = 0
    for (let p = 0; p < n; p++) if (changed(baseNd, p)) { baseChanged[p] = 1; baseChangedCnt++ }

    // 找测试块：暗像素（luma 低）但基线未改变 → 真实"漏擦区"
    const BS = Math.max(24, Math.round(Math.min(w, h) * 0.05))
    const lumaAt = (p: number) => 0.299 * od[p * 3] + 0.587 * od[p * 3 + 1] + 0.114 * od[p * 3 + 2]
    // 纸白亮度：全图 luma 98 分位
    const lums = new Float64Array(Math.ceil(n / 13))
    let li = 0
    for (let p = 0; p < n; p += 13) lums[li++] = lumaAt(p)
    const ls = Array.from(lums.slice(0, li)).sort((a, b) => a - b)
    const paper = ls[Math.floor(ls.length * 0.98)]
    const inkTh = paper - 45

    let best: { x: number; y: number; ink: number } | null = null
    for (let by = 0; by + BS <= h; by += BS) {
      for (let bx = 0; bx + BS <= w; bx += BS) {
        let ink = 0
        let chg = 0
        for (let y = by; y < by + BS; y++) {
          const b = y * w
          for (let x = bx; x < bx + BS; x++) {
            const p = b + x
            if (lumaAt(p) < inkTh) ink++
            if (baseChanged[p]) chg++
          }
        }
        if (ink > BS * BS * 0.02 && chg === 0) {
          if (!best || ink > best.ink) best = { x: bx, y: by, ink }
        }
      }
    }
    if (!best) {
      out.push({ file, skip: '未找到漏擦块' })
      continue
    }

    const rect = {
      x: +(best.x / w).toFixed(4),
      y: +(best.y / h).toFixed(4),
      w: +(BS / w).toFixed(4),
      h: +(BS / h).toFixed(4),
    }

    // ── 框选版 ──
    const man = await buildHandwritingMask(buf, '', {}, {
      allowVlm: false, eraseMode: 'hybrid', manualRects: [rect],
    })
    const manImg = await blendWithMask(buf, await inpaint(buf, 'adaptive', man.mask), man.mask)
    const { data: manNd } = await raw(manImg)

    // Q1a：集合包含
    let maskViolations = 0
    for (let p = 0; p < n; p++) {
      if (base.mask.data[p] > 127 && man.mask.data[p] <= 127) maskViolations++
    }

    // Q1b：结果图层面 —— 基线改变的像素，框选版是否仍改变
    let regressed = 0
    for (let p = 0; p < n; p++) if (baseChanged[p] && !changed(manNd, p)) regressed++

    // Q2：框选块内新增改变
    const rx0 = best.x, ry0 = best.y, rx1 = best.x + BS, ry1 = best.y + BS
    let rectChangedBefore = 0, rectChangedAfter = 0, rectDark = 0
    for (let y = ry0; y < ry1; y++) {
      const b = y * w
      for (let x = rx0; x < rx1; x++) {
        const p = b + x
        if (lumaAt(p) < inkTh) rectDark++
        if (baseChanged[p]) rectChangedBefore++
        if (changed(manNd, p)) rectChangedAfter++
      }
    }

    out.push({
      file,
      changeTH: TH, paperLuma: +paper.toFixed(0),
      baseChangedCnt,
      baseChangedRatio: +(baseChangedCnt / n).toFixed(4),
      maskCovBase: +(base.mask.data.reduce((s, v) => s + (v > 127 ? 1 : 0), 0) / n).toFixed(5),
      q1a_maskViolations: maskViolations,
      q1a_pass: maskViolations === 0,
      q1b_regressedPx: regressed,
      q1b_ratio: +(regressed / Math.max(1, baseChangedCnt)).toFixed(5),
      q1b_pass: regressed / Math.max(1, baseChangedCnt) < 0.01,
      rect: `${best.x},${best.y} ${BS}x${BS} darkPx=${rectDark}`,
      q2_darkBefore: rectChangedBefore,
      q2_darkAfter: rectChangedAfter,
      q2_newlyErased: rectChangedAfter - rectChangedBefore,
      q2_pass: rectChangedAfter - rectChangedBefore > rectDark * 0.5,
      debugManual: {
        manualRects: man.debug?.manualRects,
        before: man.debug?.coverageBeforeManual,
        after: man.debug?.coverageAfterManual,
      },
    })
    console.error(`[${file}] TH=${TH} baseChanged=${baseChangedCnt} maskViol=${maskViolations} regressed=${regressed} 框选块暗像素=${rectDark} 前=${rectChangedBefore} 后=${rectChangedAfter}`)
  }

  console.log('RESULT ' + JSON.stringify(out, null, 1))
  const fails = out.filter((r) => r.q1a_pass === false || r.q1b_pass === false || r.q2_pass === false)
  if (fails.length) {
    console.error('FAIL: ' + fails.map((f) => f.file).join(','))
    process.exitCode = 1
  }
}

main().catch((e) => { console.error(e); process.exit(1) })
