/**
 * 错题区域提取 · 前期测试探针 v6（用户反馈修正轮）
 *
 * 反馈1：原版式竖向三栏，绿色分栏没切出 → 蓝线只第一栏贴行，中/右栏分行错位。
 *        改法：c1/c2 联合搜索最空带 + 等宽偏置；每栏独立行切分，蓝线只画栏内。
 * 反馈2：红笔 mask 对勾只抓稀疏离散红点（细笔画碎成点），批注类 OK。
 *        改法：chromaMin 22→14（抓浅红）+ 闭运算补连 + 最小面积 8→3。
 *        关键修正：先排除「贴边/横幅/竖条」红色页眉家具（印刷，非批改），再对正文内红笔闭运算；
 *                  否则 chromaMin 降低 + 闭运算会把红色页眉横幅与批改笔迹连成整页巨型组件（误抓）。
 *        可视化：青色=保留的批改标记；橙色=排除的红色页眉家具；去红预览只删青色（教师红笔），保留印刷红。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { maskFromColorThreshold } from './src/image/handwriting-mask'
import { otsuThreshold, connectedComponents, quantileSorted, estimateCharMetrics } from './src/image/image-layout'
import { normalizeBackgroundLuma } from './src/image/image-doc-enhance'
import { straightenImage } from './src/image/image-dewarp'

const IN_DIR = '/workspace/wrongq-test'

function lumaFrom(data: Buffer, w: number, h: number, ch: number) {
  const n = w * h
  const luma = new Float32Array(n)
  for (let i = 0, p = 0; i < n; i++, p += ch) luma[i] = 0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2]
  return luma
}

/** 3×3 闭运算（膨胀+腐蚀），内联版：补连细笔画断裂。修正右/下边缘越界。 */
function closeInk3x3(ink: Uint8Array, w: number, h: number): Uint8Array {
  const dil = new Uint8Array(ink.length)
  for (let y = 0; y < h; y++) {
    const y0 = y > 0 ? y - 1 : 0
    const y1 = y < h - 1 ? y + 1 : h - 1
    for (let x = 0; x < w; x++) {
      if (!ink[y * w + x]) continue
      const x0 = x > 0 ? x - 1 : 0
      const x1 = x < w - 1 ? x + 1 : w - 1
      for (let yy = y0; yy <= y1; yy++) for (let xx = x0; xx <= x1; xx++) dil[yy * w + xx] = 1
    }
  }
  const ero = new Uint8Array(ink.length)
  for (let y = 0; y < h; y++) {
    const y0 = y > 0 ? y - 1 : 0
    const y1 = y < h - 1 ? y + 1 : h - 1
    for (let x = 0; x < w; x++) {
      if (!dil[y * w + x]) continue
      let all = true
      const x0 = x > 0 ? x - 1 : 0
      const x1 = x < w - 1 ? x + 1 : w - 1
      for (let yy = y0; yy <= y1 && all; yy++) for (let xx = x0; xx <= x1; xx++) if (!dil[yy * w + xx]) { all = false; break }
      if (all) ero[y * w + x] = 1
    }
  }
  return ero
}

/** 红笔组件分析：排除红色页眉家具（印刷）→ 闭运算补连 → 过滤。返回保留掩码与家具掩码。 */
function analyzeRed(
  ink: Uint8Array, w: number, h: number, medH: number, n: number, minArea: number, doClose: boolean,
) {
  const edgeTol = Math.max(4, Math.round(medH * 0.8))
  const maxArea = Math.round((6 * medH) * (6 * medH))
  const isFurniture = (c: { x0: number; x1: number; y0: number; y1: number }) =>
    c.x0 <= edgeTol || c.x1 >= w - 1 - edgeTol || c.y0 <= edgeTol || c.y1 >= h - 1 - edgeTol ||
    (c.x1 - c.x0 + 1 > w * 0.8 && c.y1 - c.y0 + 1 < medH * 3) ||
    (c.y1 - c.y0 + 1 > h * 0.8 && c.x1 - c.x0 + 1 < medH * 3)
  const { comps: rawComps } = connectedComponents(ink, w, h, false)
  const interior = new Uint8Array(n)
  const furnitureMask = new Uint8Array(n)
  let furnitureCount = 0
  for (const c of rawComps) {
    if (isFurniture(c)) {
      furnitureCount++
      for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x]) furnitureMask[b + x] = 1 }
      continue
    }
    if (c.n < 3) continue
    for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x]) interior[b + x] = 1 }
  }
  const closed = doClose ? closeInk3x3(interior, w, h) : interior
  const cc = connectedComponents(closed, w, h, true)
  const comps = cc.comps
  const labels = cc.labels as Int32Array
  const marks = comps.filter((c) => c.n >= minArea && c.n <= maxArea)
  const keptMask = new Uint8Array(n)
  for (let p = 0; p < n; p++) {
    if (closed[p] && labels[p] >= 0) {
      const c = comps[labels[p]]
      if (c.n >= minArea && c.n <= maxArea) keptMask[p] = 1
    }
  }
  return { marks, keptMask, furnitureMask, furnitureCount, maxArea }
}

/** 剔除图形大连通域（框线/插图），从文字 ink 中移除 */
function stripGraphics(ink: Uint8Array, w: number, h: number, medH: number) {
  const { comps } = connectedComponents(ink, w, h, false)
  const out = new Uint8Array(ink)
  let stripped = 0
  for (const c of comps) {
    const bw = c.x1 - c.x0 + 1
    const bh = c.y1 - c.y0 + 1
    if ((bh > 4 * medH && bw > 2 * medH) || (bw > w * 0.85 && bh > 3 * medH)) {
      stripped++
      for (let y = c.y0; y <= c.y1; y++) {
        const base = y * w
        for (let x = c.x0; x <= c.x1; x++) out[base + x] = 0
      }
    }
  }
  return { ink2: out, stripped }
}

/** 约束式三栏切分：c1、c2 联合搜索最空带 + 等宽偏置（报纸三栏近似等宽） */
function findThreeColumns(ink: Uint8Array, w: number, h: number, medH: number) {
  const y0 = Math.round(0.07 * h)
  const y1 = Math.round(0.93 * h)
  const prof = new Int32Array(w)
  for (let y = y0; y < y1; y++) {
    const base = y * w
    for (let x = 0; x < w; x++) if (ink[base + x]) prof[x]++
  }
  const bw = Math.max(6, Math.round(medH * 0.7))
  const pre = new Int32Array(w + 1)
  for (let x = 0; x < w; x++) pre[x + 1] = pre[x] + prof[x]
  const bandInk = (cx: number) => {
    const a = Math.max(0, Math.round(cx - bw / 2))
    const b = Math.min(w - 1, Math.round(cx + bw / 2))
    return pre[b + 1] - pre[a]
  }
  const target = w / 3
  const biasScale = 6
  const c1Lo = Math.round(0.22 * w), c1Hi = Math.round(0.46 * w)
  const c2Lo = Math.round(0.54 * w), c2Hi = Math.round(0.80 * w)
  let bestC1 = Math.round(w / 3), bestC2 = Math.round((2 * w) / 3), bestScore = Infinity
  for (let c1 = c1Lo; c1 <= c1Hi; c1++) {
    for (let c2 = Math.max(c1 + Math.round(0.18 * w), c2Lo); c2 <= c2Hi; c2++) {
      const widths = [c1, c2 - c1, w - c2]
      const bias = (Math.abs(widths[0] - target) + Math.abs(widths[1] - target) + Math.abs(widths[2] - target)) * biasScale
      const score = bandInk(c1) + bandInk(c2) + bias
      if (score < bestScore) { bestScore = score; bestC1 = c1; bestC2 = c2 }
    }
  }
  const c1 = bestC1, c2 = bestC2
  const sampleAt = (f: number) => bandInk(Math.round(f * w))
  return {
    c1, c2,
    cols: [[0, c1], [c1, c2], [c2, w]] as Array<[number, number]>,
    bandProbe: { third1: sampleAt(1 / 3), third2: sampleAt(2 / 3), chosen1: bandInk(c1), chosen2: bandInk(c2) },
    widths: [c1, c2 - c1, w - c2],
  }
}

/** 单栏行切分 */
function colRows(ink: Uint8Array, w: number, h: number, x0: number, x1: number, rowThRatio: number) {
  const prof = new Int32Array(h)
  for (let y = 0; y < h; y++) {
    const base = y * w
    let c = 0
    for (let x = x0; x < x1; x++) if (ink[base + x]) c++
    prof[y] = c
  }
  const profMax = Math.max(...prof)
  const th = Math.max(1, Math.round(profMax * rowThRatio))
  const rows: Array<{ y0: number; y1: number }> = []
  let y = 0
  while (y < h) {
    if (prof[y] < th) { y++; continue }
    const y0 = y
    while (y < h && prof[y] >= th) y++
    rows.push({ y0, y1: y })
  }
  return rows
}

async function probePage(file: string) {
  const buf = fs.readFileSync(file)
  const st = await straightenImage(buf, { auto: true, curved: false })
  const flatBuf = st.buffer ?? buf
  const { data, info } = await sharp(flatBuf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
  const w = info.width, h = info.height, ch = info.channels
  const n = w * h
  const luma = lumaFrom(data, w, h, ch)

  const flatMetrics = await estimateCharMetrics(flatBuf, {})
  const prior = w / 70
  const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, flatMetrics.medH > 0 ? flatMetrics.medH : prior))

  const lumaN = await normalizeBackgroundLuma(luma, w, h, { medH, flatten: 1, inkIsDark: true })
  const g1 = new Uint8Array(n)
  for (let i = 0; i < n; i++) g1[i] = Math.max(0, Math.min(255, Math.round(lumaN[i])))
  const t1 = otsuThreshold(g1, n)
  const ink1 = new Uint8Array(n)
  for (let i = 0; i < n; i++) ink1[i] = g1[i] < t1 ? 1 : 0
  const { ink2 } = stripGraphics(ink1, w, h, medH)

  // ── 三栏切分 + 每栏行切分 ──
  const { c1, c2, cols, bandProbe, widths } = findThreeColumns(ink2, w, h, medH)
  const colRowCounts: number[] = []
  const colRowLines: Array<Array<number>> = []
  for (const [a, b] of cols) {
    const rows = colRows(ink2, w, h, a, b, 0.06)
    const merged: Array<{ y0: number; y1: number }> = []
    for (const r of rows) {
      const last = merged[merged.length - 1]
      if (last && r.y0 - last.y1 <= medH * 0.15) last.y1 = r.y1
      else merged.push({ ...r })
    }
    colRowCounts.push(merged.length)
    colRowLines.push(merged.map((r) => r.y0))
  }

  // ── 红笔 mask：默认(chromaMin22,无闭运算) vs 改进(chromaMin14+闭运算+家具排除) ──
  const base = await maskFromColorThreshold(flatBuf, {})
  const baseInk = new Uint8Array(n)
  for (let i = 0; i < n; i++) baseInk[i] = base.data[i] ? 1 : 0
  const baseA = analyzeRed(baseInk, w, h, medH, n, 8, false)

  const imp = await maskFromColorThreshold(flatBuf, { chromaMin: 14 })
  const impInk = new Uint8Array(n)
  for (let i = 0; i < n; i++) impInk[i] = imp.data[i] ? 1 : 0
  const impA = analyzeRed(impInk, w, h, medH, n, 3, true)

  const markStat = (marks: { n: number }[]) => {
    const areas = marks.map((m) => m.n).sort((a, b) => a - b)
    return {
      marks: marks.length,
      coverage: +(areas.reduce((s, x) => s + x, 0) / n).toFixed(4),
      areaP50: areas.length ? quantileSorted(areas, 0.5) : 0,
      areaMax: areas.length ? areas[areas.length - 1] : 0,
      smallMarks: marks.filter((m) => m.n < 8).length,
    }
  }
  const topBig = impA.marks.slice().sort((a, b) => b.n - a.n).slice(0, 3).map((c) => ({
    box: [c.x0, c.y0, c.x1, c.y1], n: c.n,
    fill: +(c.n / Math.max(1, (c.x1 - c.x0 + 1) * (c.y1 - c.y0 + 1))).toFixed(2),
  }))

  // ── 诊断图 1：三栏 + 栏内蓝线（灰度底）──
  const dw = 900
  const dh = Math.round((h / w) * dw)
  const baseGray = await sharp(flatBuf).resize(dw, dh, { fit: 'fill' }).grayscale().removeAlpha().raw().toBuffer()
  const sx = dw / w, sy = dh / h
  const put = (buf3: Buffer, x: number, y: number, r: number, g: number, b: number) => {
    if (x < 0 || y < 0 || x >= dw || y >= dh) return
    const q3 = (y * dw + x) * 3; buf3[q3] = r; buf3[q3 + 1] = g; buf3[q3 + 2] = b
  }
  const out1 = Buffer.alloc(dw * dh * 3)
  for (let i = 0, q3 = 0; i < dw * dh; i++, q3 += 3) { const g = baseGray[i]; out1[q3] = g; out1[q3 + 1] = g; out1[q3 + 2] = g }
  for (const gx of [c1, c2]) { const dx = Math.round(gx * sx); for (let y = 0; y < dh; y++) put(out1, dx, y, 0, 200, 0) }
  cols.forEach(([a, b], ci) => {
    for (const ry of colRowLines[ci]) {
      const dy = Math.round(ry * sy)
      for (let x = Math.round(a * sx); x <= Math.round(b * sx); x += 2) put(out1, x, dy, 40, 120, 255)
    }
  })
  const diag1 = path.join(IN_DIR, 'diag6-col-' + path.basename(file))
  await sharp(out1, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(diag1)

  // ── 诊断图 2：青色=保留标记 / 橙色=排除的红色页眉家具（叠加灰度）──
  const out2 = Buffer.alloc(dw * dh * 3)
  for (let i = 0, q3 = 0; i < dw * dh; i++, q3 += 3) { const g = baseGray[i]; out2[q3] = g; out2[q3 + 1] = g; out2[q3 + 2] = g }
  for (let y = 0; y < dh; y++) {
    const my = Math.min(h - 1, Math.round(y / sy))
    for (let x = 0; x < dw; x++) {
      const mx = Math.min(w - 1, Math.round(x / sx))
      const idx = my * w + mx
      if (impA.keptMask[idx]) put(out2, x, y, 0, 230, 230)
      else if (impA.furnitureMask[idx]) put(out2, x, y, 255, 150, 0)
    }
  }
  const diag2 = path.join(IN_DIR, 'diag6-mask-' + path.basename(file))
  await sharp(out2, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(diag2)

  // ── 诊断图 3：去红干净预览（仅删青色=教师红笔，保留印刷红页眉）──
  const color = await sharp(flatBuf).resize(dw, dh, { fit: 'fill' }).removeAlpha().toColourspace('srgb').raw().toBuffer()
  const out3 = Buffer.alloc(dw * dh * 3)
  for (let y = 0; y < dh; y++) {
    const my = Math.min(h - 1, Math.round(y / sy))
    for (let x = 0; x < dw; x++) {
      const mx = Math.min(w - 1, Math.round(x / sx))
      const q3 = (y * dw + x) * 3
      if (impA.keptMask[my * w + mx]) {
        const lum = Math.max(0, Math.min(255, Math.round(luma[my * w + mx])))
        out3[q3] = lum; out3[q3 + 1] = lum; out3[q3 + 2] = lum
      } else {
        out3[q3] = color[q3]; out3[q3 + 1] = color[q3 + 1]; out3[q3 + 2] = color[q3 + 2]
      }
    }
  }
  const diag3 = path.join(IN_DIR, 'diag6-clean-' + path.basename(file))
  await sharp(out3, { raw: { width: dw, height: dh, channels: 3 } }).png().toFile(diag3)

  console.log('GUARD ' + JSON.stringify({
    file: path.basename(file),
    size: `${w}x${h}`,
    medH: +medH.toFixed(1),
    cols: { c1, c2, widths, bandProbe, rowCounts: colRowCounts },
    redMask: {
      base: markStat(baseA.marks),
      improved: markStat(impA.marks),
      deltaMarks: impA.marks.length - baseA.marks.length,
      furnitureCount: impA.furnitureCount,
      paperChroma: imp.debug?.paperChroma,
      topBig,
    },
    diag: [path.basename(diag1), path.basename(diag2), path.basename(diag3)],
  }))
}

async function main() {
  const files = fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()
  for (const f of files) {
    try {
      await probePage(path.join(IN_DIR, f))
    } catch (e) {
      console.log(`GUARD {"file":"${f}","error":${JSON.stringify(String((e as Error)?.message ?? e))}}`)
    }
  }
}
main().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })
