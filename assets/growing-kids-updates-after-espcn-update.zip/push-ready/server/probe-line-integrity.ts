/**
 * v20.6 · 行墨量守恒诊断 v4（正确口径）
 * ============================================================
 * v3 之前的两处自身错误（都是"指标失真"的经典来源，必须记下来）：
 *   ① 语义写反：`luma(nd) >= darkTh` 判的是"结果图里已变亮"=**被擦掉**，
 *      却被命名为 b 并算成 keepAll。v3 输出的 keepAll=0.0435 其实是**擦除率**，
 *      真实保持率 ≈ 0.9565，与目检一致。指标名一旦与语义脱节，
 *      后面所有推论全错——比算法 bug 更危险。
 *   ② medH 未做 buildLayoutContext 的双源钳位（prior=w/70，钳到 [0.8P, 2.0P]），
 *      用 105/77/70/48 去找行会把整栏并成单行（209"行"其实是 209 个整栏）。
 *
 * 本版目标：把用户反馈②「擦红笔时把红笔周边印刷体一起擦掉」变成可测量的数字。
 * 口径（不依赖任何"什么是印刷体"的假设）：
 *   · 行内原图暗像素 A；结果图中该位置**仍然是暗像素**的个数 B → B/A = 保持率
 *   · 受损行 = 无红笔行（纯印刷行）且 B/A < 0.8 且损失 > 40px
 *     「无红笔行」的损失在物理上只能是误擦（那里本来没有任何该擦的东西）
 *   · 归因：被擦像素分「落在 mask 内」= 检测层越界 / 「落在 mask 外」= 修复层副作用
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask, maskFromColorThreshold } from './src/image/handwriting-mask'
import { findThreeColumns, colRowsIn } from './src/image/wrongq-layout'
import { estimateCharMetrics, connectedComponents } from './src/image/image-layout'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]
const chrom = (d: Buffer, p: number) => Math.max(d[p], d[p + 1], d[p + 2]) - Math.min(d[p], d[p + 1], d[p + 2])

async function raw(buf: Buffer) {
  return sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
}

async function main() {
  const only = process.env.E7_ONLY ? process.env.E7_ONLY.split(',') : null
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    if (only && !only.includes(file)) continue
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await raw(buf)
    const w = info.width, h = info.height, ch = info.channels, n = w * h

    const seg = await buildHandwritingMask(buf, '', {}, { allowVlm: false, eraseMode: (process.env.E7_MODE as 'hybrid' | 'union') || 'hybrid' })
    const rep = await inpaint(buf, 'adaptive', seg.mask)
    const img = await blendWithMask(buf, rep, seg.mask)
    fs.writeFileSync(`${IN_DIR}/look/full4-${file}`, img)
    const { data: nd } = await raw(img)

    // 全局红笔像素（用于校验行内红墨统计是否有效）
    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    let redTot = 0
    for (let i = 0; i < n; i++) if (redO.data[i] > 127) redTot++

    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const paper = ls[Math.floor(ls.length * 0.9)] || 240
    const darkTh = paper * 0.62

    const ink = new Uint8Array(n)
    for (let i = 0; i < n; i++) {
      const p = i * ch
      if (chrom(od, p) < 14 && luma(od, p) < darkTh) ink[i] = 1
    }

    const fm = await estimateCharMetrics(buf, {})
    const prior = w / 70
    const medH = Math.max(prior * 0.8, Math.min(prior * 2.0, fm.medH > 0 ? fm.medH : prior))
    const cols = findThreeColumns(ink, w, h, medH).cols

    // ⭐ 印刷域筛选（v20.6 修正假阴性）
    //   "纯印刷行"= 行内无红笔，但**学生手写答案若恰好写在无红笔的行里**，
    //   被正确擦除后会被算成"印刷损失"（probe-dmg-crop page31-worst1 目视确认：
    //   `have (has)` 是潦草手写，擦掉是对的，却被计为损失）。
    //   ⚠️ 判据不能依赖被测对象（循环论证），故用第三方结构特征：
    //     印刷字连通域高度 ≈ 行高（6~7px）且形状规则；
    //     手写域更高（8~20px）且常跨出行带。
    //   probe-dmg-domain 实测受损印刷域 bh=6~11 / bw=5~10，与手写可分离。
    //   取 rowH_med（中位行高，实测 9~11px）作为行高基准。
    // 行高基准：用第一栏的水平投影自估（不依赖后面的 rowH，那时还没填）
    const medRowH = (() => {
      const [fx0, fx1] = cols[0]
      const prof = new Int32Array(h)
      for (let y = 0; y < h; y++) { const b = y * w; let c = 0; for (let x = fx0; x < fx1; x++) if (ink[b + x]) c++; prof[y] = c }
      const pmax = Math.max(...Array.from(prof))
      const th = Math.max(1, Math.round(pmax * 0.06))
      const hs: number[] = []
      let y = 0
      while (y < h) {
        if (prof[y] < th) { y++; continue }
        const y0 = y
        while (y < h && prof[y] >= th) y++
        if (y - y0 >= 3) hs.push(y - y0)
      }
      hs.sort((a, b) => a - b)
      return hs.length ? hs[Math.floor(hs.length / 2)] : 10
    })()
    const { comps } = connectedComponents(ink, w, h, false)
    const printPx = new Uint8Array(n)     // 属于"印刷字域"的像素
    for (const c of comps) {
      const bh = c.y1 - c.y0 + 1, bw = c.x1 - c.x0 + 1
      if (c.n < 4) continue
      // 域高不超过 1.6 倍行高 → 视为印刷字（手写域更高）
      if (bh > medRowH * 1.6) continue
      // 过宽的域（整行框线/表格线）也排除
      if (bw > medRowH * 6) continue
      for (let y = c.y0; y <= c.y1; y++) { const b = y * w; for (let x = c.x0; x <= c.x1; x++) if (ink[b + x]) printPx[b + x] = 1 }
    }

    type Row = { c: number; y0: number; y1: number; a: number; keep: number; lost: number; lostInMask: number; red: number }
    const rows: Row[] = []
    const rowH: number[] = []
    let redInRows = 0

    cols.forEach(([cx0, cx1], c) => {
      for (const r of colRowsIn(ink, w, h, cx0, cx1)) {
        let a = 0, keep = 0, lost = 0, lostInMask = 0, red = 0
        // ⚠️ 红笔统计必须放在 `!ink` 判断**之前**：红笔像素 chrom≥14 本身不满足 ink 定义，
        //    写在后面会让"无红笔行"筛选永远为真（v3~v4 redInRows 恒为 0 的原因）。
        for (let y = r.y0; y <= r.y1; y++) {
          const base = y * w
          for (let x = cx0; x <= cx1; x++) {
            if (redO.data[base + x] > 127) red++
          }
        }
        for (let y = r.y0; y <= r.y1; y++) {
          const base = y * w
          for (let x = cx0; x <= cx1; x++) {
            const i = base + x
            if (!printPx[i]) continue          // ★只统计印刷字域像素（排除手写）
            a++
            const p = i * ch
            const stillDark = luma(nd, p) < darkTh && chrom(nd, p) < 14
            if (stillDark) keep++
            else { lost++; if (seg.mask.data[i] > 127) lostInMask++ }
          }
        }
        redInRows += red
        if (a >= 25) { rows.push({ c, y0: r.y0, y1: r.y1, a, keep, lost, lostInMask, red }); rowH.push(r.y1 - r.y0) }
      }
    })
    rowH.sort((x, y) => x - y)

    const clean = rows.filter((r) => r.red === 0)          // 纯印刷行
    const S = (arr: Row[], k: 'a' | 'keep' | 'lost' | 'lostInMask' | 'red') => arr.reduce((s, r) => s + r[k], 0)
    const damaged = clean
      .map((r) => ({ ...r, ratio: r.keep / Math.max(1, r.a) }))
      .filter((r) => r.ratio < 0.8 && r.lost > 40)
      .sort((x, y) => y.lost - x.lost)

    // 逐像素全局归因：把「原图暗像素消失」按是否在 mask 内 / 是否近红笔 分桶
    let inkTot = 0, lostAll = 0, lostInMaskAll = 0, lostNearRed = 0, lostNearRedHand = 0
    const R = 24
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x
        if (!ink[i]) continue
        inkTot++
        const p = i * ch
        if (luma(nd, p) < darkTh && chrom(nd, p) < 14) continue
        lostAll++
        if (seg.mask.data[i] > 127) lostInMaskAll++
        // 近红 = 24px 内存在 v19 红笔像素
        let near = false
        const yA = Math.max(0, y - R), yB = Math.min(h - 1, y + R), xA = Math.max(0, x - R), xB = Math.min(w - 1, x + R)
        for (let yy = yA; yy <= yB && !near; yy += 2) {
          const bb = yy * w
          for (let xx = xA; xx <= xB; xx += 2) if (redO.data[bb + xx] > 127) { near = true; break }
        }
        if (near) { lostNearRed++; if (!printPx[i]) lostNearRedHand++ } // hand=非印刷域=手写(黑笔)近似
      }
    }

    console.log('GUARD ' + JSON.stringify({
      file, paper: +paper.toFixed(0), medH: +medH.toFixed(1),
      rowN: rows.length, rowH_med: rowH[Math.floor(rowH.length / 2)] ?? 0,
      redTot, redInRows,                                  // 两者应一致（行覆盖全图）
      keepAll: +(S(rows, 'keep') / Math.max(1, S(rows, 'a'))).toFixed(4),
      rowsNoRed: clean.length,
      keepNoRed: +(S(clean, 'keep') / Math.max(1, S(clean, 'a'))).toFixed(4),
      lostNoRedPx: S(clean, 'lost'),
      lostNoRedInMask: S(clean, 'lostInMask'),
      lostNoRedOutsideMask: S(clean, 'lost') - S(clean, 'lostInMask'),
      dmgRows: damaged.length,
      // 全局像素级归因（这是最硬的口径）
      inkTot, lostAll, lostPct: +(lostAll / Math.max(1, inkTot)).toFixed(4),
      lostInMaskAll, lostNearRed, lostNearRedHand,
      lostFarRed: lostAll - lostNearRed,
      worst: damaged.slice(0, 6).map((r) => ({ c: r.c, y0: r.y0, y1: r.y1, h: r.y1 - r.y0, keep: +r.ratio.toFixed(2), lost: r.lost, inMask: r.lostInMask })),
    }))
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
