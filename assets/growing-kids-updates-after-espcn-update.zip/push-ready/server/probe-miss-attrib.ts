/**
 * v20.5 · 漏擦归因：未被 hybrid 擦掉的黑笔候选像素，卡在哪一步？
 * ============================================================
 * 三次差异把每个 penSet 像素分到互斥桶：
 *   A 菱形外   —— 离任何批改点曼哈顿距离 > 24（受限于批改点分布，增大 R 才能覆盖，
 *                 但 R=28 起印刷误删超安全线 4~10 倍 → 这条路已封）
 *   B 域过滤丢 —— 在菱形内且是墨迹，但所属连通域延伸到菱形外被判印刷整域丢弃
 *   C 非墨迹   —— 在菱形内但没过 ink 判据（太浅/彩度偏高）
 *   D 已擦     —— 进了最终 mask
 * 目的：用数据决定下一步改哪一个环节，而不是继续扫参数。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { maskFromColorThreshold, protectPrintUnderColorHandwriting, refineColorEraseMask, normalizeIlluminationForDetection } from './src/image/handwriting-mask'
import { maskFromRedSpatialPrior } from './src/image/red-ink-prior'

const IN_DIR = '/workspace/wrongq-test'
const luma = (d: Buffer, p: number) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2]

async function main() {
  for (const file of fs.readdirSync(IN_DIR).filter((f) => /^page\d+\.png$/.test(f)).sort()) {
    const buf = fs.readFileSync(`${IN_DIR}/${file}`)
    const { data: od, info } = await sharp(buf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const w = info.width, h = info.height, ch = info.channels, n = w * h
    const ls: number[] = []
    for (let i = 0; i < n; i += 37) ls.push(luma(od, i * ch))
    ls.sort((a, b) => a - b)
    const darkTh = (ls[Math.floor(ls.length * 0.9)] || 240) * 0.62

    const pre = await normalizeIlluminationForDetection(buf)
    const cs = await maskFromColorThreshold(pre.buffer, { chromaMin: 14 })
    const rp = await protectPrintUnderColorHandwriting(buf, cs)
    const rw = await sharp(pre.buffer).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const red = refineColorEraseMask(rp, 10, { grow: { rgb: rw.data, channels: rw.info.channels, radius: 2, chromaMin: 8 } })

    const full = await maskFromRedSpatialPrior(buf, { radius: 24, redMask: red.data, minDomainRatio: 0.6 })
    const all = await maskFromRedSpatialPrior(buf, { radius: 24, redMask: red.data, minDomainRatio: 0 })

    // 菱形区域（与先验内部一致，用于判断"A 菱形外"）
    const { data: dd } = await sharp(pre.buffer).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const dch = dd === rw.data ? rw.info.channels : rw.info.channels
    void dch
    // 用 minDomainRatio=0 的结果反推 region∩ink；菱形本身再单独算一次（简易膨胀）
    // 为避免重复实现，region 用「red 膨胀 24」近似（与 dilateDiamond 等价的方形上界不够，这里用方形 24）
    const region = new Uint8Array(n)
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!red.data[y * w + x]) continue
        for (let yy = Math.max(0, y - 24); yy <= Math.min(h - 1, y + 24); yy++)
          for (let xx = Math.max(0, x - 24); xx <= Math.min(w - 1, x + 24); xx++) region[yy * w + xx] = 1
      }
    }

    // penSet：黑笔候选（近红 24px 内的低彩度暗像素）
    const redO = await maskFromColorThreshold(buf, { chromaMin: 14 })
    const nearS = region // 同构：红笔 ±24 方形
    const penSet = new Uint8Array(n)
    for (let i = 0; i < n; i++) {
      const p = i * ch
      if (redO.data[i]) continue
      const c = Math.max(od[p], od[p + 1], od[p + 2]) - Math.min(od[p], od[p + 1], od[p + 2])
      if (c >= 14 || luma(od, p) >= darkTh) continue
      if (nearS[i]) penSet[i] = 1
    }
    let nPen = 0
    for (let i = 0; i < n; i++) if (penSet[i]) nPen++

    let A = 0, B = 0, C = 0, D = 0
    for (let i = 0; i < n; i++) {
      if (!penSet[i]) continue
      if (full.data[i]) { D++; continue }
      if (all.data[i]) { B++; continue }         // 在 region∩ink 内，但被域包含度过滤剔除
      if (region[i]) { C++; continue }           // 在菱形内但不是 ink（太浅）
      A++                                        // 菱形都没有够到
    }
    console.log('GUARD ' + JSON.stringify({
      file, nPen,
      D: +(D / nPen).toFixed(3),
      A: +(A / nPen).toFixed(3),
      B: +(B / nPen).toFixed(3),
      C: +(C / nPen).toFixed(3),
      redPx: red.data.reduce((s: number, v: number) => s + (v ? 1 : 0), 0),
    }))
  }
}
main().catch((e) => { console.error('FAILED', e); process.exit(1) })
