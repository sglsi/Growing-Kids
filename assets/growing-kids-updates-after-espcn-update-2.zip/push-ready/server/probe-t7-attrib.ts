/**
 * probe-t7-attrib.ts —— T7 根因归因探针（v21.7）
 * ==========================================================================
 * 目标：定位「框外印刷墨迹被擦比例 M」到底来自哪些词。
 * 核心假设（已读源码证实）：erase-mask-policy 的 word 策略只把
 *   state===1（确信手写）词的 **ink 像素** 标为擦除；M 的来源 = 被误判为
 *   手写的印刷词，其印刷墨迹像素落在 GT 框外 R 区域。
 *
 * 方法：复用生产 buildEraseMask('word') 拿到最终 mask（255=擦）；
 *   对每个 state===1 词 bbox，计算其覆盖的「R 内被擦印刷墨迹像素」数 = 贡献。
 * 口径与 G16 探针一致（不跑 inpaint，mask 即擦除范围；R=GT框外+5px；
 *   印刷墨迹=擦前 luma<200 且非标注红）。
 * 输出：每页 Top15 贡献词（bbox@原图尺度、面积、score、贡献像素、贡献/面积）。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { buildEraseMask } from './src/image/erase-mask-policy'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
const INK_LUM = 200
const DILATE = 5

async function main() {
  const gt: Record<string, any[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!

    // 生产链路（与 G16 探针同口径，但只取到 mask，不 inpaint）
    const seg = await buildHandwritingMask(srcBuf, '', {}, { eraseMode: 'hybrid', allowVlm: false })
    const mask = await buildEraseMask(srcBuf, seg.mask, 'word')
    const md = mask.data as Buffer
    const before = await sharp(srcBuf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const cb = before.info.channels

    // 区域 R：GT 框外（各 +DILATE）
    const inBox = new Uint8Array(W * H)
    for (const b of gt[f]) {
      for (let y = Math.max(0, b.y0 - DILATE); y <= Math.min(H - 1, b.y1 + DILATE); y++)
        for (let x = Math.max(0, b.x0 - DILATE); x <= Math.min(W - 1, b.x1 + DILATE); x++) inBox[y * W + x] = 1
    }

    // 被擦的框外印刷墨迹像素集合 inS
    const inS = new Uint8Array(W * H)
    let inkR = 0
    for (let y = 0; y < H; y++) {
      const pb = y * W * cb
      for (let x = 0; x < W; x++) {
        const i = y * W + x
        if (inBox[i]) continue
        const bi = pb + x * cb
        const r = before.data[bi], g = before.data[bi + 1], b = before.data[bi + 2]
        const luma = 0.299 * r + 0.587 * g + 0.114 * b
        if (luma >= INK_LUM) continue
        if (r > 140 && g < 110 && b < 110) continue
        inkR++
        if (md[i] > 127) inS[i] = 1   // 被最终 mask 擦除
      }
    }
    const erasedR = Array.from(inS).reduce((s, v) => s + v, 0)

    // 判别器 words（work 尺度 bbox）
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false }, { charHFix: true })
    const wres = await discriminateWords({ ctx })
    const invX = W / ctx.work.w, invY = H / ctx.work.h

    const contrib = new Map<number, number>()
    wres.words.forEach((wd, idx) => {
      if (wd.state !== 1) return
      const ox0 = Math.max(0, Math.floor(wd.x0 * invX)), oy0 = Math.max(0, Math.floor(wd.y0 * invY))
      const ox1 = Math.min(W - 1, Math.floor(wd.x1 * invX)), oy1 = Math.min(H - 1, Math.floor(wd.y1 * invY))
      let c = 0
      for (let y = oy0; y <= oy1; y++) for (let x = ox0; x <= ox1; x++) if (inS[y * W + x]) c++
      if (c > 0) contrib.set(idx, c)
    })
    const sorted = [...contrib.entries()].sort((a, b) => b[1] - a[1])
    const totalC = sorted.reduce((s, [, c]) => s + c, 0)
    const state1 = wres.words.filter((w) => w.state === 1).length

    console.log(`\n══ ${f} ══`)
    console.log(`  R内印刷墨迹 ${inkR}px | 被擦 ${erasedR}px | M=${(erasedR / inkR * 100).toFixed(2)}% | state===1词 ${state1}个`)
    console.log(`  归因到state===1词合计 ${totalC}px（=被擦框外印刷的 ${totalC / erasedR * 100 | 0}%）`)
    console.log(`  Top15 贡献词 (idx | bbox@orig | 面积 | score | 贡献px | 贡献/面积):`)
    sorted.slice(0, 15).forEach(([idx, c]) => {
      const wd = wres.words[idx]
      const ox0 = Math.floor(wd.x0 * invX), oy0 = Math.floor(wd.y0 * invY)
      const ox1 = Math.floor(wd.x1 * invX), oy1 = Math.floor(wd.y1 * invY)
      const area = (ox1 - ox0 + 1) * (oy1 - oy0 + 1)
      console.log(`   #${idx} (${ox0},${oy0})-(${ox1},${oy1}) area=${area} score=${wd.score.toFixed(2)} contrib=${c} ratio=${(c / area * 100).toFixed(1)}%`)
    })
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
