/**
 * probe-p4-feature.ts —— P4 候选判据**判别力实测**（先量化，再选判据）
 * ==========================================================================
 * 背景（见 verify-out/p4-diag.json 归因）：
 *   插图损伤的主责是词级通道把插图的**单个大连通域**当成"词"，
 *   而 nComp=1 时 heightCV 退化成 |h-baseH|/baseH → 数值爆炸 → score→0.9。
 *   治本要在"行/词切分"之前加一层：**这个连通域是不是字符？**
 *
 * 本探针的任务：把"手写 CC"与"插图 CC"两组在候选特征上的**分布**打出来，
 * 用数据回答：有没有无监督可分的、物理量纲明确的判据？
 *
 * ⚠️ GT 协议：这里只用 GT 做**判据选型与可分离性验证**，
 *    阈值一律由 charH 归一化的**排版/物理量纲**给出，不对这 4 张图拟合。
 *
 * 用法：npx tsx probe-p4-feature.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { connectedComponents } from './src/image/image-layout'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
const INK_T = 128

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

function q(a: number[], p: number): number {
  if (!a.length) return 0
  const s = a.slice().sort((x, y) => x - y)
  const i = Math.min(s.length - 1, Math.max(0, Math.floor(p * (s.length - 1))))
  return s[i]
}
function stats(a: number[]) {
  return a.length
    ? { n: a.length, p10: +q(a, 0.1).toFixed(2), p50: +q(a, 0.5).toFixed(2), p90: +q(a, 0.9).toFixed(2), max: +q(a, 1).toFixed(2) }
    : { n: 0, p10: 0, p50: 0, p90: 0, max: 0 }
}

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const aggIl: number[][] = Array.from({ length: 8 }, () => [])
  const aggHw: number[][] = Array.from({ length: 8 }, () => [])
  const NAMES = ['h/charH', 'w/charH', 'area/charH²', 'density', 'maxRun/charH', 'isoRatio', 'runCV', 'aspect']
  const rowsOut: unknown[] = []

  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
    const { w, h, ink } = ctx.work
    const s = W / w   // work → 原图放大倍数

    // 与判别器同口径：闭合后连通域
    const inkC = new Uint8Array(w * h)
    { // 3×3 闭合（膨胀后腐蚀），与 word-level-discriminator.closeInk3x3 同算法
      const d = new Uint8Array(w * h)
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        if (!ink[y * w + x]) continue
        const y0 = Math.max(0, y - 1), y1 = Math.min(h - 1, y + 1)
        const x0 = Math.max(0, x - 1), x1 = Math.min(w - 1, x + 1)
        for (let yy = y0; yy <= y1; yy++) { const b = yy * w; for (let xx = x0; xx <= x1; xx++) d[b + xx] = 1 }
      }
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        let all = true
        const y0 = Math.max(0, y - 1), y1 = Math.min(h - 1, y + 1)
        const x0 = Math.max(0, x - 1), x1 = Math.min(w - 1, x + 1)
        for (let yy = y0; yy <= y1 && all; yy++) { const b = yy * w; for (let xx = x0; xx <= x1; xx++) if (!d[b + xx]) { all = false; break } }
        if (all) inkC[y * w + x] = 1
      }
    }
    const comps = connectedComponents(inkC, w, h, false).comps.filter((c) => c.n >= 4)

    // charH（复用判别器内部同一函数的结果：这里重算一遍保持一致）
    const prof = new Int32Array(h)
    for (let y = 0; y < h; y++) { let n = 0; const b = y * w; for (let x = 0; x < w; x++) if (ink[b + x]) n++; prof[y] = n }
    const thr0 = Math.max(1, Math.round(0.015 * w))
    const hsBand: number[] = []
    let st = -1
    for (let y = 0; y <= h; y++) {
      const on = y < h && prof[y] >= thr0
      if (on) { if (st < 0) st = y }
      else if (st >= 0) { const bh = y - st; if (bh >= 2 && bh <= 0.15 * h) hsBand.push(bh); st = -1 }
    }
    const charH = Math.max(3, Math.round(q(hsBand, 0.5) || 12))

    const perCc: Array<{ cls: string; feat: number[] }> = []
    for (const c of comps) {
      const bw = c.x1 - c.x0 + 1, bh = c.y1 - c.y0 + 1
      // 质心（原图坐标）
      const cx = Math.round((c.x0 + c.x1) / 2 * s), cy = Math.round((c.y0 + c.y1) / 2 * s)
      const hitIl = gt[f].find((b) => b.cls === 'illustration' && cx >= b.x0 && cx <= b.x1 && cy >= b.y0 && cy <= b.y1)
      const hitHw = gt[f].find((b) => b.cls === 'handwriting' && cx >= b.x0 && cx <= b.x1 && cy >= b.y0 && cy <= b.y1)
      // 框两边的都不要（口径含糊）；只保留明确落在一类里的
      const cls = hitIl ? 'illustration' : hitHw ? 'handwriting' : ''
      if (!cls) continue

      // 特征（全部 charH 归一化）
      let inkN = 0, iso = 0, maxRun = 0
      const runs: number[] = []
      for (let y = c.y0; y <= c.y1; y++) {
        const base = y * w
        let run = 0
        for (let x = c.x0; x <= c.x1 + 1; x++) {
          const on = x <= c.x1 && ink[base + x]
          if (on) { run++; inkN++ } else { if (run > 0) { runs.push(run); if (run > maxRun) maxRun = run; run = 0 } }
        }
      }
      for (let y = c.y0; y <= c.y1; y++) {
        const base = y * w
        for (let x = c.x0; x <= c.x1; x++) {
          if (!ink[base + x]) continue
          let nb = 0
          for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
            if (!dx && !dy) continue
            const ny = y + dy, nx = x + dx
            if (ny >= 0 && nx >= 0 && ny < h && nx < w && ink[ny * w + nx]) nb++
          }
          if (nb <= 2) iso++
        }
      }
      const chk = charH * charH
      const feat = [
        +(bh / charH).toFixed(2),
        +(bw / charH).toFixed(2),
        +((bw * bh) / chk).toFixed(2),
        +(inkN / Math.max(1, bw * bh)).toFixed(3),
        +(maxRun / charH).toFixed(2),
        +(inkN ? iso / inkN : 0).toFixed(3),
        +(() => { const a = runs.filter((r) => r >= 2); if (a.length < 2) return 0; const m = a.reduce((x, y) => x + y, 0) / a.length; const v = Math.sqrt(a.reduce((t, r) => t + (r - m) * (r - m), 0) / a.length); return m > 1e-9 ? v / m : 0 })().toFixed(3),
        +(bw / Math.max(1, bh)).toFixed(2),
      ]
      perCc.push({ cls, feat })
    }

    const il = perCc.filter((x) => x.cls === 'illustration')
    const hw = perCc.filter((x) => x.cls === 'handwriting')
    console.log(`\n════ ${f}  charH=${charH}  插图CC=${il.length}  手写CC=${hw.length} ════`)
    for (let k = 0; k < NAMES.length; k++) {
      const a = il.map((x) => x.feat[k]), b = hw.map((x) => x.feat[k])
      const si = stats(a), sh = stats(b)
      aggIl[k].push(...a); aggHw[k].push(...b)
      console.log(`  ${NAMES[k].padEnd(14)} 插图 p50=${String(si.p50).padStart(6)} p90=${String(si.p90).padStart(6)} | 手写 p50=${String(sh.p50).padStart(6)} p90=${String(sh.p90).padStart(6)} p10=${String(sh.p10).padStart(6)}`)
    }
    rowsOut.push({ file: f, charH, ilN: il.length, hwN: hw.length })
  }

  console.log('\n══════ 全集合并（4 图）══════')
  const summary: Record<string, unknown> = {}
  for (let k = 0; k < NAMES.length; k++) {
    const si = stats(aggIl[k]), sh = stats(aggHw[k])
    console.log(`  ${NAMES[k].padEnd(14)} 插图 p10=${String(si.p10).padStart(7)} p50=${String(si.p50).padStart(7)} p90=${String(si.p90).padStart(7)} | 手写 p10=${String(sh.p10).padStart(7)} p50=${String(sh.p50).padStart(7)} p90=${String(sh.p90).padStart(7)}`)
    summary[NAMES[k]] = { il: si, hw: sh }
  }
  fs.writeFileSync('verify-out/p4-feature.json', JSON.stringify({ perPage: rowsOut, summary }, null, 2))
  console.log('\n→ verify-out/p4-feature.json')
}
main().catch((e) => { console.error(e); process.exit(1) })
