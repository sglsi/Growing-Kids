/**
 * probe-gt-e2e.ts —— 独立真值上的**端到端**去手写效果检验（v21.4 · 任务 4）
 * ==========================================================================
 * 与 probe-gt-eval.ts 的区别（不要混用）：
 *   probe-gt-eval   看 **mask**（有没有把地方框出来）—— 检出层指标
 *   probe-gt-e2e    看 **擦完的图**（到底擦干净没有、有没有烧到别处）—— 用户层的指标
 *
 * 链路与生产 `image.service.eraseV2` 完全一致：
 *   buildHandwritingMask(hybrid, 禁VLM) → inpaint('adaptive') → blendWithMask
 * 输入统一用 `-clean.png`（人工标注的红/蓝框笔画已被擦除），否则标注笔本身会被当手写。
 *
 * 指标（全部基于 GT 框，红框=手写 / 蓝框=插图）：
 *   R 残留率   = 擦后框内墨迹像素 / 擦前框内墨迹像素         （手写框：越低越好，合格线 ≤0.15）
 *   D 破坏率   = 框内 |Δluma|>25 的像素占比                  （插图框：应≈0，容忍 ≤0.02）
 *   O 框外改动 = 全部 GT 框之外被实际改动的像素占比           （印刷/版面损伤）
 *   S 非手写区一致性 = 1 - 框内改变像素/被测像素（服务同口径）
 *
 * 产出：
 *   worksheet-test/annotated/e2e/<图>-erased.png        擦除结果（给人工看）
 *   worksheet-test/annotated/e2e/<图>-diff.png          改动热力图（绿=框内改动即擦除生效 / 红=框外改动即疑似损伤）
 *   verify-out/gt-e2e.json                              逐框数据
 *
 * 用法：npx tsx probe-gt-e2e.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask, protectPrintGeneric } from './src/image/handwriting-mask'
import { buildDocContext } from './src/image/adaptive-stats'
import { buildEraseMask } from './src/image/erase-mask-policy'
import { discriminateWords } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const OUT = `${DIR}/e2e`
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

/** 产物文件名后缀：标明这份图是哪个 mask 源擦出来的，避免不同配置互相覆盖造成误读 */
function srcTag2(): string {
  const m = process.env.E2E_MODE || 'hybrid'
  const src = process.env.E2E_MASK || 'seg'
  // 判别器对照变量一并入 tag：不同词切分/打分配置的结果必须落到不同文件，
  // 否则会互相覆盖（曾因此把 A 配置的结果读成 B 配置）。
  const wl: string[] = []
  if (process.env.WL_GAP_MODE) wl.push('gm' + process.env.WL_GAP_MODE)
  if (process.env.WL_GAP_ABS) wl.push('ga' + process.env.WL_GAP_ABS)
  if (process.env.WL_SCORE) wl.push('sc' + process.env.WL_SCORE)
  const wt = wl.length ? '-' + wl.join('') : ''
  // 合成策略 + 印刷保护（P4 收尾：让用户侧可对照「只擦确信手写」的几种组合）
  const cb = process.env.E2E_COMBINE
  const pr = process.env.E2E_PROTECT
  const xt = (cb && cb !== 'union' ? '-cb' + cb : '') + (pr && pr !== 'off' ? '-pr' + pr : '')
  // ⭐ 标尺开关进文件名：仅当显式**非默认**值（off/shadow）才加后缀，
  //   默认 on 不产生后缀 → 门禁 erase-guard 读取的 gt-e2e-hybrid.json 文件名稳定。
  const ch = (process.env.CHARH_FIX === 'off' ? '-fixoff' : process.env.CHARH_FIX === 'shadow' ? '-fixsh' : '') +
             (process.env.CHARH_COORD === 'off' ? '-coordoff' : process.env.CHARH_COORD === 'shadow' ? '-coordsh' : '')
  return (src === 'seg' ? `-${m}` : `-${m}-${src}`) + wt + xt + ch
}

const INK_T = 128      // L0 · 墨迹判定：亮度<128（与 probe-gt-eval 同口径，保证两探针可比）
const DIFF_T = 25      // L0 · "真的被改了"的亮度差阈值（低于此视为压缩/插值噪声）

function lumaOf(data: Buffer, channels: number, w: number, h: number): Uint8Array {
  const g = new Uint8Array(w * h)
  for (let i = 0, p = 0; i < g.length; i++, p += channels) {
    g[i] = Math.round(0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2])
  }
  return g
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const rows: Record<string, unknown>[] = []

  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!

    const mode = (process.env.E2E_MODE as 'hybrid' | 'union' | 'color') || 'hybrid'
    const maskSrc = process.env.E2E_MASK || 'seg'
    const seg = await buildHandwritingMask(srcBuf, '', {}, { eraseMode: mode, allowVlm: false })
    let mask = seg.mask
    if (mask.width !== W || mask.height !== H) {
      console.warn(`[${f}] mask 尺寸 ${mask.width}x${mask.height} ≠ 原图 ${W}x${H}，跳过`)
      continue
    }
    // ── 词级判别器结果（state: 0=印刷 1=手写 2=疑虑）；整词一个状态 ──
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
    const wres = discriminateWords({ ctx })
    const s = ctx.work.w / W
    const wl = new Uint8Array(W * H)
    for (let y = 0; y < ctx.work.h; y++) {
      const oy0 = Math.floor(y / s), oy1 = Math.min(H - 1, Math.floor((y + 1) / s))
      for (let x = 0; x < ctx.work.w; x++) {
        if (wres.labels[y * ctx.work.w + x] !== 1) continue // 只取「确信手写」，疑虑/印刷一律丢弃
        const ox0 = Math.floor(x / s), ox1 = Math.min(W - 1, Math.floor((x + 1) / s))
        for (let oy = oy0; oy <= oy1; oy++) for (let ox = ox0; ox <= ox1; ox++) wl[oy * W + ox] = 1
      }
    }
    const charH = wres.debug.charH

    // ── 颜色无关印刷保护（可选）：剔除 hybrid 中被误判为手写的印刷字域 ──
    let hybridMask = mask
    if ((process.env.E2E_PROTECT || 'off') === 'generic') {
      hybridMask = await protectPrintGeneric(srcBuf, mask, { charH })
    }

    // ── 合成策略（E2E_COMBINE；未设则用旧 E2E_MASK 语义兜底）──
    const combineEnv = process.env.E2E_COMBINE
    const combine: 'word' | 'and' | 'union' | 'seg' =
      combineEnv === 'word' || combineEnv === 'and' || combineEnv === 'union' ? combineEnv
        : maskSrc === 'word' ? 'word'
        : maskSrc === 'hybrid+word' ? 'union'
        : 'seg'
    const mergedData = Buffer.alloc(W * H)
    let covered = 0
    for (let i = 0; i < W * H; i++) {
      let take = false
      if (combine === 'word') take = wl[i] > 0
      else if (combine === 'and') take = hybridMask.data[i] > 127 && wl[i] > 0
      else if (combine === 'union') take = hybridMask.data[i] > 127 || wl[i] > 0
      else take = mask.data[i] > 127 // 'seg'：仅 hybrid
      if (take) { mergedData[i] = 255; covered++ }
    }
    const wordShare = combine === 'word' ? covered / (W * H)
      : combine === 'seg' ? 0
      : (covered / (W * H)) - mask.coverage
    mask = { ...mask, data: mergedData, coverage: covered / (W * H) }

    // ── E2E_PRODPATH=1：改走**生产函数** buildEraseMask，验证 eraseV2 的真实行为 ──
    if (process.env.E2E_PRODPATH === '1') {
      const pol: 'word' | 'union_generic' =
        process.env.E2E_COMBINE === 'union_generic' ? 'union_generic' : 'word'
      mask = await buildEraseMask(srcBuf, seg.mask, pol)
    }
    const strategy = (process.env.E2E_STRATEGY as 'adaptive') || 'adaptive'
    const inpainted = await inpaint(srcBuf, strategy, mask)
    const merged = await blendWithMask(srcBuf, inpainted, mask)
    const suffix = srcTag2()
    await sharp(merged).png().toFile(`${OUT}/${f.replace('.png', '')}-erased${suffix}.png`)

    const before = await sharp(srcBuf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const after = await sharp(merged).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const cb = before.info.channels, ca = after.info.channels
    const gBefore = lumaOf(before.data, cb, W, H)
    const gAfter = lumaOf(after.data, ca, W, H)

    // 改动图（可视化）：绿=GT框内改动（期望），红=GT框外改动（疑似损伤）
    const inBox = new Uint8Array(W * H)
    for (const b of gt[f]) {
      for (let y = Math.max(0, b.y0 - 2); y <= Math.min(H - 1, b.y1 + 2); y++) {
        for (let x = Math.max(0, b.x0 - 2); x <= Math.min(W - 1, b.x1 + 2); x++) inBox[y * W + x] = 1
      }
    }
    const vis = Buffer.alloc(W * H * 3)
    let diffAll = 0, diffOut = 0
    for (let i = 0; i < W * H; i++) {
      const d = Math.abs(gAfter[i] - gBefore[i])
      const r = before.data[i * cb], g = before.data[i * cb + 1], b = before.data[i * cb + 2]
      vis[i * 3] = r; vis[i * 3 + 1] = g; vis[i * 3 + 2] = b
      if (d > DIFF_T) {
        diffAll++
        if (!inBox[i]) diffOut++
        // 染半色：绿（框内） / 红（框外）
        if (inBox[i]) { vis[i * 3] = Math.round(r * 0.45); vis[i * 3 + 1] = Math.round(g * 0.45 + 110); vis[i * 3 + 2] = Math.round(b * 0.45) }
        else { vis[i * 3] = Math.round(r * 0.45 + 130); vis[i * 3 + 1] = Math.round(g * 0.45); vis[i * 3 + 2] = Math.round(b * 0.45) }
      }
    }
    await sharp(vis, { raw: { width: W, height: H, channels: 3 } }).png().toFile(`${OUT}/${f.replace('.png', '')}-diff${suffix}.png`)

    // 逐框统计
    const stat = (b: Box) => {
      let inkBefore = 0, inkAfter = 0, changed = 0, tot = 0, inkMasked = 0
      for (let y = Math.max(0, b.y0); y <= Math.min(H - 1, b.y1); y++) {
        for (let x = Math.max(0, b.x0); x <= Math.min(W - 1, b.x1); x++) {
          const i = y * W + x
          tot++
          if (gBefore[i] < INK_T) {
            inkBefore++
            if (mask.data[i] > 127) inkMasked++
          }
          if (gAfter[i] < INK_T) inkAfter++
          if (Math.abs(gAfter[i] - gBefore[i]) > DIFF_T) changed++
        }
      }
      const maskShareOfInk = inkBefore ? inkMasked / inkBefore : 0
      return {
        residual: inkBefore ? +(inkAfter / inkBefore).toFixed(3) : 0,
        maskShareOfInk: +maskShareOfInk.toFixed(3),
        // residual 与 (1-maskShare) 的偏差：若≈0，说明"擦不干净"完全由"没框到"解释
        gapVsDetection: +Math.abs((inkBefore ? inkAfter / inkBefore : 0) - (1 - maskShareOfInk)).toFixed(3),
        damage: tot ? +(changed / tot).toFixed(3) : 0,
        inkBefore,
      }
    }
    const hw = gt[f].filter((b) => b.cls === 'handwriting')
    const il = gt[f].filter((b) => b.cls === 'illustration')
    const hwStats = hw.map(stat)
    const ilStats = il.map(stat)

    const passedHw = hwStats.filter((s) => s.residual <= 0.15).length
    const badIl = ilStats.filter((s) => s.damage >= 0.02).length
    const avgRes = hwStats.length ? +(hwStats.reduce((a, s) => a + s.residual, 0) / hwStats.length).toFixed(3) : 0
    const worstRes = hwStats.reduce((a, s) => Math.max(a, s.residual), 0)
    const worstIl = ilStats.reduce((a, s) => Math.max(a, s.damage), 0)
    const avgGap = hwStats.length ? +(hwStats.reduce((a, s) => a + s.gapVsDetection, 0) / hwStats.length).toFixed(3) : 0
    const avgMaskShare = hwStats.length ? +(hwStats.reduce((a, s) => a + s.maskShareOfInk, 0) / hwStats.length).toFixed(3) : 0

    console.log(`\n${f}  mask覆盖率=${(mask.coverage * 100).toFixed(2)}%  mode=${seg.debug?.mode ?? '?'}`)
    console.log(`  手写框 ${hw.length}：擦净(残留≤0.15) ${passedHw} | 平均残留 ${avgRes} | 最差 ${worstRes}`)
    for (const b of hw) {
      const s = stat(b)
      if (s.residual > 0.15) console.log(`    [残留] (${b.x0},${b.y0}) ${b.x1 - b.x0}x${b.y1 - b.y0} 残留=${s.residual} 墨迹${s.inkBefore}px`)
    }
    console.log(`  插图框 ${il.length}：受损(≥2%) ${badIl} | 最差破坏 ${worstIl}`)
    for (const b of il) {
      const s = stat(b)
      if (s.damage >= 0.02) console.log(`    [损伤] (${b.x0},${b.y0}) ${b.x1 - b.x0}x${b.y1 - b.y0} 破坏=${s.damage}`)
    }
    console.log(`  框外改动 ${diffOut}px (${(diffOut / (W * H) * 100).toFixed(3)}%) | 全图改动 ${(diffAll / (W * H) * 100).toFixed(2)}%`)

    rows.push({
      file: f, w: W, h: H, coverage: +mask.coverage.toFixed(4), mode: seg.debug?.mode ?? '',
      hwN: hw.length, hwClean: passedHw, avgResidual: avgRes, worstResidual: worstRes,
      ilN: il.length, ilDamaged: badIl, worstIlDamage: +worstIl.toFixed(3),
      avgMaskShareOfInk: avgMaskShare, avgGapVsDetection: avgGap,
      wordExtraCoverage: +wordShare.toFixed(4),
      outsideChangedPx: diffOut,
      outsideChangedPct: +(diffOut / (W * H) * 100).toFixed(3),
    })
  }

  const tot = rows.reduce((a, r) => a + (r.hwN as number), 0)
  const clean = rows.reduce((a, r) => a + (r.hwClean as number), 0)
  const ilN = rows.reduce((a, r) => a + (r.ilN as number), 0)
  const ilBad = rows.reduce((a, r) => a + (r.ilDamaged as number), 0)
  console.log('\n══ 端到端汇总 ══')
  console.log(`手写框擦净 ${clean}/${tot} (${(clean / tot * 100).toFixed(0)}%) | 插图框受损 ${ilBad}/${ilN}`)
  const out2 = rows.reduce((a: Record<string, number>, r) => {
    for (const k of ['outsideChangedPx'] as const) a[k] = (a[k] ?? 0) + (r[k] as number)
    return a
  }, {})
  console.log(`框外改动合计 ${out2.outsideChangedPx}px`)
  const tag = srcTag2()
  fs.mkdirSync('verify-out', { recursive: true })
  // ⚠️ tag 已自带前导 '-'（如 '-hybrid'），故文件名用 `gt-e2e${tag}` 而非 `gt-e2e-${tag}`，
  // 否则会写出双横杠 gt-e2e--hybrid.json，与门禁 erase-guard 读取的 gt-e2e-hybrid.json 错位（ENOENT）。
  fs.writeFileSync(path.join('verify-out', `gt-e2e${tag}.json`), JSON.stringify(rows, null, 2))
  console.log(`→ verify-out/gt-e2e${tag}.json　图片 → ` + OUT)
}
main().catch((e) => { console.error(e); process.exit(1) })
