/**
 * probe-gt-survival.ts —— G16 印刷存活门禁探针（v21.5）
 * ==========================================================================
 * 度量：框外（GT 手写框 ∪ 插图框 之外，各 +5px）印刷墨迹被擦比例 M。
 *   M = (R 内 印刷墨迹 ∩ 改动像素) / (R 内 印刷墨迹)
 *   · 改动像素：mean_RGB(|after − before|) > 25
 *   · 印刷墨迹（仅看擦前图）：luma < 200 且非标注红 (r>140 & g<110 & b<110)
 * 链路与生产 image.service.eraseV2 同口径：buildHandwritingMask(hybrid,禁VLM)
 *   → buildEraseMask('word') → inpaint('adaptive') → blendWithMask。
 * 冻结值 M_frozen = 2.0%（固定验收阈值，非回归棘轮，见 G16-印刷存活门禁-度量与冻结值.md）。
 * 输出：GUARD JSON，含逐页 M 与加权总 M，供 erase-guard.ts 的 G16 读取。
 *
 * 用法：npx tsx probe-gt-survival.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { inpaint, blendWithMask } from './src/image/handwriting-mask'
import { buildEraseMask } from './src/image/erase-mask-policy'

const DIR = '/workspace/worksheet-test/annotated'
const OUT = `${DIR}/g16`
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

const DIFF_T = 25     // L0 · "真的被改了"的 RGB 均值差阈值
const INK_LUM = 200   // L0 · 印刷墨迹亮度上限（luma<200）
const DILATE = 5      // L0 · GT 框外扩容差（吸收合法边缘羽化/抗锯齿/轻微欠覆盖）
const M_FROZEN = 2.0  // L0 · 固定验收阈值（天花板闸）

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const per: Record<string, { inkR: number; erasedR: number; M: number }> = {}
  let totInk = 0, totErased = 0

  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!

    // ── 生产链路（word 路径，用户默认）──
    const seg = await buildHandwritingMask(srcBuf, '', {}, { eraseMode: 'hybrid', allowVlm: false })
    const mask = await buildEraseMask(srcBuf, seg.mask, 'word')
    const inpainted = await inpaint(srcBuf, 'adaptive', mask)
    const merged = await blendWithMask(srcBuf, inpainted, mask)
    await sharp(merged).png().toFile(`${OUT}/${f.replace('.png', '')}-erased.png`)

    const before = await sharp(srcBuf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const after = await sharp(merged).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const cb = before.info.channels, ca = after.info.channels

    // 区域 R：在 GT 框之外（各 +DILATE）
    const inBox = new Uint8Array(W * H)
    for (const b of gt[f]) {
      for (let y = Math.max(0, b.y0 - DILATE); y <= Math.min(H - 1, b.y1 + DILATE); y++) {
        for (let x = Math.max(0, b.x0 - DILATE); x <= Math.min(W - 1, b.x1 + DILATE); x++) inBox[y * W + x] = 1
      }
    }

    let inkR = 0, erasedR = 0
    for (let y = 0; y < H; y++) {
      const pb = y * W * cb, pa = y * W * ca
      for (let x = 0; x < W; x++) {
        const i = y * W + x
        if (inBox[i]) continue
        // 印刷墨迹（仅看擦前）：亮度<200 且非标注红
        const bi = pb + x * cb
        const r = before.data[bi], g = before.data[bi + 1], b = before.data[bi + 2]
        const luma = 0.299 * r + 0.587 * g + 0.114 * b
        if (luma >= INK_LUM) continue
        if (r > 140 && g < 110 && b < 110) continue
        inkR++
        // 改动：RGB 均值差
        const ai = pa + x * ca
        const d = (Math.abs(after.data[ai] - r) + Math.abs(after.data[ai + 1] - g) + Math.abs(after.data[ai + 2] - b)) / 3
        if (d > DIFF_T) erasedR++
      }
    }
    const M = inkR ? +(erasedR / inkR * 100).toFixed(2) : 0
    per[f] = { inkR, erasedR, M }
    totInk += inkR; totErased += erasedR
    console.log(`${f}  框外印刷墨迹 ${inkR}px  被擦 ${erasedR}px  M=${M}%`)
  }

  const Mavg = totInk ? +(totErased / totInk * 100).toFixed(2) : 0
  const Mmax = Math.max(...PAGES.map((p) => per[p].M))
  const pass = PAGES.every((p) => per[p].M <= M_FROZEN) && Mavg <= M_FROZEN
  console.log(`\n══ G16 汇总 ══  加权M=${Mavg}%  最大页M=${Mmax}%  冻结值=${M_FROZEN}%  ${pass ? 'PASS' : 'FAIL'}`)
  fs.mkdirSync('verify-out', { recursive: true })
  fs.writeFileSync(path.join('verify-out', 'g16-survival.json'), JSON.stringify({ Mavg, Mmax, Mfrozen: M_FROZEN, per }, null, 2))

  const out = {
    id: 'G16', pass,
    M1: per['annot1.png'].M, M2: per['annot2.png'].M, M3: per['annot3.png'].M, M4: per['annot4.png'].M,
    Mavg, Mmax, Mfrozen: M_FROZEN,
    detail: PAGES.map((p) => `${p.replace('.png', '')}:${per[p].M}%(${per[p].erasedR}/${per[p].inkR})`).join(' '),
  }
  console.log('GUARD ' + JSON.stringify(out))
}
main().catch((e) => { console.error(e); process.exit(1) })
