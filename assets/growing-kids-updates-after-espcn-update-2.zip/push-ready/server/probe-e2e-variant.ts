/**
 * probe-e2e-variant.ts —— 对比两种最终 mask 在独立真值上的表现：
 *   A = 纯词级 state===1（当前生产 'word' 路径）
 *   B = 词级 state===1 ∩ hybrid 异常墨迹区（证据与 / AND-of-evidence）
 * 指标（独立真值 GT）：手写框召回（框内墨迹被标 ≥0.5）、框外印刷墨迹被擦比例 M。
 * 目的：验证"与 hybrid 交集"能否在不掉召回的前提下压低印刷误擦（M）。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

process.env.CHARH_FIX = 'on'
process.env.CHARH_COORD = 'on'
process.env.SAUVOLA_WIN_K = process.env.SAUVOLA_WIN_K || '4'

function lumDiffErased(before: Buffer, after: Buffer, W: number, H: number, ch: number) {
  // 返回 [changedMask:Uint8Array, beforeLuma:Uint8Array]
  const gB = new Uint8Array(W * H), gA = new Uint8Array(W * H)
  for (let i = 0, p = 0; i < W * H; i++, p += ch) {
    gB[i] = Math.round(0.299 * before[p] + 0.587 * before[p + 1] + 0.114 * before[p + 2])
    gA[i] = Math.round(0.299 * after[p] + 0.587 * after[p + 1] + 0.114 * after[p + 2])
  }
  const chg = new Uint8Array(W * H)
  for (let i = 0; i < W * H; i++) chg[i] = Math.abs(gA[i] - gB[i]) > 25 ? 1 : 0
  return { chg, gB }
}

const clamp = (v: number, lo: number, hi: number) => (v < lo ? lo : v > hi ? hi : v)
// 共识判定：复用判别器的特征与权重，但 state=1 要求 分数高 且 多判别特征同时明显升高
const HI = { heightCV: 0.40, strokeCV: 0.60, strokeDev: 0.80, baseDev: 0.50, ascDev: 0.45, spacingCV: 0.80, intensityStd: 0.18, slantDeg: 18 }
const SEP = ['heightCV', 'strokeCV', 'intensityStd', 'slantDeg', 'spacingCV'] as const
const W = { heightCV: 0.50, strokeCV: 0.15, strokeDev: 0.05, baseDev: 0.0, ascDev: 0.0, spacingCV: 0.08, intensityStd: 0.12, slantDeg: 0.05, anchor: 0.05 }
function wscore(f: any): number {
  let s = 0
  for (const k of ['heightCV','strokeCV','strokeDev','baseDev','ascDev','spacingCV','intensityStd','slantDeg'] as const)
    s += W[k] * clamp(f[k] / HI[k], 0, 1)
  return s
}

async function runMode(label: string, decide: (f: any) => boolean, gt: Record<string, Box[]>) {
  console.log(`\n══════ ${label} ══════`)
  console.log('page    hwRecall  printInk(R)  erased(R)  M%')
  let totHw = 0, totHwN = 0, totMden = 0, totMnum = 0
  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const Wd = meta.width!, Hd = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: Wd, height: Hd, isGray: false }, { charHFix: true })
    const wres = discriminateWords({ ctx })
    const seg = await buildHandwritingMask(srcBuf, '', {}, { eraseMode: 'hybrid', allowVlm: false })
    const s = ctx.work.w / Wd
    const wl = Buffer.alloc(Wd * Hd)
    for (let y = 0; y < ctx.work.h; y++) {
      const oy0 = Math.floor(y / s), oy1 = Math.min(Hd - 1, Math.floor((y + 1) / s))
      for (let x = 0; x < ctx.work.w; x++) {
        // 只在"词被判为确信手写"时才取像素；decide 决定该词是否确信手写
        const lab = wres.labels[y * ctx.work.w + x]
        if (lab !== 1) continue
        // 找该像素所属词，用其 decide 结果
        const ox0 = Math.floor(x / s), ox1 = Math.min(Wd - 1, Math.floor((x + 1) / s))
        for (let oy = oy0; oy <= oy1; oy++) for (let ox = ox0; ox <= ox1; ox++) wl[oy * Wd + ox] = 1
      }
    }
    // 按词级 decide 重算 mask：遍历词，整词一个状态
    const final = Buffer.alloc(Wd * Hd)
    for (const wd of wres.words) {
      if (!decide(wd.f)) continue
      const x0 = Math.round(wd.x0 / s), y0 = Math.round(wd.y0 / s), x1 = Math.round(wd.x1 / s), y1 = Math.round(wd.y1 / s)
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) final[y * Wd + x] = 255
    }
    const { inpaint, blendWithMask } = await import('./src/image/handwriting-mask')
    const inpainted = await inpaint(srcBuf, 'adaptive', { ...seg.mask, data: final, width: Wd, height: Hd, coverage: 0 } as any)
    const merged = await blendWithMask(srcBuf, inpainted, { ...seg.mask, data: final, width: Wd, height: Hd, coverage: 0 } as any)
    const before = await sharp(srcBuf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const after = await sharp(merged).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const { chg, gB } = lumDiffErased(before.data, after.data, Wd, Hd, before.info.channels)
    const boxes = gt[f]
    const inBox = new Uint8Array(Wd * Hd)
    for (const b of boxes) for (let y = Math.max(0, b.y0 - 5); y <= Math.min(Hd - 1, b.y1 + 5); y++) for (let x = Math.max(0, b.x0 - 5); x <= Math.min(Wd - 1, b.x1 + 5); x++) inBox[y * Wd + x] = 1
    let hwHit = 0, hwN = 0
    const hwBoxes = boxes.filter(b => b.cls === 'handwriting')
    for (const b of hwBoxes) {
      let ink = 0, marked = 0
      for (let y = b.y0; y <= b.y1; y++) for (let x = b.x0; x <= b.x1; x++) { const i = y * Wd + x; if (gB[i] < 128) { ink++; if (final[i]) marked++ } }
      hwN++; if (ink > 0 && marked / ink >= 0.5) hwHit++
    }
    let inkR = 0, erasedR = 0
    for (let i = 0; i < Wd * Hd; i++) {
      if (inBox[i]) continue
      const ch = before.info.channels, r = before.data[i * ch], g = before.data[i * ch + 1], bl = before.data[i * ch + 2]
      if (gB[i] < 200 && !(r > 140 && g < 110 && bl < 110)) { inkR++; if (chg[i]) erasedR++ }
    }
    const M = inkR ? (erasedR / inkR * 100) : 0
    totHw += hwHit; totHwN += hwN; totMden += inkR; totMnum += erasedR
    console.log(`${f}  ${hwHit}/${hwN}      ${inkR}     ${erasedR}      ${M.toFixed(2)}%`)
    void wl
  }
  console.log(`汇总：手写召回 ${totHw}/${totHwN} | M = ${(totMnum / Math.max(1, totMden) * 100).toFixed(2)}%`)
}

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  // A：当前（整词 state===1，即判别器原始三态）
  await runMode('A 当前（state===1 即确信手写）', () => true, gt)
  // C1：共识 TAU=0.50 NH=2
  await runMode('C1 共识 TAU=0.50 NH=2', (f) => wscore(f) >= 0.50 && SEP.filter(k => clamp(f[k] / HI[k], 0, 1) >= 0.5).length >= 2, gt)
  // C2：共识 TAU=0.55 NH=2
  await runMode('C2 共识 TAU=0.55 NH=2', (f) => wscore(f) >= 0.55 && SEP.filter(k => clamp(f[k] / HI[k], 0, 1) >= 0.5).length >= 2, gt)
  // C3：共识 TAU=0.55 NH=3
  await runMode('C3 共识 TAU=0.55 NH=3', (f) => wscore(f) >= 0.55 && SEP.filter(k => clamp(f[k] / HI[k], 0, 1) >= 0.5).length >= 3, gt)
}

main().catch((e) => { console.error(e); process.exit(1) })
