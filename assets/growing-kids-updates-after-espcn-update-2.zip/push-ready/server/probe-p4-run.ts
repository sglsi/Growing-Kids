/**
 * probe-p4-run.ts —— 「长直游程」判据的判别力实测（为 P4-2 定系数取证）
 * ==========================================================================
 * 背景（见 verify-out/p4-strip.json）：
 *   插图合并块 **100% 通过尺寸闸门**，却在"文本段落豁免"被放行（带周期墨带 ⇒ 被当成多行文本）。
 *   那条豁免规则证不出"这是文本"，必须换成有量纲的判据。
 *
 * 候选判据：**最长连续墨迹游程 / charH**（maxRunK）。
 *   物理依据：单个字符的水平连续笔画长度受**字宽**约束（≈charH 量级）；
 *   而直线/表格框/示意图轮廓是跨字尺度的一笔画，长度远超单字。
 *   这是**字符模型 vs 线条模型**的分界，与具体内容无关。
 *
 * 本探针要回答：印刷文本 имеет 多大的 maxRunK？图示组织呢？（对照组比较，不是说阈值）
 *   - 印刷组：本页所有"文本行型"合并块（bh ∈ [0.7, 2]×charH，且不与任何 GT 框相交）
 *   - 插图组：与 GT 插图框相交最大的合并块
 *   - 手写组：与 GT 手写框相交最大的合并块
 *
 * ⚠️ 阈值系数本身不由此拟合；本探针只提供"两者是否落在不同量级"的证据。
 *
 * 用法：npx tsx probe-p4-run.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { estimateCharH, dilateRect } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
const RLSA_H_K = 1.2, RLSA_V_K = 0.3

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

/** 块内最长水平/垂直连续墨迹游程（在**原始 ink** 上算，与 blockStats 同口径） */
function maxRun(c: { x0: number; y0: number; x1: number; y1: number }, ink: Uint8Array, w: number): number {
  let best = 0
  for (let y = c.y0; y <= c.y1; y++) {
    const b = y * w
    let run = 0
    for (let x = c.x0; x <= c.x1; x++) {
      if (ink[b + x]) { run++; if (run > best) best = run } else run = 0
    }
  }
  for (let x = c.x0; x <= c.x1; x++) {
    let run = 0
    for (let y = c.y0; y <= c.y1; y++) {
      if (ink[y * w + x]) { run++; if (run > best) best = run } else run = 0
    }
  }
  return best
}

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const P: Record<string, number[]> = { print: [], illus: [], hand: [] }
  const rowsOut: unknown[] = []

  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
    const { w, h, ink } = ctx.work
    const s = W / w
    const ch = estimateCharH(ink, w, h)

    const merged = dilateRect(ink, w, h, Math.max(3, Math.round(RLSA_H_K * ch)), Math.max(3, Math.round(RLSA_V_K * ch)))
    // 8 邻域连通域
    const lab = new Int32Array(w * h).fill(-1)
    const comps: Array<{ x0: number; y0: number; x1: number; y1: number; n: number }> = []
    for (let i = 0; i < w * h; i++) {
      if (!merged[i] || lab[i] >= 0) continue
      const id = comps.length
      let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1, n = 0
      const st = [i]; lab[i] = id
      while (st.length) {
        const p = st.pop()!
        const py = (p / w) | 0, px = p % w
        n++
        if (px < x0) x0 = px; if (px > x1) x1 = px
        if (py < y0) y0 = py; if (py > y1) y1 = py
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const ny = py + dy, nx = px + dx
          if (ny < 0 || nx < 0 || ny >= h || nx >= w) continue
          const q = ny * w + nx
          if (merged[q] && lab[q] < 0) { lab[q] = id; st.push(q) }
        }
      }
      comps.push({ x0, y0, x1, y1, n })
    }
    const cs = comps.filter((c) => c.n >= 4)

    const inIl = (c: typeof cs[0]) => gt[f].some((b) => b.cls === 'illustration' &&
      !(Math.round(c.x1 * s) < b.x0 || Math.round(c.x0 * s) > b.x1 || Math.round(c.y1 * s) < b.y0 || Math.round(c.y0 * s) > b.y1))
    const inHw = (c: typeof cs[0]) => gt[f].some((b) => b.cls === 'handwriting' &&
      !(Math.round(c.x1 * s) < b.x0 || Math.round(c.x0 * s) > b.x1 || Math.round(c.y1 * s) < b.y0 || Math.round(c.y0 * s) > b.y1))

    console.log(`\n════ ${f}  charH=${ch}  合并块 ${cs.length} ════`)
    for (const [name, pred] of [['印刷', (c: typeof cs[0]) => !inIl(c) && !inHw(c)], ['插图', inIl], ['手写', inHw]] as const) {
      const grp = cs.filter((c) => pred(c) && (('bh', c.y1 - c.y0 + 1) >= 0 && true))
        .map((c) => ({ k: +(((c.y1 - c.y0 + 1) / ch)).toFixed(2), bw: +(((c.x1 - c.x0 + 1) / ch)).toFixed(2), bh: +(((c.y1 - c.y0 + 1) / ch)).toFixed(2), r: +((maxRun(c, ink, w) / ch)).toFixed(2) }))
      const rs = grp.map((g) => g.r).sort((a, b) => a - b)
      const q = (p: number) => rs.length ? rs[Math.min(rs.length - 1, Math.floor(p * (rs.length - 1)))] : 0
      console.log(`  ${name} n=${String(grp.length).padStart(3)}  maxRun/charH: p50=${q(.5)} p75=${q(.75)} p90=${q(.9)} p95=${q(.95)} max=${q(1)}`)
      for (const g of grp) if (name === '印刷') P.print.push(g.r); else if (name === '插图') P.illus.push(g.r); else P.hand.push(g.r)
    }
    rowsOut.push({ file: f, charH: ch, nBlocks: cs.length })
  }

  console.log('\n══════ 全集合并 ══════')
  const out: Record<string, unknown> = {}
  for (const k of ['print', 'illus', 'hand'] as const) {
    const rs = P[k].slice().sort((a, b) => a - b)
    const q = (p: number) => rs.length ? rs[Math.min(rs.length - 1, Math.floor(p * (rs.length - 1)))] : 0
    console.log(`  ${k.padEnd(6)} n=${String(rs.length).padStart(4)}  p50=${q(.5)} p75=${q(.75)} p90=${q(.9)} p95=${q(.95)} max=${q(1)}`)
    // 各候选系数下的混淆（**观察用**，不是最终阈值来源）
    for (const T of [2, 2.5, 3, 3.5, 4]) {
      const overP = P.print.filter((v) => v >= T).length, overI = P.illus.filter((v) => v >= T).length, overH = P.hand.filter((v) => v >= T).length
      if (k === 'print') console.log(`      K=${T}: 印刷触发 ${overP}/${P.print.length}  插图触发 ${overI}/${P.illus.length}  手写触发 ${overH}/${P.hand.length}`)
    }
    out[k] = { n: rs.length, p50: q(.5), p90: q(.9), p95: q(.95), max: q(1) }
  }
  rowsOut.push({ summary: out })
  fs.writeFileSync('verify-out/p4-run.json', JSON.stringify(rowsOut, null, 2))
  console.log('\n→ verify-out/p4-run.json')
}
main().catch((e) => { console.error(e); process.exit(1) })
