/**
 * probe-word-diag.ts —— 诊断：逐词 dump 判别器特征 + 状态 + GT 类别。
 * 生产同参（charHFix=true）。产出 verify-out/word-diag.json 供 Python 分析分离度。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

process.env.CHARH_FIX = 'on'
process.env.CHARH_COORD = 'on'
process.env.SAUVOLA_WIN_K = process.env.SAUVOLA_WIN_K || '4'

function clsOf(boxes: Box[], x0: number, y0: number, x1: number, y1: number): 'hw' | 'illus' | 'print' {
  const wa = Math.max(1, (x1 - x0) * (y1 - y0))
  let best = 0, cls: 'hw' | 'illus' | 'print' = 'print'
  for (const b of boxes) {
    const ox = Math.max(0, Math.min(x1, b.x1) - Math.max(x0, b.x0))
    const oy = Math.max(0, Math.min(y1, b.y1) - Math.max(y0, b.y0))
    const sh = (ox * oy) / wa
    if (sh > best) { best = sh; cls = b.cls === 'handwriting' ? 'hw' : b.cls === 'illustration' ? 'illus' : 'print' }
  }
  return best >= 0.3 ? cls : 'print'
}

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const rows: any[] = []
  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false }, { charHFix: true })
    const wres = discriminateWords({ ctx })
    const s = ctx.work.w / W
    for (const wd of wres.words) {
      const x0 = Math.round(wd.x0 / s), y0 = Math.round(wd.y0 / s)
      const x1 = Math.round(wd.x1 / s), y1 = Math.round(wd.y1 / s)
      const cls = clsOf(gt[f], x0, y0, x1, y1)
      rows.push({
        page: f, cls,
        state: wd.state,
        score: +wd.score.toFixed(3),
        n: wd.n,
        heightCV: +wd.f.heightCV.toFixed(3),
        strokeCV: +wd.f.strokeCV.toFixed(3),
        strokeDev: +wd.f.strokeDev.toFixed(3),
        baseDev: +wd.f.baseDev.toFixed(3),
        ascDev: +wd.f.ascDev.toFixed(3),
        spacingCV: +wd.f.spacingCV.toFixed(3),
        intensityStd: +wd.f.intensityStd.toFixed(3),
        slantDeg: +wd.f.slantDeg.toFixed(3),
      })
    }
  }
  fs.mkdirSync('verify-out', { recursive: true })
  fs.writeFileSync('verify-out/word-diag.json', JSON.stringify(rows, null, 2))
  // 控制台摘要：三类的特征均值与 state 分布
  const clsK = ['print', 'hw', 'illus'] as const
  console.log('\n══ 逐词诊断摘要（生产参数，4 页）══')
  for (const c of clsK) {
    const rs = rows.filter(r => r.cls === c)
    if (!rs.length) continue
    const avg = (k: string) => (rs.reduce((a, r) => a + r[k], 0) / rs.length).toFixed(3)
    const st = [0, 0, 0]; rs.forEach(r => st[r.state]++)
    console.log(`\n[${c}] n=${rs.length}  state0/1/2=${st.join('/')}`)
    console.log(`  heightCV=${avg('heightCV')} strokeCV=${avg('strokeCV')} strokeDev=${avg('strokeDev')} baseDev=${avg('baseDev')} ascDev=${avg('ascDev')} spacingCV=${avg('spacingCV')} intensityStd=${avg('intensityStd')} slantDeg=${avg('slantDeg')} score=${avg('score')}`)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
