/**
 * P4-3 归因探针：把「图形域保护」的粒度从"合并块"下沉到"细连通域"，是否成立？
 * ==============================================================================
 * 背景（verify-out/p4-run.json 已确立的事实）：
 *   maxRun/charH 在 **印刷（max 1.45）** 与 **插图（min 3.48）** 之间是真空档，
 *   但 **手写（p50 1.63, p90 6.14）与插图大面积重叠**。
 *
 * ⇒ 在"整个合并块"这个粒度上使用该判据必然两败俱伤（已实测：救 4 个插图要付 9 个手写）。
 *   但合并块粒度不是唯一选择：**保护范围可以是"命中判据的那些连通域本身"**，
 *   而不是"包含它们的整个合并块"。
 *
 * 本探针回答一件事：**在细 CC 粒度上，该判据能否精确锁住插图本体而不吃掉手写？**
 *   covIllus = 插图框内墨迹像素落在 runK>=K 的 CC 中的比例  → 越高越好（保护到位）
 *   covHand  = 手写框内墨迹像素落在 runK>=K 的 CC 中的比例  → 越低越好（不误伤）
 *
 * 判据成立的门槛：covIllus 显著高于 covHand（例如 ≥0.6 vs ≤0.2）。
 * 注意这里用的是**像素覆盖率**而非块计数——因为最终被擦的是像素。
 *
 * GT 仅用于归因，不参与任何设计决策。阈值系数亦不由此拟合。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { estimateCharH } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
const K_LIST = [1.5, 2.0, 2.5, 3.0, 4.0]

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const rowsOut: unknown[] = []
  const A: Record<string, { iInk: number; iCov: number; hInk: number; hCov: number }> = {}
  for (const k of K_LIST) A[k.toFixed(1)] = { iInk: 0, iCov: 0, hInk: 0, hCov: 0 }

  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
    const { w, h, ink } = ctx.work
    const s = W / w
    const ch = estimateCharH(ink, w, h)

    // ── 原始 ink 上的 8 邻域连通域（细粒度，不打合并）──────────────────────
    const lab = new Int32Array(w * h).fill(-1)
    const comps: Array<{ x0: number; y0: number; x1: number; y1: number; n: number }> = []
    for (let i = 0; i < w * h; i++) {
      if (!ink[i] || lab[i] >= 0) continue
      const id = comps.length
      let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1, n = 0
      const st = [i]; lab[i] = id
      while (st.length) {
        const p = st.pop()!
        const py = (p / w) | 0, px = p % w
        n++
        if (px < x0) x0 = px; if (px > x1) x1 = px
        if (py < y0) y0 = py; if (py > y1) y1 = py
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const ny = py + dy, nx = px + dx
          if (ny < 0 || nx < 0 || ny >= h || nx >= w) continue
          const q = ny * w + nx
          if (ink[q] && lab[q] < 0) { lab[q] = id; st.push(q) }
        }
      }
      comps.push({ x0, y0, x1, y1, n })
    }

    // 逐 CC 的 maxRun/charH
    const runK = new Float32Array(comps.length)
    for (let ci = 0; ci < comps.length; ci++) {
      const c = comps[ci]
      let best = 0
      for (let y = c.y0; y <= c.y1; y++) {
        const b = y * w
        let run = 0
        for (let x = c.x0; x <= c.x1; x++) {
          if (lab[b + x] === ci) { run++; if (run > best) best = run } else run = 0
        }
      }
      for (let x = c.x0; x <= c.x1; x++) {
        let run = 0
        for (let y = c.y0; y <= c.y1; y++) {
          if (lab[y * w + x] === ci) { run++; if (run > best) best = run } else run = 0
        }
      }
      runK[ci] = best / ch
    }

    /** 给定 GT 类别，统计框内墨迹像素数，以及落在 runK>=K 的 CC 中的像素数 */
    const scan = (want: 'illustration' | 'handwriting') => {
      let tot = 0
      const cov: Record<string, number> = {}
      for (const k of K_LIST) cov[k.toFixed(1)] = 0
      for (const bx of gt[f]) {
        if (bx.cls !== want) continue
        const x0 = Math.max(0, Math.floor(bx.x0 / s)), x1 = Math.min(w - 1, Math.ceil(bx.x1 / s))
        const y0 = Math.max(0, Math.floor(bx.y0 / s)), y1 = Math.min(h - 1, Math.ceil(bx.y1 / s))
        for (let y = y0; y <= y1; y++) {
          const b = y * w
          for (let x = x0; x <= x1; x++) {
            if (!ink[b + x]) continue
            tot++
            const ci = lab[b + x]
            if (ci < 0) continue
            for (const k of K_LIST) if (runK[ci] >= k) cov[k.toFixed(1)]++
          }
        }
      }
      return { tot, cov }
    }

    const il = scan('illustration'), hd = scan('handwriting')
    console.log(`\n════ ${f}  charH=${ch.toFixed(1)}  细CC ${comps.length} ════`)
    for (const k of K_LIST) {
      const key = k.toFixed(1)
      console.log(`  K=${key}  插图覆盖 ${(il.cov[key] / Math.max(1, il.tot) * 100).toFixed(1)}% (${il.cov[key]}/${il.tot})` +
        `   手写覆盖 ${(hd.cov[key] / Math.max(1, hd.tot) * 100).toFixed(1)}% (${hd.cov[key]}/${hd.tot})`)
      A[key].iInk += il.tot; A[key].iCov += il.cov[key]
      A[key].hInk += hd.tot; A[key].hCov += hd.cov[key]
    }
    rowsOut.push({ file: f, charH: +ch.toFixed(1), nCC: comps.length, illusInk: il.tot, handInk: hd.tot,
      illusCov: il.cov, handCov: hd.cov })
  }

  console.log('\n══════ 全集合并（像素级）══════')
  const summary: Record<string, unknown> = {}
  for (const k of K_LIST) {
    const a = A[k.toFixed(1)]
    const ci = a.iCov / Math.max(1, a.iInk), chh = a.hCov / Math.max(1, a.hInk)
    console.log(`  K=${k.toFixed(1)}  covIllus=${(ci * 100).toFixed(1)}%  covHand=${(chh * 100).toFixed(1)}%  分离度=${(ci - chh).toFixed(3)}`)
    summary[k.toFixed(1)] = { covIllus: +ci.toFixed(3), covHand: +chh.toFixed(3), gap: +(ci - chh).toFixed(3) }
  }
  rowsOut.push({ summary })
  fs.writeFileSync('verify-out/p4-line.json', JSON.stringify(rowsOut, null, 2))
  console.log('\n→ verify-out/p4-line.json')
}
main().catch((e) => { console.error(e); process.exit(1) })
