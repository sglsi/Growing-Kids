/**
 * probe-p4-gap.ts —— 行内相邻块间隙的自然分布：词边界从哪切？
 * ==========================================================================
 * 动机：词切分现在用 `wordGap = max(0.6×charH, 1.8×medGap)`，这两个系数没有来源，
 *      结果词宽 13.6×charH（实测），等于"半行"，混合了印刷与手写 ⇒
 *      手写信号被稀释 ⇒ 稳健相对打分后召回掉到 8/34。
 *
 * 本探针只做一件事：把行内相邻连通域的**间隙直方图**打出来，看有没有自然双峰。
 *   排版事实：字间距 << 词间距，两者量级差数倍 → 间隙分布应当双峰。
 *   若有双峰 → 用 **Otsu**（本项目既有标准件）在间隙直方图上自动取谷/中点，
 *              阈值来源变成 L1（本页统计量），替换两个无来源常数。
 *   若无双峰 → 说明"词"不是可靠的分析单位，须换"行内亚线段"等其他粒度。
 *
 * ⚠️ 不读任何标注，纯版面统计。
 *
 * 用法：npx tsx probe-p4-gap.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']

/** Otsu 双峰阈值（返回索引）。hist 长度需 ≥2。 */
function otsu(hist: number[]): number {
  const n = hist.reduce((a, b) => a + b, 0)
  if (!n) return 0
  let sum = 0
  for (let i = 0; i < hist.length; i++) sum += i * hist[i]
  let wB = 0, sumB = 0, best = 0, bestV = -1
  for (let i = 0; i < hist.length; i++) {
    wB += hist[i]
    if (!wB) continue
    const wF = n - wB
    if (!wF) break
    sumB += i * hist[i]
    const mB = sumB / wB, mF = (sum - sumB) / wF
    const v = wB * wF * (mB - mF) * (mB - mF)
    if (v > bestV) { bestV = v; best = i }
  }
  return best
}

async function main() {
  const rowsOut: unknown[] = []
  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
    const { w, h, ink } = ctx.work
    const wres = discriminateWords({ ctx })
    const ch = Number(wres.debug.charH) || 12

    // 复算行内排序（与判别器同口径：按质心 X 排序）
    // 注：判别器没导出 rows，这里用 words 的并集不可行，改为直接重做一次最简行切分
    // ——用 estimateCharH 的投影带切行，再在每行内按 x 排序统计间隙。
    // 逐行统计相邻墨段之间的空白宽度（gap>0 才计）
    const gaps: number[] = []
    for (let y = 0; y < h; y++) {
      const b = y * w
      let lastInkEnd = -1, gapStart = -1
      for (let x = 0; x < w; x++) {
        if (ink[b + x]) {
          if (gapStart >= 0 && lastInkEnd >= 0) gaps.push(x - lastInkEnd - 1)
          gapStart = -1
          lastInkEnd = x
        } else if (gapStart < 0) gapStart = x
      }
    }

    const nz = gaps.filter((g) => g > 0)
    nz.sort((a, b) => a - b)
    const q = (p: number) => nz.length ? nz[Math.min(nz.length - 1, Math.floor(p * (nz.length - 1)))] : 0
    // 直方图（1px 一 bin，截到 40px）
    const NB = 41
    const hist = new Array(NB).fill(0)
    for (const g of nz) hist[Math.min(NB - 1, g)]++
    const t = otsu(hist.slice(1)) + 1   // 跳过 bin0（g=0 不计）
    console.log(`\n════ ${f}  charH=${ch}  间隙样本 ${nz.length} ════`)
    console.log(`  间隙px p10=${q(.1)} p25=${q(.25)} p50=${q(.5)} p75=${q(.75)} p90=${q(.9)} p95=${q(.95)} p99=${q(.99)}  /charH: ${(q(.5)/ch).toFixed(2)} ${(q(.9)/ch).toFixed(2)}`)
    console.log(`  Otsu 阈值 = ${t}px = ${(t / ch).toFixed(2)}×charH`)
    let acc = ''
    for (let i = 1; i < NB; i++) acc += `${i}:${hist[i]} `
    console.log(`  直方图(px:count) ${acc}`)
    rowsOut.push({ file: f, charH: ch, n: nz.length, otsuPx: t, otsuK: +(t / ch).toFixed(2), p50: q(.5), p90: q(.9) })
  }
  fs.writeFileSync('verify-out/p4-gap.json', JSON.stringify(rowsOut, null, 2))
  console.log('\n→ verify-out/p4-gap.json')
}
main().catch((e) => { console.error(e); process.exit(1) })
