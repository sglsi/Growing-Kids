/**
 * probe-t7-improve.ts —— T7 验证：像素级保护加「笔画粗细闸门」（erodeSurvivalRate）
 * ==========================================================================
 * 内联复刻 protectPrintGeneric 的核心（CC + print 占比），但增加 esr 闸门：
 *   粗笔（手写，esr 高）→ 保留；细线高印刷占比（印刷字）→ 剔除；其余保留。
 * 目标：无 GT 框条件下，也能精准剔印刷、留手写，逼近 P1（框外专用）的效果。
 * 扫描 ESR_HAND ∈ {0.05, 0.08, 0.11}，看黑笔页（annot3/4）框内召回回升程度。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { buildEraseMask } from './src/image/erase-mask-policy'
import { protectPrintGeneric } from './src/image/handwriting-mask'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1', 'annot2', 'annot3', 'annot4']
const INK_LUM = 200, DILATE = 5
const PRINT_RATIO_MIN = 0.6

function fill(b: any, arr: Uint8Array, W: number, H: number, d: number) {
  for (let y = Math.max(0, b.y0 - d); y <= Math.min(H - 1, b.y1 + d); y++)
    for (let x = Math.max(0, b.x0 - d); x <= Math.min(W - 1, b.x1 + d); x++) arr[y * W + x] = 1
}

// 4邻域连通域（BFS）
function ccs(mask: Uint8Array, W: number, H: number): number[][] {
  const label = new Int32Array(W * H).fill(-1)
  const out: number[][] = []
  let cur = 0
  for (let s = 0; s < W * H; s++) {
    if (mask[s] <= 127 || label[s] >= 0) continue
    const stack = [s]; label[s] = cur; const px: number[] = []
    while (stack.length) {
      const i = stack.pop()!; px.push(i); const x = i % W, y = (i / W) | 0
      const nb = [i - 1, i + 1, i - W, i + W]
      const xok = [x > 0, x < W - 1, true, true], yok = [true, true, y > 0, y < H - 1]
      for (let k = 0; k < 4; k++) {
        const j = nb[k]; if (!xok[k] || !yok[k]) continue
        if (mask[j] > 127 && label[j] < 0) { label[j] = cur; stack.push(j) }
      }
    }
    out.push(px); cur++
  }
  return out
}

function improvedMask(mask: Buffer, W: number, H: number, print: Uint8Array, esrHand: number): Buffer {
  const m = new Uint8Array(W * H)
  for (let i = 0; i < W * H; i++) m[i] = mask[i] > 127 ? 255 : 0
  const comps = ccs(m, W, H)
  for (const px of comps) {
    if (px.length < 4) continue
    let tot = 0, alive = 0, pr = 0
    for (const i of px) {
      const x = i % W, y = (i / W) | 0
      const up = y > 0 && m[i - W] === 255, dn = y < H - 1 && m[i + W] === 255
      const lf = x > 0 && m[i - 1] === 255, rt = x < W - 1 && m[i + 1] === 255
      tot++; if (up && dn && lf && rt) alive++; if (print[i]) pr++
    }
    const esr = alive / tot, pRatio = pr / tot
    const keep = esr >= esrHand || pRatio < PRINT_RATIO_MIN
    if (!keep) for (const i of px) m[i] = 0
  }
  return Buffer.from(m)
}

async function main() {
  const gt: Record<string, any[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  for (const f of PAGES) {
    const fp = `${f}.png`
    const src = await sharp(`${DIR}/${f}-clean.png`).png().toBuffer()
    const meta = await sharp(src).metadata(); const W = meta.width!, H = meta.height!
    const seg = await buildHandwritingMask(src, '', {}, { eraseMode: 'hybrid', allowVlm: false })
    const mask = await buildEraseMask(src, seg.mask, 'word')
    const wd = mask.data as Buffer
    const charH = Number((mask.debug as any)?.wordCharH) || 0
    const prot = await protectPrintGeneric(src, mask, { charH }); const pd = prot.data as Buffer

    const before = await sharp(src).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const cb = before.info.channels
    const allBoxes = gt[fp]
    const handBoxes = allBoxes.filter((b) => String(b.cls ?? '').toLowerCase().includes('hand'))
    const inAny = new Uint8Array(W * H); for (const b of allBoxes) fill(b, inAny, W, H, DILATE)
    const inHand = new Uint8Array(W * H); for (const b of handBoxes) fill(b, inHand, W, H, 0)
    const ink = new Uint8Array(W * H); const print = new Uint8Array(W * H)
    for (let y = 0; y < H; y++) {
      const pb = y * W * cb
      for (let x = 0; x < W; x++) {
        const bi = pb + x * cb, r = before.data[bi], g = before.data[bi + 1], b = before.data[bi + 2]
        const luma = 0.299 * r + 0.587 * g + 0.114 * b
        const chroma = Math.max(r, g, b) - Math.min(r, g, b)
        if (luma < INK_LUM && !(r > 140 && g < 110 && b < 110)) ink[y * W + x] = 1
        if (chroma <= 42 && luma <= 190 && !(r > 140 && g < 110 && b < 110)) print[y * W + x] = 1
      }
    }
    const metrics = (name: string, m: Uint8Array) => {
      let Rink = 0, er = 0, Hink = 0, h = 0
      for (let i = 0; i < W * H; i++) {
        if (!ink[i]) continue
        if (!inAny[i]) { Rink++; if (m[i] > 127) er++ }
        if (inHand[i]) { Hink++; if (m[i] > 127) h++ }
      }
      console.log(`    ${name}: M=${(er / Rink * 100).toFixed(2)}%  框内召回=${(h / Hink * 100).toFixed(1)}%`)
    }
    console.log(`\n══ ${fp} ══`)
    metrics('word      ', wd as any)
    metrics('protect默认', pd as any)
    for (const esr of [0.05, 0.08, 0.11]) {
      const imp = improvedMask(wd, W, H, print, esr)
      metrics(`improved${esr}`, imp as any)
    }
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
