/**
 * probe-word-fp.ts —— 诊断：词级判别器把多少**印刷**内容判成 state=1（确信手写）
 * 生产同参（charHFix=true → CHARH_FIX/COORD=on + SAUVOLA_WIN_K=4）。
 * 按 GT 把词分类：与手写框交 >30% = hw 词；与插图框交 >30% = 插图词；否则 = 印刷词。
 * 输出：三类词的 state 分布 + 印刷墨迹被标 state=1 的比例（= 用户看到的"印刷被擦"）。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

// 生产同参：buildEraseMask 内部即如此启用
process.env.CHARH_FIX = 'on'
process.env.CHARH_COORD = 'on'
process.env.SAUVOLA_WIN_K = process.env.SAUVOLA_WIN_K || '4'

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  let tot = { hw: [0, 0, 0], print: [0, 0, 0], illus: [0, 0, 0] } // [state0,state1,state2] 词数
  let ink = { hw: [0, 0], print: [0, 0], illus: [0, 0] }          // [总墨px, state1墨px]
  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false }, { charHFix: true })
    const wres = discriminateWords({ ctx })
    const s = ctx.work.w / W
    const boxes = gt[f]
    const clsOf = (x0: number, y0: number, x1: number, y1: number): 'hw' | 'illus' | 'print' => {
      const wa = Math.max(1, (x1 - x0) * (y1 - y0))
      let best = 0, cls: 'hw' | 'illus' | 'print' = 'print'
      for (const b of boxes) {
        const ox = Math.max(0, Math.min(x1, b.x1) - Math.max(x0, b.x0))
        const oy = Math.max(0, Math.min(y1, b.y1) - Math.max(y0, b.y0))
        const sh = (ox * oy) / wa
        if (sh > best) { best = sh; cls = b.cls === 'handwriting' ? 'hw' : b.cls === 'illustration' ? 'illus' : 'print' }
      }
      return best >= 0.3 ? cls : 'print'
    }
    for (const wd of wres.words) {
      // 工作尺度 → 原图尺度
      const x0 = Math.round(wd.x0 / s), y0 = Math.round(wd.y0 / s)
      const x1 = Math.round(wd.x1 / s), y1 = Math.round(wd.y1 / s)
      const c = clsOf(x0, y0, x1, y1)
      tot[c][wd.state]++
      const n1 = wd.state === 1 ? wd.n : 0
      ink[c][0] += wd.n; ink[c][1] += n1
    }
  }
  const name = ['印刷( PRINT)', '手写( HW)  ', '插图(ILLUS)']
  const order: Array<'print' | 'hw' | 'illus'> = ['print', 'hw', 'illus']
  console.log('\n══ 词级判别器三态分布（生产参数，4 页合计）══')
  console.log('类别          state0(印刷) state1(手写) state2(疑虑) |  墨迹被标state=1比例')
  for (const k of order) {
    const t = tot[k], ik = ink[k]
    const share = ik[0] ? (ik[1] / ik[0] * 100).toFixed(1) : '0'
    console.log(`${name[k]}   ${String(t[0]).padStart(8)}  ${String(t[1]).padStart(8)}  ${String(t[2]).padStart(8)}   |  ${ik[1]}/${ik[0]} = ${share}%`)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
