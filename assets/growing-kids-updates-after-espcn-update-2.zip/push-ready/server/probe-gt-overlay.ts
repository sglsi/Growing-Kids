/**
 * probe-gt-overlay.ts —— 把"模型的 handwriting mask"与"人工 GT 框"摆在一起对照
 * ==========================================================================
 * 目的：回答一个方法论疑问 —— "有没有把识别结果和人工标注比对？"
 *   本探针正面回答：比了，并且可视化出来。
 *
 * 图层（颜色约定与 GT 一致：红=手写 / 蓝=插图，勿再用蓝画手写——曾因此被误读为插图框）：
 *   底图                 = 原图（-clean.png，标注笔已擦）
 *   红框                 = 人工 handwriting 框（GT 真相）
 *   蓝框                 = 人工 illustration 框（GT 真相）
 *   绿填充               = 模型 handwriting mask 落在 handwriting GT 框【内】= 命中（正确检出）
 *   橙填充               = 模型 handwriting mask 落在【所有 GT 框外】= 过覆盖（会烧到印刷体）
 *   紫填充               = 模型 handwriting mask 落在插图框内（误碰插图）
 *
 * 关键点：本图展示的是"模型到底把哪些像素判成了手写"，不是改动热力图。
 *   改动热力图（probe-gt-e2e 的 -diff）的红色是"被改动的像素在框外"，与本图红填充同源但不同义。
 *
 * 用法：npx tsx probe-gt-overlay.ts
 *   可选 E2E_MASK=word|hybrid+word|seg 切换 mask 来源
 */
import sharp from 'sharp'
import * as fs from 'fs'
import * as path from 'path'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const OUT = `${DIR}/e2e`
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

async function buildMask(f: string, W: number, H: number) {
  const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
  const mode = (process.env.E2E_MODE as 'hybrid' | 'union' | 'color') || 'hybrid'
  const maskSrc = process.env.E2E_MASK || 'hybrid+word'
  const seg = await buildHandwritingMask(srcBuf, '', {}, { eraseMode: mode, allowVlm: false })
  let mask = seg.mask
  if (mask.width !== W || mask.height !== H) throw new Error(`${f} mask尺寸不符`)
  if (maskSrc === 'seg') return mask
  const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
  const wres = discriminateWords({ ctx })
  const s = ctx.work.w / W
  const wl = new Uint8Array(W * H)
  for (let y = 0; y < ctx.work.h; y++) {
    const oy0 = Math.floor(y / s), oy1 = Math.min(H - 1, Math.floor((y + 1) / s))
    for (let x = 0; x < ctx.work.w; x++) {
      if (wres.labels[y * ctx.work.w + x] !== 1) continue
      const ox0 = Math.floor(x / s), ox1 = Math.min(W - 1, Math.floor((x + 1) / s))
      for (let oy = oy0; oy <= oy1; oy++) for (let ox = ox0; ox <= ox1; ox++) wl[oy * W + ox] = 1
    }
  }
  const merged = Buffer.alloc(W * H)
  let cov = 0
  for (let i = 0; i < W * H; i++) { const t = maskSrc === 'word' ? wl[i] : (mask.data[i] > 127 || wl[i]); if (t) { merged[i] = 255; cov++ } }
  return { ...mask, data: merged, coverage: cov / (W * H) }
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true })
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const mask = await buildMask(f, W, H)
    const raw = await sharp(srcBuf).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const cb = raw.info.channels
    const boxes = gt[f] || []
    const hwBoxes = boxes.filter((b) => b.cls === 'handwriting')
    const ilBoxes = boxes.filter((b) => b.cls === 'illustration')

    // 标记每个像素是否在 手写框 / 插图框 内（2px 扩张，与 diff 探针同口径）
    const inHw = new Uint8Array(W * H), inIl = new Uint8Array(W * H)
    const stamp = (b: Box, buf: Uint8Array) => {
      for (let y = Math.max(0, b.y0 - 2); y <= Math.min(H - 1, b.y1 + 2); y++)
        for (let x = Math.max(0, b.x0 - 2); x <= Math.min(W - 1, b.x1 + 2); x++) buf[y * W + x] = 1
    }
    hwBoxes.forEach((b) => stamp(b, inHw)); ilBoxes.forEach((b) => stamp(b, inIl))

    const vis = Buffer.from(raw.data) // 复制底图
    // 墨迹掩码（亮度<128，与 probe-gt-eval.boxInkStats 同口径）：命中=框内墨迹被 flag 覆盖的比例
    const ink = new Uint8Array(W * H)
    for (let i = 0; i < W * H; i++) {
      const lum = 0.299 * raw.data[i * cb] + 0.587 * raw.data[i * cb + 1] + 0.114 * raw.data[i * cb + 2]
      if (lum < 128) ink[i] = 1
    }
    let mInHw = 0, mOutAll = 0, mTot = 0
    for (let i = 0; i < W * H; i++) {
      const p = i * cb
      if (mask.data[i] > 127) {
        mTot++
        if (inHw[i]) { mInHw++; vis[p] = Math.min(255, vis[p] * 0.4 + 30); vis[p + 1] = Math.min(255, vis[p + 1] * 0.4 + 150); vis[p + 2] = vis[p + 2] * 0.4 }       // 绿：落在手写框内
        else if (!inIl[i]) { mOutAll++; vis[p] = Math.min(255, vis[p] * 0.4 + 200); vis[p + 1] = Math.min(255, vis[p + 1] * 0.4 + 110); vis[p + 2] = vis[p + 2] * 0.4 } // 橙：落在所有框外（过覆盖）
        else { vis[p] = Math.min(255, vis[p] * 0.4 + 120); vis[p + 1] = vis[p + 1] * 0.4; vis[p + 2] = vis[p + 2] * 0.4 + 60 }                                       // 紫：落在插图框内（误碰插图）
      }
    }
    // 画框：手写=蓝，插图=青
    const draw = (b: Box, col: [number, number, number]) => {
      for (let t = -1; t <= 1; t++) {
        for (let x = b.x0; x <= b.x1; x++) { for (const y of [b.y0, b.y1]) { const yy = y + t; if (yy < 0 || yy >= H) continue; const p = (yy * W + x) * cb; vis[p] = col[0]; vis[p + 1] = col[1]; vis[p + 2] = col[2] } }
        for (let y = b.y0; y <= b.y1; y++) { for (const x of [b.x0, b.x1]) { const xx = x + t; if (xx < 0 || xx >= W) continue; const p = (y * W + xx) * cb; vis[p] = col[0]; vis[p + 1] = col[1]; vis[p + 2] = col[2] } }
      }
    }
    hwBoxes.forEach((b) => draw(b, [230, 30, 30]))   // 红框=手写（与 GT 约定一致）
    ilBoxes.forEach((b) => draw(b, [30, 80, 255]))   // 蓝框=插图

    const tag = (process.env.E2E_MASK || 'hybrid+word')
    await sharp(vis, { raw: { width: W, height: H, channels: cb } }).png().toFile(`${OUT}/${f.replace('.png', '')}-overlay-${tag}.png`)

    // 逐手写框的"命中率"：框内墨迹被 mask 覆盖的比例（与 probe-gt-eval.boxInkStats 同口径）
    const perBox = hwBoxes.map((b) => {
      let inkN = 0, hitN = 0
      for (let y = b.y0; y <= b.y1; y++) for (let x = b.x0; x <= b.x1; x++) { const j = y * W + x; if (!ink[j]) continue; inkN++; if (mask.data[j] > 127) hitN++ }
      return inkN ? hitN / inkN : 0
    })
    const recalled = perBox.filter((s) => s >= 0.5).length
    console.log(`${f}: mask覆盖${(mask.coverage * 100).toFixed(1)}% | 框内命中墨迹px ${mInHw} | 框外过覆盖 ${mOutAll}px(${(mOutAll / (W * H) * 100).toFixed(2)}%) | 手写框命中(masked ink) ${recalled}/${hwBoxes.length}`)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
