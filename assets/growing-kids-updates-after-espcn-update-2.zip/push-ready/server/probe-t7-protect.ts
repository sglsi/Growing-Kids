/**
 * probe-t7-protect.ts —— T7 实验：对 word mask 套 protectPrintGeneric 的效果
 * ==========================================================================
 * 验证假设：T7 的 M 来自被误判为手写的"手写体印刷字"（低彩度暗墨迹）。
 *   protectPrintGeneric 按连通域粒度剔除"印刷字域"（print 占比≥0.6），
 *   应只剔印刷、不动蓝笔/彩色手写。
 *
 * 对比（均用 mask 口径，不跑 inpaint，与 probe-t7-attrib 同口径）：
 *   M_word / M_protect    —— 框外印刷墨迹被擦比例（越小越好，目标 ≤2.0%）
 *   recall_word / recall_protect —— 手写框内墨迹被擦覆盖比例（越高越好，不能塌）
 *   protectedPx / protInHand —— 被保护掉的像素数 / 其中落在手写框内（=误剔真手写）
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { buildEraseMask } from './src/image/erase-mask-policy'
import { protectPrintGeneric } from './src/image/handwriting-mask'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1', 'annot2', 'annot3', 'annot4']
const INK_LUM = 200, DILATE = 5

function fill(b: any, arr: Uint8Array, W: number, H: number, d: number) {
  for (let y = Math.max(0, b.y0 - d); y <= Math.min(H - 1, b.y1 + d); y++)
    for (let x = Math.max(0, b.x0 - d); x <= Math.min(W - 1, b.x1 + d); x++) arr[y * W + x] = 1
}

async function main() {
  const gt: Record<string, any[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  // 先打印 cls 分布以确认手写框字段
  for (const f of PAGES) {
    const clss = gt[`${f}.png`].map((b) => b.cls)
    const uniq = [...new Set(clss)]
    console.log(`  ${f} cls 分布:`, uniq, ' 总数', clss.length)
  }
  for (const f of PAGES) {
    const fp = `${f}.png`
    const src = await sharp(`${DIR}/${f}-clean.png`).png().toBuffer()
    const meta = await sharp(src).metadata(); const W = meta.width!, H = meta.height!
    const seg = await buildHandwritingMask(src, '', {}, { eraseMode: 'hybrid', allowVlm: false })
    const mask = await buildEraseMask(src, seg.mask, 'word')
    const wd = mask.data as Buffer
    const charH = Number((mask.debug as any)?.wordCharH) || 0
    const prot = await protectPrintGeneric(src, mask, { charH })
    const pd = prot.data as Buffer

    const before = await sharp(src).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const cb = before.info.channels
    const allBoxes = gt[fp]
    const handBoxes = allBoxes.filter((b) => String(b.cls ?? '').toLowerCase().includes('hand') || String(b.cls ?? '').toLowerCase().includes('hw'))
    const inAny = new Uint8Array(W * H); for (const b of allBoxes) fill(b, inAny, W, H, DILATE)
    const inHand = new Uint8Array(W * H); for (const b of handBoxes) fill(b, inHand, W, H, 0)
    const ink = new Uint8Array(W * H)
    for (let y = 0; y < H; y++) {
      const pb = y * W * cb
      for (let x = 0; x < W; x++) {
        const bi = pb + x * cb, r = before.data[bi], g = before.data[bi + 1], b = before.data[bi + 2]
        const luma = 0.299 * r + 0.587 * g + 0.114 * b
        if (luma < INK_LUM && !(r > 140 && g < 110 && b < 110)) ink[y * W + x] = 1
      }
    }
    let Rink = 0, wEr = 0, pEr = 0, Hink = 0, wH = 0, pH = 0, protPx = 0, protInHand = 0
    for (let i = 0; i < W * H; i++) {
      if (ink[i]) {
        if (!inAny[i]) { Rink++; if (wd[i] > 127) wEr++; if (pd[i] > 127) pEr++ }
        if (inHand[i]) { Hink++; if (wd[i] > 127) wH++; if (pd[i] > 127) pH++ }
      }
      if (wd[i] > 127 && pd[i] <= 127) { protPx++; if (inHand[i]) protInHand++ }
    }
    console.log(`\n══ ${fp} (charH=${charH}) ══`)
    console.log(`  M:        word=${(wEr / Rink * 100).toFixed(2)}%  protect=${(pEr / Rink * 100).toFixed(2)}%  (Rink=${Rink})`)
    console.log(`  手写召回:  word=${(wH / Hink * 100).toFixed(1)}%  protect=${(pH / Hink * 100).toFixed(1)}%  (Hink=${Hink})`)
    console.log(`  被保护像素=${protPx}  误剔真手写(在手写框内)=${protInHand} (${(protInHand / protPx * 100 || 0).toFixed(1)}%)`)
    const wCov = Array.from(wd).reduce((s, v) => s + (v > 127 ? 1 : 0), 0)
    console.log(`  word覆盖=${wCov}px  protect覆盖=${Array.from(pd).reduce((s, v) => s + (v > 127 ? 1 : 0), 0)}px`)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
