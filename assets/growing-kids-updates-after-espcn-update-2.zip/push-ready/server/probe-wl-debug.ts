/**
 * 词级判别器 · 图形域判据实测（用数据定闸门，不靠猜）。
 * 对每类真值框（插图/手写）按工作尺度计算区域统计，输出分布，
 * 据以设定"图形域剥离"的阈值。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { blockStats, regionBands, type CC } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
const WORK_MAX = 800

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

function fmt(a: number[]) {
  if (!a.length) return '-'
  const s = a.slice().sort((x, y) => x - y)
  return `min=${s[0].toFixed(2)} med=${s[s.length >> 1].toFixed(2)} max=${s[s.length - 1].toFixed(2)}`
}

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const acc: Record<string, Record<string, number[]>> = {}
  const push = (cls: string, k: string, v: number) => {
    acc[cls] ??= {}
    acc[cls][k] ??= []
    acc[cls][k].push(v)
  }

  for (const f of PAGES) {
    const buf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(buf).metadata()
    const W = meta.width!, H = meta.height!
    const s = WORK_MAX / Math.max(W, H)
    const ctx = await buildDocContext(buf, { width: W, height: H, isGray: false })
    const { w, h, ink } = ctx.work
    const charH = Math.max(1, ctx.layout.charH || 1)
    console.log(`\n${f} work=${w}x${h} charH=${charH.toFixed(1)}`)
    for (const b of gt[f]) {
      const c: CC = {
        x0: Math.max(0, Math.round(b.x0 * s)), y0: Math.max(0, Math.round(b.y0 * s)),
        x1: Math.min(w - 1, Math.round(b.x1 * s)), y1: Math.min(h - 1, Math.round(b.y1 * s)), n: 0,
      }
      const st = blockStats(c, ink, w, h, charH)
      const bd = regionBands(c, ink, w)
      push(b.cls, 'density', st.density)
      push(b.cls, 'iso', st.isoRatio)
      push(b.cls, 'maxRun/charH', st.maxRun / charH)
      push(b.cls, 'runCV', st.runCV)
      push(b.cls, 'cellMed', st.cellMedian)
      push(b.cls, 'cellCV', st.cellCV)
      push(b.cls, 'bands', bd.n)
      push(b.cls, 'spacing/charH', bd.medSpacing / charH)
    }
  }

  console.log('\n===== 按真值类别的区域统计分布 =====')
  for (const [cls, m] of Object.entries(acc)) {
    console.log(`\n[${cls}]  样本框数=${m['density'].length}`)
    for (const [k, v] of Object.entries(m)) console.log(`  ${k.padEnd(13)} ${fmt(v)}`)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
