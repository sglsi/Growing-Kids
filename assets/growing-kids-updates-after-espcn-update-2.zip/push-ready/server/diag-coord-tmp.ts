import * as fs from 'fs'
import { buildDocContext, estimateLayout } from './src/image/adaptive-stats'
async function main() {
  const files = ['/workspace/worksheet-test/annotated/annot1.png','/workspace/wrongq-test/page28.png','/workspace/charh-calib/calib_2480x3508_F96_V1.png','/workspace/charh-calib/calib_1700x2400_F65_V1.png']
  for (const f of files) {
    const buf = fs.readFileSync(f)
    const L = await estimateLayout(buf)
    const ctx = await buildDocContext(buf, { width: 1, height: 1, isGray: false } as any).catch(() => null)
    console.log(f.split('/').pop().padEnd(32), 'charH(orig)='+L.charH, 'charHWork='+L.charHWork, 'scale='+L.scale.toFixed(3),
      'win旧='+Math.min(64,Math.max(16,2*L.charH)), 'win新='+Math.min(64,Math.max(16,2*L.charHWork)))
  }
}
main()
