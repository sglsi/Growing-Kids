/**
 * probe-t7-protect2.ts —— T7 验证：框外专用印刷保护（P1）是否既能降 M 又不损框内召回
 * ==========================================================================
 * 方案 P1：finalMask = 框内用 wordMask（不保护，保留真手写召回）∪ 框外用 protect 后结果
 *   （production 无 GT 框，此处用 GT 框模拟"R 外=应保守、R 内=应擦手写"的语义，
 *    验证框外保护是否能纯净降 M 而不牵连框内。）
 * 同时扫描 protect 的 printRatioMin（0.6/0.8/0.9）看全局版在黑笔页的误剔收敛。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { buildEraseMask } from './src/image/erase-mask-policy'
import { protectPrintGeneric } from './src/image/handwriting-mask'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1', 'annot2', 'annot3', 'annot4']
const INK_LUM = 200, DILATE = 5

function fill(b: any, arr: Uint8Array, W: number, H: number, d: number) {
  for (let y = Math.max(0, b.y0 - d); y <= Math.min(H - 1, b.y1 + d); y++)
    for (let x = Math.max(0, b.x0 - d); x <= Math.min(W - 1, b.x1 + d); x++) arr[y * W + x] = 1
}

async function main() {
  const gt: Record<string, any[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  for (const f of PAGES) {
    const fp = `${f}.png`
    const src = await sharp(`${DIR}/${f}-clean.png`).png().toBuffer()
    const meta = await sharp(src).metadata(); const W = meta.width!, H = meta.height!
    const seg = await buildHandwritingMask(src, '', {}, { eraseMode: 'hybrid', allowVlm: false })
    const mask = await buildEraseMask(src, seg.mask, 'word')
    const wd = mask.data as Buffer
    const charH = Number((mask.debug as any)?.wordCharH) || 0
    const prot = await protectPrintGeneric(src, mask, { charH })
    const pd = prot.data as Buffer

    const before = await sharp(src).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const cb = before.info.channels
    const allBoxes = gt[fp]
    const handBoxes = allBoxes.filter((b) => String(b.cls ?? '').toLowerCase().includes('hand'))
    const inAny = new Uint8Array(W * H); for (const b of allBoxes) fill(b, inAny, W, H, DILATE)
    const inHand = new Uint8Array(W * H); for (const b of handBoxes) fill(b, inHand, W, H, 0)
    const ink = new Uint8Array(W * H)
    for (let y = 0; y < H; y++) {
      const pb = y * W * cb
      for (let x = 0; x < W; x++) {
        const bi = pb + x * cb, r = before.data[bi], g = before.data[bi + 1], b = before.data[bi + 2]
        const luma = 0.299 * r + 0.587 * g + 0.114 * b
        if (luma < INK_LUM && !(r > 140 && g < 110 && b < 110)) ink[y * W + x] = 1
      }
    }
    // P1: 框内用 word，框外用 prot
    const p1 = Buffer.from(wd)
    for (let i = 0; i < W * H; i++) if (!inHand[i]) p1[i] = pd[i]

    const metrics = (name: string, m: Buffer) => {
      let Rink = 0, er = 0, Hink = 0, h = 0
      for (let i = 0; i < W * H; i++) {
        if (!ink[i]) continue
        if (!inAny[i]) { Rink++; if (m[i] > 127) er++ }
        if (inHand[i]) { Hink++; if (m[i] > 127) h++ }
      }
      console.log(`    ${name}: M=${(er / Rink * 100).toFixed(2)}%  框内召回=${(h / Hink * 100).toFixed(1)}%`)
    }
    console.log(`\n══ ${fp} (charH=${charH}) ══`)
    metrics('word     ', wd)
    metrics('protect  ', pd)
    metrics('P1框外专用', p1)
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
