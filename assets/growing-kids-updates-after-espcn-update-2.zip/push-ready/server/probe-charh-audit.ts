/**
 * probe-charh-audit.ts —— 字高标尺三方审计（v21.4 · P0-5 证据工具）
 * ==================================================================
 * 为什么要有这个文件（这不是又一个探针，是给"自适应"的地基装校验器件）：
 *
 * 所有自适应参数都以「字高 charH」为标尺：Sauvola 窗口 = 2×charH、红笔膨胀半径 = k_r×medH、
 * 背景归一化结构元 = SE_SCALE×medH/2、行切分间隙阈值 = charH×1.2……
 * **标尺错了，所有"自适应"都只是把错误按比例放大**。v21.1 复核发现：同一张 page28.png，
 * 三条口径给出的字高相差 10 倍（详见《去手写-自适应实施方案-复核报告-v21.4.md》）。
 *
 * 本探针用三条**互相独立**的路径测同一张图，判定标尺是否可信：
 *   ① estimateCharMetrics（生产 L3 口径，报 medH / rowPitch / strokeWidth / conf）
 *   ② 全分辨率连通域高度众数（不降采样、不依赖行聚类）
 *   ③ 行投影自相关主周期 ÷1.8（行距 → 字身；已用 ASCII 目视交叉校验过两型图）
 * 判据：① 与 ②③ 的比值应在 ~1.0±0.3；显著 >1 说明①的**行聚类失效**（多栏/大块跨行）。
 *
 * 用法：
 *   npx tsx probe-charh-audit.ts                 # 三方对比表
 *   CHARH_INTERNALS=1 npx tsx probe-charh-audit.ts   # 附带 ① 的内部分步量（定位用）
 * 输出：verify-out/charh-audit.json
 */
import * as fs from 'fs'
import sharp from 'sharp'
import {
  estimateCharMetrics, otsuThreshold, connectedComponents, closeInk3x3,
  quantileSorted, median, LAYOUT_MAX_SIDE,
} from './src/image/image-layout'

const FILES: { file: string; tag: string }[] = [
  { file: '/workspace/wrongq-test/page28.png', tag: 'page28 报纸' },
  { file: '/workspace/wrongq-test/page29.png', tag: 'page29 报纸' },
  { file: '/workspace/wrongq-test/page30.png', tag: 'page30 报纸' },
  { file: '/workspace/wrongq-test/page31.png', tag: 'page31 报纸' },
  { file: '/workspace/wrongq-test/case3-photo.png', tag: 'case3 拍照' },
  { file: '/workspace/worksheet-test/annotated/annot1.png', tag: 'annot1 物理卷' },
  { file: '/workspace/worksheet-test/annotated/annot2.png', tag: 'annot2 物理卷' },
  { file: '/workspace/worksheet-test/annotated/annot3.png', tag: 'annot3 物理卷' },
  { file: '/workspace/worksheet-test/annotated/annot4.png', tag: 'annot4 物理卷' },
]

/** Otsu（双峰平台中点） */
function otsu(hist: number[], N: number): number {
  let sum = 0
  for (let t = 0; t < 256; t++) sum += t * hist[t]
  let sumB = 0, wB = 0, maxVar = 0
  const plateau: number[] = []
  for (let t = 0; t < 256; t++) {
    wB += hist[t]
    if (!wB) continue
    const wF = N - wB
    if (!wF) break
    sumB += t * hist[t]
    const mB = sumB / wB, mF = (sum - sumB) / wF
    const v = wB * wF * (mB - mF) ** 2
    if (v > maxVar * 1.0000001) { maxVar = v; plateau.length = 0; plateau.push(t) }
    else if (v >= maxVar * 0.9999999) plateau.push(t)
  }
  return plateau.length ? plateau[plateau.length >> 1] : 127
}

function modeInRange(hist: Map<number, number>, lo: number, hi: number): number {
  let best = 0, bestC = 0
  for (let v = lo; v <= hi; v++) {
    let c = 0
    for (let d = -1; d <= 1; d++) c += hist.get(v + d) ?? 0
    if (c > bestC) { bestC = c; best = v }
  }
  return bestC > 0 ? best : 0
}

/** CHARH_INTERNALS=1 时复现 metricsFromGray 的分步量，用于定位行聚类失效点 */
async function dumpInternals(file: string) {
  const meta = await sharp(file).metadata()
  const W0 = meta.width!, H0 = meta.height!
  const scale0 = Math.min(1, LAYOUT_MAX_SIDE / Math.max(W0, H0))
  const w = Math.round(W0 * scale0), h = Math.round(H0 * scale0)
  const raw = await sharp(file).resize(w, h, { fit: 'fill' }).grayscale().raw().toBuffer()
  const gray = new Uint8Array(raw.buffer, raw.byteOffset, raw.length)
  const n = w * h
  const thr = otsuThreshold(gray, n)
  const ink = new Uint8Array(n)
  for (let i = 0; i < n; i++) if (gray[i] < thr) ink[i] = 1
  const inkC = closeInk3x3(ink, w, h)
  const { comps } = connectedComponents(inkC, w, h, false)
  const blocks = comps.filter((c) => c.n >= 4 && c.x1 - c.x0 < w * 0.9 && c.y1 - c.y0 < h * 0.3)
  const heights = blocks.map((c) => c.y1 - c.y0 + 1).sort((a, b) => a - b)
  const hInit = Math.max(3, quantileSorted(heights, 0.25))
  const sorted = blocks.slice().sort((a, b) => (a.y0 + a.y1) / 2 - (b.y0 + b.y1) / 2)
  const groups: (typeof blocks)[] = [[sorted[0]]]
  for (let i = 1; i < sorted.length; i++) {
    const prev = groups[groups.length - 1]
    const last = prev[prev.length - 1]
    const prevY = (last.y0 + last.y1) / 2
    const y = (sorted[i].y0 + sorted[i].y1) / 2
    if (y - prevY > Math.max(2, hInit * 1.2)) groups.push([sorted[i]])
    else prev.push(sorted[i])
  }
  const rows = groups.filter((g) => {
    const xL = Math.min(...g.map((b) => b.x0))
    const xR = Math.max(...g.map((b) => b.x1))
    return xR - xL >= w * 0.12 || g.length >= 3
  })
  const rowHeights = rows.map((g) => Math.max(...g.map((b) => b.y1)) - Math.min(...g.map((b) => b.y0)) + 1)
  // ⭐ 相邻质心间隙分布 —— 行媒体各聚合能否切开的直接证据
  const gaps: number[] = []
  for (let i = 1; i < sorted.length; i++) {
    gaps.push((sorted[i].y0 + sorted[i].y1) / 2 - (sorted[i - 1].y0 + sorted[i - 1].y1) / 2)
  }
  gaps.sort((a, b) => a - b)
  const rowHMed = rows.length ? median(rowHeights) : 0
  const binW = Math.max(2, Math.round(hInit))
  const bins = new Int32Array(Math.floor(heights[heights.length - 1] / binW) + 1)
  for (const hh of heights) bins[Math.min(bins.length - 1, Math.floor(hh / binW))]++
  let peakIdx = 0, peakCnt = -1
  for (let i = 0; i < bins.length; i++) {
    const c = (i > 0 ? bins[i - 1] : 0) + bins[i] + (i < bins.length - 1 ? bins[i + 1] : 0)
    if (c > peakCnt) { peakCnt = c; peakIdx = i }
  }
  const inPeak = heights.filter((hh) => Math.floor(hh / binW) === peakIdx)
  const peakMed = inPeak.length ? median(inPeak) : quantileSorted(heights, 0.3)
  const raw1 = rowHMed > peakMed * 2.2 ? rowHMed * 0.85 : (peakMed * 1.2 + rowHMed * 0.9) / 2
  console.log(`   [内部] work ${w}x${h} thr=${thr} | 块 ${comps.length}→${blocks.length}`)
  console.log(`   [内部] 块高 p25=${hInit} 切行阈值=${Math.max(2, hInit * 1.2)} | 相邻质心间隙 p50=${gaps[gaps.length >> 1]?.toFixed(2)} p90=${quantileSorted(gaps, 0.9).toFixed(2)} p99=${quantileSorted(gaps, 0.99).toFixed(2)}`)
  console.log(`   [内部] 组 ${groups.length} → 行 ${rows.length} | 行高中位=${rowHMed} 最大=${Math.max(...rowHeights)} | 峰medH=${peakMed}`)
  console.log(`   [内部] medHWork raw=${raw1.toFixed(1)} cap(h*0.08=${(h * 0.08).toFixed(1)}) → ${Math.max(4, Math.min(h * 0.08, raw1)).toFixed(1)}`)
}

async function main() {
  const rows: Record<string, unknown>[] = []
  const showInternals = process.env.CHARH_INTERNALS === '1'
  for (const { file, tag } of FILES) {
    if (!fs.existsSync(file)) { console.log(`SKIP ${tag}（文件不存在）`); continue }
    const { data, info } = await sharp(file).removeAlpha().grayscale().raw().toBuffer({ resolveWithObject: true })
    const W = info.width, H = info.height, N = W * H
    const g = new Uint8Array(data.buffer, data.byteOffset, N)

    const hist = new Array(256).fill(0)
    for (let i = 0; i < N; i++) hist[g[i]]++
    const T = otsu(hist, N)
    const dark = new Uint8Array(N)
    for (let i = 0; i < N; i++) dark[i] = g[i] < T ? 1 : 0

    // ① 生产 L3 口径
    // ⚠️ P0-5e（v21.5）：审计的必须是**生产路径实际使用的标尺**。去手写生产路径
    //   `buildEraseMask('word')` 经 `buildDocContext({charHFix:true})` 内部启用
    //   `CHARH_FIX=on`（修正后的字高标尺 = 四路取小，已用合成标定集 96 图验证）。
    //   若用默认 off 度量，测到的是被三方审计判为"虚大"的旧标尺 → G14 必然软失败，
    //   而该标尺并无任何生产路径在使用（疑罪从无原则下生产只用修正标尺）。
    //   故此处显式在 CHARH_FIX=on 下度量 ①，与 ②③ 两路独立参考对照，验证生产标尺正确。
    const _prevFix = process.env.CHARH_FIX
    process.env.CHARH_FIX = 'on'
    const m = await estimateCharMetrics(fs.readFileSync(file))
    if (_prevFix === undefined) delete process.env.CHARH_FIX; else process.env.CHARH_FIX = _prevFix

    // ② 全分辨率 CC 高度众数
    const label = new Int32Array(N).fill(-1)
    const hHist = new Map<number, number>()
    const stack: number[] = []
    let nCC = 0
    for (let s = 0; s < N; s++) {
      if (!dark[s] || label[s] >= 0) continue
      let x0 = W, x1 = 0, y0 = H, y1 = 0, cnt = 0
      label[s] = nCC; stack.push(s)
      while (stack.length) {
        const q = stack.pop()!
        const qx = q % W, qy = (q / W) | 0
        if (qx < x0) x0 = qx
        if (qx > x1) x1 = qx
        if (qy < y0) y0 = qy
        if (qy > y1) y1 = qy
        cnt++
        const nb = [q - 1, q + 1, q - W, q + W]
        for (const u of nb) {
          if (u < 0 || u >= N || label[u] >= 0 || !dark[u]) continue
          if (Math.abs((u % W) - qx) > 1) continue
          label[u] = nCC; stack.push(u)
        }
      }
      const cw = x1 - x0 + 1, ch = y1 - y0 + 1
      if (ch >= 5 && ch <= 120 && cnt < N * 0.02 && cw / ch > 0.05 && cw / ch < 20) {
        hHist.set(ch, (hHist.get(ch) ?? 0) + 1)
      }
      nCC++
    }
    const ccMode = modeInRange(hHist, 5, 120)

    // ③ 行投影自相关 → 行距主周期
    const proj = new Float64Array(H)
    for (let y = 0; y < H; y++) {
      let c = 0
      const base = y * W
      for (let x = 0; x < W; x++) if (dark[base + x]) c++
      proj[y] = c
    }
    const mean = proj.reduce((a, b) => a + b, 0) / H
    const dev = new Float64Array(H)
    for (let y = 0; y < H; y++) dev[y] = proj[y] - mean
    let bestP = 0, bestCorr = -Infinity
    for (let p = 8; p <= Math.min(240, H >> 2); p++) {
      let c = 0
      for (let y = 0; y + p < H; y++) c += dev[y] * dev[y + p]
      c /= (H - p)
      if (c > bestCorr) { bestCorr = c; bestP = p }
    }
    const charFromPitch = Math.round(bestP / 1.8)
    // ⚠️ 判据纪律：③存在**半周期歧义**（力密排 Science 上自相关常锁到半行距），
    //    单个参考不足以定罪。只有当 ① 同时偏离 ② 与 ③ 两个独立参考 ≥1.6× 时才判 FAIL；
    //    两个参考互相打架时标记 WARN —— 宁可说"不知道"，也不谎报。
    const r2 = +(m.medH / (ccMode || 1)).toFixed(2)
    const r3 = +(m.medH / (charFromPitch || 1)).toFixed(2)
    const bothFar = r2 > 1.6 && r3 > 1.6
    const verdict = bothFar ? 'FAIL(行聚类失效)' : (r2 > 1.6 || r3 > 1.6) ? 'WARN(参考不一致)' : 'OK'

    console.log(`\n### ${tag}  ${W}x${H}`)
    if (showInternals) await dumpInternals(file)
    console.log(`   ①charMetrics medH=${m.medH.toFixed(1)} rowPitch=${m.rowPitch.toFixed(1)} conf=${m.confidence.toFixed(2)}`)
    console.log(`   ②CC高度众数=${ccMode}   ③行距主周期=${bestP} → 字身≈${charFromPitch}`)
    console.log(`   ⇒ ①/②=${r2}  ①/③=${r3}  ${verdict}`)

    rows.push({
      tag, size: `${W}x${H}`,
      '①medH(charMetrics)': +m.medH.toFixed(1),
      '①rowPitch': +m.rowPitch.toFixed(1),
      '①strokeW': +m.strokeWidth.toFixed(1),
      '①conf': +m.confidence.toFixed(2),
      '②CC众数': ccMode,
      '③主周期(行距)': bestP,
      '③推字身(p/1.8)': charFromPitch,
      '①/②比值': r2,
      '①/③比值': r3,
      verdict,
    })
  }
  console.log('\n══ 字高口径三方审计 ══')
  const cols = Object.keys(rows[0] ?? {})
  console.log(cols.join('\t'))
  for (const r of rows) console.log(cols.map((c) => String(r[c])).join('\t'))
  const bad = rows.filter((r) => r.verdict === 'FAIL(行聚类失效)')
  const warn = rows.filter((r) => r.verdict === 'WARN(参考不一致)')
  console.log(`\nGUARD ${JSON.stringify({
    pass: bad.length === 0, checked: rows.length,
    bad: bad.map((b) => b.tag), warn: warn.map((b) => b.tag),
  })}`)
  fs.writeFileSync('verify-out/charh-audit.json', JSON.stringify(rows, null, 2))
}
main().catch((e) => { console.error(e); process.exit(1) })
