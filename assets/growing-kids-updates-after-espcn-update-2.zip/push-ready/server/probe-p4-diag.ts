/**
 * probe-p4-diag.ts —— P4「插图受损」定位探针
 * ==========================================================================
 * 目的：回答一个**归因问题**——插图框里的损伤，究竟是
 *   (a) 词级通道把框**内部**的墨标成了手写；
 *   (b) 还是框**外**被标的手写经 mask 膨胀/羽化渗进框内。
 * 两者修法完全不同：(a) 改判别器，(b) 改 mask 后处理/收敛。
 *
 * 独立真值只用于**归因**，不用于调参（GT 协议：标注框只做验证）。
 *
 * 用法：npx tsx probe-p4-diag.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
const PAD = 2   // 与 probe-gt-e2e 的 inBox 外扩口径一致
const INK_T = 128

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const out: unknown[] = []

  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const raw = await sharp(srcBuf).removeAlpha().greyscale().raw().toBuffer()
    const gray = Uint8Array.from(raw)
    const inkAll = new Uint8Array(W * H)
    for (let i = 0; i < W * H; i++) inkAll[i] = gray[i] < INK_T ? 1 : 0

    const mode = (process.env.E2E_MODE as 'hybrid' | 'union' | 'color') || 'hybrid'
    const seg = await buildHandwritingMask(srcBuf, '', {}, { eraseMode: mode, allowVlm: false })
    const segMask = seg.mask

    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
    const wres = discriminateWords({ ctx })
    const s = ctx.work.w / W
    const wl = new Uint8Array(W * H)
    for (let y = 0; y < ctx.work.h; y++) {
      const oy0 = Math.floor(y / s), oy1 = Math.min(H - 1, Math.floor((y + 1) / s))
      for (let x = 0; x < ctx.work.w; x++) {
        if (wres.labels[y * ctx.work.w + x] !== 1) continue
        const ox0 = Math.floor(x / s), ox1 = Math.min(W - 1, Math.floor((x + 1) / s))
        for (let oy = oy0; oy <= oy1; oy++) for (let ox = ox0; ox <= ox1; ox++) wl[oy * W + ox] = 1
      }
    }

    console.log(`\n════ ${f}  ${W}x${H} ════`)
    console.log(`  debug=${JSON.stringify(wres.debug)}`)

    const diag: Record<string, unknown> = { file: f, charH: wres.debug.charH, boxes: [] }

    for (const b of gt[f]) {
      // 框内统计：以 PAD 外扩口径算 x0..x1
      const x0 = Math.max(0, b.x0 - PAD), x1 = Math.min(W - 1, b.x1 + PAD)
      const y0 = Math.max(0, b.y0 - PAD), y1 = Math.min(H - 1, b.y1 + PAD)
      let ink = 0, segIn = 0, wordIn = 0, unionIn = 0
      for (let y = y0; y <= y1; y++) {
        const base = y * W
        for (let x = x0; x <= x1; x++) {
          const i = base + x
          if (!inkAll[i]) continue
          ink++
          const a = segMask.data[i] > 127
          const c = wl[i] === 1
          if (a) segIn++
          if (c) wordIn++
          if (a || c) unionIn++
        }
      }
      // 归因：seg 独有的框内标记 vs word 独有的 vs 交集
      let bothIn = 0, segOnly = 0, wordOnly = 0
      for (let y = y0; y <= y1; y++) {
        const base = y * W
        for (let x = x0; x <= x1; x++) {
          const i = base + x
          if (!inkAll[i]) continue
          const a = segMask.data[i] > 127
          const c = wl[i] === 1
          if (a && c) bothIn++
          else if (a) segOnly++
          else if (c) wordOnly++
        }
      }
      const row = {
        cls: b.cls, x0: b.x0, y0: b.y0, x1: b.x1, y1: b.y1,
        ink,
        segShare: ink ? +(segIn / ink).toFixed(3) : 0,
        wordShare: ink ? +(wordIn / ink).toFixed(3) : 0,
        unionShare: ink ? +(unionIn / ink).toFixed(3) : 0,
        wordOnlyPx: wordOnly, segOnlyPx: segOnly, bothPx: bothIn,
      }
      ;(diag.boxes as unknown[]).push(row)
      if (b.cls === 'illustration') {
        console.log(`  [插图] (${b.x0},${b.y0})-(${b.x1},${b.y1}) 墨${ink}px  seg=${row.segShare} word=${row.wordShare}  ∪=${row.unionShare}  (word独有${wordOnly} seg独有${segOnly} 共有${bothIn})`)
      }
    }
    // 命中插图的词记录（state=1 且与插图框相交）
    const ch = Number(wres.debug.charH) || 1
    const hit = wres.words.filter((wd) => wd.state === 1 && gt[f].some((b) => b.cls === 'illustration' &&
      !(Math.round(wd.x1 / s) < b.x0 || Math.round(wd.x0 / s) > b.x1 || Math.round(wd.y1 / s) < b.y0 || Math.round(wd.y0 / s) > b.y1)))
    console.log(`  词级命中的印刷/插图框词数：${hit.length} / 词总数 ${wres.words.length}`)
    for (const wd of hit.slice(0, 12)) {
      console.log(`    score=${wd.score.toFixed(3)} (${Math.round(wd.x0 / s)},${Math.round(wd.y0 / s)})-(${Math.round(wd.x1 / s)},${Math.round(wd.y1 / s)}) nComp=${wd.nComp} ` +
        `hCV=${wd.f.heightCV.toFixed(2)} sCV=${wd.f.strokeCV.toFixed(2)} sDev=${wd.f.strokeDev.toFixed(2)} bDev=${wd.f.baseDev.toFixed(2)} aDev=${wd.f.ascDev.toFixed(2)} spCV=${wd.f.spacingCV.toFixed(2)} int=${wd.f.intensityStd.toFixed(3)}`)
    }
    // ★ 词级**尺度**分布：插图词 vs 手写词 vs 其余（印刷）
    const sh = (wd: typeof wres.words[0]) => +((wd.y1 - wd.y0 + 1) / ch).toFixed(2)
    const sw = (wd: typeof wres.words[0]) => +((wd.x1 - wd.x0 + 1) / ch).toFixed(2)
    const clsOf = (wd: typeof wres.words[0]) => {
      const cx = Math.round(((wd.x0 + wd.x1) / 2) * s), cy = Math.round(((wd.y0 + wd.y1) / 2) * s)
      if (gt[f].some((b) => b.cls === 'illustration' && cx >= b.x0 && cx <= b.x1 && cy >= b.y0 && cy <= b.y1)) return 'il'
      if (gt[f].some((b) => b.cls === 'handwriting' && cx >= b.x0 && cx <= b.x1 && cy >= b.y0 && cy <= b.y1)) return 'hw'
      return 'pr'
    }
    const grp = { hw: wres.words.filter((w) => clsOf(w) === 'hw'), il: wres.words.filter((w) => clsOf(w) === 'il'), pr: wres.words.filter((w) => clsOf(w) === 'pr') }
    const q = (a: number[], p: number) => { if (!a.length) return 0; const t = a.slice().sort((x, y) => x - y); return +t[Math.min(t.length - 1, Math.floor(p * (t.length - 1)))].toFixed(2) }
    console.log(`  —— 词级尺度（/charH=${ch}）——`)
    for (const k of ['hw', 'il', 'pr'] as const) {
      const A = grp[k].map(sh), B = grp[k].map(sw)
      console.log(`    ${k} n=${String(grp[k].length).padStart(3)}  h/charH p50=${q(A, .5)} p90=${q(A, .9)} max=${q(A, 1)}   w/charH p50=${q(B, .5)} p90=${q(B, .9)} max=${q(B, 1)}`)
    }
    // 尺度闸门候选：**判为手写的词**里，插图词 vs 手写词的尺度
    const flHw = grp.hw.filter((w) => w.state === 1), flIl = grp.il.filter((w) => w.state === 1)
    console.log(`    被判手写的词：手写 n=${flHw.length} h/charH p90=${q(flHw.map(sh), .9)} max=${q(flHw.map(sh), 1)}  |  插图 n=${flIl.length} h/charH p50=${q(flIl.map(sh), .5)} p90=${q(flIl.map(sh), .9)}`)
    ;(diag as Record<string, unknown>).nWords = wres.words.length
    ;(diag as Record<string, unknown>).nHwWords = wres.words.filter((w) => w.state === 1).length
    out.push(diag)
  }
  fs.writeFileSync('verify-out/p4-diag.json', JSON.stringify(out, null, 2))
  console.log('\n→ verify-out/p4-diag.json')
}
main().catch((e) => { console.error(e); process.exit(1) })
