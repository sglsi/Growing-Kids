/**
 * probe-t7-thresh.ts —— T7 扫描 protectPrintGeneric 的 printRatioMin 平衡点
 * ==========================================================================
 * 假设：误判「印刷词」是纯印刷（print 占比极高，≥0.9），黑笔手写词混白边（占比略低）。
 * 提高 printRatioMin 应能：仍剔印刷词（降 M）+ 放过黑笔手写（保召回）。
 * 量化每档：M(框外) / 框内召回 / 误剔真手写(手写框内被剔像素/总被剔像素)。
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { buildEraseMask } from './src/image/erase-mask-policy'
import { protectPrintGeneric } from './src/image/handwriting-mask'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1', 'annot2', 'annot3', 'annot4']
const INK_LUM = 200, DILATE = 5

function fill(b: any, arr: Uint8Array, W: number, H: number, d: number) {
  for (let y = Math.max(0, b.y0 - d); y <= Math.min(H - 1, b.y1 + d); y++)
    for (let x = Math.max(0, b.x0 - d); x <= Math.min(W - 1, b.x1 + d); x++) arr[y * W + x] = 1
}

async function main() {
  const gt: Record<string, any[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  for (const f of PAGES) {
    const fp = `${f}.png`
    const src = await sharp(`${DIR}/${f}-clean.png`).png().toBuffer()
    const meta = await sharp(src).metadata(); const W = meta.width!, H = meta.height!
    const seg = await buildHandwritingMask(src, '', {}, { eraseMode: 'hybrid', allowVlm: false })
    const mask = await buildEraseMask(src, seg.mask, 'word')
    const wd = mask.data as Buffer
    const charH = Number((mask.debug as any)?.wordCharH) || 0

    const before = await sharp(src).removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const cb = before.info.channels
    const allBoxes = gt[fp]
    const handBoxes = allBoxes.filter((b) => String(b.cls ?? '').toLowerCase().includes('hand'))
    const inAny = new Uint8Array(W * H); for (const b of allBoxes) fill(b, inAny, W, H, DILATE)
    const inHand = new Uint8Array(W * H); for (const b of handBoxes) fill(b, inHand, W, H, 0)
    const ink = new Uint8Array(W * H)
    for (let y = 0; y < H; y++) {
      const pb = y * W * cb
      for (let x = 0; x < W; x++) {
        const bi = pb + x * cb, r = before.data[bi], g = before.data[bi + 1], b = before.data[bi + 2]
        const luma = 0.299 * r + 0.587 * g + 0.114 * b
        if (luma < INK_LUM && !(r > 140 && g < 110 && b < 110)) ink[y * W + x] = 1
      }
    }
    const metrics = (name: string, m: Buffer) => {
      let Rink = 0, er = 0, Hink = 0, h = 0, prot = 0, protInHand = 0
      for (let i = 0; i < W * H; i++) {
        if (!ink[i]) continue
        if (!inAny[i]) { Rink++; if (m[i] > 127) er++ }
        if (inHand[i]) { Hink++; if (m[i] > 127) h++ }
        if (wd[i] > 127 && m[i] <= 127) { prot++; if (inHand[i]) protInHand++ }
      }
      const mVal = (er / Rink * 100).toFixed(2)
      const rec = (h / Hink * 100).toFixed(1)
      const mis = prot ? (protInHand / prot * 100).toFixed(1) : '0.0'
      console.log(`    ${name}: M=${mVal}%  框内召回=${rec}%  误剔真手写=${mis}%`)
    }
    console.log(`\n══ ${fp} ══`)
    metrics('word        ', wd)
    for (const prm of [0.6, 0.7, 0.8, 0.9]) {
      const prot = await protectPrintGeneric(src, mask, { charH, printRatioMin: prm })
      metrics(`protect${prm} `, prot.data as Buffer)
    }
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
