import * as fs from 'fs'
import sharp from 'sharp'
import { estimateCharMetrics, otsuThreshold, connectedComponents, LAYOUT_MAX_SIDE } from './src/image/image-layout'
async function main() {
  const files = process.argv.slice(2)
  for (const f of files) {
    const buf = fs.readFileSync(f)
    const m = await estimateCharMetrics(buf)
    const meta = await sharp(buf).metadata()
    const W0 = meta.width!, H0 = meta.height!
    const scale = Math.min(1, LAYOUT_MAX_SIDE / Math.max(W0, H0))
    const w = Math.round(W0 * scale), h = Math.round(H0 * scale)
    const raw = await sharp(buf).resize(w, h, { fit: 'fill' }).grayscale().raw().toBuffer()
    const gray = new Uint8Array(raw.buffer, raw.byteOffset, raw.length)
    const n = w * h
    const thr = otsuThreshold(gray, n)
    const ink = new Uint8Array(n)
    for (let i = 0; i < n; i++) if (gray[i] < thr) ink[i] = 1
    // 不闭合 CC（审计②同款过滤）
    const { comps } = connectedComponents(ink, w, h, false)
    const hist = new Map<number, number>()
    for (const c of comps) {
      const cw = c.x1 - c.x0 + 1, ch = c.y1 - c.y0 + 1
      if (ch >= 5 && ch <= 120 && c.n < n * 0.02 && cw / ch > 0.05 && cw / ch < 20) hist.set(ch, (hist.get(ch) ?? 0) + 1)
    }
    let um = 0, uc = 0
    for (const [v, c] of hist) {
      let s = 0
      for (let d = -1; d <= 1; d++) s += hist.get(v + d) ?? 0
      if (s > uc) { uc = s; um = v }
    }
    console.log(f.split('/').pop().padEnd(34), 'F=' + (f.match(/F(\d+)/)?.[1] ?? '?').padEnd(3),
      'medH=' + m.medH.toFixed(1), 'uMode=' + um, 'uCnt=' + uc, 'ratio_u=' + (um / +(f.match(/F(\d+)/)?.[1] ?? 1)).toFixed(2))
  }
}
main()
