import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'
async function main() {
  const files = ['annot1','annot2','annot3','annot4'].map(n=>`/workspace/worksheet-test/annotated/${n}-clean.png`)
  for (const f of files) {
    const buf = fs.readFileSync(f)
    const ctx = await buildDocContext(buf, { width: 1, height: 1, isGray: false } as any)
    const wres = discriminateWords({ ctx })
    const l = ctx.layout
    const s = wres.debug.wordStateCount as any
    let n1 = 0
    for (let i=0;i<wres.labels.length;i++) if (wres.labels[i]===1) n1++
    console.log(f.split('/').pop().padEnd(22),
      'charH='+(wres.debug.charH as number).toFixed(1),
      'L.charH='+l.charH, 'work='+l.charHWork,
      'state0='+(s?.['0']??0), 'state1='+(s?.['1']??0), 'state2='+(s?.['2']??0),
      'px1='+n1)
  }
}
main()
