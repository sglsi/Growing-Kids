/**
 * probe-charh-calib.ts —— 字高标尺**合成真值**标定（P0-5d）
 * =====================================================================
 * 与 probe-charh-audit.ts（真实图·三口径互证）互补：那边没有真值，只能
 * "用估计验证估计"；这边每个像素的字高都是**渲染时已知的**（字号 F），
 * 因此给出的是绝对误差，可直接证伪。
 *
 * 判定：
 *   medH / F ∈ [0.85, 1.20]  PASS（CJK 字面≈0.88em，允许略低于字号）
 *   medH / F ∈ (1.20, 1.60]  WARN（系统性偏高，标尺虚大）
 *   medH / F >  1.60         FAIL（虚大数倍 = 行聚类/大块污染，P0-5 战场）
 *
 * 用法：
 *   npx tsx probe-charh-calib.ts                # 全量汇总
 *   CHARH_FIX=on npx tsx probe-charh-calib.ts   # 修正分支生效后对比
 *   CHARH_PROJ=on npx tsx probe-charh-calib.ts  # P0-5a 投影分带生效后对比
 * 输出：verify-out/charh-calib.json
 */
import * as fs from 'fs'
import * as path from 'path'
import { estimateCharMetrics } from './src/image/image-layout'

const DIR = '/workspace/charh-calib'

interface Row {
  id: string
  W: number; H: number; F: number; variant: string
  medH: number; ratio: number
  workMedH: number; winOrig: number; winWork: number
  rowPitch: number; conf: number
  verdict: string
}

async function main() {
  const truth = JSON.parse(fs.readFileSync(path.join(DIR, 'truth.json'), 'utf8')) as Record<
    string, { W: number; H: number; F: number; variant: string }>
  const ids = Object.keys(truth).sort()
  const rows: Row[] = []
  const perFile = process.env.CHARH_VERBOSE === '1'

  for (const id of ids) {
    const t = truth[id]
    const buf = fs.readFileSync(path.join(DIR, id + '.png'))
    const m = await estimateCharMetrics(buf)
    const ratio = m.medH / t.F
    const workMedH = m.medH * m.scale
    // P0-5c 证据：同一把尺在两个坐标系里给出的 Sauvola 窗口
    const winOrig = Math.min(64, Math.max(16, 2 * Math.round(m.medH)))
    const winWork = Math.min(64, Math.max(16, 2 * Math.round(workMedH)))
    const verdict = ratio > 1.6 ? 'FAIL' : ratio > 1.2 ? 'WARN' : 'PASS'
    rows.push({
      id, W: t.W, H: t.H, F: t.F, variant: t.variant,
      medH: +m.medH.toFixed(1), ratio: +ratio.toFixed(2),
      workMedH: +workMedH.toFixed(1), winOrig, winWork,
      rowPitch: +m.rowPitch.toFixed(1), conf: +m.confidence.toFixed(2),
      verdict,
    })
    if (perFile) console.log(`${id}  F=${t.F} medH=${m.medH.toFixed(1)} ratio=${ratio.toFixed(2)} ${verdict}`)
  }

  // 汇总：按 variant × 分辨率档
  const buckets = new Map<string, Row[]>()
  for (const r of rows) {
    const sizeBucket = r.H <= 1100 ? 'S(≤1100)' : r.H <= 1754 ? 'M(1754)' : r.H <= 2400 ? 'L(2400)' : 'XL(3508)'
    for (const k of [r.variant, sizeBucket, `${r.variant}|${sizeBucket}`]) {
      if (!buckets.has(k)) buckets.set(k, [])
      buckets.get(k)!.push(r)
    }
  }
  console.log('\n══ 字高标尺 · 合成真值标定 ══')
  console.log('桶\t张数\tratio中位\tratio p90\tratio最大\tPASS率\tFAIL数')
  const order = ['V0', 'V1', 'V2', 'V3', 'S(≤1100)', 'M(1754)', 'L(2400)', 'XL(3508)']
  for (const k of [...order, ...[...buckets.keys()].filter((x) => x.includes('|'))]) {
    const rs = buckets.get(k)
    if (!rs) continue
    const rsSorted = rs.map((r) => r.ratio).sort((a, b) => a - b)
    const med = rsSorted[rsSorted.length >> 1]
    const p90 = rsSorted[Math.min(rsSorted.length - 1, Math.floor(rsSorted.length * 0.9))]
    const pass = rs.filter((r) => r.verdict === 'PASS').length
    const fail = rs.filter((r) => r.verdict === 'FAIL').length
    console.log(`${k}\t${rs.length}\t${med}\t${p90}\t${Math.max(...rsSorted)}\t${(pass / rs.length * 100).toFixed(0)}%\t${fail}`)
  }

  const failRows = rows.filter((r) => r.verdict === 'FAIL')
  console.log(`\nGUARD ${JSON.stringify({
    pass: failRows.length === 0,
    checked: rows.length,
    fail: failRows.length,
    failIds: failRows.slice(0, 12).map((r) => `${r.id}(r=${r.ratio})`),
  })}`)
  fs.mkdirSync('verify-out', { recursive: true })
  fs.writeFileSync('verify-out/charh-calib.json', JSON.stringify(rows, null, 1))
}
main().catch((e) => { console.error(e); process.exit(1) })
