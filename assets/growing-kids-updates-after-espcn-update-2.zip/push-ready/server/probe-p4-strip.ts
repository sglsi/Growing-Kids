/**
 * probe-p4-strip.ts —— 图形域剥离**为什么失效**的逐步取证
 * ==========================================================================
 * 事实：annot1/2/3/4 的图形块数 = 4 / 2 / 0 / 1（nGraphics），而真插图有 16 个框，
 *      其中 9~11 个被词级通道当做手写擦掉。⇒ **"图形域优先剥离"这道防线基本没起作用**。
 *
 * 本探针把剥离链路拆成四步，逐步问"卡在哪一步"：
 *   S1 RLSA 多尺度合并后，是否存在覆盖插图框主体的**合并块**？（没有 ⇒ 合并尺度不足）
 *   S2 命中块的几何尺寸是否达到 bigArea 闸门？（没达到 ⇒ 闸门阈值不对）
 *   S3 达到闸门的块是否被**文本段落豁免**（regionBands）放行？（是 ⇒ 豁免条件过宽）
 *   S4 若前三项都过，为什么最终仍没进 graphics？
 *
 * ⚠️ 只读版面，不读标注做判定；GT 插图框仅用于**定位观察对象**（观察什么，不是改什么）。
 *
 * 用法：npx tsx probe-p4-strip.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords, blockStats, estimateCharH, regionBands, dilateRect } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']
const G_W_K = 2.0, G_H_K = 4.0, G_AREA_K = 8.0
const RLSA_H_K = 1.2, RLSA_V_K = 0.3, RLSA_FINE_K = 0.3
const TEXT_BANDS_MIN = 2, TEXT_BAND_SP_MAX = 4.0, TEXT_BAND_CV_HI = 0.50

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

/** 8 邻域连通域 */
function comps8(bin: Uint8Array, w: number, h: number) {
  const lab = new Int32Array(w * h).fill(-1)
  const out: Array<{ x0: number; y0: number; x1: number; y1: number; n: number }> = []
  const stack: number[] = []
  for (let i = 0; i < w * h; i++) {
    if (!bin[i] || lab[i] >= 0) continue
    const id = out.length
    let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1, n = 0
    stack.push(i); lab[i] = id
    while (stack.length) {
      const p = stack.pop()!
      const py = (p / w) | 0, px = p % w
      n++
      if (px < x0) x0 = px; if (px > x1) x1 = px
      if (py < y0) y0 = py; if (py > y1) y1 = py
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const ny = py + dy, nx = px + dx
        if (ny < 0 || nx < 0 || ny >= h || nx >= w) continue
        const q = ny * w + nx
        if (bin[q] && lab[q] < 0) { lab[q] = id; stack.push(q) }
      }
    }
    out.push({ x0, y0, x1, y1, n })
  }
  return out
}

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const rowsOut: unknown[] = []

  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
    const { w, h, ink } = ctx.work
    const s = W / w                        // work → 原图
    const ch = estimateCharH(ink, w, h)
    const wres = discriminateWords({ ctx })
    console.log(`\n══════ ${f}  charH=${ch}  nGraphics=${wres.debug.nGraphics} ══════`)

    const scales: Array<{ name: string; dh: number; dv: number }> = [
      { name: 'fine', dh: Math.max(2, Math.round(RLSA_FINE_K * ch)), dv: Math.max(2, Math.round(RLSA_FINE_K * ch)) },
      { name: 'coarse', dh: Math.max(3, Math.round(RLSA_H_K * ch)), dv: Math.max(3, Math.round(RLSA_V_K * ch)) },
    ]

    for (const b of gt[f].filter((x) => x.cls === 'illustration')) {
      // 框 → work 坐标
      const bx0 = Math.max(0, Math.round(b.x0 / s)), bx1 = Math.min(w - 1, Math.round(b.x1 / s))
      const by0 = Math.max(0, Math.round(b.y0 / s)), by1 = Math.min(h - 1, Math.round(b.y1 / s))
      const areaBox = (bx1 - bx0 + 1) * (by1 - by0 + 1)
      console.log(`\n  [插图框] (${b.x0},${b.y0})-(${b.x1},${b.y1}) → work ${bx1 - bx0 + 1}x${by1 - by0 + 1}`)
      for (const sc of scales) {
        const merged = dilateRect(ink, w, h, sc.dh, sc.dv)
        const cs = comps8(merged, w, h).filter((c) => c.n >= 4)
        // S1：找与插图框相交最大的合并块，算覆盖率
        let best: { c: typeof cs[0]; inter: number; cover: number } | null = null
        for (const c of cs) {
          const ix0 = Math.max(c.x0, bx0), ix1 = Math.min(c.x1, bx1)
          const iy0 = Math.max(c.y0, by0), iy1 = Math.min(c.y1, by1)
          if (ix1 < ix0 || iy1 < iy0) continue
          const inter = (ix1 - ix0 + 1) * (iy1 - iy0 + 1)
          const cover = inter / areaBox
          if (!best || cover > best.cover) best = { c, inter, cover }
        }
        if (!best) { console.log(`    ${sc.name}(dh=${sc.dh},dv=${sc.dv}) 无相交合并块`); continue }
        const c = best.c
        const bw = c.x1 - c.x0 + 1, bh = c.y1 - c.y0 + 1
        const bigArea = bw >= G_W_K * ch && bh >= G_H_K * ch && bw * bh >= G_AREA_K * ch * ch
        const bands = regionBands(c, ink, w, ch)
        const exempt = bands.n >= TEXT_BANDS_MIN && bands.medSpacing >= 0.8 * ch &&
          bands.medSpacing <= TEXT_BAND_SP_MAX * ch && bands.spacingCV <= TEXT_BAND_CV_HI
        const st = blockStats(c, ink, w, h, ch)
        console.log(`    ${sc.name.padEnd(6)} 覆盖=${(best.cover * 100).toFixed(0)}%  块 ${bw}x${bh} (${(bw / ch).toFixed(1)}x${(bh / ch).toFixed(1)}charH)` +
          `  bigArea=${bigArea ? '✓' : '✗'} density=${st.density.toFixed(2)} iso=${st.isoRatio.toFixed(2)} maxRun=${st.maxRun}`)
        console.log(`           bands n=${bands.n} medSpacing=${bands.medSpacing.toFixed(1)}(${(bands.medSpacing / ch).toFixed(2)}charH) spacingCV=${bands.spacingCV.toFixed(2)}  豁免=${exempt ? '★被放行★' : '否'}`)
        rowsOut.push({
          file: f, box: [b.x0, b.y0, b.x1, b.y1], scale: sc.name, cover: +best.cover.toFixed(3),
          bw, bh, bwK: +(bw / ch).toFixed(2), bhK: +(bh / ch).toFixed(2), bigArea, exempt,
          bands: { n: bands.n, medSpacingK: +(bands.medSpacing / ch).toFixed(2), spacingCV: +bands.spacingCV.toFixed(2) },
          density: +st.density.toFixed(3), isoRatio: +st.isoRatio.toFixed(3),
        })
      }
    }
  }
  fs.writeFileSync('verify-out/p4-strip.json', JSON.stringify(rowsOut, null, 2))
  console.log('\n→ verify-out/p4-strip.json')
}
main().catch((e) => { console.error(e); process.exit(1) })
