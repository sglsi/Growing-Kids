import * as fs from 'fs'
import { estimateCharMetrics } from './src/image/image-layout'
async function main() {
  for (const f of ['/workspace/wrongq-test/page28.png','/workspace/wrongq-test/page31.png','/workspace/worksheet-test/annotated/annot1.png']) {
    const m = await estimateCharMetrics(fs.readFileSync(f))
    console.log(f.split('/').pop().padEnd(14), 'medH='+m.medH.toFixed(1), 'bands='+(m.bandCount??0), 'bandH='+(m.charHBand??0).toFixed(1), 'uMode='+(m.charHUMode??0).toFixed(1), 'rowPitch='+m.rowPitch.toFixed(1), 'rowCount='+m.rowCount)
  }
}
main()
