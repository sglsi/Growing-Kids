#!/usr/bin/env python3
"""
gen-charh-calib.py —— P0-5d 字高标尺合成标定集生成器
=====================================================
为什么必须有它：
  P0-5 的战场是「字高标尺」——Sauvola 窗口=2×charH、红笔膨胀半径=k_r×medH、
  背景归一化结构元=SE_SCALE×medH/2、行切分间隙=charH×1.2 …… 全部以它为分母。
  但此前**没有任何一张图的真值字高是已知的**，所有"修正"只能在三条互相打架的
  估计口径之间投票选边 —— 这是"用估计验证估计"，无法证伪。

  本脚本生成**字高已知**的合成页（渲染字号 F 即真值字身），覆盖四类真实故障：
    V0 纯印刷单栏         —— 基线，验证标尺无偏
    V1 印刷 + 手写大块     —— 复现"少数连笔大块抬高高度中位数"
    V2 双栏印刷            —— 复现行聚类按质心间隙切行失效（跨栏并组）
    V3 印刷 + 插图/公式块   —— 复现纵向大块干扰
  并叠加分辨率维度（同一版面渲染到 4 种尺寸），用于暴露 P0-5c 的坐标系 bug
  （medH 是原图尺度，却被当 work 尺度去算 Sauvola 窗口 → 窗口虚大 1/scale 倍）。

输出： /workspace/charh-calib/<id>.png  +  truth.json（id → 真值字高 F）
"""
import json, os, random
from PIL import Image, ImageDraw, ImageFont

OUT = "/workspace/charh-calib"
os.makedirs(OUT, exist_ok=True)

SERIF = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc"
SANS = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"

# 物理卷语料：印刷题干风格
POOL = (
    "如图所示电路中电源电压保持不变闭合开关后滑动变阻器的滑片向右移动时"
    "电流表的示数将如何变化电压表的示数将如何变化请说明理由并写出计算过程"
    "已知物体质量为二千克在水平拉力作用下沿水平面做匀速直线运动受到的摩擦力"
    "大小为物重的零点二倍求拉力的大小和物体在十秒内通过的距离重力加速度取"
    "下列现象中属于光的折射的是水中倒影筷子弯折镜中成像影子的形成"
    "甲乙两车同时从两地相向而行甲车速度为六十千米每小时乙车速度为四十千米"
    "每小时两地相距二百千米问几小时后两车相遇相遇点距甲地多远"
    "在探究凸透镜成像规律的实验中当烛焰距凸透镜十五厘米时在光屏上得到一个"
    "倒立放大的实像则该凸透镜的焦距可能是多少厘米请写出判断依据"
)

LATIN = (
    "The quick brown fox jumps over the lazy dog while the angular momentum "
    "of the rotating body remains constant under zero external torque so that "
    "the moment of inertia decreases as the radius shrinks and spin rate rises "
)

random.seed(20261006)


def load_font(path, size):
    try:
        return ImageFont.truetype(path, size, index=0)
    except Exception:
        return ImageFont.truetype(path, size)


def wrap(draw, text, font, max_w):
    """按像素宽度折行（中英混排：逐字累加）"""
    lines, cur = [], ""
    for ch in text:
        t = cur + ch
        if draw.textlength(t, font=font) > max_w and cur:
            lines.append(cur)
            cur = ch
        else:
            cur = t
    if cur:
        lines.append(cur)
    return lines


def scribble(draw, x0, y0, x1, y1, width, rng, dark=0):
    """模拟手写连笔：随机折线，笔画偏粗 → 闭合后连成大块（V1 的故障成因）"""
    n = rng.randint(3, 7)
    xs = [rng.uniform(x0, x1) for _ in range(n)]
    ys = [rng.uniform(y0, y1) for _ in range(n)]
    pts = list(zip(xs, ys))
    draw.line(pts, fill=dark, width=width, joint="curve")
    # 再叠一条，制造交叉粘连
    if rng.random() < 0.6:
        xs2 = [rng.uniform(x0, x1) for _ in range(3)]
        ys2 = [rng.uniform(y0, y1) for _ in range(3)]
        draw.line(list(zip(xs2, ys2)), fill=dark, width=width, joint="curve")


def make_page(W, H, F, variant, rng):
    img = Image.new("L", (W, H), 255)
    d = ImageDraw.Draw(img)
    font = load_font(SERIF if variant != "V3" else SANS, F)

    margin = int(min(W, H) * 0.08)
    line_gap = int(round(F * 1.7))          # 中文 1.5~1.8 倍行距
    cols = 2 if variant == "V2" else 1
    col_w = (W - margin * 2 - (30 if cols == 2 else 0)) // cols

    # ── 印刷正文 ──
    y = margin
    for ci in range(cols):
        cx = margin + ci * (col_w + 30)
        yy = margin
        src = (POOL + LATIN) if ci == 0 else POOL
        off = rng.randint(0, 50)
        while yy < H - margin - line_gap:
            chunk = src[off: off + rng.randint(28, 46)]
            off += len(chunk)
            if off > len(src) - 60:
                off = 0
            for ln in wrap(d, chunk, font, col_w):
                if yy > H - margin - line_gap:
                    break
                d.text((cx, yy), ln, font=font, fill=0)
                yy += line_gap
            yy += int(line_gap * 0.4)        # 段落间距
        y = max(y, yy)

    # ── V3：插图 / 公式块（纵向大块）──
    if variant == "V3":
        for _ in range(3):
            bx = rng.randint(margin, max(margin + 1, W - margin - int(W * 0.25)))
            by = rng.randint(margin, max(margin + 1, H - margin - int(H * 0.18)))
            bw = int(W * rng.uniform(0.12, 0.22))
            bh = int(H * rng.uniform(0.06, 0.12))
            d.rectangle([bx, by, bx + bw, by + bh], outline=0, width=max(2, F // 12))
            d.line([bx, by + bh // 2, bx + bw, by + bh // 2], fill=0, width=max(2, F // 14))

    # ── V1：手写墨迹（连笔大块）──
    if variant == "V1":
        hw = max(2, int(round(F * 0.35)))    # 手写笔画更粗
        for _ in range(int(18 * (F / 20 + 0.5))):
            x0 = rng.randint(margin, W - margin - 60)
            y0 = rng.randint(margin, H - margin - 40)
            scribble(d, x0, y0, x0 + rng.randint(50, 160), y0 + rng.randint(30, 90), hw, rng)

    return img


def main():
    truth = {}
    # (宽, 高, 字号F) —— 字号跨 9~48px，页面跨 800~3000px（覆盖 scale<1 的降采样场景）
    combos = []
    for (W, H) in [(800, 1100), (1240, 1754), (1700, 2400), (2480, 3508)]:
        base = H / 1100.0
        for F in (9, 12, 16, 22, 30, 42):
            combos.append((W, H, max(9, int(round(F * base)))))
    for (W, H, F) in combos:
        for variant in ("V0", "V1", "V2", "V3"):
            rng = random.Random(hash((W, H, F, variant)) & 0xFFFFFFFF)
            img = make_page(W, H, F, variant, rng)
            pid = f"calib_{W}x{H}_F{F}_{variant}"
            img.save(os.path.join(OUT, pid + ".png"))
            truth[pid] = {"W": W, "H": H, "F": F, "variant": variant}
    with open(os.path.join(OUT, "truth.json"), "w") as f:
        json.dump(truth, f, ensure_ascii=False, indent=1)
    print(f"生成 {len(truth)} 张标定图 → {OUT}")


if __name__ == "__main__":
    main()
