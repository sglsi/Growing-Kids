/**
 * probe-p4-score.ts —— 词级 score 在三类真值上的**分布实测**
 * ==========================================================================
 * 上一步（probe-p4-feature）已证：**CC 级特征在"插图碎片 vs 手写笔画"上不可分**
 *   h/charH 插图 p50=0.64 p90=4.55 | 手写 p50=0.92 p90=1.64 —— 中位重叠，密度反而插图更高。
 *   → 说明"这个 CC 是不是字符"这个问题在 CC 级无解，硬设阈值就是打补丁，此路不通。
 *
 * 本探针退到**词级**看：判别器实际输出的 word.score 在
 *   ① 手写 GT 框内的词 / ② 插图 GT 框内的词 / ③ 框外的词（≈印刷）
 * 三类上是何分布？回答两个问题：
 *   Q1 现在的绝对分数到底有没有区分力？
 *   Q2 "相对页面主群做离群判定"（ENS/相对 z）能不能拉开？
 *
 * ⚠️ GT 协议：只用于**判定现有机制是否可用**，不用于调阈值。
 *
 * 用法：npx tsx probe-p4-score.ts
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildDocContext } from './src/image/adaptive-stats'
import { discriminateWords } from './src/image/word-level-discriminator'

const DIR = '/workspace/worksheet-test/annotated'
const PAGES = ['annot1.png', 'annot2.png', 'annot3.png', 'annot4.png']

interface Box { x0: number; y0: number; x1: number; y1: number; cls: string }

function q(a: number[], p: number): number {
  if (!a.length) return 0
  const s = a.slice().sort((x, y) => x - y)
  return s[Math.min(s.length - 1, Math.max(0, Math.floor(p * (s.length - 1))))]
}
function fmt(a: number[]): string {
  if (!a.length) return 'n=0'
  return `n=${String(a.length).padStart(4)} p10=${q(a, 0.1).toFixed(2)} p25=${q(a, 0.25).toFixed(2)} p50=${q(a, 0.5).toFixed(2)} p75=${q(a, 0.75).toFixed(2)} p90=${q(a, 0.9).toFixed(2)}`
}

async function main() {
  const gt: Record<string, Box[]> = JSON.parse(fs.readFileSync(`${DIR}/gt.json`, 'utf8'))
  const allHw: number[] = [], allIl: number[] = [], allPr: number[] = []
  const rowsOut: unknown[] = []
  const FEAT = ['heightCV', 'strokeCV', 'strokeDev', 'baseDev', 'ascDev', 'spacingCV', 'intensityStd'] as const

  for (const f of PAGES) {
    const srcBuf = await sharp(`${DIR}/${f.replace('.png', '-clean.png')}`).png().toBuffer()
    const meta = await sharp(srcBuf).metadata()
    const W = meta.width!, H = meta.height!
    const ctx = await buildDocContext(srcBuf, { width: W, height: H, isGray: false })
    const wres = discriminateWords({ ctx })
    const s = W / ctx.work.w

    const hwN: number[] = [], ilN: number[] = [], prN: number[] = []
    const hwF: number[][] = FEAT.map(() => []), ilF: number[][] = FEAT.map(() => []), prF: number[][] = FEAT.map(() => [])
    const recs: Array<{ cls: string; score: number; nComp: number; h: number; w: number }> = []

    for (const wd of wres.words) {
      const cx = Math.round(((wd.x0 + wd.x1) / 2) * s), cy = Math.round(((wd.y0 + wd.y1) / 2) * s)
      const ilHit = gt[f].some((b) => b.cls === 'illustration' && cx >= b.x0 && cx <= b.x1 && cy >= b.y0 && cy <= b.y1)
      const hwHit = !ilHit && gt[f].some((b) => b.cls === 'handwriting' && cx >= b.x0 && cx <= b.x1 && cy >= b.y0 && cy <= b.y1)
      const cls = ilHit ? 'il' : hwHit ? 'hw' : 'pr'
      const tgt = cls === 'il' ? ilN : cls === 'hw' ? hwN : prN
      tgt.push(wd.score)
      const tf = cls === 'il' ? ilF : cls === 'hw' ? hwF : prF
      FEAT.forEach((k, i) => tf[i].push(wd.f[k]))
      recs.push({ cls, score: +wd.score.toFixed(3), nComp: wd.nComp, h: wd.y1 - wd.y0 + 1, w: wd.x1 - wd.x0 + 1 })
    }
    allHw.push(...hwN); allIl.push(...ilN); allPr.push(...prN)

    console.log(`\n════ ${f}  charH=${wres.debug.charH} nGraphics=${wres.debug.nGraphics} nWords=${wres.words.length} ════`)
    console.log(`  手写词 ${fmt(hwN)}`)
    console.log(`  插图词 ${fmt(ilN)}`)
    console.log(`  印刷词 ${fmt(prN)}`)
    // 分特征的相对位置（印刷作为参考群）
    console.log(`  —— 各特征：手写/插图 p50 相对印刷 p50 的倍数 ——`)
    for (let i = 0; i < FEAT.length; i++) {
      const p = q(prF[i], 0.5), hh = q(hwF[i], 0.5), ii = q(ilF[i], 0.5)
      const r = (v: number) => (Math.abs(p) < 1e-9 ? (v < 1e-9 ? '0' : '∞') : (v / p).toFixed(1))
      console.log(`    ${FEAT[i].padEnd(13)} 印刷p50=${p.toFixed(3).padStart(7)}  手写/印刷=${r(hh).padStart(6)}  插图/印刷=${r(ii).padStart(6)}`)
    }
    rowsOut.push({ file: f, charH: wres.debug.charH, nGraphics: wres.debug.nGraphics, recs })
  }

  console.log('\n══════ 全集合并 ══════')
  console.log(`  手写词 ${fmt(allHw)}`)
  console.log(`  插图词 ${fmt(allIl)}`)
  console.log(`  印刷词 ${fmt(allPr)}`)

  // 现有多个阈值的精度/召回（**仅看机制有没有区分力**，不是最终选型依据）
  console.log('\n  —— 现有绝对阈值的表现（诊断用，非选型）——')
  for (const t of [0.30, 0.35, 0.45, 0.50, 0.55, 0.60]) {
    const hit = (a: number[]) => a.filter((v) => v >= t).length
    console.log(`    τ=${t.toFixed(2)}  手写召回 ${hit(allHw)}/${allHw.length}  插图误标 ${hit(allIl)}/${allIl.length}  印刷误标 ${hit(allPr)}/${allPr.length}`)
  }
  fs.writeFileSync('verify-out/p4-score.json', JSON.stringify({ perPage: rowsOut }, null, 2))
  console.log('\n→ verify-out/p4-score.json')
}
main().catch((e) => { console.error(e); process.exit(1) })
