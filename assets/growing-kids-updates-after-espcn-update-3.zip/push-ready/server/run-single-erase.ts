/**
 * 单图去手写运行器 —— 完全复刻生产 image.service.eraseV2 默认（word 策略）链路：
 *   buildHandwritingMask(hybrid, 禁VLM) → buildEraseMask(word) → inpaint('adaptive') → blendWithMask
 * 用法：npx tsx run-single-erase.ts <输入图> <输出目录>
 */
import sharp from 'sharp'
import * as fs from 'fs'
import { buildHandwritingMask } from './src/image/handwriting-segmenter'
import { buildEraseMask } from './src/image/erase-mask-policy'
import { inpaint, blendWithMask, unmodifiedRegionSimilarity } from './src/image/handwriting-mask'

const SRC = process.argv[2]
const OUTDIR = process.argv[3] || '/workspace/去手写-结果-语文002小卷'

async function main() {
  fs.mkdirSync(OUTDIR, { recursive: true })
  const srcBuffer = await sharp(SRC).rotate().png().toBuffer()
  const meta = await sharp(srcBuffer).metadata()
  const W = meta.width!, H = meta.height!
  console.log(`输入 ${W}x${H}`)

  // ① 分割（生产默认 hybrid 基础 mask；沙箱无 VLM 凭证 → allowVlm:false 即生产降级路径）
  const seg = await buildHandwritingMask(srcBuffer, '', {}, { allowVlm: false, eraseMode: 'hybrid' })
  let mask = seg.mask
  console.log(`基础 mask source=${seg.mask.source ?? '-'} coverage=${(mask.coverage * 100).toFixed(2)}%`)

  // ①-extra OCR 框先验（实验）：调本地 OCR 侧车拿文字框坐标（不画框、不改原图），
  // 只把"落在 OCR 文字框内且本身是深墨"的像素抬为去手写候选，并入基础 mask。
  if (process.env.OCR_PRIOR === '1') {
    const { buildOcrPriorMask } = await import('./src/image/ocr-prior')
    const ocr = await buildOcrPriorMask(srcBuffer)
    if (ocr) {
      const n = W * H
      let added = 0
      for (let i = 0; i < n; i++) {
        if (ocr.prior[i] > 127 && mask.data[i] <= 127) { mask.data[i] = ocr.prior[i]; added++ }
      }
      mask.coverage = (mask.data.reduce((s, v) => s + (v > 127 ? 1 : 0), 0)) / n
      console.log(`[ocr-prior] 并入候选 +${(added / n * 100).toFixed(2)}% → 基础 coverage=${(mask.coverage * 100).toFixed(2)}%`)
      fs.writeFileSync(`${OUTDIR}/ocr-boxes.json`, JSON.stringify(ocr.boxes, null, 2))
      // 先验可视化（绿色半透明叠加：候选像素）
      const base2 = await sharp(srcBuffer).removeAlpha().raw().toBuffer()
      const vis2 = Buffer.from(base2)
      for (let i = 0; i < n; i++) {
        if (ocr.prior[i] <= 127) continue
        const p = i * 3
        vis2[p] = Math.round(vis2[p] * 0.5 + 40)
        vis2[p + 1] = Math.round(vis2[p + 1] * 0.5 + 200)
        vis2[p + 2] = Math.round(vis2[p + 2] * 0.5 + 40)
      }
      await sharp(vis2, { raw: { width: W, height: H, channels: 3 } }).png().toFile(`${OUTDIR}/ocr-prior-vis.png`)
    } else {
      console.log('[ocr-prior] 侧车无有效框，走原链路')
    }
  }

  // ② 策略：ERASE_POLICY=word(默认,只擦确信手写)/union_generic/union(基础hybrid)
  const policyEnv = (process.env.ERASE_POLICY || 'word') as 'word' | 'union_generic' | 'union'
  let policyUsed = policyEnv
  try {
    if (policyEnv === 'union') {
      mask = seg.mask // 生产 erase_mode='union' → 不做合成，直接用基础 mask
    } else {
      mask = await buildEraseMask(srcBuffer, mask, policyEnv)
    }
    console.log(`${policyEnv} 合成后 coverage=${(mask.coverage * 100).toFixed(2)}%`)
  } catch (e) {
    console.warn(`${policyEnv} 策略失败，降级基础 mask：${String(e)}`)
    mask = seg.mask
    policyUsed = 'hybrid(降级)'
  }

  if (mask.coverage <= 0.0001) {
    console.log('未检测到手写，原样返回')
    fs.copyFileSync(SRC, `${OUTDIR}/result.png`)
    return
  }
  if (mask.coverage > 0.7) {
    console.log(`coverage=${(mask.coverage * 100).toFixed(1)}% > 70%，生产会中止；此处仍输出但请人工复核`)
  }

  // ③ 修复 + 混合（生产链路）
  const inpainted = await inpaint(srcBuffer, 'adaptive', mask)
  const merged = await blendWithMask(srcBuffer, inpainted, mask)

  // ④ 护栏：非 mask 区一致性
  const sim = await unmodifiedRegionSimilarity(srcBuffer, merged, mask)
  console.log(`非 mask 区一致性 = ${(sim.similarity * 100).toFixed(2)}% ${sim.similarity > 0.999 ? '✅' : '❌'}`)

  await sharp(merged).png().toFile(`${OUTDIR}/result.png`)
  await sharp(srcBuffer).png().toFile(`${OUTDIR}/original.png`)

  // mask 可视化（红色半透明）
  const base = await sharp(srcBuffer).removeAlpha().raw().toBuffer()
  const vis = Buffer.from(base)
  for (let i = 0; i < W * H; i++) {
    const a = mask.data[i]
    if (a <= 8) continue
    const p = i * 3
    vis[p] = Math.round(vis[p] * (1 - a / 255) + 255 * (a / 255) * 0.55)
    vis[p + 1] = Math.round(vis[p + 1] * (1 - a / 255))
    vis[p + 2] = Math.round(vis[p + 2] * (1 - a / 255))
  }
  await sharp(vis, { raw: { width: W, height: H, channels: 3 } }).png().toFile(`${OUTDIR}/mask-vis.png`)

  // 左右对照图（等比缩到 1200 宽拼接）
  const CW = 1200
  const half = await sharp(srcBuffer).resize({ width: Math.floor(CW / 2) }).png().toBuffer()
  const halfM = await sharp(merged).resize({ width: Math.floor(CW / 2) }).png().toBuffer()
  const hMeta = await sharp(half).metadata()
  await sharp({ create: { width: CW, height: hMeta.height!, channels: 3, background: '#ffffff' } })
    .composite([{ input: half, left: 0, top: 0 }, { input: halfM, left: Math.floor(CW / 2), top: 0 }])
    .jpeg({ quality: 90 }).toFile(`${OUTDIR}/compare.jpg`)

  fs.writeFileSync(`${OUTDIR}/summary.json`, JSON.stringify({
    input: SRC, width: W, height: H,
    baseCoverage: +(seg.mask.coverage * 100).toFixed(2),
    finalCoverage: +(mask.coverage * 100).toFixed(2),
    policy: policyUsed,
    strategy: 'adaptive',
    unmaskedSimilarity: +(sim.similarity * 100).toFixed(2),
    note: '生产 eraseV2 默认 word 策略（沙箱降级路径，无 VLM）',
  }, null, 2))
  console.log(`已输出 ${OUTDIR}/result.png original.png mask-vis.png compare.jpg summary.json`)
}

main().catch((e) => { console.error(e); process.exit(1) })
