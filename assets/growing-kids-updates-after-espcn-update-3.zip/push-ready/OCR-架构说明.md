# OCR 架构说明（本地主识别 + VLM 语义切分/兜底）

> 适用版本：去手写项目当前 OCR 改造后
> 关联：`ocr-engine/`（侧车）、`server/src/ocr/`（Node 端）、`去手写-升级方向-低质量照片自适应.md`

## 1. 设计目标

文字识别从**纯远程 VLM（豆包 Seed 2.0 Pro）**改造为：

- **本地 OCR 引擎 = 主文字提取**：离线、可靠、零按次计费、确定性强（不依赖 token）。
- **VLM = 语义切分 + 兜底**：仅负责把本地 OCR 的文字+版面切成结构化题目；本地 OCR 整体失败时，VLM 直接看图。

这样即使 VLM 凭证缺失/宕机，系统仍能**离线产出文字**（前端可编辑），不会硬失败。

## 2. 引擎选型（已与用户确认）

| 角色 | 引擎 | 说明 |
|---|---|---|
| 主识别 · 互为备份 A | **RapidOCR**（ONNX） | CPU 友好、快、依赖轻（~15MB，无 paddle） |
| 主识别 · 互为备份 B | **PaddleOCR 3.0** | PP-OCRv5（中文印刷+复杂手写）+ PP-StructureV3（版面/表格/公式→LaTeX） |
| 语义切分 / 兜底 | **豆包 Seed 2.0 Pro** | 经 `coze-coding-dev-sdk` 的 `LLMClient`，`temperature=0.1` |

双本地引擎**同时运行、按置信度择优融合**（IoU>0.5 去重，保留高分），任一引擎失败不影响另一条。

## 3. 架构图

```
[前端 /ocr/*] → OcrController → OcrService
   ├─① LocalOcrClient (HTTP → OCR_ENGINE_URL 侧车, 平台单独部署)
   │     Sidecar(Python): RapidOCR ∥ PaddleOCR+PP-StructureV3 → 融合
   │     输出 {raw_text, text_regions[], layout[], tables[], formulas[], confidence, engine_used, low_confidence}
   ├─② 本地 OCR 成功(且非低置信) → 把 {raw_text, layout} 喂 VLM 做语义切分 → RecognizedItem[]
   └─③ 本地 OCR 失败/低置信 → VLM 直接看图(现有逻辑) → RecognizedItem[]
   （VLM 也不可用 → 退化为本地纯文字 item，前端可编辑，不硬失败）
```

一致性校验（`image.service.verifyOcrConsistency`）专用 `OcrService.recognizeRawItems`：
直接返回本地 OCR **原始文字区域**作为可比对题面（不经 VLM 重构，稳定可复现），VLM 仅兜底。

## 4. 输出契约（侧车 ↔ Node）

`ocr-engine/main.py` 的 `POST /recognize` 返回（见 `server/src/ocr/ocr.types.ts` 的 `LocalOcrResult`）：

```json
{
  "raw_text": "按阅读顺序拼接的全文",
  "text_regions": [{"text":"...","box":[x0,y0,x1,y1],"score":0.97}],
  "layout": [{"type":"text","box":[...],"text":""}],
  "tables": [], "formulas": [],
  "confidence": 0.95,
  "engine_used": ["rapidocr","paddleocr"],
  "low_confidence": false
}
```

Node 端 `LocalOcrClient`（`ocr-engine.client.ts`）：内置 `fetch` 调用，**任何失败返回 `null` 不抛错**，交由 `OcrService` 降级到 VLM。

## 5. 关键配置（环境变量，全 `process.env` 直读）

| 变量 | 默认 | 说明 |
|---|---|---|
| `OCR_ENGINE_URL` | `http://127.0.0.1:9000` | 本地侧车地址（Node 端） |
| `OCR_FALLBACK_TO_VLM` | `true` | 关掉则完全不用本地 OCR，退回纯 VLM |
| `OCR_LOW_CONF_THRESHOLD` | `0.6` | 低于则 `low_confidence=true` → 走 VLM 直接看图 |
| `OCR_ENGINE_MODE` | `both` | 侧车侧：`both`/`rapid`/`paddle` |
| `OCR_DEVICE` | `cpu` | 侧车侧：`cpu`/`gpu` |
| `OCR_DRY_RUN` | `0` | 侧车侧：不加载模型返回样例（契约验证） |
| `COZE_API_TOKEN` | — | VLM 凭证（由 coze-coding-dev-sdk 隐式消费） |

## 6. 部署形态

- **侧车独立部署**：`ocr-engine/` 作为独立进程（Dockerfile 已备），平台单独起；Node 单进程不变。
- **模型权重**：首次启动下载 PaddleOCR / RapidOCR 权重（需出网或预置 `MODEL_DIR`）；CPU 用 mobile 档。
- **降级链**：侧车宕机 → `LocalOcrClient` 返回 null → VLM 直接看图；VLM 无凭证 → 本地纯文字退化。

## 7. 已知边界（与升级方向关联）

- 本地 OCR 在**模糊/斜拍/低清照片**上同样会退化（与去手写是同一道坎），无魔法；真正根治见 `去手写-升级方向-低质量照片自适应.md`。
- VLM 仍是**语义切分**主力（用户已确认），故"纯离线出题"在 VLM 不可用时退化为纯文字，需用户手动归题。
- 双引擎融合初版用"置信度择优 + 版面块合并"，需真实作业样本调参。
- **真实中文/手写/表格精度**须在部署环境（有模型+token+真实图）实测作为验收门槛；沙箱 CPU 无 token 无法验证精度。

## 8. 沙箱实测记录（2026-10，真实运行）

本轮在沙箱内完成了**可本地验证的全部环节**，把架构从"mock 验证"推进到"真实运行"：

### 8.1 实测内容与结果

| 验证项 | 结果 | 说明 |
|---|---|---|
| RapidOCR 安装与导入 | ✅ | `rapidocr-onnxruntime`（包内自带 ONNX 模型，CPU 可跑） |
| 侧车 real 模式 | ✅ | `OCR_ENGINE_MODE=rapid`，PaddleOCR 缺席时自动跳过、不报错 |
| 清晰扫描件识别 | ✅ | `annot1-clean.png`：49 区、置信 **0.966**，"九年级物理练习卷"全文正确 |
| 低质量照片识别 | ✅ | 实拍语文卷（1080px 斜拍偏暗）：74 区、置信 **0.924**，印刷体表头/题干/表格全出 |
| Node↔Python 端到端 | ✅ | `LocalOcrClient.recognizeByBase64` → 侧车 → RapidOCR → 结构化 JSON，真实数据打通 |
| OcrService 生产路径降级 | ✅ | 集成测试 `INTEGRATION_PASS`：本地成功→VLM 失败(无 token)→**降级纯文字 9 items，未崩溃** |
| 类型检查 | ✅ | 改动的 4 个 TS 文件 0 错误（工程存量 28 个错误均在 probe/diag 调试脚本，与本次无关） |

### 8.2 实测中发现并修复的问题

1. **RapidOCR 新版返回结构变更**：新版返回 2-tuple `( [[box,text,score],...], meta )`，非旧版 3-tuple
   —— `_run_rapid` 已重写为三格式兼容（新 2-tuple / 旧 3-tuple / 对象式）。
2. **`OcrService` 构造期强依赖 VLM 凭证**：原构造函数立即 `new LLMClient()`，无 token 直接抛错，
   连"本地 OCR 主路径"都无法实例化 —— 已改为**懒加载** `getVlm()`（本地优先不因缺凭证而崩溃）。
3. **客户端默认 15s 超时会误杀本地 OCR**：CPU 推理实测单页 **~27s**（沙箱受限 CPU + 大图），
   15s 超时导致本地 OCR 被误判失败 —— 默认放宽至 **60s**，支持 `OCR_TIMEOUT_MS` 覆盖。

### 8.3 关键实测数据

- **CPU 单页延迟 ~27s**（清晰扫描件，沙箱受限 CPU）；侧车常驻后仍 ~26-29s/页 ——
  部署时建议 GPU 或缩小输入尺寸，并把 `OCR_TIMEOUT_MS` 设为 ≥60s。
- 本地 OCR 对**低质量照片的印刷文字**抽取稳健（conf 0.924）—— 与去手写在低质量照片上失效
  形成对照：OCR 只需"读字"，去手写需要"分离手写与印刷"，后者难度本质更高。

### 8.4 沙箱仍无法验证（需部署环境）

- PaddleOCR 3.0 重模型（paddlepaddle 安装体积大）→ 融合双引擎、版面/表格/公式能力未实测。
- VLM 语义切分质量（无 `COZE_API_TOKEN`）→ 7 字段切分准确率需部署环境评估。
- 大样本精度基准（准确率/召回）→ 需真实作业图集。
